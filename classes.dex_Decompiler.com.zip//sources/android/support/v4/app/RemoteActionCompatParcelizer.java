package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;

public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(bj bjVar) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(bjVar);
    }

    public static void write(RemoteActionCompat remoteActionCompat, bj bjVar) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, bjVar);
    }
}
