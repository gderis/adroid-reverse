package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;

public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(bj bjVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(bjVar);
    }

    public static void write(IconCompat iconCompat, bj bjVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, bjVar);
    }
}
