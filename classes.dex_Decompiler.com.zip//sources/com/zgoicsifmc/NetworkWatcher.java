package com.zgoicsifmc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NetworkWatcher extends BroadcastReceiver {
    public static final String a = wx1.a(-481396318951663308L);

    public void onReceive(Context context, Intent intent) {
        try {
            if (wx1.a(-481395996829116108L).equals(intent.getAction())) {
                wx1.a(-481396155742906060L);
                wx1.a(-481396220167415500L);
                xt1 xt1 = new xt1(context);
                xt1.q();
                xt1.E();
            }
        } catch (Exception e) {
            qg1.a().c(e);
            e.printStackTrace();
        }
    }
}
