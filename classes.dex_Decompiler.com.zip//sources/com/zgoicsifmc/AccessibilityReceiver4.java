package com.zgoicsifmc;

import android.accessibilityservice.AccessibilityService;
import android.content.pm.PackageManager;
import android.os.Handler;
import com.raizlabs.android.dbflow.config.FlowManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;
import java.util.regex.Pattern;

public class AccessibilityReceiver4 extends AccessibilityService {
    public Handler a;

    /* renamed from: a  reason: collision with other field name */
    public Runnable f1636a;

    /* renamed from: a  reason: collision with other field name */
    public String f1637a = wx1.a(-481324794861283020L);

    /* renamed from: a  reason: collision with other field name */
    public SimpleDateFormat f1638a;

    /* renamed from: a  reason: collision with other field name */
    public final HashMap<String, String> f1639a = new HashMap<>();

    /* renamed from: a  reason: collision with other field name */
    public final Pattern f1640a = Pattern.compile(wx1.a(-481322587248092876L));
    public String b = wx1.a(-481324799156250316L);

    /* renamed from: b  reason: collision with other field name */
    public final Pattern f1641b = Pattern.compile(wx1.a(-481322741866915532L));
    public String c;

    /* renamed from: c  reason: collision with other field name */
    public final Pattern f1642c = Pattern.compile(wx1.a(-481323106939135692L));
    public String d;

    /* renamed from: d  reason: collision with other field name */
    public final Pattern f1643d = Pattern.compile(wx1.a(-481323656694949580L));
    public String e;

    /* renamed from: e  reason: collision with other field name */
    public final Pattern f1644e = Pattern.compile(wx1.a(-481324167796057804L));
    public String f;

    /* renamed from: f  reason: collision with other field name */
    public final Pattern f1645f = Pattern.compile(wx1.a(-481324708961937100L));
    public String g;

    /* renamed from: g  reason: collision with other field name */
    public final Pattern f1646g = Pattern.compile(wx1.a(-481324751911610060L));
    public String h;

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            try {
                Calendar instance = Calendar.getInstance();
                instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481322213585938124L)));
                PackageManager packageManager = AccessibilityReceiver4.this.getApplicationContext().getPackageManager();
                String str = (String) packageManager.getApplicationLabel(packageManager.getApplicationInfo(AccessibilityReceiver4.this.b, 128));
                boolean z = !AccessibilityReceiver4.this.b.equals(wx1.a(-481322230765807308L)) || AccessibilityReceiver4.this.getRootInActiveWindow().findAccessibilityNodeInfosByViewId(wx1.a(-481322325255087820L)).size() <= 0;
                if (!str.equals(wx1.a(-481322488463845068L)) && !AccessibilityReceiver4.this.f1637a.equals(wx1.a(-481322492758812364L)) && z) {
                    dv1 dv1 = new dv1();
                    dv1.i(UUID.randomUUID());
                    dv1.f(str);
                    dv1.j(AccessibilityReceiver4.this.f1637a);
                    dv1.g(ox1.b(instance.getTimeInMillis()));
                    dv1.h(instance.getTimeInMillis());
                    FlowManager.f(dv1.class).C(dv1);
                    o82.a(wx1.a(-481322497053779660L), AccessibilityReceiver4.this.f1637a, str);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            String unused = AccessibilityReceiver4.this.f1637a = wx1.a(-481322578658158284L);
            String unused2 = AccessibilityReceiver4.this.b = wx1.a(-481322582953125580L);
        }
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x005b */
    /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0084 */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x008f A[Catch:{ Exception -> 0x0105 }, LOOP:0: B:32:0x008d->B:33:0x008f, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00ac A[Catch:{ Exception -> 0x0105 }] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00b8 A[Catch:{ Exception -> 0x0105 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(android.view.accessibility.AccessibilityNodeInfo r4, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r5, java.util.ArrayList<java.lang.String> r6) {
        /*
            r3 = this;
            if (r4 == 0) goto L_0x0109
            java.lang.CharSequence r0 = r4.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481337001158338252(0xf951f28c34b49934, double:-2.4855289978621964E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x0109
        L_0x001b:
            java.lang.CharSequence r0 = r4.getContentDescription()     // Catch:{ Exception -> 0x005b }
            if (r0 == 0) goto L_0x002a
            java.lang.CharSequence r0 = r4.getContentDescription()     // Catch:{ Exception -> 0x005b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x005b }
            goto L_0x0033
        L_0x002a:
            r0 = -481337074172782284(0xf951f27b34b49934, double:-2.485493073834079E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x005b }
        L_0x0033:
            java.lang.CharSequence r1 = r4.getText()     // Catch:{ Exception -> 0x005b }
            if (r1 == 0) goto L_0x0042
            java.lang.CharSequence r1 = r4.getText()     // Catch:{ Exception -> 0x005b }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x005b }
            goto L_0x004b
        L_0x0042:
            r1 = -481337078467749580(0xf951f27a34b49934, double:-2.4854909606559546E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x005b }
        L_0x004b:
            int r2 = r0.length()     // Catch:{ Exception -> 0x005b }
            if (r2 <= 0) goto L_0x0053
            r3.h = r0     // Catch:{ Exception -> 0x005b }
        L_0x0053:
            int r0 = r1.length()     // Catch:{ Exception -> 0x005b }
            if (r0 <= 0) goto L_0x005b
            r3.g = r1     // Catch:{ Exception -> 0x005b }
        L_0x005b:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x0105 }
            r0.<init>()     // Catch:{ Exception -> 0x0105 }
            r4.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x0105 }
            int r0 = r4.getChildCount()     // Catch:{ Exception -> 0x0105 }
            java.lang.String r1 = r3.h     // Catch:{ Exception -> 0x0105 }
            if (r1 == 0) goto L_0x0071
            int r1 = r1.length()     // Catch:{ Exception -> 0x0105 }
            if (r1 > 0) goto L_0x0073
        L_0x0071:
            if (r0 <= 0) goto L_0x0109
        L_0x0073:
            r1 = -481337082762716876(0xf951f27934b49934, double:-2.48548884747783E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0105 }
            java.lang.CharSequence r2 = r4.getText()     // Catch:{ Exception -> 0x0084 }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x0084 }
        L_0x0084:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x0105 }
            if (r1 == 0) goto L_0x0099
            if (r0 <= 0) goto L_0x0099
            r1 = 0
        L_0x008d:
            if (r1 >= r0) goto L_0x0099
            android.view.accessibility.AccessibilityNodeInfo r2 = r4.getChild(r1)     // Catch:{ Exception -> 0x0105 }
            r3.a(r2, r5, r6)     // Catch:{ Exception -> 0x0105 }
            int r1 = r1 + 1
            goto L_0x008d
        L_0x0099:
            r0 = -481337087057684172(0xf951f27834b49934, double:-2.4854867342997055E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0105 }
            java.lang.String r1 = r4.getViewIdResourceName()     // Catch:{ Exception -> 0x0105 }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x0105 }
            if (r0 == 0) goto L_0x00b8
            java.lang.CharSequence r4 = r4.getText()     // Catch:{ Exception -> 0x0105 }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x0105 }
            r6.add(r4)     // Catch:{ Exception -> 0x0105 }
            goto L_0x0109
        L_0x00b8:
            java.lang.CharSequence r6 = r4.getClassName()     // Catch:{ Exception -> 0x0105 }
            if (r6 == 0) goto L_0x00e8
            java.lang.CharSequence r6 = r4.getClassName()     // Catch:{ Exception -> 0x0105 }
            r0 = -481337245971474124(0xf951f25334b49934, double:-2.4854085467090974E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0105 }
            boolean r6 = r6.equals(r0)     // Catch:{ Exception -> 0x0105 }
            if (r6 == 0) goto L_0x00e8
            java.lang.CharSequence r6 = r4.getContentDescription()     // Catch:{ Exception -> 0x0105 }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x0105 }
            r0 = -481337349050689228(0xf951f23b34b49934, double:-2.4853578304341084E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0105 }
            boolean r6 = r6.equals(r0)     // Catch:{ Exception -> 0x0105 }
            if (r6 != 0) goto L_0x0101
        L_0x00e8:
            r0 = -481337404885264076(0xf951f22e34b49934, double:-2.4853303591184894E276)
            java.lang.String r6 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0105 }
            java.lang.String r0 = r4.getViewIdResourceName()     // Catch:{ Exception -> 0x0105 }
            boolean r6 = r6.equals(r0)     // Catch:{ Exception -> 0x0105 }
            if (r6 == 0) goto L_0x0109
            java.lang.CharSequence r6 = r4.getText()     // Catch:{ Exception -> 0x0105 }
            if (r6 == 0) goto L_0x0109
        L_0x0101:
            r5.add(r4)     // Catch:{ Exception -> 0x0105 }
            goto L_0x0109
        L_0x0105:
            r4 = move-exception
            r4.printStackTrace()
        L_0x0109:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.a(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0059 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x007e */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0085 A[ADDED_TO_REGION, Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00a2 A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00b8 A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00cc A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00d3 A[Catch:{ Exception -> 0x00f4 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(android.view.accessibility.AccessibilityNodeInfo r7, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r8, java.util.ArrayList<java.lang.String> r9) {
        /*
            r6 = this;
            if (r7 == 0) goto L_0x00f8
            java.lang.CharSequence r0 = r7.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481340325463025356(0xf951ef8634b49934, double:-2.4838933979938004E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x00f8
        L_0x001b:
            r0 = -481340377002632908(0xf951ef7a34b49934, double:-2.483868039856306E276)
            defpackage.wx1.a(r0)
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0059 }
            if (r0 == 0) goto L_0x0032
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0059 }
            goto L_0x003b
        L_0x0032:
            r0 = -481340381297600204(0xf951ef7934b49934, double:-2.4838659266781813E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0059 }
        L_0x003b:
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0059 }
            if (r1 == 0) goto L_0x004a
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x0059 }
            goto L_0x0053
        L_0x004a:
            r1 = -481340385592567500(0xf951ef7834b49934, double:-2.4838638135000568E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0059 }
        L_0x0053:
            r0.length()     // Catch:{ Exception -> 0x0059 }
            r1.length()     // Catch:{ Exception -> 0x0059 }
        L_0x0059:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x00f4 }
            r0.<init>()     // Catch:{ Exception -> 0x00f4 }
            r7.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x00f4 }
            int r0 = r7.getChildCount()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r1 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00f4 }
            if (r1 != 0) goto L_0x006d
            if (r0 <= 0) goto L_0x00f8
        L_0x006d:
            r1 = -481340389887534796(0xf951ef7734b49934, double:-2.483861700321932E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00f4 }
            java.lang.CharSequence r2 = r7.getText()     // Catch:{ Exception -> 0x007e }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x007e }
        L_0x007e:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x00f4 }
            r2 = 0
            if (r1 == 0) goto L_0x0093
            if (r0 <= 0) goto L_0x0093
        L_0x0087:
            if (r2 >= r0) goto L_0x00f8
            android.view.accessibility.AccessibilityNodeInfo r1 = r7.getChild(r2)     // Catch:{ Exception -> 0x00f4 }
            r6.b(r1, r8, r9)     // Catch:{ Exception -> 0x00f4 }
            int r2 = r2 + 1
            goto L_0x0087
        L_0x0093:
            java.lang.String r0 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00f4 }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x00f4 }
            r4 = 491595796(0x1d4d2814, float:2.7152244E-21)
            r5 = 1
            if (r3 == r4) goto L_0x00b8
            r4 = 963359483(0x396bb2fb, float:2.2478022E-4)
            if (r3 == r4) goto L_0x00a8
            goto L_0x00c9
        L_0x00a8:
            r3 = -481340394182502092(0xf951ef7634b49934, double:-2.4838595871438077E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x00f4 }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x00f4 }
            if (r0 == 0) goto L_0x00c9
            goto L_0x00ca
        L_0x00b8:
            r2 = -481340518736553676(0xf951ef5934b49934, double:-2.483798304978196E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00f4 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x00f4 }
            if (r0 == 0) goto L_0x00c9
            r2 = 1
            goto L_0x00ca
        L_0x00c9:
            r2 = -1
        L_0x00ca:
            if (r2 == 0) goto L_0x00d3
            if (r2 == r5) goto L_0x00cf
            goto L_0x00f8
        L_0x00cf:
            r8.add(r7)     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00f8
        L_0x00d3:
            int r8 = r9.size()     // Catch:{ Exception -> 0x00f4 }
            if (r8 != 0) goto L_0x00f8
            java.lang.CharSequence r8 = r7.getText()     // Catch:{ Exception -> 0x00f4 }
            if (r8 == 0) goto L_0x00eb
            java.lang.CharSequence r7 = r7.getText()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00f4 }
        L_0x00e7:
            r9.add(r7)     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00f8
        L_0x00eb:
            java.lang.CharSequence r7 = r7.getContentDescription()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00e7
        L_0x00f4:
            r7 = move-exception
            r7.printStackTrace()
        L_0x00f8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.b(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:7|8|9|10|11|(4:16|(2:18|(1:20)(2:21|(2:23|(1:(2:30|41)(2:31|42))(2:32|(2:34|45)(1:43)))))(2:24|(2:26|(0)(0)))|27|(0)(0))(3:(1:15)|37|46)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x0040 */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0064 A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x007b A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x008e A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0095 A[Catch:{ Exception -> 0x00a7 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(android.view.accessibility.AccessibilityNodeInfo r7, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r8, java.util.ArrayList<java.lang.String> r9) {
        /*
            r6 = this;
            if (r7 == 0) goto L_0x00ab
            java.lang.CharSequence r0 = r7.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481341253175961292(0xf951eeae34b49934, double:-2.483436951518899E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x00ab
        L_0x001b:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x00a7 }
            r0.<init>()     // Catch:{ Exception -> 0x00a7 }
            r7.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x00a7 }
            int r0 = r7.getChildCount()     // Catch:{ Exception -> 0x00a7 }
            java.lang.String r1 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00a7 }
            if (r1 != 0) goto L_0x002f
            if (r0 <= 0) goto L_0x00ab
        L_0x002f:
            r1 = -481341330485372620(0xf951ee9c34b49934, double:-2.4833989143126574E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00a7 }
            java.lang.CharSequence r2 = r7.getText()     // Catch:{ Exception -> 0x0040 }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x0040 }
        L_0x0040:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x00a7 }
            r2 = 0
            if (r1 == 0) goto L_0x0055
            if (r0 <= 0) goto L_0x0055
        L_0x0049:
            if (r2 >= r0) goto L_0x00ab
            android.view.accessibility.AccessibilityNodeInfo r1 = r7.getChild(r2)     // Catch:{ Exception -> 0x00a7 }
            r6.c(r1, r8, r9)     // Catch:{ Exception -> 0x00a7 }
            int r2 = r2 + 1
            goto L_0x0049
        L_0x0055:
            java.lang.String r0 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00a7 }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x00a7 }
            r4 = -2096886772(0xffffffff83040c0c, float:-3.8805143E-37)
            r5 = 1
            if (r3 == r4) goto L_0x007b
            r2 = 1671850179(0x63a668c3, float:6.139417E21)
            if (r3 == r2) goto L_0x006a
            goto L_0x008b
        L_0x006a:
            r2 = -481341450744456908(0xf951ee8034b49934, double:-2.48333974532517E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00a7 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x00a7 }
            if (r0 == 0) goto L_0x008b
            r2 = 1
            goto L_0x008c
        L_0x007b:
            r3 = -481341334780339916(0xf951ee9b34b49934, double:-2.483396801134533E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x00a7 }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x00a7 }
            if (r0 == 0) goto L_0x008b
            goto L_0x008c
        L_0x008b:
            r2 = -1
        L_0x008c:
            if (r2 == 0) goto L_0x0095
            if (r2 == r5) goto L_0x0091
            goto L_0x00ab
        L_0x0091:
            r8.add(r7)     // Catch:{ Exception -> 0x00a7 }
            goto L_0x00ab
        L_0x0095:
            int r8 = r9.size()     // Catch:{ Exception -> 0x00a7 }
            if (r8 != 0) goto L_0x00ab
            java.lang.CharSequence r7 = r7.getText()     // Catch:{ Exception -> 0x00a7 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00a7 }
            r9.add(r7)     // Catch:{ Exception -> 0x00a7 }
            goto L_0x00ab
        L_0x00a7:
            r7 = move-exception
            r7.printStackTrace()
        L_0x00ab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.c(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:7|8|9|10|11|(4:16|(2:18|(1:20)(2:21|(2:23|(1:(2:30|41)(2:31|42))(2:32|(2:34|45)(1:43)))))(2:24|(2:26|(0)(0)))|27|(0)(0))(3:(1:15)|37|46)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x0040 */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0064 A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x007b A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x008e A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0095 A[Catch:{ Exception -> 0x00a7 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void d(android.view.accessibility.AccessibilityNodeInfo r7, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r8, java.util.ArrayList<java.lang.String> r9) {
        /*
            r6 = this;
            if (r7 == 0) goto L_0x00ab
            java.lang.CharSequence r0 = r7.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481340754959754956(0xf951ef2234b49934, double:-2.483682080181346E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x00ab
        L_0x001b:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x00a7 }
            r0.<init>()     // Catch:{ Exception -> 0x00a7 }
            r7.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x00a7 }
            int r0 = r7.getChildCount()     // Catch:{ Exception -> 0x00a7 }
            java.lang.String r1 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00a7 }
            if (r1 != 0) goto L_0x002f
            if (r0 <= 0) goto L_0x00ab
        L_0x002f:
            r1 = -481340849449035468(0xf951ef0c34b49934, double:-2.483635590262606E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00a7 }
            java.lang.CharSequence r2 = r7.getText()     // Catch:{ Exception -> 0x0040 }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x0040 }
        L_0x0040:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x00a7 }
            r2 = 0
            if (r1 == 0) goto L_0x0055
            if (r0 <= 0) goto L_0x0055
        L_0x0049:
            if (r2 >= r0) goto L_0x00ab
            android.view.accessibility.AccessibilityNodeInfo r1 = r7.getChild(r2)     // Catch:{ Exception -> 0x00a7 }
            r6.d(r1, r8, r9)     // Catch:{ Exception -> 0x00a7 }
            int r2 = r2 + 1
            goto L_0x0049
        L_0x0055:
            java.lang.String r0 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00a7 }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x00a7 }
            r4 = 669844963(0x27ed05e3, float:6.5787097E-15)
            r5 = 1
            if (r3 == r4) goto L_0x007b
            r2 = 1671850179(0x63a668c3, float:6.139417E21)
            if (r3 == r2) goto L_0x006a
            goto L_0x008b
        L_0x006a:
            r2 = -481341016952760012(0xf951eee534b49934, double:-2.483553176315749E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00a7 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x00a7 }
            if (r0 == 0) goto L_0x008b
            r2 = 1
            goto L_0x008c
        L_0x007b:
            r3 = -481340853744002764(0xf951ef0b34b49934, double:-2.4836334770844816E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x00a7 }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x00a7 }
            if (r0 == 0) goto L_0x008b
            goto L_0x008c
        L_0x008b:
            r2 = -1
        L_0x008c:
            if (r2 == 0) goto L_0x0095
            if (r2 == r5) goto L_0x0091
            goto L_0x00ab
        L_0x0091:
            r8.add(r7)     // Catch:{ Exception -> 0x00a7 }
            goto L_0x00ab
        L_0x0095:
            int r8 = r9.size()     // Catch:{ Exception -> 0x00a7 }
            if (r8 != 0) goto L_0x00ab
            java.lang.CharSequence r7 = r7.getText()     // Catch:{ Exception -> 0x00a7 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00a7 }
            r9.add(r7)     // Catch:{ Exception -> 0x00a7 }
            goto L_0x00ab
        L_0x00a7:
            r7 = move-exception
            r7.printStackTrace()
        L_0x00ab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.d(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0059 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x007e */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0085 A[ADDED_TO_REGION, Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00a2 A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00b9 A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00cc A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00d3 A[Catch:{ Exception -> 0x00f4 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e(android.view.accessibility.AccessibilityNodeInfo r7, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r8, java.util.ArrayList<java.lang.String> r9) {
        /*
            r6 = this;
            if (r7 == 0) goto L_0x00f8
            java.lang.CharSequence r0 = r7.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481337555209119436(0xf951f20b34b49934, double:-2.4852563978841304E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x00f8
        L_0x001b:
            r0 = -481337619633628876(0xf951f1fc34b49934, double:-2.485224700212262E276)
            defpackage.wx1.a(r0)
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0059 }
            if (r0 == 0) goto L_0x0032
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0059 }
            goto L_0x003b
        L_0x0032:
            r0 = -481337623928596172(0xf951f1fb34b49934, double:-2.4852225870341377E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0059 }
        L_0x003b:
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0059 }
            if (r1 == 0) goto L_0x004a
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x0059 }
            goto L_0x0053
        L_0x004a:
            r1 = -481337628223563468(0xf951f1fa34b49934, double:-2.485220473856013E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0059 }
        L_0x0053:
            r0.length()     // Catch:{ Exception -> 0x0059 }
            r1.length()     // Catch:{ Exception -> 0x0059 }
        L_0x0059:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x00f4 }
            r0.<init>()     // Catch:{ Exception -> 0x00f4 }
            r7.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x00f4 }
            int r0 = r7.getChildCount()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r1 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00f4 }
            if (r1 != 0) goto L_0x006d
            if (r0 <= 0) goto L_0x00f8
        L_0x006d:
            r1 = -481337632518530764(0xf951f1f934b49934, double:-2.4852183606778886E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00f4 }
            java.lang.CharSequence r2 = r7.getText()     // Catch:{ Exception -> 0x007e }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x007e }
        L_0x007e:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x00f4 }
            r2 = 0
            if (r1 == 0) goto L_0x0093
            if (r0 <= 0) goto L_0x0093
        L_0x0087:
            if (r2 >= r0) goto L_0x00f8
            android.view.accessibility.AccessibilityNodeInfo r1 = r7.getChild(r2)     // Catch:{ Exception -> 0x00f4 }
            r6.e(r1, r8, r9)     // Catch:{ Exception -> 0x00f4 }
            int r2 = r2 + 1
            goto L_0x0087
        L_0x0093:
            java.lang.String r0 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00f4 }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x00f4 }
            r4 = -1980261903(0xffffffff89f799f1, float:-5.9607853E-33)
            r5 = 1
            if (r3 == r4) goto L_0x00b9
            r2 = -988294433(0xffffffffc517d2df, float:-2429.1794)
            if (r3 == r2) goto L_0x00a8
            goto L_0x00c9
        L_0x00a8:
            r2 = -481337752777615052(0xf951f1dd34b49934, double:-2.4851591916904014E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00f4 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x00f4 }
            if (r0 == 0) goto L_0x00c9
            r2 = 1
            goto L_0x00ca
        L_0x00b9:
            r3 = -481337636813498060(0xf951f1f834b49934, double:-2.485216247499764E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x00f4 }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x00f4 }
            if (r0 == 0) goto L_0x00c9
            goto L_0x00ca
        L_0x00c9:
            r2 = -1
        L_0x00ca:
            if (r2 == 0) goto L_0x00d3
            if (r2 == r5) goto L_0x00cf
            goto L_0x00f8
        L_0x00cf:
            r8.add(r7)     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00f8
        L_0x00d3:
            int r8 = r9.size()     // Catch:{ Exception -> 0x00f4 }
            if (r8 != 0) goto L_0x00f8
            java.lang.CharSequence r8 = r7.getText()     // Catch:{ Exception -> 0x00f4 }
            if (r8 == 0) goto L_0x00eb
            java.lang.CharSequence r7 = r7.getText()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00f4 }
        L_0x00e7:
            r9.add(r7)     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00f8
        L_0x00eb:
            java.lang.CharSequence r7 = r7.getContentDescription()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00e7
        L_0x00f4:
            r7 = move-exception
            r7.printStackTrace()
        L_0x00f8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.e(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(14:3|4|(1:6)(1:7)|8|(1:10)(1:11)|12|(1:14)|15|(1:17)|18|19|(1:43)|44|(1:69)(6:49|50|51|52|53|(2:59|(1:71)(2:63|73))(4:56|(1:58)|66|74))) */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x014e, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x014f, code lost:
        r5.printStackTrace();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:?, code lost:
        return;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x005b */
    /* JADX WARNING: Missing exception handler attribute for start block: B:52:0x011c */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0122 A[ADDED_TO_REGION, Catch:{ Exception -> 0x014e }] */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x014a A[Catch:{ Exception -> 0x014e }] */
    /* JADX WARNING: Removed duplicated region for block: B:71:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(android.view.accessibility.AccessibilityNodeInfo r5, java.util.ArrayList<java.lang.String> r6, java.util.ArrayList<java.lang.String> r7) {
        /*
            r4 = this;
            if (r5 == 0) goto L_0x0152
            java.lang.CharSequence r0 = r5.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481337864446764748(0xf951f1c334b49934, double:-2.4851042490591633E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x0152
        L_0x001b:
            java.lang.CharSequence r0 = r5.getContentDescription()     // Catch:{ Exception -> 0x005b }
            if (r0 == 0) goto L_0x002a
            java.lang.CharSequence r0 = r5.getContentDescription()     // Catch:{ Exception -> 0x005b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x005b }
            goto L_0x0033
        L_0x002a:
            r0 = -481337954641077964(0xf951f1ae34b49934, double:-2.485059872318548E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x005b }
        L_0x0033:
            java.lang.CharSequence r1 = r5.getText()     // Catch:{ Exception -> 0x005b }
            if (r1 == 0) goto L_0x0042
            java.lang.CharSequence r1 = r5.getText()     // Catch:{ Exception -> 0x005b }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x005b }
            goto L_0x004b
        L_0x0042:
            r1 = -481337958936045260(0xf951f1ad34b49934, double:-2.4850577591404234E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x005b }
        L_0x004b:
            int r2 = r0.length()     // Catch:{ Exception -> 0x005b }
            if (r2 <= 0) goto L_0x0053
            r4.e = r0     // Catch:{ Exception -> 0x005b }
        L_0x0053:
            int r0 = r1.length()     // Catch:{ Exception -> 0x005b }
            if (r0 <= 0) goto L_0x005b
            r4.f = r1     // Catch:{ Exception -> 0x005b }
        L_0x005b:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x014e }
            r0.<init>()     // Catch:{ Exception -> 0x014e }
            r5.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x014e }
            java.lang.String r0 = r4.e     // Catch:{ Exception -> 0x014e }
            if (r0 == 0) goto L_0x00fb
            int r0 = r0.length()     // Catch:{ Exception -> 0x014e }
            if (r0 <= 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            if (r0 == 0) goto L_0x00fb
            int r0 = r0.length()     // Catch:{ Exception -> 0x014e }
            if (r0 <= 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r1 = -481337963231012556(0xf951f1ac34b49934, double:-2.485055645962299E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r1 = -481338001885718220(0xf951f1a334b49934, double:-2.485036627359178E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r1 = -481338066310227660(0xf951f19434b49934, double:-2.48500492968731E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r1 = -481338087785064140(0xf951f18f34b49934, double:-2.484994363796687E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r1 = -481338109259900620(0xf951f18a34b49934, double:-2.4849837979060644E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r1 = -481338152209573580(0xf951f18034b49934, double:-2.484962666124819E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            r0 = -481338182274344652(0xf951f17934b49934, double:-2.484947873877947E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x014e }
            java.lang.String r1 = r5.getViewIdResourceName()     // Catch:{ Exception -> 0x014e }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x014e }
            if (r0 == 0) goto L_0x00fb
            int r0 = r7.size()     // Catch:{ Exception -> 0x014e }
            if (r0 != 0) goto L_0x00fb
            java.lang.String r0 = r4.f     // Catch:{ Exception -> 0x014e }
            r7.add(r0)     // Catch:{ Exception -> 0x014e }
        L_0x00fb:
            int r0 = r5.getChildCount()     // Catch:{ Exception -> 0x014e }
            java.lang.String r1 = r4.e     // Catch:{ Exception -> 0x014e }
            if (r1 == 0) goto L_0x0109
            int r1 = r1.length()     // Catch:{ Exception -> 0x014e }
            if (r1 > 0) goto L_0x010b
        L_0x0109:
            if (r0 <= 0) goto L_0x0152
        L_0x010b:
            r1 = -481338409907611340(0xf951f14434b49934, double:-2.4848358754373464E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x014e }
            java.lang.CharSequence r2 = r5.getText()     // Catch:{ Exception -> 0x011c }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x011c }
        L_0x011c:
            boolean r2 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x014e }
            if (r2 == 0) goto L_0x0131
            if (r0 <= 0) goto L_0x0131
            r1 = 0
        L_0x0125:
            if (r1 >= r0) goto L_0x0152
            android.view.accessibility.AccessibilityNodeInfo r2 = r5.getChild(r1)     // Catch:{ Exception -> 0x014e }
            r4.f(r2, r6, r7)     // Catch:{ Exception -> 0x014e }
            int r1 = r1 + 1
            goto L_0x0125
        L_0x0131:
            java.lang.CharSequence r7 = r5.getClassName()     // Catch:{ Exception -> 0x014e }
            if (r7 == 0) goto L_0x0152
            java.lang.CharSequence r5 = r5.getClassName()     // Catch:{ Exception -> 0x014e }
            r2 = -481338414202578636(0xf951f14334b49934, double:-2.484833762259222E276)
            java.lang.String r7 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x014e }
            boolean r5 = r5.equals(r7)     // Catch:{ Exception -> 0x014e }
            if (r5 == 0) goto L_0x0152
            r6.add(r1)     // Catch:{ Exception -> 0x014e }
            goto L_0x0152
        L_0x014e:
            r5 = move-exception
            r5.printStackTrace()
        L_0x0152:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.f(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(14:3|4|(1:6)(1:7)|8|(1:10)(1:11)|12|(1:14)|15|(1:17)|18|19|(1:35)|36|(1:65)(6:41|42|43|44|45|(2:51|(1:67)(2:55|(2:59|70)(1:68)))(4:48|(1:50)|62|71))) */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x012c, code lost:
        r4 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x012d, code lost:
        r4.printStackTrace();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:?, code lost:
        return;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x005b */
    /* JADX WARNING: Missing exception handler attribute for start block: B:44:0x00d8 */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00de A[ADDED_TO_REGION, Catch:{ Exception -> 0x012c }] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0106 A[Catch:{ Exception -> 0x012c }] */
    /* JADX WARNING: Removed duplicated region for block: B:67:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void g(android.view.accessibility.AccessibilityNodeInfo r4, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r5, java.util.ArrayList<java.lang.String> r6) {
        /*
            r3 = this;
            if (r4 == 0) goto L_0x0130
            java.lang.CharSequence r0 = r4.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481339767117276876(0xf951f00834b49934, double:-2.484168111149991E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x0130
        L_0x001b:
            java.lang.CharSequence r0 = r4.getContentDescription()     // Catch:{ Exception -> 0x005b }
            if (r0 == 0) goto L_0x002a
            java.lang.CharSequence r0 = r4.getContentDescription()     // Catch:{ Exception -> 0x005b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x005b }
            goto L_0x0033
        L_0x002a:
            r0 = -481339865901524684(0xf951eff134b49934, double:-2.4841195080531264E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x005b }
        L_0x0033:
            java.lang.CharSequence r1 = r4.getText()     // Catch:{ Exception -> 0x005b }
            if (r1 == 0) goto L_0x0042
            java.lang.CharSequence r1 = r4.getText()     // Catch:{ Exception -> 0x005b }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x005b }
            goto L_0x004b
        L_0x0042:
            r1 = -481339870196491980(0xf951eff034b49934, double:-2.484117394875002E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x005b }
        L_0x004b:
            int r2 = r0.length()     // Catch:{ Exception -> 0x005b }
            if (r2 <= 0) goto L_0x0053
            r3.c = r0     // Catch:{ Exception -> 0x005b }
        L_0x0053:
            int r0 = r1.length()     // Catch:{ Exception -> 0x005b }
            if (r0 <= 0) goto L_0x005b
            r3.d = r1     // Catch:{ Exception -> 0x005b }
        L_0x005b:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x012c }
            r0.<init>()     // Catch:{ Exception -> 0x012c }
            r4.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x012c }
            java.lang.String r0 = r3.c     // Catch:{ Exception -> 0x012c }
            if (r0 == 0) goto L_0x00b7
            int r0 = r0.length()     // Catch:{ Exception -> 0x012c }
            if (r0 <= 0) goto L_0x00b7
            java.lang.String r0 = r3.d     // Catch:{ Exception -> 0x012c }
            if (r0 == 0) goto L_0x00b7
            int r0 = r0.length()     // Catch:{ Exception -> 0x012c }
            if (r0 <= 0) goto L_0x00b7
            java.lang.String r0 = r3.c     // Catch:{ Exception -> 0x012c }
            r1 = -481339874491459276(0xf951efef34b49934, double:-2.4841152816968773E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x012c }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x012c }
            if (r0 == 0) goto L_0x00b7
            java.lang.CharSequence r0 = r4.getClassName()     // Catch:{ Exception -> 0x012c }
            r1 = -481339938915968716(0xf951efe034b49934, double:-2.484083584025009E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x012c }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x012c }
            if (r0 == 0) goto L_0x00b7
            java.lang.String r0 = r3.d     // Catch:{ Exception -> 0x012c }
            r1 = -481340041995183820(0xf951efc834b49934, double:-2.48403286775002E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x012c }
            boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x012c }
            if (r0 != 0) goto L_0x00b7
            int r0 = r6.size()     // Catch:{ Exception -> 0x012c }
            if (r0 != 0) goto L_0x00b7
            java.lang.String r0 = r3.d     // Catch:{ Exception -> 0x012c }
            r6.add(r0)     // Catch:{ Exception -> 0x012c }
        L_0x00b7:
            int r0 = r4.getChildCount()     // Catch:{ Exception -> 0x012c }
            java.lang.String r1 = r3.c     // Catch:{ Exception -> 0x012c }
            if (r1 == 0) goto L_0x00c5
            int r1 = r1.length()     // Catch:{ Exception -> 0x012c }
            if (r1 > 0) goto L_0x00c7
        L_0x00c5:
            if (r0 <= 0) goto L_0x0130
        L_0x00c7:
            r1 = -481340123599562444(0xf951efb534b49934, double:-2.483992717365654E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x012c }
            java.lang.CharSequence r2 = r4.getText()     // Catch:{ Exception -> 0x00d8 }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x00d8 }
        L_0x00d8:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x012c }
            if (r1 == 0) goto L_0x00ed
            if (r0 <= 0) goto L_0x00ed
            r1 = 0
        L_0x00e1:
            if (r1 >= r0) goto L_0x0130
            android.view.accessibility.AccessibilityNodeInfo r2 = r4.getChild(r1)     // Catch:{ Exception -> 0x012c }
            r3.g(r2, r5, r6)     // Catch:{ Exception -> 0x012c }
            int r1 = r1 + 1
            goto L_0x00e1
        L_0x00ed:
            java.lang.CharSequence r6 = r4.getClassName()     // Catch:{ Exception -> 0x012c }
            if (r6 == 0) goto L_0x0130
            java.lang.CharSequence r6 = r4.getClassName()     // Catch:{ Exception -> 0x012c }
            r0 = -481340127894529740(0xf951efb434b49934, double:-2.4839906041875293E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x012c }
            boolean r6 = r6.equals(r0)     // Catch:{ Exception -> 0x012c }
            if (r6 == 0) goto L_0x0130
            java.lang.String r6 = r3.c     // Catch:{ Exception -> 0x012c }
            r0 = -481340226678777548(0xf951ef9d34b49934, double:-2.483942001090665E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x012c }
            boolean r6 = r6.contains(r0)     // Catch:{ Exception -> 0x012c }
            if (r6 != 0) goto L_0x0128
            java.lang.String r6 = r3.c     // Catch:{ Exception -> 0x012c }
            r0 = -481340273923417804(0xf951ef9234b49934, double:-2.483918756131295E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x012c }
            boolean r6 = r6.contains(r0)     // Catch:{ Exception -> 0x012c }
            if (r6 == 0) goto L_0x0130
        L_0x0128:
            r5.add(r4)     // Catch:{ Exception -> 0x012c }
            goto L_0x0130
        L_0x012c:
            r4 = move-exception
            r4.printStackTrace()
        L_0x0130:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.g(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0059 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x007e */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0085 A[ADDED_TO_REGION, Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00a2 A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00b9 A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00cc A[Catch:{ Exception -> 0x00f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00d3 A[Catch:{ Exception -> 0x00f4 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void h(android.view.accessibility.AccessibilityNodeInfo r7, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r8, java.util.ArrayList<java.lang.String> r9) {
        /*
            r6 = this;
            if (r7 == 0) goto L_0x00f8
            java.lang.CharSequence r0 = r7.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481336606021347020(0xf951f2e834b49934, double:-2.4857234102496543E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x00f8
        L_0x001b:
            r0 = -481336713395529420(0xf951f2cf34b49934, double:-2.4856705807965407E276)
            defpackage.wx1.a(r0)
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0059 }
            if (r0 == 0) goto L_0x0032
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0059 }
            goto L_0x003b
        L_0x0032:
            r0 = -481336717690496716(0xf951f2ce34b49934, double:-2.485668467618416E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0059 }
        L_0x003b:
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0059 }
            if (r1 == 0) goto L_0x004a
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x0059 }
            goto L_0x0053
        L_0x004a:
            r1 = -481336721985464012(0xf951f2cd34b49934, double:-2.4856663544402916E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0059 }
        L_0x0053:
            r0.length()     // Catch:{ Exception -> 0x0059 }
            r1.length()     // Catch:{ Exception -> 0x0059 }
        L_0x0059:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x00f4 }
            r0.<init>()     // Catch:{ Exception -> 0x00f4 }
            r7.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x00f4 }
            int r0 = r7.getChildCount()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r1 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00f4 }
            if (r1 != 0) goto L_0x006d
            if (r0 <= 0) goto L_0x00f8
        L_0x006d:
            r1 = -481336726280431308(0xf951f2cc34b49934, double:-2.485664241262167E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00f4 }
            java.lang.CharSequence r2 = r7.getText()     // Catch:{ Exception -> 0x007e }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x007e }
        L_0x007e:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x00f4 }
            r2 = 0
            if (r1 == 0) goto L_0x0093
            if (r0 <= 0) goto L_0x0093
        L_0x0087:
            if (r2 >= r0) goto L_0x00f8
            android.view.accessibility.AccessibilityNodeInfo r1 = r7.getChild(r2)     // Catch:{ Exception -> 0x00f4 }
            r6.h(r1, r8, r9)     // Catch:{ Exception -> 0x00f4 }
            int r2 = r2 + 1
            goto L_0x0087
        L_0x0093:
            java.lang.String r0 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00f4 }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x00f4 }
            r4 = 436603178(0x1a06092a, float:2.7717953E-23)
            r5 = 1
            if (r3 == r4) goto L_0x00b9
            r2 = 649786170(0x26baf33a, float:1.2972269E-15)
            if (r3 == r2) goto L_0x00a8
            goto L_0x00c9
        L_0x00a8:
            r2 = -481336863719384780(0xf951f2ac34b49934, double:-2.4855966195621817E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00f4 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x00f4 }
            if (r0 == 0) goto L_0x00c9
            r2 = 1
            goto L_0x00ca
        L_0x00b9:
            r3 = -481336730575398604(0xf951f2cb34b49934, double:-2.4856621280840426E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x00f4 }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x00f4 }
            if (r0 == 0) goto L_0x00c9
            goto L_0x00ca
        L_0x00c9:
            r2 = -1
        L_0x00ca:
            if (r2 == 0) goto L_0x00d3
            if (r2 == r5) goto L_0x00cf
            goto L_0x00f8
        L_0x00cf:
            r8.add(r7)     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00f8
        L_0x00d3:
            int r8 = r9.size()     // Catch:{ Exception -> 0x00f4 }
            if (r8 != 0) goto L_0x00f8
            java.lang.CharSequence r8 = r7.getText()     // Catch:{ Exception -> 0x00f4 }
            if (r8 == 0) goto L_0x00eb
            java.lang.CharSequence r7 = r7.getText()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00f4 }
        L_0x00e7:
            r9.add(r7)     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00f8
        L_0x00eb:
            java.lang.CharSequence r7 = r7.getContentDescription()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00f4 }
            goto L_0x00e7
        L_0x00f4:
            r7 = move-exception
            r7.printStackTrace()
        L_0x00f8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.h(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0051 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x0076 */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x007d A[ADDED_TO_REGION, Catch:{ Exception -> 0x00dd }] */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x009a A[Catch:{ Exception -> 0x00dd }] */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00b0 A[Catch:{ Exception -> 0x00dd }] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00c4 A[Catch:{ Exception -> 0x00dd }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00cb A[Catch:{ Exception -> 0x00dd }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void i(android.view.accessibility.AccessibilityNodeInfo r7, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r8, java.util.ArrayList<java.lang.String> r9) {
        /*
            r6 = this;
            if (r7 == 0) goto L_0x00e1
            java.lang.CharSequence r0 = r7.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481338457152251596(0xf951f13934b49934, double:-2.4848126304779764E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x001b
            goto L_0x00e1
        L_0x001b:
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0051 }
            if (r0 == 0) goto L_0x002a
            java.lang.CharSequence r0 = r7.getContentDescription()     // Catch:{ Exception -> 0x0051 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0051 }
            goto L_0x0033
        L_0x002a:
            r0 = -481338504396891852(0xf951f12e34b49934, double:-2.4847893855186064E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x0051 }
        L_0x0033:
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0051 }
            if (r1 == 0) goto L_0x0042
            java.lang.CharSequence r1 = r7.getText()     // Catch:{ Exception -> 0x0051 }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x0051 }
            goto L_0x004b
        L_0x0042:
            r1 = -481338508691859148(0xf951f12d34b49934, double:-2.484787272340482E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0051 }
        L_0x004b:
            r0.length()     // Catch:{ Exception -> 0x0051 }
            r1.length()     // Catch:{ Exception -> 0x0051 }
        L_0x0051:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x00dd }
            r0.<init>()     // Catch:{ Exception -> 0x00dd }
            r7.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x00dd }
            int r0 = r7.getChildCount()     // Catch:{ Exception -> 0x00dd }
            java.lang.String r1 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00dd }
            if (r1 != 0) goto L_0x0065
            if (r0 <= 0) goto L_0x00e1
        L_0x0065:
            r1 = -481338512986826444(0xf951f12c34b49934, double:-2.4847851591623574E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00dd }
            java.lang.CharSequence r2 = r7.getText()     // Catch:{ Exception -> 0x0076 }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x0076 }
        L_0x0076:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x00dd }
            r2 = 0
            if (r1 == 0) goto L_0x008b
            if (r0 <= 0) goto L_0x008b
        L_0x007f:
            if (r2 >= r0) goto L_0x00e1
            android.view.accessibility.AccessibilityNodeInfo r1 = r7.getChild(r2)     // Catch:{ Exception -> 0x00dd }
            r6.i(r1, r8, r9)     // Catch:{ Exception -> 0x00dd }
            int r2 = r2 + 1
            goto L_0x007f
        L_0x008b:
            java.lang.String r0 = r7.getViewIdResourceName()     // Catch:{ Exception -> 0x00dd }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x00dd }
            r4 = 837761174(0x31ef3896, float:6.9622486E-9)
            r5 = 1
            if (r3 == r4) goto L_0x00b0
            r4 = 1379127292(0x5233cffc, float:1.93072136E11)
            if (r3 == r4) goto L_0x00a0
            goto L_0x00c1
        L_0x00a0:
            r3 = -481338517281793740(0xf951f12b34b49934, double:-2.484783045984233E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x00dd }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x00dd }
            if (r0 == 0) goto L_0x00c1
            goto L_0x00c2
        L_0x00b0:
            r2 = -481338633245910732(0xf951f11034b49934, double:-2.48472599017487E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00dd }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x00dd }
            if (r0 == 0) goto L_0x00c1
            r2 = 1
            goto L_0x00c2
        L_0x00c1:
            r2 = -1
        L_0x00c2:
            if (r2 == 0) goto L_0x00cb
            if (r2 == r5) goto L_0x00c7
            goto L_0x00e1
        L_0x00c7:
            r8.add(r7)     // Catch:{ Exception -> 0x00dd }
            goto L_0x00e1
        L_0x00cb:
            int r8 = r9.size()     // Catch:{ Exception -> 0x00dd }
            if (r8 != 0) goto L_0x00e1
            java.lang.CharSequence r7 = r7.getText()     // Catch:{ Exception -> 0x00dd }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x00dd }
            r9.add(r7)     // Catch:{ Exception -> 0x00dd }
            goto L_0x00e1
        L_0x00dd:
            r7 = move-exception
            r7.printStackTrace()
        L_0x00e1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.i(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x0057 */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x007d A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x007e A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x008f A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00a0 A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00b1 A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00c2 A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00d2 A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00fb A[Catch:{ Exception -> 0x0107 }] */
    /* JADX WARNING: Removed duplicated region for block: B:59:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void j(android.view.accessibility.AccessibilityNodeInfo r12, java.util.ArrayList<android.view.accessibility.AccessibilityNodeInfo> r13, java.util.ArrayList<java.lang.String> r14) {
        /*
            r11 = this;
            if (r12 == 0) goto L_0x010b
            java.lang.CharSequence r0 = r12.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481338792159700684(0xf951f0eb34b49934, double:-2.484647802584262E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x0032
            java.lang.CharSequence r0 = r12.getPackageName()
            java.lang.String r0 = r0.toString()
            r1 = -481338847994275532(0xf951f0de34b49934, double:-2.484620331268643E276)
            java.lang.String r1 = defpackage.wx1.a(r1)
            boolean r0 = r0.equalsIgnoreCase(r1)
            if (r0 != 0) goto L_0x0032
            goto L_0x010b
        L_0x0032:
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x0107 }
            r0.<init>()     // Catch:{ Exception -> 0x0107 }
            r12.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x0107 }
            int r0 = r12.getChildCount()     // Catch:{ Exception -> 0x0107 }
            java.lang.String r1 = r12.getViewIdResourceName()     // Catch:{ Exception -> 0x0107 }
            if (r1 != 0) goto L_0x0046
            if (r0 <= 0) goto L_0x010b
        L_0x0046:
            r1 = -481338921008719564(0xf951f0cd34b49934, double:-2.484584407240526E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0107 }
            java.lang.CharSequence r2 = r12.getText()     // Catch:{ Exception -> 0x0057 }
            java.lang.String r1 = r2.toString()     // Catch:{ Exception -> 0x0057 }
        L_0x0057:
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x0107 }
            r2 = 0
            if (r1 == 0) goto L_0x006c
            if (r0 <= 0) goto L_0x006c
        L_0x0060:
            if (r2 >= r0) goto L_0x010b
            android.view.accessibility.AccessibilityNodeInfo r1 = r12.getChild(r2)     // Catch:{ Exception -> 0x0107 }
            r11.j(r1, r13, r14)     // Catch:{ Exception -> 0x0107 }
            int r2 = r2 + 1
            goto L_0x0060
        L_0x006c:
            java.lang.String r0 = r12.getViewIdResourceName()     // Catch:{ Exception -> 0x0107 }
            r1 = -1
            int r3 = r0.hashCode()     // Catch:{ Exception -> 0x0107 }
            r4 = 5
            r5 = 4
            r6 = 3
            r7 = 2
            r8 = 1
            switch(r3) {
                case -1447285323: goto L_0x00d2;
                case -655488051: goto L_0x00c2;
                case -646741250: goto L_0x00b1;
                case 1421704246: goto L_0x00a0;
                case 1871123646: goto L_0x008f;
                case 2077655815: goto L_0x007e;
                default: goto L_0x007d;
            }     // Catch:{ Exception -> 0x0107 }
        L_0x007d:
            goto L_0x00e3
        L_0x007e:
            r2 = -481339303260808908(0xf951f07434b49934, double:-2.4843963343874415E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0107 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x0107 }
            if (r0 == 0) goto L_0x00e3
            r2 = 2
            goto L_0x00e4
        L_0x008f:
            r2 = -481339393455122124(0xf951f05f34b49934, double:-2.484351957646826E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0107 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x0107 }
            if (r0 == 0) goto L_0x00e3
            r2 = 3
            goto L_0x00e4
        L_0x00a0:
            r2 = -481339105692313292(0xf951f0a234b49934, double:-2.4844935405811705E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0107 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x0107 }
            if (r0 == 0) goto L_0x00e3
            r2 = 1
            goto L_0x00e4
        L_0x00b1:
            r2 = -481339518009173708(0xf951f04234b49934, double:-2.4842906754812144E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0107 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x0107 }
            if (r0 == 0) goto L_0x00e3
            r2 = 4
            goto L_0x00e4
        L_0x00c2:
            r9 = -481338925303686860(0xf951f0cc34b49934, double:-2.4845822940624013E276)
            java.lang.String r3 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x0107 }
            boolean r0 = r0.equals(r3)     // Catch:{ Exception -> 0x0107 }
            if (r0 == 0) goto L_0x00e3
            goto L_0x00e4
        L_0x00d2:
            r2 = -481339625383356108(0xf951f02934b49934, double:-2.484237846028101E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0107 }
            boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x0107 }
            if (r0 == 0) goto L_0x00e3
            r2 = 5
            goto L_0x00e4
        L_0x00e3:
            r2 = -1
        L_0x00e4:
            if (r2 == 0) goto L_0x00f5
            if (r2 == r8) goto L_0x00f5
            if (r2 == r7) goto L_0x00f1
            if (r2 == r6) goto L_0x00f1
            if (r2 == r5) goto L_0x00f1
            if (r2 == r4) goto L_0x00f1
            goto L_0x010b
        L_0x00f1:
            r13.add(r12)     // Catch:{ Exception -> 0x0107 }
            goto L_0x010b
        L_0x00f5:
            int r13 = r14.size()     // Catch:{ Exception -> 0x0107 }
            if (r13 != 0) goto L_0x010b
            java.lang.CharSequence r12 = r12.getText()     // Catch:{ Exception -> 0x0107 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x0107 }
            r14.add(r12)     // Catch:{ Exception -> 0x0107 }
            goto L_0x010b
        L_0x0107:
            r12 = move-exception
            r12.printStackTrace()
        L_0x010b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.j(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList, java.util.ArrayList):void");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(25:45|(3:49|50|(1:52)(3:53|(4:55|(1:57)|58|(5:62|63|64|65|(6:70|(2:76|(1:81)(1:80))|82|(1:84)(2:85|(1:87))|88|(1:90))))|91))|92|93|94|(3:96|97|(1:99)(4:100|(2:106|(2:108|(11:111|112|113|114|115|(4:119|124|698|125)|123|124|698|125|109)))|127|128))|132|(3:134|135|(1:137)(4:138|(4:143|(3:145|146|(1:(7:148|149|(1:151)(1:152)|153|(1:157)|158|(5:160|161|162|699|163)(2:702|166))(2:700|168)))|170|(1:(11:173|174|175|176|(6:181|186|(1:188)(1:189)|190|(2:192|703)(1:704)|193)|185|186|(0)(0)|190|(0)(0)|193)))|195|196))|200|(3:202|203|(1:205)(4:206|(2:212|(2:214|(6:217|218|219|705|220|215)))|222|223))|227|(3:231|232|(1:234)(6:235|(1:237)|238|(2:248|(6:250|(2:251|(3:253|254|(2:707|256)(2:708|257))(2:706|259))|260|261|262|(4:264|(3:266|267|(1:(7:269|270|(1:272)(1:273)|274|(1:278)|279|(5:281|282|283|709|284)(3:287|712|291))(1:710)))|293|(1:(3:296|(2:298|714)(6:299|300|(10:302|303|304|(1:306)(1:307)|308|(1:310)|311|313|314|(2:344|(1:346)(2:347|(6:351|352|(3:357|362|(4:364|365|368|715))|361|362|(0)))))|366|368|715)|713)))))|369|370))|374|(3:376|377|(1:379)(4:380|(2:386|(2:388|(11:391|392|393|394|395|(3:397|398|(4:400|407|717|410))(1:401)|406|407|717|410|389)))|412|413))|417|(3:419|420|(1:422)(4:423|(2:429|(2:431|(11:434|435|436|437|438|(4:443|448|718|449)|447|448|718|449|432)))|451|452))|456|457|(3:459|460|(1:462)(4:463|(2:471|(2:473|(13:476|477|478|479|480|(2:482|(6:485|490|(1:492)(1:493)|494|719|495))|489|490|(0)(0)|494|719|495|474)))|497|498))|502|(3:504|505|(1:507)(4:508|(2:516|(2:518|(13:521|522|523|524|525|(2:527|(6:530|535|(1:537)(1:538)|539|720|540))|534|535|(0)(0)|539|720|540|519)))|542|543))|547|(3:549|550|(1:552)(4:553|(2:561|(2:563|(10:566|567|568|(2:570|571)|572|573|574|(11:579|580|581|582|(1:584)|585|(1:587)|591|(1:593)(1:594)|595|725)|600|564)))|602|603))|607|(3:609|610|(1:612)(7:613|(1:615)|616|(2:624|(2:626|(20:629|(1:631)(1:632)|633|(1:637)|638|(11:640|(1:642)|643|645|647|649|651|653|655|727|689)|657|(1:659)(1:660)|661|(26:665|666|667|668|669|670|671|672|673|674|675|676|677|678|679|680|681|682|683|684|685|686|687|688|726|689)|643|645|647|649|651|653|655|727|689|627)))|691|692|732))(1:731)) */
    /* JADX WARNING: Code restructure failed: missing block: B:169:0x0601, code lost:
        if (r13 == false) goto L_0x0603;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:292:0x0aa8, code lost:
        if (r10 == false) goto L_0x0aaa;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:92:0x034b */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0511 A[SYNTHETIC, Splitter:B:134:0x0511] */
    /* JADX WARNING: Removed duplicated region for block: B:188:0x0640 A[Catch:{ Exception -> 0x0752 }] */
    /* JADX WARNING: Removed duplicated region for block: B:189:0x0649 A[Catch:{ Exception -> 0x0752 }] */
    /* JADX WARNING: Removed duplicated region for block: B:192:0x0658 A[Catch:{ Exception -> 0x0752 }] */
    /* JADX WARNING: Removed duplicated region for block: B:202:0x0778 A[SYNTHETIC, Splitter:B:202:0x0778] */
    /* JADX WARNING: Removed duplicated region for block: B:234:0x08fe A[Catch:{ Exception -> 0x0d3b }, RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:235:0x08ff A[Catch:{ Exception -> 0x0d3b }] */
    /* JADX WARNING: Removed duplicated region for block: B:364:0x0c39 A[Catch:{ Exception -> 0x0d32 }] */
    /* JADX WARNING: Removed duplicated region for block: B:492:0x1233 A[Catch:{ Exception -> 0x127c }] */
    /* JADX WARNING: Removed duplicated region for block: B:493:0x123d A[Catch:{ Exception -> 0x127c }] */
    /* JADX WARNING: Removed duplicated region for block: B:537:0x1408 A[Catch:{ Exception -> 0x1451 }] */
    /* JADX WARNING: Removed duplicated region for block: B:538:0x1412 A[Catch:{ Exception -> 0x1451 }] */
    /* JADX WARNING: Removed duplicated region for block: B:704:0x0752 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x0365 A[SYNTHETIC, Splitter:B:96:0x0365] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent r26) {
        /*
            r25 = this;
            r1 = r25
            android.view.accessibility.AccessibilityNodeInfo r0 = r26.getSource()     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0009
            return
        L_0x0009:
            boolean r0 = com.zgoicsifmc.App.j()     // Catch:{ Exception -> 0x18ad }
            r2 = 16
            r3 = 2
            r4 = 0
            r5 = 1
            if (r0 == 0) goto L_0x0130
            int r0 = r26.getEventType()     // Catch:{ Exception -> 0x18ad }
            if (r0 != r2) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481324906530432716(0xf951fd8c34b49934, double:-2.4914797074609085E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481324983839844044(0xf951fd7a34b49934, double:-2.4914416702546667E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325039674418892(0xf951fd6d34b49934, double:-2.4914141989390477E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325112688862924(0xf951fd5c34b49934, double:-2.4913782749109305E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325211473110732(0xf951fd4534b49934, double:-2.491329671814066E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325318847293132(0xf951fd2c34b49934, double:-2.4912768423609524E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325366091933388(0xf951fd2134b49934, double:-2.4912535974015824E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325447696312012(0xf951fd0e34b49934, double:-2.491213447017216E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.contains(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x0130
            java.util.List r0 = r26.getText()     // Catch:{ Exception -> 0x012c }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x012c }
            java.lang.String r0 = r0.trim()     // Catch:{ Exception -> 0x012c }
            int r6 = r0.length()     // Catch:{ Exception -> 0x012c }
            int r6 = r6 - r3
            java.lang.String r7 = r1.f1637a     // Catch:{ Exception -> 0x012c }
            int r7 = r7.length()     // Catch:{ Exception -> 0x012c }
            if (r6 <= r7) goto L_0x0130
            int r6 = r0.length()     // Catch:{ Exception -> 0x012c }
            if (r6 <= r3) goto L_0x0130
            int r6 = r26.getAddedCount()     // Catch:{ Exception -> 0x012c }
            if (r6 <= 0) goto L_0x0130
            r1.f1637a = r0     // Catch:{ Exception -> 0x012c }
            java.lang.String r0 = r0.substring(r5)     // Catch:{ Exception -> 0x012c }
            r1.f1637a = r0     // Catch:{ Exception -> 0x012c }
            int r6 = r0.length()     // Catch:{ Exception -> 0x012c }
            int r6 = r6 - r5
            java.lang.String r0 = r0.substring(r4, r6)     // Catch:{ Exception -> 0x012c }
            r1.f1637a = r0     // Catch:{ Exception -> 0x012c }
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x012c }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x012c }
            r1.b = r0     // Catch:{ Exception -> 0x012c }
            java.lang.Runnable r0 = r1.f1636a     // Catch:{ Exception -> 0x012c }
            if (r0 == 0) goto L_0x011d
            android.os.Handler r6 = r1.a     // Catch:{ Exception -> 0x012c }
            r6.removeCallbacks(r0)     // Catch:{ Exception -> 0x012c }
        L_0x011d:
            com.zgoicsifmc.AccessibilityReceiver4$a r0 = new com.zgoicsifmc.AccessibilityReceiver4$a     // Catch:{ Exception -> 0x012c }
            r0.<init>()     // Catch:{ Exception -> 0x012c }
            r1.f1636a = r0     // Catch:{ Exception -> 0x012c }
            android.os.Handler r6 = r1.a     // Catch:{ Exception -> 0x012c }
            r7 = 5000(0x1388, double:2.4703E-320)
            r6.postDelayed(r0, r7)     // Catch:{ Exception -> 0x012c }
            goto L_0x0130
        L_0x012c:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x0130:
            boolean r0 = com.zgoicsifmc.App.j()     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x18b8
            int r0 = r26.getEventType()     // Catch:{ Exception -> 0x18ad }
            if (r0 == r2) goto L_0x0144
            int r0 = r26.getEventType()     // Catch:{ Exception -> 0x18ad }
            r2 = 2048(0x800, float:2.87E-42)
            if (r0 != r2) goto L_0x18b8
        L_0x0144:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            r2 = 3
            if (r0 == 0) goto L_0x034b
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481325537890625228(0xf951fcf934b49934, double:-2.4911690702766007E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x034b
            android.view.accessibility.AccessibilityNodeInfo r6 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x034b }
            if (r6 != 0) goto L_0x0169
            return
        L_0x0169:
            r6.refresh()     // Catch:{ Exception -> 0x034b }
            r7 = -481325619495003852(0xf951fce634b49934, double:-2.4911289198922344E276)
            java.lang.String r0 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x034b }
            java.util.List r0 = r6.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x034b }
            int r7 = r0.size()     // Catch:{ Exception -> 0x034b }
            if (r7 <= 0) goto L_0x0348
            java.lang.Object r0 = r0.get(r4)     // Catch:{ Exception -> 0x034b }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x034b }
            java.lang.CharSequence r0 = r0.getText()     // Catch:{ Exception -> 0x034b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x034b }
            r7 = -481325748344022732(0xf951fcc834b49934, double:-2.491065524548498E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x034b }
            boolean r7 = r0.startsWith(r7)     // Catch:{ Exception -> 0x034b }
            if (r7 != 0) goto L_0x01b4
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x034b }
            r7.<init>()     // Catch:{ Exception -> 0x034b }
            r8 = -481325769818859212(0xf951fcc334b49934, double:-2.4910549586578754E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x034b }
            r7.append(r8)     // Catch:{ Exception -> 0x034b }
            r7.append(r0)     // Catch:{ Exception -> 0x034b }
            java.lang.String r0 = r7.toString()     // Catch:{ Exception -> 0x034b }
        L_0x01b4:
            r7 = r0
            r8 = -481325804178597580(0xf951fcbb34b49934, double:-2.491038053232879E276)
            java.lang.String r0 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x034b }
            boolean r0 = android.text.TextUtils.equals(r7, r0)     // Catch:{ Exception -> 0x034b }
            if (r0 != 0) goto L_0x0348
            r8 = -481325838538335948(0xf951fcb334b49934, double:-2.4910211478078827E276)
            java.lang.String r0 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x034b }
            boolean r0 = android.text.TextUtils.equals(r7, r0)     // Catch:{ Exception -> 0x034b }
            if (r0 != 0) goto L_0x0348
            boolean r0 = defpackage.ox1.h(r7)     // Catch:{ Exception -> 0x034b }
            java.net.URL r8 = new java.net.URL     // Catch:{ Exception -> 0x034b }
            r9 = -481325877193041612(0xf951fcaa34b49934, double:-2.491002129204762E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            r8.<init>(r9)     // Catch:{ Exception -> 0x034b }
            java.net.URL r9 = new java.net.URL     // Catch:{ Exception -> 0x01ec }
            r9.<init>(r7)     // Catch:{ Exception -> 0x01ec }
            r8 = r9
            goto L_0x01f1
        L_0x01ec:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x034b }
            r0 = 0
        L_0x01f1:
            if (r0 == 0) goto L_0x0348
            java.util.Calendar r0 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x034b }
            r9 = -481325975977289420(0xf951fc9334b49934, double:-2.4909535261078974E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            java.util.TimeZone r9 = java.util.TimeZone.getTimeZone(r9)     // Catch:{ Exception -> 0x034b }
            r0.setTimeZone(r9)     // Catch:{ Exception -> 0x034b }
            r9 = -481325993157158604(0xf951fc8f34b49934, double:-2.490945073395399E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            boolean r9 = r7.contains(r9)     // Catch:{ Exception -> 0x034b }
            if (r9 != 0) goto L_0x0225
            r9 = -481326027516896972(0xf951fc8734b49934, double:-2.490928167970403E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            boolean r9 = r7.contains(r9)     // Catch:{ Exception -> 0x034b }
            if (r9 == 0) goto L_0x0234
        L_0x0225:
            r9 = -481326053286700748(0xf951fc8134b49934, double:-2.4909154889016556E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            boolean r9 = r7.contains(r9)     // Catch:{ Exception -> 0x034b }
            if (r9 != 0) goto L_0x02b6
        L_0x0234:
            r9 = -481326066171602636(0xf951fc7e34b49934, double:-2.490909149367282E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            boolean r9 = r7.contains(r9)     // Catch:{ Exception -> 0x034b }
            if (r9 == 0) goto L_0x0253
            r9 = -481326126301144780(0xf951fc7034b49934, double:-2.4908795648735384E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            boolean r9 = r7.contains(r9)     // Catch:{ Exception -> 0x034b }
            if (r9 == 0) goto L_0x0253
            goto L_0x02b6
        L_0x0253:
            vv1 r7 = new vv1     // Catch:{ Exception -> 0x034b }
            r7.<init>()     // Catch:{ Exception -> 0x034b }
            java.util.UUID r9 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x034b }
            r7.g(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.CharSequence r9 = r26.getPackageName()     // Catch:{ Exception -> 0x034b }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x034b }
            r7.h(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.String r9 = r8.toString()     // Catch:{ Exception -> 0x034b }
            r7.i(r9)     // Catch:{ Exception -> 0x034b }
            long r9 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x034b }
            java.lang.String r9 = defpackage.ox1.b(r9)     // Catch:{ Exception -> 0x034b }
            r7.e(r9)     // Catch:{ Exception -> 0x034b }
            long r9 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x034b }
            r7.f(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.Class<vv1> r9 = defpackage.vv1.class
            ys1 r9 = com.raizlabs.android.dbflow.config.FlowManager.f(r9)     // Catch:{ Exception -> 0x034b }
            r9.C(r7)     // Catch:{ Exception -> 0x034b }
            r9 = -481326306689771212(0xf951fc4634b49934, double:-2.4907908113923076E276)
            java.lang.String r7 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.Object[] r9 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x034b }
            java.lang.CharSequence r10 = r26.getPackageName()     // Catch:{ Exception -> 0x034b }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x034b }
            r9[r4] = r10     // Catch:{ Exception -> 0x034b }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x034b }
            r9[r5] = r8     // Catch:{ Exception -> 0x034b }
            long r10 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x034b }
            java.lang.String r0 = defpackage.ox1.b(r10)     // Catch:{ Exception -> 0x034b }
            r9[r3] = r0     // Catch:{ Exception -> 0x034b }
            defpackage.o82.d(r7, r9)     // Catch:{ Exception -> 0x034b }
            goto L_0x0348
        L_0x02b6:
            r8 = -481326139186046668(0xf951fc6d34b49934, double:-2.490873225339165E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x034b }
            java.util.regex.Pattern r9 = r1.f1645f     // Catch:{ Exception -> 0x034b }
            java.util.regex.Matcher r9 = r9.matcher(r7)     // Catch:{ Exception -> 0x034b }
            java.util.regex.Pattern r10 = r1.f1646g     // Catch:{ Exception -> 0x034b }
            java.util.regex.Matcher r7 = r10.matcher(r7)     // Catch:{ Exception -> 0x034b }
            boolean r10 = r9.find()     // Catch:{ Exception -> 0x034b }
            if (r10 == 0) goto L_0x02d6
            java.lang.String r8 = r9.group(r5)     // Catch:{ Exception -> 0x034b }
            goto L_0x02e0
        L_0x02d6:
            boolean r9 = r7.find()     // Catch:{ Exception -> 0x034b }
            if (r9 == 0) goto L_0x02e0
            java.lang.String r8 = r7.group(r5)     // Catch:{ Exception -> 0x034b }
        L_0x02e0:
            r9 = -481326143481013964(0xf951fc6c34b49934, double:-2.49087111216104E276)
            java.lang.String r7 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            boolean r7 = android.text.TextUtils.equals(r8, r7)     // Catch:{ Exception -> 0x034b }
            if (r7 != 0) goto L_0x0348
            xv1 r7 = new xv1     // Catch:{ Exception -> 0x034b }
            r7.<init>()     // Catch:{ Exception -> 0x034b }
            java.util.UUID r9 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x034b }
            r7.g(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.CharSequence r9 = r26.getPackageName()     // Catch:{ Exception -> 0x034b }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x034b }
            r7.i(r9)     // Catch:{ Exception -> 0x034b }
            r7.h(r8)     // Catch:{ Exception -> 0x034b }
            long r9 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x034b }
            java.lang.String r9 = defpackage.ox1.b(r9)     // Catch:{ Exception -> 0x034b }
            r7.e(r9)     // Catch:{ Exception -> 0x034b }
            long r9 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x034b }
            r7.f(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.Class<xv1> r9 = defpackage.xv1.class
            ys1 r9 = com.raizlabs.android.dbflow.config.FlowManager.f(r9)     // Catch:{ Exception -> 0x034b }
            r9.C(r7)     // Catch:{ Exception -> 0x034b }
            r9 = -481326147775981260(0xf951fc6b34b49934, double:-2.4908689989829157E276)
            java.lang.String r7 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x034b }
            java.lang.Object[] r9 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x034b }
            java.lang.CharSequence r10 = r26.getPackageName()     // Catch:{ Exception -> 0x034b }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x034b }
            r9[r4] = r10     // Catch:{ Exception -> 0x034b }
            r9[r5] = r8     // Catch:{ Exception -> 0x034b }
            long r10 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x034b }
            java.lang.String r0 = defpackage.ox1.b(r10)     // Catch:{ Exception -> 0x034b }
            r9[r3] = r0     // Catch:{ Exception -> 0x034b }
            defpackage.o82.d(r7, r9)     // Catch:{ Exception -> 0x034b }
        L_0x0348:
            r6.recycle()     // Catch:{ Exception -> 0x034b }
        L_0x034b:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r6 = -481326448423691980(0xf951fc2534b49934, double:-2.4907210765141977E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r6)     // Catch:{ Exception -> 0x18ad }
            r6 = 150(0x96, float:2.1E-43)
            r7 = 6
            if (r0 == 0) goto L_0x04fa
            android.view.accessibility.AccessibilityNodeInfo r10 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x04f6 }
            if (r10 != 0) goto L_0x036c
            return
        L_0x036c:
            r10.refresh()     // Catch:{ Exception -> 0x04f6 }
            r11 = -481326525733103308(0xf951fc1334b49934, double:-2.490683039307956E276)
            java.lang.String r0 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x04f6 }
            r10.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x04f6 }
            java.util.ArrayList r11 = new java.util.ArrayList     // Catch:{ Exception -> 0x04f6 }
            r11.<init>()     // Catch:{ Exception -> 0x04f6 }
            java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ Exception -> 0x04f6 }
            r0.<init>()     // Catch:{ Exception -> 0x04f6 }
            r1.c(r10, r11, r0)     // Catch:{ Exception -> 0x04f6 }
            int r12 = r11.size()     // Catch:{ Exception -> 0x04f6 }
            if (r12 < r3) goto L_0x04f2
            int r12 = r0.size()     // Catch:{ Exception -> 0x04f6 }
            if (r12 <= 0) goto L_0x04f2
            java.lang.CharSequence r12 = r26.getPackageName()     // Catch:{ Exception -> 0x04f6 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x04f6 }
            r13 = -481326654582122188(0xf951fbf534b49934, double:-2.4906196439642196E276)
            java.lang.String r13 = defpackage.wx1.a(r13)     // Catch:{ Exception -> 0x04f6 }
            boolean r12 = r12.contains(r13)     // Catch:{ Exception -> 0x04f6 }
            if (r12 == 0) goto L_0x04f2
            java.lang.Object r0 = r0.get(r4)     // Catch:{ Exception -> 0x04f6 }
            r12 = r0
            java.lang.String r12 = (java.lang.String) r12     // Catch:{ Exception -> 0x04f6 }
            boolean r0 = r12.isEmpty()     // Catch:{ Exception -> 0x04f6 }
            if (r0 != 0) goto L_0x04f2
            r13 = 0
        L_0x03b9:
            int r0 = r11.size()     // Catch:{ Exception -> 0x04f6 }
            if (r13 >= r0) goto L_0x04f2
            r14 = -481326731891533516(0xf951fbe334b49934, double:-2.490581606757978E276)
            java.lang.String r14 = defpackage.wx1.a(r14)     // Catch:{ Exception -> 0x04ec }
            java.lang.Object r0 = r11.get(r13)     // Catch:{ Exception -> 0x04ec }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x04ec }
            java.lang.CharSequence r15 = r0.getText()     // Catch:{ Exception -> 0x04ec }
            java.lang.String r15 = r15.toString()     // Catch:{ Exception -> 0x04ec }
            android.graphics.Rect r8 = new android.graphics.Rect     // Catch:{ Exception -> 0x03fa }
            r8.<init>()     // Catch:{ Exception -> 0x03fa }
            r0.getBoundsInScreen(r8)     // Catch:{ Exception -> 0x03fa }
            java.util.regex.Pattern r0 = r1.f1640a     // Catch:{ Exception -> 0x03fa }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x03fa }
            java.util.regex.Matcher r0 = r0.matcher(r8)     // Catch:{ Exception -> 0x03fa }
            boolean r8 = r0.find()     // Catch:{ Exception -> 0x03fa }
            if (r8 == 0) goto L_0x03fe
            java.lang.String r0 = r0.group(r5)     // Catch:{ Exception -> 0x03fa }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x03fa }
            if (r0 >= r6) goto L_0x03fe
            r0 = 0
            goto L_0x03ff
        L_0x03fa:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x04ec }
        L_0x03fe:
            r0 = 1
        L_0x03ff:
            java.util.Calendar r8 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x04ec }
            r17 = -481326757661337292(0xf951fbdd34b49934, double:-2.4905689276892306E276)
            java.lang.String r17 = defpackage.wx1.a(r17)     // Catch:{ Exception -> 0x04ec }
            java.util.TimeZone r6 = java.util.TimeZone.getTimeZone(r17)     // Catch:{ Exception -> 0x04ec }
            r8.setTimeZone(r6)     // Catch:{ Exception -> 0x04ec }
            xu1 r6 = new xu1     // Catch:{ Exception -> 0x04ec }
            r6.<init>()     // Catch:{ Exception -> 0x04ec }
            java.util.UUID r9 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x04ec }
            r6.j(r9)     // Catch:{ Exception -> 0x04ec }
            r6.m(r12)     // Catch:{ Exception -> 0x04ec }
            r6.k(r15)     // Catch:{ Exception -> 0x04ec }
            r6.n(r14)     // Catch:{ Exception -> 0x04ec }
            r6.o(r0)     // Catch:{ Exception -> 0x04ec }
            long r19 = r8.getTimeInMillis()     // Catch:{ Exception -> 0x04ec }
            java.lang.String r0 = defpackage.ox1.b(r19)     // Catch:{ Exception -> 0x04ec }
            r6.h(r0)     // Catch:{ Exception -> 0x04ec }
            long r8 = r8.getTimeInMillis()     // Catch:{ Exception -> 0x04ec }
            r6.i(r8)     // Catch:{ Exception -> 0x04ec }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04ec }
            r0.<init>()     // Catch:{ Exception -> 0x04ec }
            r8 = -481326774841206476(0xf951fbd934b49934, double:-2.4905604749767324E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x04ec }
            r19 = -481326830675781324(0xf951fbcc34b49934, double:-2.4905330036611134E276)
            java.lang.String r9 = defpackage.wx1.a(r19)     // Catch:{ Exception -> 0x04ec }
            java.lang.String r8 = r12.replaceAll(r8, r9)     // Catch:{ Exception -> 0x04ec }
            r0.append(r8)     // Catch:{ Exception -> 0x04ec }
            r8 = -481326834970748620(0xf951fbcb34b49934, double:-2.490530890482989E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x04ec }
            r19 = -481326890805323468(0xf951fbbe34b49934, double:-2.49050341916737E276)
            java.lang.String r9 = defpackage.wx1.a(r19)     // Catch:{ Exception -> 0x04ec }
            java.lang.String r8 = r15.replaceAll(r8, r9)     // Catch:{ Exception -> 0x04ec }
            r0.append(r8)     // Catch:{ Exception -> 0x04ec }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x04ec }
            r6.l(r0)     // Catch:{ Exception -> 0x04ec }
            java.lang.Class<xu1> r0 = defpackage.xu1.class
            ys1 r0 = com.raizlabs.android.dbflow.config.FlowManager.f(r0)     // Catch:{ Exception -> 0x04ec }
            r0.C(r6)     // Catch:{ Exception -> 0x04ec }
            r8 = -481326895100290764(0xf951fbbd34b49934, double:-2.4905013059892453E276)
            java.lang.String r0 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x04ec }
            java.lang.Object[] r8 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x04ec }
            java.lang.CharSequence r9 = r26.getPackageName()     // Catch:{ Exception -> 0x04ec }
            r8[r4] = r9     // Catch:{ Exception -> 0x04ec }
            java.lang.String r9 = r6.e()     // Catch:{ Exception -> 0x04ec }
            r8[r5] = r9     // Catch:{ Exception -> 0x04ec }
            java.lang.String r9 = r6.c()     // Catch:{ Exception -> 0x04ec }
            r8[r3] = r9     // Catch:{ Exception -> 0x04ec }
            java.lang.String r9 = r6.d()     // Catch:{ Exception -> 0x04ec }
            r8[r2] = r9     // Catch:{ Exception -> 0x04ec }
            java.lang.String r9 = r6.f()     // Catch:{ Exception -> 0x04ec }
            r14 = 4
            r8[r14] = r9     // Catch:{ Exception -> 0x04ec }
            int r9 = r6.g()     // Catch:{ Exception -> 0x04ec }
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ Exception -> 0x04ec }
            r14 = 5
            r8[r14] = r9     // Catch:{ Exception -> 0x04ec }
            defpackage.o82.d(r0, r8)     // Catch:{ Exception -> 0x04ec }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x04ec }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04ec }
            r8.<init>()     // Catch:{ Exception -> 0x04ec }
            r8.append(r12)     // Catch:{ Exception -> 0x04ec }
            r19 = -481327195748001484(0xf951fb7734b49934, double:-2.4903533835205273E276)
            java.lang.String r9 = defpackage.wx1.a(r19)     // Catch:{ Exception -> 0x04ec }
            r8.append(r9)     // Catch:{ Exception -> 0x04ec }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x04ec }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04ec }
            r9.<init>()     // Catch:{ Exception -> 0x04ec }
            r9.append(r15)     // Catch:{ Exception -> 0x04ec }
            java.lang.String r6 = r6.f()     // Catch:{ Exception -> 0x04ec }
            r9.append(r6)     // Catch:{ Exception -> 0x04ec }
            java.lang.String r6 = r9.toString()     // Catch:{ Exception -> 0x04ec }
            r0.put(r8, r6)     // Catch:{ Exception -> 0x04ec }
        L_0x04ec:
            int r13 = r13 + 1
            r6 = 150(0x96, float:2.1E-43)
            goto L_0x03b9
        L_0x04f2:
            r10.recycle()     // Catch:{ Exception -> 0x04f6 }
            goto L_0x04fa
        L_0x04f6:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x04fa:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r8 = -481327273057412812(0xf951fb6534b49934, double:-2.4903153463142855E276)
            java.lang.String r6 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r6)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x0761
            android.view.accessibility.AccessibilityNodeInfo r6 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x075d }
            if (r6 != 0) goto L_0x0518
            return
        L_0x0518:
            r6.refresh()     // Catch:{ Exception -> 0x075d }
            java.util.ArrayList r8 = new java.util.ArrayList     // Catch:{ Exception -> 0x075d }
            r8.<init>()     // Catch:{ Exception -> 0x075d }
            java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ Exception -> 0x075d }
            r0.<init>()     // Catch:{ Exception -> 0x075d }
            r1.d(r6, r8, r0)     // Catch:{ Exception -> 0x075d }
            int r9 = r8.size()     // Catch:{ Exception -> 0x075d }
            int r10 = r0.size()     // Catch:{ Exception -> 0x075d }
            if (r10 <= 0) goto L_0x0759
            if (r9 < r3) goto L_0x0759
            java.lang.CharSequence r10 = r26.getPackageName()     // Catch:{ Exception -> 0x075d }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x075d }
            r11 = -481327367546693324(0xf951fb4f34b49934, double:-2.4902688563955456E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x075d }
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x075d }
            if (r10 == 0) goto L_0x0759
            java.lang.Object r0 = r0.get(r4)     // Catch:{ Exception -> 0x075d }
            r10 = r0
            java.lang.String r10 = (java.lang.String) r10     // Catch:{ Exception -> 0x075d }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x075d }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x075d }
            r11.<init>()     // Catch:{ Exception -> 0x075d }
            r11.append(r10)     // Catch:{ Exception -> 0x075d }
            java.lang.CharSequence r12 = r26.getPackageName()     // Catch:{ Exception -> 0x075d }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x075d }
            r11.append(r12)     // Catch:{ Exception -> 0x075d }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x075d }
            boolean r0 = r0.containsKey(r11)     // Catch:{ Exception -> 0x075d }
            if (r0 == 0) goto L_0x0603
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x075d }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x075d }
            r11.<init>()     // Catch:{ Exception -> 0x075d }
            r11.append(r10)     // Catch:{ Exception -> 0x075d }
            java.lang.CharSequence r12 = r26.getPackageName()     // Catch:{ Exception -> 0x075d }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x075d }
            r11.append(r12)     // Catch:{ Exception -> 0x075d }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x075d }
            java.lang.Object r0 = r0.get(r11)     // Catch:{ Exception -> 0x075d }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ Exception -> 0x075d }
            r11 = 0
            r12 = 0
            r13 = 0
        L_0x0593:
            if (r11 > r9) goto L_0x0600
            java.lang.Object r12 = r8.get(r11)     // Catch:{ Exception -> 0x05f8 }
            android.view.accessibility.AccessibilityNodeInfo r12 = (android.view.accessibility.AccessibilityNodeInfo) r12     // Catch:{ Exception -> 0x05f8 }
            java.lang.CharSequence r14 = r12.getText()     // Catch:{ Exception -> 0x05f8 }
            if (r14 == 0) goto L_0x05aa
            java.lang.CharSequence r14 = r12.getText()     // Catch:{ Exception -> 0x05f8 }
            java.lang.String r14 = r14.toString()     // Catch:{ Exception -> 0x05f8 }
            goto L_0x05b3
        L_0x05aa:
            r14 = -481327462035973836(0xf951fb3934b49934, double:-2.4902223664768056E276)
            java.lang.String r14 = defpackage.wx1.a(r14)     // Catch:{ Exception -> 0x05f8 }
        L_0x05b3:
            r19 = -481327466330941132(0xf951fb3834b49934, double:-2.490220253298681E276)
            java.lang.String r15 = defpackage.wx1.a(r19)     // Catch:{ Exception -> 0x05f8 }
            boolean r15 = android.text.TextUtils.equals(r14, r15)     // Catch:{ Exception -> 0x05f8 }
            if (r15 == 0) goto L_0x05d0
            java.lang.CharSequence r15 = r12.getContentDescription()     // Catch:{ Exception -> 0x05f8 }
            if (r15 == 0) goto L_0x05d0
            java.lang.CharSequence r12 = r12.getContentDescription()     // Catch:{ Exception -> 0x05f8 }
            java.lang.String r14 = r12.toString()     // Catch:{ Exception -> 0x05f8 }
        L_0x05d0:
            boolean r12 = android.text.TextUtils.equals(r14, r0)     // Catch:{ Exception -> 0x05f8 }
            if (r12 == 0) goto L_0x05f8
            r12 = -481327470625908428(0xf951fb3734b49934, double:-2.4902181401205565E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x05f7 }
            r13 = 4
            java.lang.Object[] r15 = new java.lang.Object[r13]     // Catch:{ Exception -> 0x05f7 }
            java.lang.Integer r13 = java.lang.Integer.valueOf(r11)     // Catch:{ Exception -> 0x05f7 }
            r15[r4] = r13     // Catch:{ Exception -> 0x05f7 }
            java.lang.Integer r13 = java.lang.Integer.valueOf(r11)     // Catch:{ Exception -> 0x05f7 }
            r15[r5] = r13     // Catch:{ Exception -> 0x05f7 }
            r15[r3] = r14     // Catch:{ Exception -> 0x05f7 }
            r15[r2] = r0     // Catch:{ Exception -> 0x05f7 }
            defpackage.o82.a(r12, r15)     // Catch:{ Exception -> 0x05f7 }
            r13 = 1
            goto L_0x0601
        L_0x05f7:
            r13 = 1
        L_0x05f8:
            int r12 = r11 + 1
            r24 = r12
            r12 = r11
            r11 = r24
            goto L_0x0593
        L_0x0600:
            r11 = r12
        L_0x0601:
            if (r13 != 0) goto L_0x0604
        L_0x0603:
            r11 = 0
        L_0x0604:
            if (r11 >= r9) goto L_0x0759
        L_0x0606:
            if (r11 >= r9) goto L_0x0759
            java.lang.Object r0 = r8.get(r11)     // Catch:{ Exception -> 0x0752 }
            r12 = r0
            android.view.accessibility.AccessibilityNodeInfo r12 = (android.view.accessibility.AccessibilityNodeInfo) r12     // Catch:{ Exception -> 0x0752 }
            android.graphics.Rect r0 = new android.graphics.Rect     // Catch:{ Exception -> 0x0635 }
            r0.<init>()     // Catch:{ Exception -> 0x0635 }
            r12.getBoundsInScreen(r0)     // Catch:{ Exception -> 0x0635 }
            java.util.regex.Pattern r13 = r1.f1640a     // Catch:{ Exception -> 0x0635 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0635 }
            java.util.regex.Matcher r0 = r13.matcher(r0)     // Catch:{ Exception -> 0x0635 }
            boolean r13 = r0.find()     // Catch:{ Exception -> 0x0635 }
            if (r13 == 0) goto L_0x0639
            java.lang.String r0 = r0.group(r5)     // Catch:{ Exception -> 0x0635 }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x0635 }
            r13 = 270(0x10e, float:3.78E-43)
            if (r0 >= r13) goto L_0x0639
            r0 = 0
            goto L_0x063a
        L_0x0635:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x0752 }
        L_0x0639:
            r0 = 1
        L_0x063a:
            java.lang.CharSequence r13 = r12.getText()     // Catch:{ Exception -> 0x0752 }
            if (r13 == 0) goto L_0x0649
            java.lang.CharSequence r12 = r12.getText()     // Catch:{ Exception -> 0x0752 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x0752 }
            goto L_0x0652
        L_0x0649:
            r12 = -481327547935319756(0xf951fb2534b49934, double:-2.490180102914315E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0752 }
        L_0x0652:
            boolean r13 = android.text.TextUtils.isEmpty(r12)     // Catch:{ Exception -> 0x0752 }
            if (r13 != 0) goto L_0x0752
            java.util.Calendar r13 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x0752 }
            r14 = -481327552230287052(0xf951fb2434b49934, double:-2.49017798973619E276)
            java.lang.String r14 = defpackage.wx1.a(r14)     // Catch:{ Exception -> 0x0752 }
            java.util.TimeZone r14 = java.util.TimeZone.getTimeZone(r14)     // Catch:{ Exception -> 0x0752 }
            r13.setTimeZone(r14)     // Catch:{ Exception -> 0x0752 }
            java.text.SimpleDateFormat r14 = new java.text.SimpleDateFormat     // Catch:{ Exception -> 0x0752 }
            r19 = -481327569410156236(0xf951fb2034b49934, double:-2.490169537023692E276)
            java.lang.String r15 = defpackage.wx1.a(r19)     // Catch:{ Exception -> 0x0752 }
            java.util.Locale r7 = java.util.Locale.US     // Catch:{ Exception -> 0x0752 }
            r14.<init>(r15, r7)     // Catch:{ Exception -> 0x0752 }
            r20 = -481327608064861900(0xf951fb1734b49934, double:-2.490150518420571E276)
            java.lang.String r7 = defpackage.wx1.a(r20)     // Catch:{ Exception -> 0x0752 }
            java.util.TimeZone r7 = java.util.TimeZone.getTimeZone(r7)     // Catch:{ Exception -> 0x0752 }
            r14.setTimeZone(r7)     // Catch:{ Exception -> 0x0752 }
            zu1 r7 = new zu1     // Catch:{ Exception -> 0x0752 }
            r7.<init>()     // Catch:{ Exception -> 0x0752 }
            java.util.UUID r15 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x0752 }
            r7.l(r15)     // Catch:{ Exception -> 0x0752 }
            r7.o(r10)     // Catch:{ Exception -> 0x0752 }
            r7.m(r12)     // Catch:{ Exception -> 0x0752 }
            r7.q(r0)     // Catch:{ Exception -> 0x0752 }
            long r20 = r13.getTimeInMillis()     // Catch:{ Exception -> 0x0752 }
            java.lang.String r15 = defpackage.ox1.b(r20)     // Catch:{ Exception -> 0x0752 }
            r7.j(r15)     // Catch:{ Exception -> 0x0752 }
            long r2 = r13.getTimeInMillis()     // Catch:{ Exception -> 0x0752 }
            r7.k(r2)     // Catch:{ Exception -> 0x0752 }
            long r2 = r13.getTimeInMillis()     // Catch:{ Exception -> 0x0752 }
            java.lang.Long r2 = java.lang.Long.valueOf(r2)     // Catch:{ Exception -> 0x0752 }
            java.lang.String r2 = r14.format(r2)     // Catch:{ Exception -> 0x0752 }
            r7.p(r2)     // Catch:{ Exception -> 0x0752 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0752 }
            r2.<init>()     // Catch:{ Exception -> 0x0752 }
            r21 = -481327625244731084(0xf951fb1334b49934, double:-2.490142065708073E276)
            java.lang.String r3 = defpackage.wx1.a(r21)     // Catch:{ Exception -> 0x0752 }
            r21 = -481327681079305932(0xf951fb0634b49934, double:-2.490114594392454E276)
            java.lang.String r14 = defpackage.wx1.a(r21)     // Catch:{ Exception -> 0x0752 }
            java.lang.String r3 = r10.replaceAll(r3, r14)     // Catch:{ Exception -> 0x0752 }
            r2.append(r3)     // Catch:{ Exception -> 0x0752 }
            r21 = -481327685374273228(0xf951fb0534b49934, double:-2.4901124812143294E276)
            java.lang.String r3 = defpackage.wx1.a(r21)     // Catch:{ Exception -> 0x0752 }
            r21 = -481327741208848076(0xf951faf834b49934, double:-2.4900850098987103E276)
            java.lang.String r14 = defpackage.wx1.a(r21)     // Catch:{ Exception -> 0x0752 }
            java.lang.String r3 = r12.replaceAll(r3, r14)     // Catch:{ Exception -> 0x0752 }
            r2.append(r3)     // Catch:{ Exception -> 0x0752 }
            java.lang.String r2 = r2.toString()     // Catch:{ Exception -> 0x0752 }
            r7.n(r2)     // Catch:{ Exception -> 0x0752 }
            java.lang.Class<zu1> r2 = defpackage.zu1.class
            ys1 r2 = com.raizlabs.android.dbflow.config.FlowManager.f(r2)     // Catch:{ Exception -> 0x0752 }
            r2.C(r7)     // Catch:{ Exception -> 0x0752 }
            java.util.HashMap<java.lang.String, java.lang.String> r2 = r1.f1639a     // Catch:{ Exception -> 0x0752 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0752 }
            r3.<init>()     // Catch:{ Exception -> 0x0752 }
            r3.append(r10)     // Catch:{ Exception -> 0x0752 }
            r21 = -481327745503815372(0xf951faf734b49934, double:-2.490082896720586E276)
            java.lang.String r7 = defpackage.wx1.a(r21)     // Catch:{ Exception -> 0x0752 }
            r3.append(r7)     // Catch:{ Exception -> 0x0752 }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x0752 }
            r2.put(r3, r12)     // Catch:{ Exception -> 0x0752 }
            r2 = -481327839993095884(0xf951fae134b49934, double:-2.490036406801846E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0752 }
            r3 = 5
            java.lang.Object[] r7 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x0752 }
            java.lang.CharSequence r3 = r26.getPackageName()     // Catch:{ Exception -> 0x0752 }
            r7[r4] = r3     // Catch:{ Exception -> 0x0752 }
            r7[r5] = r10     // Catch:{ Exception -> 0x0752 }
            long r13 = r13.getTimeInMillis()     // Catch:{ Exception -> 0x0752 }
            java.lang.String r3 = defpackage.ox1.b(r13)     // Catch:{ Exception -> 0x0752 }
            r13 = 2
            r7[r13] = r3     // Catch:{ Exception -> 0x0752 }
            r3 = 3
            r7[r3] = r12     // Catch:{ Exception -> 0x0752 }
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch:{ Exception -> 0x0752 }
            r3 = 4
            r7[r3] = r0     // Catch:{ Exception -> 0x0752 }
            defpackage.o82.d(r2, r7)     // Catch:{ Exception -> 0x0752 }
        L_0x0752:
            int r11 = r11 + 1
            r2 = 3
            r3 = 2
            r7 = 6
            goto L_0x0606
        L_0x0759:
            r6.recycle()     // Catch:{ Exception -> 0x075d }
            goto L_0x0761
        L_0x075d:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x0761:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481328093396166348(0xf951faa634b49934, double:-2.489911729292498E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x08ca
            android.view.accessibility.AccessibilityNodeInfo r0 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x08c6 }
            if (r0 != 0) goto L_0x077f
            return
        L_0x077f:
            r0.refresh()     // Catch:{ Exception -> 0x08c6 }
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ Exception -> 0x08c6 }
            r2.<init>()     // Catch:{ Exception -> 0x08c6 }
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ Exception -> 0x08c6 }
            r3.<init>()     // Catch:{ Exception -> 0x08c6 }
            r1.b(r0, r2, r3)     // Catch:{ Exception -> 0x08c6 }
            int r6 = r2.size()     // Catch:{ Exception -> 0x08c6 }
            if (r6 < r5) goto L_0x08c2
            int r6 = r3.size()     // Catch:{ Exception -> 0x08c6 }
            if (r6 <= 0) goto L_0x08c2
            java.lang.CharSequence r6 = r26.getPackageName()     // Catch:{ Exception -> 0x08c6 }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x08c6 }
            r7 = -481328144935773900(0xf951fa9a34b49934, double:-2.4898863711550033E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x08c6 }
            boolean r6 = r6.contains(r7)     // Catch:{ Exception -> 0x08c6 }
            if (r6 == 0) goto L_0x08c2
            java.lang.Object r3 = r3.get(r4)     // Catch:{ Exception -> 0x08c6 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x08c6 }
            boolean r6 = r3.isEmpty()     // Catch:{ Exception -> 0x08c6 }
            if (r6 != 0) goto L_0x08c2
            r6 = 0
        L_0x07bf:
            int r7 = r2.size()     // Catch:{ Exception -> 0x08c6 }
            if (r6 >= r7) goto L_0x08c2
            r7 = -481328196475381452(0xf951fa8e34b49934, double:-2.489861013017509E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x08be }
            java.lang.Object r8 = r2.get(r6)     // Catch:{ Exception -> 0x08be }
            android.view.accessibility.AccessibilityNodeInfo r8 = (android.view.accessibility.AccessibilityNodeInfo) r8     // Catch:{ Exception -> 0x08be }
            java.lang.CharSequence r8 = r8.getText()     // Catch:{ Exception -> 0x08be }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x08be }
            java.util.Calendar r9 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x08be }
            r10 = -481328222245185228(0xf951fa8834b49934, double:-2.4898483339487616E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x08be }
            java.util.TimeZone r10 = java.util.TimeZone.getTimeZone(r10)     // Catch:{ Exception -> 0x08be }
            r9.setTimeZone(r10)     // Catch:{ Exception -> 0x08be }
            tu1 r10 = new tu1     // Catch:{ Exception -> 0x08be }
            r10.<init>()     // Catch:{ Exception -> 0x08be }
            java.util.UUID r11 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x08be }
            r10.k(r11)     // Catch:{ Exception -> 0x08be }
            r10.n(r3)     // Catch:{ Exception -> 0x08be }
            r10.l(r8)     // Catch:{ Exception -> 0x08be }
            r10.o(r7)     // Catch:{ Exception -> 0x08be }
            long r11 = r9.getTimeInMillis()     // Catch:{ Exception -> 0x08be }
            java.lang.String r7 = defpackage.ox1.b(r11)     // Catch:{ Exception -> 0x08be }
            r10.i(r7)     // Catch:{ Exception -> 0x08be }
            long r11 = r9.getTimeInMillis()     // Catch:{ Exception -> 0x08be }
            r10.j(r11)     // Catch:{ Exception -> 0x08be }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x08be }
            r7.<init>()     // Catch:{ Exception -> 0x08be }
            r11 = -481328239425054412(0xf951fa8434b49934, double:-2.4898398812362634E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x08be }
            r11 = -481328295259629260(0xf951fa7734b49934, double:-2.4898124099206443E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r3.replaceAll(r9, r11)     // Catch:{ Exception -> 0x08be }
            r7.append(r9)     // Catch:{ Exception -> 0x08be }
            r11 = -481328299554596556(0xf951fa7634b49934, double:-2.48981029674252E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x08be }
            r11 = -481328355389171404(0xf951fa6934b49934, double:-2.4897828254269007E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r8.replaceAll(r9, r11)     // Catch:{ Exception -> 0x08be }
            r7.append(r9)     // Catch:{ Exception -> 0x08be }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x08be }
            r10.m(r7)     // Catch:{ Exception -> 0x08be }
            java.lang.Class<tu1> r7 = defpackage.tu1.class
            ys1 r7 = com.raizlabs.android.dbflow.config.FlowManager.f(r7)     // Catch:{ Exception -> 0x08be }
            r7.C(r10)     // Catch:{ Exception -> 0x08be }
            r11 = -481328359684138700(0xf951fa6834b49934, double:-2.489780712248776E276)
            java.lang.String r7 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x08be }
            r9 = 5
            java.lang.Object[] r11 = new java.lang.Object[r9]     // Catch:{ Exception -> 0x08be }
            java.lang.CharSequence r9 = r26.getPackageName()     // Catch:{ Exception -> 0x08be }
            r11[r4] = r9     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r10.g()     // Catch:{ Exception -> 0x08be }
            r11[r5] = r9     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r10.c()     // Catch:{ Exception -> 0x08be }
            r12 = 2
            r11[r12] = r9     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r10.e()     // Catch:{ Exception -> 0x08be }
            r12 = 3
            r11[r12] = r9     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r10.h()     // Catch:{ Exception -> 0x08be }
            r12 = 4
            r11[r12] = r9     // Catch:{ Exception -> 0x08be }
            defpackage.o82.d(r7, r11)     // Catch:{ Exception -> 0x08be }
            java.util.HashMap<java.lang.String, java.lang.String> r7 = r1.f1639a     // Catch:{ Exception -> 0x08be }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x08be }
            r9.<init>()     // Catch:{ Exception -> 0x08be }
            r9.append(r3)     // Catch:{ Exception -> 0x08be }
            r11 = -481328613087209164(0xf951fa2d34b49934, double:-2.489656034739428E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x08be }
            r9.append(r11)     // Catch:{ Exception -> 0x08be }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x08be }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x08be }
            r11.<init>()     // Catch:{ Exception -> 0x08be }
            r11.append(r8)     // Catch:{ Exception -> 0x08be }
            java.lang.String r8 = r10.h()     // Catch:{ Exception -> 0x08be }
            r11.append(r8)     // Catch:{ Exception -> 0x08be }
            java.lang.String r8 = r11.toString()     // Catch:{ Exception -> 0x08be }
            r7.put(r9, r8)     // Catch:{ Exception -> 0x08be }
        L_0x08be:
            int r6 = r6 + 1
            goto L_0x07bf
        L_0x08c2:
            r0.recycle()     // Catch:{ Exception -> 0x08c6 }
            goto L_0x08ca
        L_0x08c6:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x08ca:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481328664626816716(0xf951fa2134b49934, double:-2.4896306766019337E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 != 0) goto L_0x08f8
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481328720461391564(0xf951fa1434b49934, double:-2.4896032052863146E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x0d3f
        L_0x08f8:
            android.view.accessibility.AccessibilityNodeInfo r2 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x0d3b }
            if (r2 != 0) goto L_0x08ff
            return
        L_0x08ff:
            r2.refresh()     // Catch:{ Exception -> 0x0d3b }
            r6 = -481328793475835596(0xf951fa0334b49934, double:-2.4895672812581974E276)
            java.lang.String r0 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x0d3b }
            java.util.List r0 = r2.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x0d3b }
            java.lang.CharSequence r3 = r26.getPackageName()     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x0d3b }
            r6 = -481328922324854476(0xf951f9e534b49934, double:-2.489503885914461E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x0d3b }
            boolean r3 = r3.equalsIgnoreCase(r6)     // Catch:{ Exception -> 0x0d3b }
            if (r3 == 0) goto L_0x0933
            r6 = -481328995339298508(0xf951f9d434b49934, double:-2.489467961886344E276)
            java.lang.String r0 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x0d3b }
            java.util.List r0 = r2.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x0d3b }
        L_0x0933:
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ Exception -> 0x0d3b }
            r3.<init>()     // Catch:{ Exception -> 0x0d3b }
            java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ Exception -> 0x0d3b }
            r6.<init>()     // Catch:{ Exception -> 0x0d3b }
            r1.j(r2, r3, r6)     // Catch:{ Exception -> 0x0d3b }
            int r7 = r3.size()     // Catch:{ Exception -> 0x0d3b }
            r8 = 2
            if (r7 < r8) goto L_0x0d37
            int r8 = r6.size()     // Catch:{ Exception -> 0x0d3b }
            if (r8 <= 0) goto L_0x0d37
            int r0 = r0.size()     // Catch:{ Exception -> 0x0d3b }
            if (r0 != 0) goto L_0x0d37
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0d3b }
            r8 = -481329141368186572(0xf951f9b234b49934, double:-2.4893961138301094E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x0d3b }
            boolean r0 = r0.contains(r8)     // Catch:{ Exception -> 0x0d3b }
            if (r0 != 0) goto L_0x0981
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0d3b }
            r8 = -481329197202761420(0xf951f9a534b49934, double:-2.4893686425144904E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x0d3b }
            boolean r0 = r0.contains(r8)     // Catch:{ Exception -> 0x0d3b }
            if (r0 == 0) goto L_0x0d37
        L_0x0981:
            java.lang.Object r0 = r6.get(r4)     // Catch:{ Exception -> 0x0d3b }
            r6 = r0
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ Exception -> 0x0d3b }
            boolean r0 = r6.isEmpty()     // Catch:{ Exception -> 0x0d3b }
            if (r0 != 0) goto L_0x0d37
            r0 = 0
        L_0x098f:
            int r8 = r3.size()     // Catch:{ Exception -> 0x0d3b }
            if (r0 >= r8) goto L_0x09b4
            java.util.regex.Pattern r8 = r1.f1641b     // Catch:{ Exception -> 0x09b1 }
            java.lang.Object r9 = r3.get(r0)     // Catch:{ Exception -> 0x09b1 }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x09b1 }
            java.lang.CharSequence r9 = r9.getText()     // Catch:{ Exception -> 0x09b1 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x09b1 }
            java.util.regex.Matcher r8 = r8.matcher(r9)     // Catch:{ Exception -> 0x09b1 }
            boolean r8 = r8.find()     // Catch:{ Exception -> 0x09b1 }
            if (r8 == 0) goto L_0x09b1
            int r0 = r0 - r5
            goto L_0x09b5
        L_0x09b1:
            int r0 = r0 + 1
            goto L_0x098f
        L_0x09b4:
            r0 = 1
        L_0x09b5:
            int r0 = r0 + r5
            java.lang.Object r0 = r3.get(r0)     // Catch:{ Exception -> 0x0d3b }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x0d3b }
            java.util.regex.Pattern r8 = r1.f1641b     // Catch:{ Exception -> 0x0d3b }
            java.lang.CharSequence r0 = r0.getText()     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0d3b }
            java.util.regex.Matcher r0 = r8.matcher(r0)     // Catch:{ Exception -> 0x0d3b }
            boolean r0 = r0.find()     // Catch:{ Exception -> 0x0d3b }
            if (r0 == 0) goto L_0x0d37
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x0d3b }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0d3b }
            r8.<init>()     // Catch:{ Exception -> 0x0d3b }
            r8.append(r6)     // Catch:{ Exception -> 0x0d3b }
            java.lang.CharSequence r9 = r26.getPackageName()     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0d3b }
            r8.append(r9)     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x0d3b }
            boolean r0 = r0.containsKey(r8)     // Catch:{ Exception -> 0x0d3b }
            if (r0 == 0) goto L_0x0aaa
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x0d3b }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0d3b }
            r8.<init>()     // Catch:{ Exception -> 0x0d3b }
            r8.append(r6)     // Catch:{ Exception -> 0x0d3b }
            java.lang.CharSequence r9 = r26.getPackageName()     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0d3b }
            r8.append(r9)     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x0d3b }
            java.lang.Object r0 = r0.get(r8)     // Catch:{ Exception -> 0x0d3b }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ Exception -> 0x0d3b }
            r8 = 0
            r9 = 0
            r10 = 0
        L_0x0a11:
            if (r8 > r7) goto L_0x0aa8
            java.lang.Object r9 = r3.get(r8)     // Catch:{ Exception -> 0x0a9d }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x0a9d }
            java.lang.CharSequence r11 = r9.getText()     // Catch:{ Exception -> 0x0a9d }
            if (r11 == 0) goto L_0x0a28
            java.lang.CharSequence r11 = r9.getText()     // Catch:{ Exception -> 0x0a9d }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x0a9d }
            goto L_0x0a31
        L_0x0a28:
            r11 = -481329270217205452(0xf951f99434b49934, double:-2.489332718486373E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0a9d }
        L_0x0a31:
            r12 = -481329274512172748(0xf951f99334b49934, double:-2.4893306053082486E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0a9d }
            boolean r12 = android.text.TextUtils.equals(r11, r12)     // Catch:{ Exception -> 0x0a9d }
            if (r12 == 0) goto L_0x0a4e
            java.lang.CharSequence r12 = r9.getContentDescription()     // Catch:{ Exception -> 0x0a9d }
            if (r12 == 0) goto L_0x0a4e
            java.lang.CharSequence r9 = r9.getContentDescription()     // Catch:{ Exception -> 0x0a9d }
            java.lang.String r11 = r9.toString()     // Catch:{ Exception -> 0x0a9d }
        L_0x0a4e:
            int r9 = r8 + 1
            java.lang.Object r9 = r3.get(r9)     // Catch:{ Exception -> 0x0a9d }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x0a9d }
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0a9d }
            r12.<init>()     // Catch:{ Exception -> 0x0a9d }
            r12.append(r11)     // Catch:{ Exception -> 0x0a9d }
            java.lang.CharSequence r9 = r9.getText()     // Catch:{ Exception -> 0x0a9d }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0a9d }
            r12.append(r9)     // Catch:{ Exception -> 0x0a9d }
            java.lang.String r9 = r12.toString()     // Catch:{ Exception -> 0x0a9d }
            boolean r11 = android.text.TextUtils.equals(r9, r0)     // Catch:{ Exception -> 0x0a9d }
            if (r11 == 0) goto L_0x0a9b
            int r10 = r8 + 2
            r11 = -481329278807140044(0xf951f99234b49934, double:-2.489328492130124E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0a99 }
            r12 = 4
            java.lang.Object[] r13 = new java.lang.Object[r12]     // Catch:{ Exception -> 0x0a99 }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r8)     // Catch:{ Exception -> 0x0a99 }
            r13[r4] = r12     // Catch:{ Exception -> 0x0a99 }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r10)     // Catch:{ Exception -> 0x0a99 }
            r13[r5] = r12     // Catch:{ Exception -> 0x0a99 }
            r12 = 2
            r13[r12] = r9     // Catch:{ Exception -> 0x0a99 }
            r9 = 3
            r13[r9] = r0     // Catch:{ Exception -> 0x0a99 }
            defpackage.o82.a(r11, r13)     // Catch:{ Exception -> 0x0a99 }
            r9 = r10
            r10 = 1
            goto L_0x0aa8
        L_0x0a99:
            r9 = 1
            goto L_0x0a9f
        L_0x0a9b:
            r9 = r8
            goto L_0x0aa4
        L_0x0a9d:
            r9 = r10
            r10 = r8
        L_0x0a9f:
            r24 = r10
            r10 = r9
            r9 = r24
        L_0x0aa4:
            int r8 = r8 + 1
            goto L_0x0a11
        L_0x0aa8:
            if (r10 != 0) goto L_0x0aab
        L_0x0aaa:
            r9 = 0
        L_0x0aab:
            if (r9 >= r7) goto L_0x0d37
        L_0x0aad:
            if (r9 >= r7) goto L_0x0d37
            int r8 = r9 + 1
            if (r8 < r7) goto L_0x0ab5
            r9 = r8
            goto L_0x0aad
        L_0x0ab5:
            java.lang.Object r0 = r3.get(r9)     // Catch:{ Exception -> 0x0d32 }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x0d32 }
            java.lang.Object r10 = r3.get(r8)     // Catch:{ Exception -> 0x0d32 }
            android.view.accessibility.AccessibilityNodeInfo r10 = (android.view.accessibility.AccessibilityNodeInfo) r10     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r11 = r10.getText()     // Catch:{ Exception -> 0x0d32 }
            if (r11 == 0) goto L_0x0d32
            r11 = -481329356116551372(0xf951f98034b49934, double:-2.4892904549238823E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r12 = r0.getText()     // Catch:{ Exception -> 0x0af6 }
            if (r12 == 0) goto L_0x0adf
            java.lang.CharSequence r12 = r0.getText()     // Catch:{ Exception -> 0x0af6 }
            java.lang.String r11 = r12.toString()     // Catch:{ Exception -> 0x0af6 }
            goto L_0x0ae8
        L_0x0adf:
            r12 = -481329360411518668(0xf951f97f34b49934, double:-2.489288341745758E276)
            java.lang.String r11 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0af6 }
        L_0x0ae8:
            boolean r12 = android.text.TextUtils.isEmpty(r11)     // Catch:{ Exception -> 0x0af6 }
            if (r12 == 0) goto L_0x0af6
            java.lang.CharSequence r12 = r0.getContentDescription()     // Catch:{ Exception -> 0x0af6 }
            java.lang.String r11 = r12.toString()     // Catch:{ Exception -> 0x0af6 }
        L_0x0af6:
            r12 = -481329364706485964(0xf951f97e34b49934, double:-2.489286228567633E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329472080668364(0xf951f96534b49934, double:-2.4892333991145197E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329562274981580(0xf951f95034b49934, double:-2.4891890223739043E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329648174327500(0xf951f93c34b49934, double:-2.4891467588114134E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329695418967756(0xf951f93134b49934, double:-2.4891235138520434E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329789908248268(0xf951f91b34b49934, double:-2.4890770239333035E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329880102561484(0xf951f90634b49934, double:-2.489032647192688E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481329974591841996(0xf951f8f034b49934, double:-2.488986157273948E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330056196220620(0xf951f8dd34b49934, double:-2.488946006889582E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330112030795468(0xf951f8d034b49934, double:-2.488918535573963E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330150685501132(0xf951f8c734b49934, double:-2.488899516970842E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330197930141388(0xf951f8bc34b49934, double:-2.488876272011472E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330309599291084(0xf951f8a234b49934, double:-2.488821329380234E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330343959029452(0xf951f89a34b49934, double:-2.4888044239552375E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.contains(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330378318767820(0xf951f89234b49934, double:-2.488787518530241E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.equals(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            r12 = -481330421268440780(0xf951f88834b49934, double:-2.4887663867489957E276)
            java.lang.String r12 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            boolean r12 = r11.equals(r12)     // Catch:{ Exception -> 0x0d32 }
            if (r12 == 0) goto L_0x0be8
            goto L_0x0d32
        L_0x0be8:
            java.util.regex.Pattern r12 = r1.f1641b     // Catch:{ Exception -> 0x0d32 }
            java.util.regex.Matcher r12 = r12.matcher(r11)     // Catch:{ Exception -> 0x0d32 }
            java.util.regex.Pattern r13 = r1.f1641b     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r14 = r10.getText()     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r14 = r14.toString()     // Catch:{ Exception -> 0x0d32 }
            java.util.regex.Matcher r13 = r13.matcher(r14)     // Catch:{ Exception -> 0x0d32 }
            boolean r13 = r13.find()     // Catch:{ Exception -> 0x0d32 }
            if (r13 == 0) goto L_0x0d32
            boolean r12 = r12.find()     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            android.graphics.Rect r12 = new android.graphics.Rect     // Catch:{ Exception -> 0x0c2e }
            r12.<init>()     // Catch:{ Exception -> 0x0c2e }
            r0.getBoundsInScreen(r12)     // Catch:{ Exception -> 0x0c2e }
            java.util.regex.Pattern r0 = r1.f1640a     // Catch:{ Exception -> 0x0c2e }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x0c2e }
            java.util.regex.Matcher r0 = r0.matcher(r12)     // Catch:{ Exception -> 0x0c2e }
            boolean r12 = r0.find()     // Catch:{ Exception -> 0x0c2e }
            if (r12 == 0) goto L_0x0c32
            java.lang.String r0 = r0.group(r5)     // Catch:{ Exception -> 0x0c2e }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x0c2e }
            r12 = 100
            if (r0 >= r12) goto L_0x0c32
            r0 = 0
            goto L_0x0c33
        L_0x0c2e:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x0d32 }
        L_0x0c32:
            r0 = 1
        L_0x0c33:
            boolean r12 = android.text.TextUtils.isEmpty(r11)     // Catch:{ Exception -> 0x0d32 }
            if (r12 != 0) goto L_0x0d32
            java.util.Calendar r12 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x0d32 }
            r13 = -481330442743277260(0xf951f88334b49934, double:-2.488755820858373E276)
            java.lang.String r13 = defpackage.wx1.a(r13)     // Catch:{ Exception -> 0x0d32 }
            java.util.TimeZone r13 = java.util.TimeZone.getTimeZone(r13)     // Catch:{ Exception -> 0x0d32 }
            r12.setTimeZone(r13)     // Catch:{ Exception -> 0x0d32 }
            zv1 r13 = new zv1     // Catch:{ Exception -> 0x0d32 }
            r13.<init>()     // Catch:{ Exception -> 0x0d32 }
            java.util.UUID r14 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x0d32 }
            r13.l(r14)     // Catch:{ Exception -> 0x0d32 }
            r13.o(r6)     // Catch:{ Exception -> 0x0d32 }
            r13.m(r11)     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r14 = r10.getText()     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r14 = r14.toString()     // Catch:{ Exception -> 0x0d32 }
            r13.p(r14)     // Catch:{ Exception -> 0x0d32 }
            r13.q(r0)     // Catch:{ Exception -> 0x0d32 }
            long r21 = r12.getTimeInMillis()     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r14 = defpackage.ox1.b(r21)     // Catch:{ Exception -> 0x0d32 }
            r13.j(r14)     // Catch:{ Exception -> 0x0d32 }
            long r4 = r12.getTimeInMillis()     // Catch:{ Exception -> 0x0d32 }
            r13.k(r4)     // Catch:{ Exception -> 0x0d32 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0d32 }
            r4.<init>()     // Catch:{ Exception -> 0x0d32 }
            r22 = -481330459923146444(0xf951f87f34b49934, double:-2.488747368145875E276)
            java.lang.String r5 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0d32 }
            r22 = -481330515757721292(0xf951f87234b49934, double:-2.488719896830256E276)
            java.lang.String r14 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r5 = r6.replaceAll(r5, r14)     // Catch:{ Exception -> 0x0d32 }
            r4.append(r5)     // Catch:{ Exception -> 0x0d32 }
            r22 = -481330520052688588(0xf951f87134b49934, double:-2.488717783652131E276)
            java.lang.String r5 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0d32 }
            r22 = -481330575887263436(0xf951f86434b49934, double:-2.488690312336512E276)
            java.lang.String r14 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r5 = r11.replaceAll(r5, r14)     // Catch:{ Exception -> 0x0d32 }
            r4.append(r5)     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x0d32 }
            r13.n(r4)     // Catch:{ Exception -> 0x0d32 }
            java.lang.Class<zv1> r4 = defpackage.zv1.class
            ys1 r4 = com.raizlabs.android.dbflow.config.FlowManager.f(r4)     // Catch:{ Exception -> 0x0d32 }
            r4.C(r13)     // Catch:{ Exception -> 0x0d32 }
            r4 = -481330580182230732(0xf951f86334b49934, double:-2.4886881991583876E276)
            java.lang.String r4 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x0d32 }
            r5 = 6
            java.lang.Object[] r13 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r5 = r26.getPackageName()     // Catch:{ Exception -> 0x0d32 }
            r14 = 0
            r13[r14] = r5     // Catch:{ Exception -> 0x0d32 }
            r5 = 1
            r13[r5] = r6     // Catch:{ Exception -> 0x0d32 }
            long r22 = r12.getTimeInMillis()     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r5 = defpackage.ox1.b(r22)     // Catch:{ Exception -> 0x0d32 }
            r12 = 2
            r13[r12] = r5     // Catch:{ Exception -> 0x0d32 }
            r5 = 3
            r13[r5] = r11     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r5 = r10.getText()     // Catch:{ Exception -> 0x0d32 }
            r12 = 4
            r13[r12] = r5     // Catch:{ Exception -> 0x0d32 }
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch:{ Exception -> 0x0d32 }
            r5 = 5
            r13[r5] = r0     // Catch:{ Exception -> 0x0d32 }
            defpackage.o82.d(r4, r13)     // Catch:{ Exception -> 0x0d32 }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x0d32 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0d32 }
            r4.<init>()     // Catch:{ Exception -> 0x0d32 }
            r4.append(r6)     // Catch:{ Exception -> 0x0d32 }
            r12 = -481330880829941452(0xf951f81d34b49934, double:-2.4885402766896697E276)
            java.lang.String r5 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x0d32 }
            r4.append(r5)     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x0d32 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0d32 }
            r5.<init>()     // Catch:{ Exception -> 0x0d32 }
            r5.append(r11)     // Catch:{ Exception -> 0x0d32 }
            java.lang.CharSequence r10 = r10.getText()     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0d32 }
            r5.append(r10)     // Catch:{ Exception -> 0x0d32 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0d32 }
            r0.put(r4, r5)     // Catch:{ Exception -> 0x0d32 }
            int r9 = r9 + 2
            goto L_0x0d33
        L_0x0d32:
            r9 = r8
        L_0x0d33:
            r4 = 0
            r5 = 1
            goto L_0x0aad
        L_0x0d37:
            r2.recycle()     // Catch:{ Exception -> 0x0d3b }
            goto L_0x0d3f
        L_0x0d3b:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x0d3f:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481330936664516300(0xf951f81034b49934, double:-2.4885128053740506E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x0efb
            android.view.accessibility.AccessibilityNodeInfo r2 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x0ef7 }
            if (r2 != 0) goto L_0x0d5d
            return
        L_0x0d5d:
            r2.refresh()     // Catch:{ Exception -> 0x0ef7 }
            r3 = -481330983909156556(0xf951f80534b49934, double:-2.4884895604146806E276)
            java.lang.String r0 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x0ef7 }
            r2.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x0ef7 }
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ Exception -> 0x0ef7 }
            r3.<init>()     // Catch:{ Exception -> 0x0ef7 }
            java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ Exception -> 0x0ef7 }
            r0.<init>()     // Catch:{ Exception -> 0x0ef7 }
            r1.i(r2, r3, r0)     // Catch:{ Exception -> 0x0ef7 }
            int r4 = r3.size()     // Catch:{ Exception -> 0x0ef7 }
            r5 = 2
            if (r4 < r5) goto L_0x0ef3
            int r4 = r0.size()     // Catch:{ Exception -> 0x0ef7 }
            if (r4 <= 0) goto L_0x0ef3
            java.lang.CharSequence r4 = r26.getPackageName()     // Catch:{ Exception -> 0x0ef7 }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x0ef7 }
            r5 = -481331112758175436(0xf951f7e734b49934, double:-2.4884261650709444E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x0ef7 }
            boolean r4 = r4.contains(r5)     // Catch:{ Exception -> 0x0ef7 }
            if (r4 == 0) goto L_0x0ef3
            r4 = 0
            java.lang.Object r0 = r0.get(r4)     // Catch:{ Exception -> 0x0ef7 }
            r4 = r0
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x0ef7 }
            boolean r0 = r4.isEmpty()     // Catch:{ Exception -> 0x0ef7 }
            if (r0 != 0) goto L_0x0ef3
            r5 = 0
        L_0x0dac:
            int r0 = r3.size()     // Catch:{ Exception -> 0x0ef7 }
            if (r5 >= r0) goto L_0x0ef3
            r6 = -481331160002815692(0xf951f7dc34b49934, double:-2.4884029201115744E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x0eed }
            java.lang.Object r0 = r3.get(r5)     // Catch:{ Exception -> 0x0eed }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x0eed }
            java.lang.CharSequence r7 = r0.getText()     // Catch:{ Exception -> 0x0eed }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x0eed }
            android.graphics.Rect r8 = new android.graphics.Rect     // Catch:{ Exception -> 0x0df3 }
            r8.<init>()     // Catch:{ Exception -> 0x0df3 }
            r0.getBoundsInScreen(r8)     // Catch:{ Exception -> 0x0df3 }
            java.util.regex.Pattern r0 = r1.f1640a     // Catch:{ Exception -> 0x0df3 }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x0df3 }
            java.util.regex.Matcher r0 = r0.matcher(r8)     // Catch:{ Exception -> 0x0df3 }
            boolean r8 = r0.find()     // Catch:{ Exception -> 0x0df3 }
            if (r8 == 0) goto L_0x0df0
            r8 = 1
            java.lang.String r0 = r0.group(r8)     // Catch:{ Exception -> 0x0df3 }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x0df3 }
            r8 = 150(0x96, float:2.1E-43)
            if (r0 >= r8) goto L_0x0df9
            r0 = 0
            goto L_0x0dfa
        L_0x0df0:
            r8 = 150(0x96, float:2.1E-43)
            goto L_0x0df9
        L_0x0df3:
            r0 = move-exception
            r8 = 150(0x96, float:2.1E-43)
            r0.printStackTrace()     // Catch:{ Exception -> 0x0eef }
        L_0x0df9:
            r0 = 1
        L_0x0dfa:
            java.util.Calendar r9 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x0eef }
            r10 = -481331185772619468(0xf951f7d634b49934, double:-2.488390241042827E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x0eef }
            java.util.TimeZone r10 = java.util.TimeZone.getTimeZone(r10)     // Catch:{ Exception -> 0x0eef }
            r9.setTimeZone(r10)     // Catch:{ Exception -> 0x0eef }
            tv1 r10 = new tv1     // Catch:{ Exception -> 0x0eef }
            r10.<init>()     // Catch:{ Exception -> 0x0eef }
            java.util.UUID r11 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x0eef }
            r10.l(r11)     // Catch:{ Exception -> 0x0eef }
            r10.o(r4)     // Catch:{ Exception -> 0x0eef }
            r10.m(r7)     // Catch:{ Exception -> 0x0eef }
            r10.p(r6)     // Catch:{ Exception -> 0x0eef }
            r10.q(r0)     // Catch:{ Exception -> 0x0eef }
            long r11 = r9.getTimeInMillis()     // Catch:{ Exception -> 0x0eef }
            java.lang.String r0 = defpackage.ox1.b(r11)     // Catch:{ Exception -> 0x0eef }
            r10.j(r0)     // Catch:{ Exception -> 0x0eef }
            long r11 = r9.getTimeInMillis()     // Catch:{ Exception -> 0x0eef }
            r10.k(r11)     // Catch:{ Exception -> 0x0eef }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0eef }
            r0.<init>()     // Catch:{ Exception -> 0x0eef }
            r11 = -481331202952488652(0xf951f7d234b49934, double:-2.488381788330329E276)
            java.lang.String r6 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0eef }
            r11 = -481331258787063500(0xf951f7c534b49934, double:-2.48835431701471E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r4.replaceAll(r6, r9)     // Catch:{ Exception -> 0x0eef }
            r0.append(r6)     // Catch:{ Exception -> 0x0eef }
            r11 = -481331263082030796(0xf951f7c434b49934, double:-2.4883522038365854E276)
            java.lang.String r6 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0eef }
            r11 = -481331318916605644(0xf951f7b734b49934, double:-2.4883247325209663E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r7.replaceAll(r6, r9)     // Catch:{ Exception -> 0x0eef }
            r0.append(r6)     // Catch:{ Exception -> 0x0eef }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0eef }
            r10.n(r0)     // Catch:{ Exception -> 0x0eef }
            java.lang.Class<tv1> r0 = defpackage.tv1.class
            ys1 r0 = com.raizlabs.android.dbflow.config.FlowManager.f(r0)     // Catch:{ Exception -> 0x0eef }
            r0.C(r10)     // Catch:{ Exception -> 0x0eef }
            r11 = -481331323211572940(0xf951f7b634b49934, double:-2.488322619342842E276)
            java.lang.String r0 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0eef }
            r6 = 6
            java.lang.Object[] r9 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x0eef }
            java.lang.CharSequence r6 = r26.getPackageName()     // Catch:{ Exception -> 0x0eef }
            r11 = 0
            r9[r11] = r6     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r10.g()     // Catch:{ Exception -> 0x0eef }
            r11 = 1
            r9[r11] = r6     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r10.c()     // Catch:{ Exception -> 0x0eef }
            r11 = 2
            r9[r11] = r6     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r10.e()     // Catch:{ Exception -> 0x0eef }
            r11 = 3
            r9[r11] = r6     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r10.h()     // Catch:{ Exception -> 0x0eef }
            r11 = 4
            r9[r11] = r6     // Catch:{ Exception -> 0x0eef }
            int r6 = r10.i()     // Catch:{ Exception -> 0x0eef }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ Exception -> 0x0eef }
            r11 = 5
            r9[r11] = r6     // Catch:{ Exception -> 0x0eef }
            defpackage.o82.d(r0, r9)     // Catch:{ Exception -> 0x0eef }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x0eef }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0eef }
            r6.<init>()     // Catch:{ Exception -> 0x0eef }
            r6.append(r4)     // Catch:{ Exception -> 0x0eef }
            r11 = -481331623859283660(0xf951f77034b49934, double:-2.488174696874124E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x0eef }
            r6.append(r9)     // Catch:{ Exception -> 0x0eef }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x0eef }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0eef }
            r9.<init>()     // Catch:{ Exception -> 0x0eef }
            r9.append(r7)     // Catch:{ Exception -> 0x0eef }
            java.lang.String r7 = r10.h()     // Catch:{ Exception -> 0x0eef }
            r9.append(r7)     // Catch:{ Exception -> 0x0eef }
            java.lang.String r7 = r9.toString()     // Catch:{ Exception -> 0x0eef }
            r0.put(r6, r7)     // Catch:{ Exception -> 0x0eef }
            goto L_0x0eef
        L_0x0eed:
            r8 = 150(0x96, float:2.1E-43)
        L_0x0eef:
            int r5 = r5 + 1
            goto L_0x0dac
        L_0x0ef3:
            r2.recycle()     // Catch:{ Exception -> 0x0ef7 }
            goto L_0x0efb
        L_0x0ef7:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x0efb:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481331671103923916(0xf951f76534b49934, double:-2.488151451914754E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x10af
            android.view.accessibility.AccessibilityNodeInfo r2 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x10ab }
            if (r2 != 0) goto L_0x0f19
            return
        L_0x0f19:
            r2.refresh()     // Catch:{ Exception -> 0x10ab }
            r3 = -481331735528433356(0xf951f75634b49934, double:-2.4881197542428857E276)
            java.lang.String r0 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x10ab }
            r2.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x10ab }
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ Exception -> 0x10ab }
            r3.<init>()     // Catch:{ Exception -> 0x10ab }
            java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ Exception -> 0x10ab }
            r0.<init>()     // Catch:{ Exception -> 0x10ab }
            r1.e(r2, r3, r0)     // Catch:{ Exception -> 0x10ab }
            int r4 = r3.size()     // Catch:{ Exception -> 0x10ab }
            r5 = 2
            if (r4 < r5) goto L_0x10a7
            int r4 = r0.size()     // Catch:{ Exception -> 0x10ab }
            if (r4 <= 0) goto L_0x10a7
            java.lang.CharSequence r4 = r26.getPackageName()     // Catch:{ Exception -> 0x10ab }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x10ab }
            r5 = -481331864377452236(0xf951f73834b49934, double:-2.4880563588991494E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x10ab }
            boolean r4 = r4.contains(r5)     // Catch:{ Exception -> 0x10ab }
            if (r4 == 0) goto L_0x10a7
            r4 = 0
            java.lang.Object r0 = r0.get(r4)     // Catch:{ Exception -> 0x10ab }
            r4 = r0
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x10ab }
            boolean r0 = r4.isEmpty()     // Catch:{ Exception -> 0x10ab }
            if (r0 != 0) goto L_0x10a7
            r5 = 0
        L_0x0f68:
            int r0 = r3.size()     // Catch:{ Exception -> 0x10ab }
            if (r5 >= r0) goto L_0x10a7
            r6 = -481331928801961676(0xf951f72934b49934, double:-2.4880246612272813E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x10a3 }
            java.lang.Object r0 = r3.get(r5)     // Catch:{ Exception -> 0x10a3 }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x10a3 }
            java.lang.CharSequence r7 = r0.getText()     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x10a3 }
            android.graphics.Rect r8 = new android.graphics.Rect     // Catch:{ Exception -> 0x0fac }
            r8.<init>()     // Catch:{ Exception -> 0x0fac }
            r0.getBoundsInScreen(r8)     // Catch:{ Exception -> 0x0fac }
            java.util.regex.Pattern r0 = r1.f1640a     // Catch:{ Exception -> 0x0fac }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x0fac }
            java.util.regex.Matcher r0 = r0.matcher(r8)     // Catch:{ Exception -> 0x0fac }
            boolean r8 = r0.find()     // Catch:{ Exception -> 0x0fac }
            if (r8 == 0) goto L_0x0fb0
            r8 = 1
            java.lang.String r0 = r0.group(r8)     // Catch:{ Exception -> 0x0fac }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x0fac }
            r8 = 137(0x89, float:1.92E-43)
            if (r0 >= r8) goto L_0x0fb0
            r0 = 0
            goto L_0x0fb1
        L_0x0fac:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x10a3 }
        L_0x0fb0:
            r0 = 1
        L_0x0fb1:
            java.util.Calendar r8 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x10a3 }
            r9 = -481331954571765452(0xf951f72334b49934, double:-2.488011982158534E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x10a3 }
            java.util.TimeZone r9 = java.util.TimeZone.getTimeZone(r9)     // Catch:{ Exception -> 0x10a3 }
            r8.setTimeZone(r9)     // Catch:{ Exception -> 0x10a3 }
            fv1 r9 = new fv1     // Catch:{ Exception -> 0x10a3 }
            r9.<init>()     // Catch:{ Exception -> 0x10a3 }
            java.util.UUID r10 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x10a3 }
            r9.l(r10)     // Catch:{ Exception -> 0x10a3 }
            r9.o(r4)     // Catch:{ Exception -> 0x10a3 }
            r9.m(r7)     // Catch:{ Exception -> 0x10a3 }
            r9.p(r6)     // Catch:{ Exception -> 0x10a3 }
            r9.q(r0)     // Catch:{ Exception -> 0x10a3 }
            long r10 = r8.getTimeInMillis()     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r0 = defpackage.ox1.b(r10)     // Catch:{ Exception -> 0x10a3 }
            r9.j(r0)     // Catch:{ Exception -> 0x10a3 }
            long r10 = r8.getTimeInMillis()     // Catch:{ Exception -> 0x10a3 }
            r9.k(r10)     // Catch:{ Exception -> 0x10a3 }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x10a3 }
            r0.<init>()     // Catch:{ Exception -> 0x10a3 }
            r10 = -481331971751634636(0xf951f71f34b49934, double:-2.488003529446036E276)
            java.lang.String r6 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x10a3 }
            r10 = -481332027586209484(0xf951f71234b49934, double:-2.487976058130417E276)
            java.lang.String r8 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r4.replaceAll(r6, r8)     // Catch:{ Exception -> 0x10a3 }
            r0.append(r6)     // Catch:{ Exception -> 0x10a3 }
            r10 = -481332031881176780(0xf951f71134b49934, double:-2.487973944952292E276)
            java.lang.String r6 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x10a3 }
            r10 = -481332087715751628(0xf951f70434b49934, double:-2.487946473636673E276)
            java.lang.String r8 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r7.replaceAll(r6, r8)     // Catch:{ Exception -> 0x10a3 }
            r0.append(r6)     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x10a3 }
            r9.n(r0)     // Catch:{ Exception -> 0x10a3 }
            java.lang.Class<fv1> r0 = defpackage.fv1.class
            ys1 r0 = com.raizlabs.android.dbflow.config.FlowManager.f(r0)     // Catch:{ Exception -> 0x10a3 }
            r0.C(r9)     // Catch:{ Exception -> 0x10a3 }
            r10 = -481332092010718924(0xf951f70334b49934, double:-2.4879443604585486E276)
            java.lang.String r0 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x10a3 }
            r6 = 6
            java.lang.Object[] r8 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x10a3 }
            java.lang.CharSequence r6 = r26.getPackageName()     // Catch:{ Exception -> 0x10a3 }
            r10 = 0
            r8[r10] = r6     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r9.g()     // Catch:{ Exception -> 0x10a3 }
            r10 = 1
            r8[r10] = r6     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r9.c()     // Catch:{ Exception -> 0x10a3 }
            r10 = 2
            r8[r10] = r6     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r9.e()     // Catch:{ Exception -> 0x10a3 }
            r10 = 3
            r8[r10] = r6     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r9.h()     // Catch:{ Exception -> 0x10a3 }
            r10 = 4
            r8[r10] = r6     // Catch:{ Exception -> 0x10a3 }
            int r6 = r9.i()     // Catch:{ Exception -> 0x10a3 }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ Exception -> 0x10a3 }
            r10 = 5
            r8[r10] = r6     // Catch:{ Exception -> 0x10a3 }
            defpackage.o82.d(r0, r8)     // Catch:{ Exception -> 0x10a3 }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x10a3 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x10a3 }
            r6.<init>()     // Catch:{ Exception -> 0x10a3 }
            r6.append(r4)     // Catch:{ Exception -> 0x10a3 }
            r10 = -481332392658429644(0xf951f6bd34b49934, double:-2.4877964379898306E276)
            java.lang.String r8 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x10a3 }
            r6.append(r8)     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x10a3 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x10a3 }
            r8.<init>()     // Catch:{ Exception -> 0x10a3 }
            r8.append(r7)     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r7 = r9.h()     // Catch:{ Exception -> 0x10a3 }
            r8.append(r7)     // Catch:{ Exception -> 0x10a3 }
            java.lang.String r7 = r8.toString()     // Catch:{ Exception -> 0x10a3 }
            r0.put(r6, r7)     // Catch:{ Exception -> 0x10a3 }
        L_0x10a3:
            int r5 = r5 + 1
            goto L_0x0f68
        L_0x10a7:
            r2.recycle()     // Catch:{ Exception -> 0x10ab }
            goto L_0x10af
        L_0x10ab:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x10af:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481332457082939084(0xf951f6ae34b49934, double:-2.4877647403179625E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            r2 = 620(0x26c, float:8.69E-43)
            r3 = 110(0x6e, float:1.54E-43)
            if (r0 == 0) goto L_0x1288
            android.view.accessibility.AccessibilityNodeInfo r4 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x1284 }
            if (r4 != 0) goto L_0x10d1
            return
        L_0x10d1:
            r4.refresh()     // Catch:{ Exception -> 0x1284 }
            r5 = -481332564457121484(0xf951f69534b49934, double:-2.487711910864849E276)
            java.lang.String r0 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x1284 }
            java.util.List r0 = r4.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x1284 }
            java.util.ArrayList r5 = new java.util.ArrayList     // Catch:{ Exception -> 0x1284 }
            r5.<init>()     // Catch:{ Exception -> 0x1284 }
            java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ Exception -> 0x1284 }
            r6.<init>()     // Catch:{ Exception -> 0x1284 }
            r1.h(r4, r5, r6)     // Catch:{ Exception -> 0x1284 }
            int r7 = r5.size()     // Catch:{ Exception -> 0x1284 }
            r8 = 1
            if (r7 < r8) goto L_0x1280
            int r7 = r6.size()     // Catch:{ Exception -> 0x1284 }
            if (r7 <= 0) goto L_0x1280
            int r0 = r0.size()     // Catch:{ Exception -> 0x1284 }
            if (r0 != 0) goto L_0x1280
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x1284 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x1284 }
            r7 = -481332693306140364(0xf951f67734b49934, double:-2.4876485155211127E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x1284 }
            boolean r0 = r0.contains(r7)     // Catch:{ Exception -> 0x1284 }
            if (r0 == 0) goto L_0x1280
            r7 = 0
            java.lang.Object r0 = r6.get(r7)     // Catch:{ Exception -> 0x1284 }
            r6 = r0
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ Exception -> 0x1284 }
            boolean r0 = r6.isEmpty()     // Catch:{ Exception -> 0x1284 }
            if (r0 != 0) goto L_0x1280
            r7 = 0
        L_0x1127:
            int r0 = r5.size()     // Catch:{ Exception -> 0x1284 }
            if (r7 >= r0) goto L_0x1280
            r8 = -481332800680322764(0xf951f65e34b49934, double:-2.487595686067999E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x127c }
            java.lang.Object r0 = r5.get(r7)     // Catch:{ Exception -> 0x127c }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x127c }
            java.lang.CharSequence r9 = r0.getText()     // Catch:{ Exception -> 0x127c }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x127c }
            android.graphics.Rect r10 = new android.graphics.Rect     // Catch:{ Exception -> 0x1174 }
            r10.<init>()     // Catch:{ Exception -> 0x1174 }
            r0.getBoundsInScreen(r10)     // Catch:{ Exception -> 0x1174 }
            java.util.regex.Pattern r0 = r1.f1640a     // Catch:{ Exception -> 0x1174 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x1174 }
            java.util.regex.Matcher r0 = r0.matcher(r10)     // Catch:{ Exception -> 0x1174 }
            boolean r10 = r0.find()     // Catch:{ Exception -> 0x1174 }
            if (r10 == 0) goto L_0x1178
            r10 = 1
            java.lang.String r11 = r0.group(r10)     // Catch:{ Exception -> 0x1174 }
            int r10 = java.lang.Integer.parseInt(r11)     // Catch:{ Exception -> 0x1174 }
            r11 = 3
            java.lang.String r0 = r0.group(r11)     // Catch:{ Exception -> 0x1174 }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x1174 }
            if (r10 >= r3) goto L_0x1178
            if (r0 == r2) goto L_0x1178
            r0 = 0
            goto L_0x1179
        L_0x1174:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x127c }
        L_0x1178:
            r0 = 1
        L_0x1179:
            java.util.Calendar r10 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x127c }
            r11 = -481332826450126540(0xf951f65834b49934, double:-2.487583006999252E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x127c }
            java.util.TimeZone r11 = java.util.TimeZone.getTimeZone(r11)     // Catch:{ Exception -> 0x127c }
            r10.setTimeZone(r11)     // Catch:{ Exception -> 0x127c }
            rv1 r11 = new rv1     // Catch:{ Exception -> 0x127c }
            r11.<init>()     // Catch:{ Exception -> 0x127c }
            java.util.UUID r12 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x127c }
            r11.l(r12)     // Catch:{ Exception -> 0x127c }
            r11.o(r6)     // Catch:{ Exception -> 0x127c }
            r11.m(r9)     // Catch:{ Exception -> 0x127c }
            r11.p(r8)     // Catch:{ Exception -> 0x127c }
            r11.q(r0)     // Catch:{ Exception -> 0x127c }
            long r12 = r10.getTimeInMillis()     // Catch:{ Exception -> 0x127c }
            java.lang.String r0 = defpackage.ox1.b(r12)     // Catch:{ Exception -> 0x127c }
            r11.j(r0)     // Catch:{ Exception -> 0x127c }
            long r12 = r10.getTimeInMillis()     // Catch:{ Exception -> 0x127c }
            r11.k(r12)     // Catch:{ Exception -> 0x127c }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x127c }
            r0.<init>()     // Catch:{ Exception -> 0x127c }
            r12 = -481332843629995724(0xf951f65434b49934, double:-2.4875745542867537E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            r12 = -481332899464570572(0xf951f64734b49934, double:-2.4875470829711346E276)
            java.lang.String r10 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r6.replaceAll(r8, r10)     // Catch:{ Exception -> 0x127c }
            r0.append(r8)     // Catch:{ Exception -> 0x127c }
            r12 = -481332903759537868(0xf951f64634b49934, double:-2.48754496979301E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            r12 = -481332959594112716(0xf951f63934b49934, double:-2.487517498477391E276)
            java.lang.String r10 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r9.replaceAll(r8, r10)     // Catch:{ Exception -> 0x127c }
            r0.append(r8)     // Catch:{ Exception -> 0x127c }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x127c }
            r11.n(r0)     // Catch:{ Exception -> 0x127c }
            java.lang.Class<rv1> r0 = defpackage.rv1.class
            ys1 r0 = com.raizlabs.android.dbflow.config.FlowManager.f(r0)     // Catch:{ Exception -> 0x127c }
            r0.C(r11)     // Catch:{ Exception -> 0x127c }
            r12 = -481332963889080012(0xf951f63834b49934, double:-2.4875153852992665E276)
            java.lang.String r0 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            r8 = 6
            java.lang.Object[] r10 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x127c }
            java.lang.CharSequence r8 = r26.getPackageName()     // Catch:{ Exception -> 0x127c }
            r12 = 0
            r10[r12] = r8     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r11.g()     // Catch:{ Exception -> 0x127c }
            r12 = 1
            r10[r12] = r8     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r11.c()     // Catch:{ Exception -> 0x127c }
            r12 = 2
            r10[r12] = r8     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r11.e()     // Catch:{ Exception -> 0x127c }
            r12 = 3
            r10[r12] = r8     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r11.h()     // Catch:{ Exception -> 0x127c }
            r12 = 4
            r10[r12] = r8     // Catch:{ Exception -> 0x127c }
            int r8 = r11.i()     // Catch:{ Exception -> 0x127c }
            if (r8 != 0) goto L_0x123d
            r12 = -481333264536790732(0xf951f5f234b49934, double:-2.4873674628305485E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            goto L_0x1246
        L_0x123d:
            r12 = -481333303191496396(0xf951f5e934b49934, double:-2.4873484442274276E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
        L_0x1246:
            r12 = 5
            r10[r12] = r8     // Catch:{ Exception -> 0x127c }
            defpackage.o82.d(r0, r10)     // Catch:{ Exception -> 0x127c }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x127c }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x127c }
            r8.<init>()     // Catch:{ Exception -> 0x127c }
            r8.append(r6)     // Catch:{ Exception -> 0x127c }
            r12 = -481333337551234764(0xf951f5e134b49934, double:-2.4873315388024313E276)
            java.lang.String r10 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x127c }
            r8.append(r10)     // Catch:{ Exception -> 0x127c }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x127c }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x127c }
            r10.<init>()     // Catch:{ Exception -> 0x127c }
            r10.append(r9)     // Catch:{ Exception -> 0x127c }
            java.lang.String r9 = r11.h()     // Catch:{ Exception -> 0x127c }
            r10.append(r9)     // Catch:{ Exception -> 0x127c }
            java.lang.String r9 = r10.toString()     // Catch:{ Exception -> 0x127c }
            r0.put(r8, r9)     // Catch:{ Exception -> 0x127c }
        L_0x127c:
            int r7 = r7 + 1
            goto L_0x1127
        L_0x1280:
            r4.recycle()     // Catch:{ Exception -> 0x1284 }
            goto L_0x1288
        L_0x1284:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x1288:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r4 = -481333444925417164(0xf951f5c834b49934, double:-2.4872787093493177E276)
            java.lang.String r4 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r4)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x145d
            android.view.accessibility.AccessibilityNodeInfo r4 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x1459 }
            if (r4 != 0) goto L_0x12a6
            return
        L_0x12a6:
            r4.refresh()     // Catch:{ Exception -> 0x1459 }
            r5 = -481333517939861196(0xf951f5b734b49934, double:-2.4872427853212005E276)
            java.lang.String r0 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x1459 }
            java.util.List r0 = r4.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x1459 }
            java.util.ArrayList r5 = new java.util.ArrayList     // Catch:{ Exception -> 0x1459 }
            r5.<init>()     // Catch:{ Exception -> 0x1459 }
            java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ Exception -> 0x1459 }
            r6.<init>()     // Catch:{ Exception -> 0x1459 }
            r1.a(r4, r5, r6)     // Catch:{ Exception -> 0x1459 }
            int r7 = r5.size()     // Catch:{ Exception -> 0x1459 }
            r8 = 1
            if (r7 < r8) goto L_0x1455
            int r7 = r6.size()     // Catch:{ Exception -> 0x1459 }
            if (r7 <= 0) goto L_0x1455
            int r0 = r0.size()     // Catch:{ Exception -> 0x1459 }
            if (r0 != 0) goto L_0x1455
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x1459 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x1459 }
            r7 = -481333590954305228(0xf951f5a634b49934, double:-2.487206861293083E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x1459 }
            boolean r0 = r0.contains(r7)     // Catch:{ Exception -> 0x1459 }
            if (r0 == 0) goto L_0x1455
            r7 = 0
            java.lang.Object r0 = r6.get(r7)     // Catch:{ Exception -> 0x1459 }
            r6 = r0
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ Exception -> 0x1459 }
            boolean r0 = r6.isEmpty()     // Catch:{ Exception -> 0x1459 }
            if (r0 != 0) goto L_0x1455
            r7 = 0
        L_0x12fc:
            int r0 = r5.size()     // Catch:{ Exception -> 0x1459 }
            if (r7 >= r0) goto L_0x1455
            r8 = -481333663968749260(0xf951f59534b49934, double:-2.487170937264966E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x1451 }
            java.lang.Object r0 = r5.get(r7)     // Catch:{ Exception -> 0x1451 }
            android.view.accessibility.AccessibilityNodeInfo r0 = (android.view.accessibility.AccessibilityNodeInfo) r0     // Catch:{ Exception -> 0x1451 }
            java.lang.CharSequence r9 = r0.getText()     // Catch:{ Exception -> 0x1451 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x1451 }
            android.graphics.Rect r10 = new android.graphics.Rect     // Catch:{ Exception -> 0x1349 }
            r10.<init>()     // Catch:{ Exception -> 0x1349 }
            r0.getBoundsInScreen(r10)     // Catch:{ Exception -> 0x1349 }
            java.util.regex.Pattern r0 = r1.f1640a     // Catch:{ Exception -> 0x1349 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x1349 }
            java.util.regex.Matcher r0 = r0.matcher(r10)     // Catch:{ Exception -> 0x1349 }
            boolean r10 = r0.find()     // Catch:{ Exception -> 0x1349 }
            if (r10 == 0) goto L_0x134d
            r10 = 1
            java.lang.String r11 = r0.group(r10)     // Catch:{ Exception -> 0x1349 }
            int r10 = java.lang.Integer.parseInt(r11)     // Catch:{ Exception -> 0x1349 }
            r11 = 3
            java.lang.String r0 = r0.group(r11)     // Catch:{ Exception -> 0x1349 }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ Exception -> 0x1349 }
            if (r10 >= r3) goto L_0x134d
            if (r0 == r2) goto L_0x134d
            r0 = 0
            goto L_0x134e
        L_0x1349:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x1451 }
        L_0x134d:
            r0 = 1
        L_0x134e:
            java.util.Calendar r10 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x1451 }
            r11 = -481333689738553036(0xf951f58f34b49934, double:-2.487158258196219E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x1451 }
            java.util.TimeZone r11 = java.util.TimeZone.getTimeZone(r11)     // Catch:{ Exception -> 0x1451 }
            r10.setTimeZone(r11)     // Catch:{ Exception -> 0x1451 }
            ru1 r11 = new ru1     // Catch:{ Exception -> 0x1451 }
            r11.<init>()     // Catch:{ Exception -> 0x1451 }
            java.util.UUID r12 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x1451 }
            r11.l(r12)     // Catch:{ Exception -> 0x1451 }
            r11.o(r6)     // Catch:{ Exception -> 0x1451 }
            r11.m(r9)     // Catch:{ Exception -> 0x1451 }
            r11.p(r8)     // Catch:{ Exception -> 0x1451 }
            r11.q(r0)     // Catch:{ Exception -> 0x1451 }
            long r12 = r10.getTimeInMillis()     // Catch:{ Exception -> 0x1451 }
            java.lang.String r0 = defpackage.ox1.b(r12)     // Catch:{ Exception -> 0x1451 }
            r11.j(r0)     // Catch:{ Exception -> 0x1451 }
            long r12 = r10.getTimeInMillis()     // Catch:{ Exception -> 0x1451 }
            r11.k(r12)     // Catch:{ Exception -> 0x1451 }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x1451 }
            r0.<init>()     // Catch:{ Exception -> 0x1451 }
            r12 = -481333706918422220(0xf951f58b34b49934, double:-2.4871498054837206E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            r12 = -481333762752997068(0xf951f57e34b49934, double:-2.4871223341681015E276)
            java.lang.String r10 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r6.replaceAll(r8, r10)     // Catch:{ Exception -> 0x1451 }
            r0.append(r8)     // Catch:{ Exception -> 0x1451 }
            r12 = -481333767047964364(0xf951f57d34b49934, double:-2.487120220989977E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            r12 = -481333822882539212(0xf951f57034b49934, double:-2.487092749674358E276)
            java.lang.String r10 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r9.replaceAll(r8, r10)     // Catch:{ Exception -> 0x1451 }
            r0.append(r8)     // Catch:{ Exception -> 0x1451 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x1451 }
            r11.n(r0)     // Catch:{ Exception -> 0x1451 }
            java.lang.Class<ru1> r0 = defpackage.ru1.class
            ys1 r0 = com.raizlabs.android.dbflow.config.FlowManager.f(r0)     // Catch:{ Exception -> 0x1451 }
            r0.C(r11)     // Catch:{ Exception -> 0x1451 }
            r12 = -481333827177506508(0xf951f56f34b49934, double:-2.4870906364962334E276)
            java.lang.String r0 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            r8 = 6
            java.lang.Object[] r10 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x1451 }
            java.lang.CharSequence r8 = r26.getPackageName()     // Catch:{ Exception -> 0x1451 }
            r12 = 0
            r10[r12] = r8     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r11.g()     // Catch:{ Exception -> 0x1451 }
            r12 = 1
            r10[r12] = r8     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r11.c()     // Catch:{ Exception -> 0x1451 }
            r12 = 2
            r10[r12] = r8     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r11.e()     // Catch:{ Exception -> 0x1451 }
            r12 = 3
            r10[r12] = r8     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r11.h()     // Catch:{ Exception -> 0x1451 }
            r12 = 4
            r10[r12] = r8     // Catch:{ Exception -> 0x1451 }
            int r8 = r11.i()     // Catch:{ Exception -> 0x1451 }
            if (r8 != 0) goto L_0x1412
            r12 = -481334127825217228(0xf951f52934b49934, double:-2.4869427140275154E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            goto L_0x141b
        L_0x1412:
            r12 = -481334166479922892(0xf951f52034b49934, double:-2.4869236954243945E276)
            java.lang.String r8 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
        L_0x141b:
            r12 = 5
            r10[r12] = r8     // Catch:{ Exception -> 0x1451 }
            defpackage.o82.d(r0, r10)     // Catch:{ Exception -> 0x1451 }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x1451 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x1451 }
            r8.<init>()     // Catch:{ Exception -> 0x1451 }
            r8.append(r6)     // Catch:{ Exception -> 0x1451 }
            r12 = -481334200839661260(0xf951f51834b49934, double:-2.486906789999398E276)
            java.lang.String r10 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x1451 }
            r8.append(r10)     // Catch:{ Exception -> 0x1451 }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x1451 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x1451 }
            r10.<init>()     // Catch:{ Exception -> 0x1451 }
            r10.append(r9)     // Catch:{ Exception -> 0x1451 }
            java.lang.String r9 = r11.h()     // Catch:{ Exception -> 0x1451 }
            r10.append(r9)     // Catch:{ Exception -> 0x1451 }
            java.lang.String r9 = r10.toString()     // Catch:{ Exception -> 0x1451 }
            r0.put(r8, r9)     // Catch:{ Exception -> 0x1451 }
        L_0x1451:
            int r7 = r7 + 1
            goto L_0x12fc
        L_0x1455:
            r4.recycle()     // Catch:{ Exception -> 0x1459 }
            goto L_0x145d
        L_0x1459:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x145d:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481334273854105292(0xf951f50734b49934, double:-2.486870865971281E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x1669
            android.view.accessibility.AccessibilityNodeInfo r2 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x1665 }
            if (r2 != 0) goto L_0x147b
            return
        L_0x147b:
            r2.refresh()     // Catch:{ Exception -> 0x1665 }
            r3 = -481334364048418508(0xf951f4f234b49934, double:-2.4868264892306656E276)
            java.lang.String r0 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x1665 }
            java.util.List r0 = r2.findAccessibilityNodeInfosByViewId(r0)     // Catch:{ Exception -> 0x1665 }
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ Exception -> 0x1665 }
            r3.<init>()     // Catch:{ Exception -> 0x1665 }
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch:{ Exception -> 0x1665 }
            r4.<init>()     // Catch:{ Exception -> 0x1665 }
            r1.f(r2, r3, r4)     // Catch:{ Exception -> 0x1665 }
            int r5 = r3.size()     // Catch:{ Exception -> 0x1665 }
            r6 = 1
            if (r5 < r6) goto L_0x1661
            int r5 = r4.size()     // Catch:{ Exception -> 0x1665 }
            if (r5 <= 0) goto L_0x1661
            int r0 = r0.size()     // Catch:{ Exception -> 0x1665 }
            if (r0 != 0) goto L_0x1661
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x1665 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x1665 }
            r5 = -481334492897437388(0xf951f4d434b49934, double:-2.4867630938869293E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x1665 }
            boolean r0 = r0.contains(r5)     // Catch:{ Exception -> 0x1665 }
            if (r0 == 0) goto L_0x1661
            r5 = 0
            java.lang.Object r0 = r4.get(r5)     // Catch:{ Exception -> 0x1665 }
            r4 = r0
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x1665 }
            boolean r0 = r4.isEmpty()     // Catch:{ Exception -> 0x1665 }
            if (r0 != 0) goto L_0x1661
            r0 = 0
            r5 = 0
        L_0x14d2:
            int r6 = r3.size()     // Catch:{ Exception -> 0x1665 }
            if (r0 >= r6) goto L_0x1661
            r6 = 0
            java.util.regex.Pattern r7 = r1.f1644e     // Catch:{ Exception -> 0x165b }
            java.lang.Object r8 = r3.get(r0)     // Catch:{ Exception -> 0x165b }
            java.lang.CharSequence r8 = (java.lang.CharSequence) r8     // Catch:{ Exception -> 0x165b }
            java.util.regex.Matcher r7 = r7.matcher(r8)     // Catch:{ Exception -> 0x165b }
            boolean r7 = r7.find()     // Catch:{ Exception -> 0x165b }
            if (r7 == 0) goto L_0x14f3
            java.lang.Object r6 = r3.get(r0)     // Catch:{ Exception -> 0x165b }
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ Exception -> 0x165b }
            int r0 = r0 + 1
        L_0x14f3:
            r7 = r6
            r6 = r0
            java.lang.Object r0 = r3.get(r6)     // Catch:{ Exception -> 0x165a }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ Exception -> 0x165a }
            r8 = -481334583091750604(0xf951f4bf34b49934, double:-2.486718717146314E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x165a }
            boolean r0 = r0.equals(r8)     // Catch:{ Exception -> 0x165a }
            if (r0 != 0) goto L_0x165c
            java.lang.Object r0 = r3.get(r6)     // Catch:{ Exception -> 0x165a }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ Exception -> 0x165a }
            r8 = -481334604566587084(0xf951f4ba34b49934, double:-2.486708151255691E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x165a }
            boolean r0 = r0.equals(r8)     // Catch:{ Exception -> 0x165a }
            if (r0 != 0) goto L_0x165c
            if (r7 == 0) goto L_0x165c
            java.lang.Object r0 = r3.get(r6)     // Catch:{ Exception -> 0x165a }
            r8 = r0
            java.lang.String r8 = (java.lang.String) r8     // Catch:{ Exception -> 0x165a }
            int r0 = r6 + -2
            java.lang.Object r9 = r3.get(r0)     // Catch:{ Exception -> 0x1552 }
            java.lang.String r9 = (java.lang.String) r9     // Catch:{ Exception -> 0x1552 }
            java.lang.String r10 = r4.toUpperCase()     // Catch:{ Exception -> 0x1552 }
            boolean r9 = r9.equals(r10)     // Catch:{ Exception -> 0x1552 }
            if (r9 == 0) goto L_0x153b
            r5 = 0
        L_0x153b:
            java.lang.Object r0 = r3.get(r0)     // Catch:{ Exception -> 0x1552 }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ Exception -> 0x1552 }
            r9 = -481334630336390860(0xf951f4b434b49934, double:-2.486695472186944E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x1552 }
            boolean r0 = r0.equals(r9)     // Catch:{ Exception -> 0x1552 }
            if (r0 == 0) goto L_0x1556
            r5 = 1
            goto L_0x1556
        L_0x1552:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x165c }
        L_0x1556:
            java.util.Calendar r0 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x165c }
            r9 = -481334643221292748(0xf951f4b134b49934, double:-2.4866891326525703E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x165c }
            java.util.TimeZone r9 = java.util.TimeZone.getTimeZone(r9)     // Catch:{ Exception -> 0x165c }
            r0.setTimeZone(r9)     // Catch:{ Exception -> 0x165c }
            lv1 r9 = new lv1     // Catch:{ Exception -> 0x165c }
            r9.<init>()     // Catch:{ Exception -> 0x165c }
            java.util.UUID r10 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x165c }
            r9.l(r10)     // Catch:{ Exception -> 0x165c }
            r9.o(r4)     // Catch:{ Exception -> 0x165c }
            r9.m(r8)     // Catch:{ Exception -> 0x165c }
            r9.p(r7)     // Catch:{ Exception -> 0x165c }
            r9.q(r5)     // Catch:{ Exception -> 0x165c }
            long r10 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = defpackage.ox1.b(r10)     // Catch:{ Exception -> 0x165c }
            r9.j(r7)     // Catch:{ Exception -> 0x165c }
            long r10 = r0.getTimeInMillis()     // Catch:{ Exception -> 0x165c }
            r9.k(r10)     // Catch:{ Exception -> 0x165c }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x165c }
            r0.<init>()     // Catch:{ Exception -> 0x165c }
            r10 = -481334660401161932(0xf951f4ad34b49934, double:-2.486680679940072E276)
            java.lang.String r7 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x165c }
            r10 = -481334716235736780(0xf951f4a034b49934, double:-2.486653208624453E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r4.replaceAll(r7, r10)     // Catch:{ Exception -> 0x165c }
            r0.append(r7)     // Catch:{ Exception -> 0x165c }
            r10 = -481334720530704076(0xf951f49f34b49934, double:-2.4866510954463285E276)
            java.lang.String r7 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x165c }
            r10 = -481334776365278924(0xf951f49234b49934, double:-2.4866236241307095E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r8.replaceAll(r7, r10)     // Catch:{ Exception -> 0x165c }
            r0.append(r7)     // Catch:{ Exception -> 0x165c }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x165c }
            r9.n(r0)     // Catch:{ Exception -> 0x165c }
            java.lang.Class<lv1> r0 = defpackage.lv1.class
            ys1 r0 = com.raizlabs.android.dbflow.config.FlowManager.f(r0)     // Catch:{ Exception -> 0x165c }
            r0.C(r9)     // Catch:{ Exception -> 0x165c }
            r10 = -481334780660246220(0xf951f49134b49934, double:-2.486621510952585E276)
            java.lang.String r0 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x165c }
            r7 = 6
            java.lang.Object[] r10 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x165c }
            java.lang.CharSequence r7 = r26.getPackageName()     // Catch:{ Exception -> 0x165c }
            r11 = 0
            r10[r11] = r7     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r9.g()     // Catch:{ Exception -> 0x165c }
            r11 = 1
            r10[r11] = r7     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r9.c()     // Catch:{ Exception -> 0x165c }
            r11 = 2
            r10[r11] = r7     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r9.e()     // Catch:{ Exception -> 0x165c }
            r11 = 3
            r10[r11] = r7     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r9.h()     // Catch:{ Exception -> 0x165c }
            r11 = 4
            r10[r11] = r7     // Catch:{ Exception -> 0x165c }
            int r7 = r9.i()     // Catch:{ Exception -> 0x165c }
            if (r7 != 0) goto L_0x161a
            r11 = -481335081307956940(0xf951f44b34b49934, double:-2.486473588483867E276)
            java.lang.String r7 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x165c }
            goto L_0x1623
        L_0x161a:
            r11 = -481335119962662604(0xf951f44234b49934, double:-2.486454569880746E276)
            java.lang.String r7 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x165c }
        L_0x1623:
            r11 = 5
            r10[r11] = r7     // Catch:{ Exception -> 0x165c }
            defpackage.o82.d(r0, r10)     // Catch:{ Exception -> 0x165c }
            java.util.HashMap<java.lang.String, java.lang.String> r0 = r1.f1639a     // Catch:{ Exception -> 0x165c }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x165c }
            r7.<init>()     // Catch:{ Exception -> 0x165c }
            r7.append(r4)     // Catch:{ Exception -> 0x165c }
            r10 = -481335154322400972(0xf951f43a34b49934, double:-2.4864376644557497E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x165c }
            r7.append(r10)     // Catch:{ Exception -> 0x165c }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x165c }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x165c }
            r10.<init>()     // Catch:{ Exception -> 0x165c }
            r10.append(r8)     // Catch:{ Exception -> 0x165c }
            java.lang.String r8 = r9.h()     // Catch:{ Exception -> 0x165c }
            r10.append(r8)     // Catch:{ Exception -> 0x165c }
            java.lang.String r8 = r10.toString()     // Catch:{ Exception -> 0x165c }
            r0.put(r7, r8)     // Catch:{ Exception -> 0x165c }
            goto L_0x165c
        L_0x165a:
            r0 = r6
        L_0x165b:
            r6 = r0
        L_0x165c:
            r7 = 1
            int r0 = r6 + 1
            goto L_0x14d2
        L_0x1661:
            r2.recycle()     // Catch:{ Exception -> 0x1665 }
            goto L_0x1669
        L_0x1665:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
        L_0x1669:
            java.lang.CharSequence r0 = r26.getPackageName()     // Catch:{ Exception -> 0x18ad }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x18ad }
            r2 = -481335244516714188(0xf951f42534b49934, double:-2.4863932877151343E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18ad }
            boolean r0 = r0.equalsIgnoreCase(r2)     // Catch:{ Exception -> 0x18ad }
            if (r0 == 0) goto L_0x18b8
            android.view.accessibility.AccessibilityNodeInfo r0 = r25.getRootInActiveWindow()     // Catch:{ Exception -> 0x18a8 }
            if (r0 != 0) goto L_0x1687
            return
        L_0x1687:
            r0.refresh()     // Catch:{ Exception -> 0x18a8 }
            r2 = -481335343300961996(0xf951f40e34b49934, double:-2.48634468461827E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18a8 }
            java.util.List r2 = r0.findAccessibilityNodeInfosByViewId(r2)     // Catch:{ Exception -> 0x18a8 }
            java.lang.CharSequence r3 = r26.getPackageName()     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x18a8 }
            r4 = -481335472149980876(0xf951f3f034b49934, double:-2.4862812892745336E276)
            java.lang.String r4 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x18a8 }
            boolean r3 = r3.equalsIgnoreCase(r4)     // Catch:{ Exception -> 0x18a8 }
            if (r3 == 0) goto L_0x16bb
            r2 = -481335545164424908(0xf951f3df34b49934, double:-2.4862453652464163E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x18a8 }
            java.util.List r2 = r0.findAccessibilityNodeInfosByViewId(r2)     // Catch:{ Exception -> 0x18a8 }
        L_0x16bb:
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ Exception -> 0x18a8 }
            r3.<init>()     // Catch:{ Exception -> 0x18a8 }
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch:{ Exception -> 0x18a8 }
            r4.<init>()     // Catch:{ Exception -> 0x18a8 }
            r1.g(r0, r3, r4)     // Catch:{ Exception -> 0x18a8 }
            int r5 = r3.size()     // Catch:{ Exception -> 0x18a8 }
            r6 = 2
            if (r5 < r6) goto L_0x18a4
            int r5 = r4.size()     // Catch:{ Exception -> 0x18a8 }
            if (r5 <= 0) goto L_0x18a4
            int r2 = r2.size()     // Catch:{ Exception -> 0x18a8 }
            if (r2 != 0) goto L_0x18a4
            java.lang.CharSequence r2 = r26.getPackageName()     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r2 = r2.toString()     // Catch:{ Exception -> 0x18a8 }
            r5 = -481335691193312972(0xf951f3bd34b49934, double:-2.486173517190182E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x18a8 }
            boolean r2 = r2.contains(r5)     // Catch:{ Exception -> 0x18a8 }
            if (r2 == 0) goto L_0x18a4
            r2 = 0
            java.lang.Object r4 = r4.get(r2)     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x18a8 }
            boolean r2 = r4.isEmpty()     // Catch:{ Exception -> 0x18a8 }
            if (r2 != 0) goto L_0x18a4
            r2 = 0
        L_0x1700:
            int r5 = r3.size()     // Catch:{ Exception -> 0x18a8 }
            if (r2 >= r5) goto L_0x18a4
            java.lang.Object r5 = r3.get(r2)     // Catch:{ Exception -> 0x18a8 }
            android.view.accessibility.AccessibilityNodeInfo r5 = (android.view.accessibility.AccessibilityNodeInfo) r5     // Catch:{ Exception -> 0x18a8 }
            java.lang.CharSequence r6 = r5.getText()     // Catch:{ Exception -> 0x18a8 }
            if (r6 == 0) goto L_0x171b
            java.lang.CharSequence r6 = r5.getText()     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x18a8 }
            goto L_0x1724
        L_0x171b:
            r6 = -481335789977560780(0xf951f3a634b49934, double:-2.4861249140933174E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x18a8 }
        L_0x1724:
            r7 = -481335794272528076(0xf951f3a534b49934, double:-2.486122800915193E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x18a8 }
            boolean r7 = android.text.TextUtils.equals(r6, r7)     // Catch:{ Exception -> 0x18a8 }
            if (r7 == 0) goto L_0x1741
            java.lang.CharSequence r7 = r5.getContentDescription()     // Catch:{ Exception -> 0x18a8 }
            if (r7 == 0) goto L_0x1741
            java.lang.CharSequence r5 = r5.getContentDescription()     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r6 = r5.toString()     // Catch:{ Exception -> 0x18a8 }
        L_0x1741:
            r7 = -481335798567495372(0xf951f3a434b49934, double:-2.4861206877370683E276)
            java.lang.String r5 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x18a8 }
            boolean r5 = r6.contains(r5)     // Catch:{ Exception -> 0x18a8 }
            if (r5 != 0) goto L_0x176a
            r7 = -481335850107102924(0xf951f39834b49934, double:-2.486095329599574E276)
            java.lang.String r5 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x18a8 }
            boolean r5 = r6.contains(r5)     // Catch:{ Exception -> 0x18a8 }
            if (r5 == 0) goto L_0x1760
            goto L_0x176a
        L_0x1760:
            r7 = 6
        L_0x1761:
            r11 = 0
        L_0x1762:
            r12 = 1
        L_0x1763:
            r13 = 2
        L_0x1764:
            r14 = 3
        L_0x1765:
            r15 = 4
        L_0x1766:
            r16 = 5
            goto L_0x18a0
        L_0x176a:
            r7 = -481335905941677772(0xf951f38b34b49934, double:-2.4860678582839547E276)
            java.lang.String r5 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x18a8 }
            boolean r5 = r6.contains(r5)     // Catch:{ Exception -> 0x18a8 }
            if (r5 == 0) goto L_0x177b
            r5 = 1
            goto L_0x177c
        L_0x177b:
            r5 = 0
        L_0x177c:
            java.util.regex.Pattern r7 = r1.f1642c     // Catch:{ Exception -> 0x18a8 }
            java.util.regex.Matcher r7 = r7.matcher(r6)     // Catch:{ Exception -> 0x18a8 }
            boolean r8 = android.text.TextUtils.isEmpty(r6)     // Catch:{ Exception -> 0x18a8 }
            if (r8 != 0) goto L_0x1760
            boolean r8 = r7.find()     // Catch:{ Exception -> 0x18a8 }
            if (r8 == 0) goto L_0x1760
            r8 = -481335957481285324(0xf951f37f34b49934, double:-2.48604250014646E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x18a8 }
            r9 = -481336064855467724(0xf951f36634b49934, double:-2.4859896706933467E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r6 = r6.replaceAll(r8, r9)     // Catch:{ Exception -> 0x18a8 }
            java.lang.String r6 = r6.trim()     // Catch:{ Exception -> 0x18a8 }
            java.util.Calendar r8 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x1760 }
            r9 = -481336069150435020(0xf951f36534b49934, double:-2.485987557515222E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x1760 }
            java.util.TimeZone r9 = java.util.TimeZone.getTimeZone(r9)     // Catch:{ Exception -> 0x1760 }
            r8.setTimeZone(r9)     // Catch:{ Exception -> 0x1760 }
            pv1 r9 = new pv1     // Catch:{ Exception -> 0x1760 }
            r9.<init>()     // Catch:{ Exception -> 0x1760 }
            java.util.UUID r10 = java.util.UUID.randomUUID()     // Catch:{ Exception -> 0x1760 }
            r9.l(r10)     // Catch:{ Exception -> 0x1760 }
            r9.o(r4)     // Catch:{ Exception -> 0x1760 }
            r9.m(r6)     // Catch:{ Exception -> 0x1760 }
            r10 = 1
            java.lang.String r7 = r7.group(r10)     // Catch:{ Exception -> 0x1760 }
            r9.p(r7)     // Catch:{ Exception -> 0x1760 }
            r9.q(r5)     // Catch:{ Exception -> 0x1760 }
            long r10 = r8.getTimeInMillis()     // Catch:{ Exception -> 0x1760 }
            java.lang.String r5 = defpackage.ox1.b(r10)     // Catch:{ Exception -> 0x1760 }
            r9.j(r5)     // Catch:{ Exception -> 0x1760 }
            long r7 = r8.getTimeInMillis()     // Catch:{ Exception -> 0x1760 }
            r9.k(r7)     // Catch:{ Exception -> 0x1760 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x1760 }
            r5.<init>()     // Catch:{ Exception -> 0x1760 }
            r7 = -481336086330304204(0xf951f36134b49934, double:-2.485979104802724E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x1760 }
            r10 = -481336142164879052(0xf951f35434b49934, double:-2.485951633487105E276)
            java.lang.String r8 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x1760 }
            java.lang.String r7 = r4.replaceAll(r7, r8)     // Catch:{ Exception -> 0x1760 }
            r5.append(r7)     // Catch:{ Exception -> 0x1760 }
            r7 = -481336146459846348(0xf951f35334b49934, double:-2.4859495203089804E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x1760 }
            r10 = -481336202294421196(0xf951f34634b49934, double:-2.4859220489933613E276)
            java.lang.String r8 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x1760 }
            java.lang.String r7 = r6.replaceAll(r7, r8)     // Catch:{ Exception -> 0x1760 }
            r5.append(r7)     // Catch:{ Exception -> 0x1760 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x1760 }
            r9.n(r5)     // Catch:{ Exception -> 0x1760 }
            java.lang.Class<pv1> r5 = defpackage.pv1.class
            ys1 r5 = com.raizlabs.android.dbflow.config.FlowManager.f(r5)     // Catch:{ Exception -> 0x1760 }
            r5.C(r9)     // Catch:{ Exception -> 0x1760 }
            r7 = -481336206589388492(0xf951f34534b49934, double:-2.485919935815237E276)
            java.lang.String r5 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x1760 }
            r7 = 6
            java.lang.Object[] r8 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x1761 }
            java.lang.CharSequence r10 = r26.getPackageName()     // Catch:{ Exception -> 0x1761 }
            r11 = 0
            r8[r11] = r10     // Catch:{ Exception -> 0x1762 }
            java.lang.String r10 = r9.g()     // Catch:{ Exception -> 0x1762 }
            r12 = 1
            r8[r12] = r10     // Catch:{ Exception -> 0x1763 }
            java.lang.String r10 = r9.c()     // Catch:{ Exception -> 0x1763 }
            r13 = 2
            r8[r13] = r10     // Catch:{ Exception -> 0x1764 }
            java.lang.String r10 = r9.e()     // Catch:{ Exception -> 0x1764 }
            r14 = 3
            r8[r14] = r10     // Catch:{ Exception -> 0x1765 }
            java.lang.String r10 = r9.h()     // Catch:{ Exception -> 0x1765 }
            r15 = 4
            r8[r15] = r10     // Catch:{ Exception -> 0x1766 }
            int r10 = r9.i()     // Catch:{ Exception -> 0x1766 }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ Exception -> 0x1766 }
            r16 = 5
            r8[r16] = r10     // Catch:{ Exception -> 0x18a0 }
            defpackage.o82.d(r5, r8)     // Catch:{ Exception -> 0x18a0 }
            java.util.HashMap<java.lang.String, java.lang.String> r5 = r1.f1639a     // Catch:{ Exception -> 0x18a0 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x18a0 }
            r8.<init>()     // Catch:{ Exception -> 0x18a0 }
            r8.append(r4)     // Catch:{ Exception -> 0x18a0 }
            r17 = -481336507237099212(0xf951f2ff34b49934, double:-2.485772013346519E276)
            java.lang.String r10 = defpackage.wx1.a(r17)     // Catch:{ Exception -> 0x18a0 }
            r8.append(r10)     // Catch:{ Exception -> 0x18a0 }
            java.lang.String r8 = r8.toString()     // Catch:{ Exception -> 0x18a0 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x18a0 }
            r10.<init>()     // Catch:{ Exception -> 0x18a0 }
            r10.append(r6)     // Catch:{ Exception -> 0x18a0 }
            java.lang.String r6 = r9.h()     // Catch:{ Exception -> 0x18a0 }
            r10.append(r6)     // Catch:{ Exception -> 0x18a0 }
            java.lang.String r6 = r10.toString()     // Catch:{ Exception -> 0x18a0 }
            r5.put(r8, r6)     // Catch:{ Exception -> 0x18a0 }
        L_0x18a0:
            int r2 = r2 + 1
            goto L_0x1700
        L_0x18a4:
            r0.recycle()     // Catch:{ Exception -> 0x18a8 }
            goto L_0x18b8
        L_0x18a8:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x18ad }
            goto L_0x18b8
        L_0x18ad:
            r0 = move-exception
            qg1 r2 = defpackage.qg1.a()
            r2.c(r0)
            r0.printStackTrace()
        L_0x18b8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.AccessibilityReceiver4.onAccessibilityEvent(android.view.accessibility.AccessibilityEvent):void");
    }

    public void onCreate() {
        super.onCreate();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(wx1.a(-481324803451217612L), Locale.US);
        this.f1638a = simpleDateFormat;
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone(wx1.a(-481324889350563532L)));
        this.a = new Handler();
    }

    public void onDestroy() {
    }

    public void onInterrupt() {
    }

    public void onServiceConnected() {
        super.onServiceConnected();
    }
}
