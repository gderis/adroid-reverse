package com.zgoicsifmc.services;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.widget.Toast;

public class ScreenLockUnlock extends Service {
    public BroadcastReceiver a;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_ON");
        intentFilter.addAction("android.intent.action.SCREEN_OFF");
        dw1 dw1 = new dw1();
        this.a = dw1;
        registerReceiver(dw1, intentFilter);
    }

    public void onDestroy() {
        unregisterReceiver(this.a);
        super.onDestroy();
    }

    public void onStart(Intent intent, int i) {
        Context context;
        String str;
        if (!intent.getBooleanExtra("screen_state", false)) {
            context = getApplicationContext();
            str = "Awake";
        } else {
            context = getApplicationContext();
            str = "Sleep";
        }
        Toast.makeText(context, str, 1).show();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        return 1;
    }
}
