package com.zgoicsifmc.services;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.zgoicsifmc.App;
import java.util.Map;

public class FbMessagingService extends FirebaseMessagingService {
    public void o(vo1 vo1) {
        o82.a(wx1.a(-481400996171048652L), vo1.B0());
        Map<String, String> A0 = vo1.A0();
        if (A0.size() > 0) {
            o82.a(wx1.a(-481401069185492684L), A0);
            if (A0.containsKey(wx1.a(-481401155084838604L))) {
                o82.d(wx1.a(-481401189444576972L), A0.get(wx1.a(-481401279638890188L)));
                new hx1(getApplicationContext(), A0.get(wx1.a(-481401313998628556L)), A0);
            }
        }
    }

    public void q(String str) {
        try {
            new xt1(App.e().getApplicationContext()).v(wx1.a(-481401348358366924L), str);
            o82.a(wx1.a(-481401412782876364L), str);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
