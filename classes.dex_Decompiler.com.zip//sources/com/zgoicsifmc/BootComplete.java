package com.zgoicsifmc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.zgoicsifmc.services.ScreenLockUnlock;

public class BootComplete extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (TextUtils.equals(action, wx1.a(-481386260138256076L)) || TextUtils.equals(action, wx1.a(-481386419052046028L)) || TextUtils.equals(action, wx1.a(-481386590850737868L))) {
            try {
                new jx1().b();
                App.e().m(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                context.startService(new Intent(context, ScreenLockUnlock.class));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
}
