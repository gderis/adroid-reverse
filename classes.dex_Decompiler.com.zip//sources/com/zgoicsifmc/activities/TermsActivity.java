package com.zgoicsifmc.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class TermsActivity extends a0 {
    public Button a;

    /* renamed from: a  reason: collision with other field name */
    public CheckBox f1721a;

    /* access modifiers changed from: private */
    /* renamed from: L */
    public /* synthetic */ void M(View view) {
        if (this.f1721a.isChecked()) {
            startActivity(new Intent(this, TargetActivity.class));
            finish();
            return;
        }
        Toast.makeText(this, "Aceite os termos para continuar.", 1).show();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427371);
        this.f1721a = (CheckBox) findViewById(2131230831);
        this.a = (Button) findViewById(2131230822);
        WebView webView = (WebView) findViewById(2131231225);
        webView.setInitialScale(1);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.loadUrl("https://www.wtsoftware.com.br/suporte/termos-uso.html?android=true");
        this.a.setOnClickListener(new ju1(this));
    }
}
