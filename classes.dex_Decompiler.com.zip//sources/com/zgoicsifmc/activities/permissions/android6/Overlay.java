package com.zgoicsifmc.activities.permissions.android6;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Overlay extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1758a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1759a;

    /* renamed from: a  reason: collision with other field name */
    public Boolean f1760a = Boolean.FALSE;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1761a;

    public class a implements View.OnClickListener {

        /* renamed from: com.zgoicsifmc.activities.permissions.android6.Overlay$a$a  reason: collision with other inner class name */
        public class C0024a implements Runnable {
            public final /* synthetic */ Handler a;

            public C0024a(Handler handler) {
                this.a = handler;
            }

            public void run() {
                if (!Settings.canDrawOverlays(Overlay.this.a)) {
                    this.a.postDelayed(this, 700);
                } else {
                    Overlay.this.U();
                }
            }
        }

        public a() {
        }

        public void onClick(View view) {
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (Settings.canDrawOverlays(Overlay.this.a)) {
                        Overlay.this.U();
                    } else {
                        Intent intent = new Intent();
                        intent.setAction(wx1.a(-481362629228193484L));
                        intent.setData(Uri.parse(wx1.a(-481362843976558284L) + Overlay.this.getPackageName()));
                        Overlay.this.startActivity(intent);
                    }
                    if (!Settings.canDrawOverlays(Overlay.this.a) && !Overlay.this.f1760a.booleanValue() && !Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481362882631263948L))) {
                        Overlay.this.f1760a = Boolean.TRUE;
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(new C0024a(handler), 700);
                        return;
                    }
                    return;
                }
                Overlay.this.U();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public final void U() {
        this.f1761a.w(wx1.a(-481362942760806092L), true);
        L(this.a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427364);
        Context applicationContext = getApplicationContext();
        this.a = applicationContext;
        this.f1761a = new xt1(applicationContext);
        Button button = (Button) findViewById(2131230814);
        this.f1759a = button;
        button.setOnClickListener(this.f1758a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(getString(2131624124)));
    }

    public void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= 23 && Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481362912696035020L)) && Settings.canDrawOverlays(this.a)) {
            U();
        }
    }
}
