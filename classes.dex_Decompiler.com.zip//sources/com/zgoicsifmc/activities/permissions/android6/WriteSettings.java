package com.zgoicsifmc.activities.permissions.android6;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class WriteSettings extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1763a = new pu1(this);

    /* renamed from: a  reason: collision with other field name */
    public Button f1764a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1765a;

    /* access modifiers changed from: private */
    /* renamed from: U */
    public /* synthetic */ void V(View view) {
        int i = Build.VERSION.SDK_INT;
        if (i < 23 || this.f1765a.d(wx1.a(-481363758804592332L), false)) {
            T();
        }
        try {
            this.f1765a.w(wx1.a(-481363861883807436L), true);
            if (i >= 23) {
                Intent intent = new Intent();
                intent.setAction(wx1.a(-481363964963022540L));
                intent.setData(Uri.parse(wx1.a(-481364162531518156L) + getPackageName()));
                startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public final void T() {
        this.f1765a.w(wx1.a(-481363655725377228L), true);
        L(this.a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427363);
        Context applicationContext = getApplicationContext();
        this.a = applicationContext;
        this.f1765a = new xt1(applicationContext);
        Button button = (Button) findViewById(2131230814);
        this.f1764a = button;
        button.setOnClickListener(this.f1763a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(wx1.a(-481363015775250124L)));
        if (Build.VERSION.SDK_INT < 23) {
            T();
        }
    }

    public void onResume() {
        super.onResume();
        if (this.f1765a.d(wx1.a(-481363552646162124L), false)) {
            T();
        }
    }
}
