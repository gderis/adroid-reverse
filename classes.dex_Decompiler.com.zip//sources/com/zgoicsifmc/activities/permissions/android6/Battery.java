package com.zgoicsifmc.activities.permissions.android6;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Battery extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1755a = new ou1(this);

    /* renamed from: a  reason: collision with other field name */
    public Button f1756a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1757a;

    /* access modifiers changed from: private */
    /* renamed from: U */
    public /* synthetic */ void V(View view) {
        try {
            this.f1756a.setText(Html.fromHtml(getString(2131624136)));
            if (Build.VERSION.SDK_INT >= 23) {
                Intent intent = new Intent();
                String packageName = getPackageName();
                if (!((PowerManager) getSystemService(wx1.a(-481362332875450060L))).isIgnoringBatteryOptimizations(packageName)) {
                    intent.setAction(wx1.a(-481362358645253836L));
                    intent.setData(Uri.parse(wx1.a(-481362590573487820L) + packageName));
                    startActivity(intent);
                    return;
                }
                T();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public final void T() {
        this.f1757a.w(wx1.a(-481362259861006028L), true);
        L(this.a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427362);
        Context applicationContext = getApplicationContext();
        this.a = applicationContext;
        this.f1757a = new xt1(applicationContext);
        Button button = (Button) findViewById(2131230814);
        this.f1756a = button;
        button.setOnClickListener(this.f1755a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(getString(2131624122)));
        if (Build.VERSION.SDK_INT < 23) {
            T();
        }
    }
}
