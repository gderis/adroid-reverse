package com.zgoicsifmc.activities.permissions;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Accessibility extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1728a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1729a;

    /* renamed from: a  reason: collision with other field name */
    public Boolean f1730a = Boolean.FALSE;

    /* renamed from: a  reason: collision with other field name */
    public String f1731a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1732a;

    public class a implements View.OnClickListener {

        /* renamed from: com.zgoicsifmc.activities.permissions.Accessibility$a$a  reason: collision with other inner class name */
        public class C0022a implements Runnable {
            public final /* synthetic */ Handler a;

            public C0022a(Handler handler) {
                this.a = handler;
            }

            public void run() {
                String string = Settings.Secure.getString(Accessibility.this.getContentResolver(), wx1.a(-481353596911969996L));
                if (string == null || !string.contains(Accessibility.this.f1731a)) {
                    this.a.postDelayed(this, 700);
                } else {
                    Accessibility.this.U();
                }
            }
        }

        public a() {
        }

        public void onClick(View view) {
            try {
                String string = Settings.Secure.getString(Accessibility.this.getContentResolver(), wx1.a(-481353730055956172L));
                if (string == null || !string.contains(Accessibility.this.f1731a)) {
                    Intent intent = new Intent();
                    intent.setAction(wx1.a(-481353863199942348L));
                    Accessibility.this.startActivity(intent);
                } else {
                    Accessibility.this.U();
                }
                if ((string == null || !string.contains(Accessibility.this.f1731a)) && !Accessibility.this.f1730a.booleanValue() && !Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481354034998634188L))) {
                    Accessibility.this.f1730a = Boolean.TRUE;
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new C0022a(handler), 700);
                }
            } catch (Exception e) {
                qg1.a().c(e);
                e.printStackTrace();
            }
        }
    }

    public final void U() {
        try {
            String string = Settings.Secure.getString(getContentResolver(), wx1.a(-481355954849015500L));
            if (string != null) {
                if (string.contains(getPackageName())) {
                    this.f1732a.w(wx1.a(-481356087993001676L), true);
                    L(this.a);
                    return;
                }
            }
            R(2131624021);
        } catch (Exception e) {
            R(2131624021);
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        U();
    }

    public void onCreate(Bundle bundle) {
        long j;
        super.onCreate(bundle);
        setContentView(2131427360);
        this.a = getApplicationContext();
        this.f1731a = getPackageName();
        this.f1732a = new xt1(this.a);
        Button button = (Button) findViewById(2131230814);
        this.f1729a = button;
        button.setOnClickListener(this.f1728a);
        TextView textView = (TextView) findViewById(2131231183);
        String string = getString(2131624131);
        String lowerCase = Build.MANUFACTURER.toLowerCase();
        if (lowerCase.contains(wx1.a(-481354065063405260L)) && Build.VERSION.SDK_INT >= 29) {
            j = -481354099423143628L;
        } else if (!lowerCase.contains(wx1.a(-481354554689677004L)) || Build.VERSION.SDK_INT < 24) {
            if (lowerCase.contains(wx1.a(-481355040020981452L))) {
                j = -481355070085752524L;
            }
            textView.setText(Html.fromHtml(string));
        } else {
            j = -481354589049415372L;
        }
        string = string.concat(wx1.a(j));
        textView.setText(Html.fromHtml(string));
    }

    public void onResume() {
        String string;
        super.onResume();
        if (Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481355791640258252L)) && (string = Settings.Secure.getString(getContentResolver(), wx1.a(-481355821705029324L))) != null && string.contains(this.f1731a)) {
            U();
        }
    }
}
