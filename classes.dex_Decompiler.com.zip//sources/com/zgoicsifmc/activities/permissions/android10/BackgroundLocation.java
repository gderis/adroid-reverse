package com.zgoicsifmc.activities.permissions.android10;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;

public class BackgroundLocation extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1744a = new lu1(this);

    /* renamed from: a  reason: collision with other field name */
    public Button f1745a;

    /* renamed from: a  reason: collision with other field name */
    public BackgroundLocation f1746a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1747a;

    public class a implements fq1 {
        public a() {
        }

        public void a(List<String> list, boolean z) {
            BackgroundLocation.this.U();
        }

        public void b(List<String> list, boolean z) {
            BackgroundLocation.this.U();
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: V */
    public /* synthetic */ void W(View view) {
        if (this.f1747a.d(wx1.a(-481357290583844556L), false)) {
            U();
        }
        try {
            this.f1747a.w(wx1.a(-481357415137896140L), true);
            lq1.f(this.f1746a).d(wx1.a(-481357539691947724L)).e(new a());
        } catch (Exception e) {
            qg1.a().c(e);
            e.printStackTrace();
        }
    }

    public final void U() {
        this.f1747a.w(wx1.a(-481357166029792972L), true);
        L(this.a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427363);
        Context applicationContext = getApplicationContext();
        this.a = applicationContext;
        this.f1747a = new xt1(applicationContext);
        this.f1746a = this;
        Button button = (Button) findViewById(2131230814);
        this.f1745a = button;
        button.setOnClickListener(this.f1744a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(wx1.a(-481356186777249484L)));
    }

    public void onResume() {
        super.onResume();
        if (this.f1747a.d(wx1.a(-481357041475741388L), false)) {
            U();
        }
    }
}
