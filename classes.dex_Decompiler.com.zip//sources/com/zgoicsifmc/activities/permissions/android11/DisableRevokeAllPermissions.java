package com.zgoicsifmc.activities.permissions.android11;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DisableRevokeAllPermissions extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1748a = new mu1(this);

    /* renamed from: a  reason: collision with other field name */
    public Button f1749a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1750a;

    /* access modifiers changed from: private */
    /* renamed from: U */
    public /* synthetic */ void V(View view) {
        if (this.f1750a.d(wx1.a(-481359983528339148L), false)) {
            T();
        }
        try {
            this.f1750a.w(wx1.a(-481360155327030988L), true);
            Intent intent = new Intent(wx1.a(-481360327125722828L));
            intent.addCategory(wx1.a(-481360524694218444L));
            intent.addFlags(268435456);
            intent.setData(Uri.parse(wx1.a(-481360662133171916L) + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            qg1.a().c(e);
            e.printStackTrace();
        }
    }

    public final void T() {
        this.f1750a.w(wx1.a(-481359811729647308L), true);
        L(this.a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427366);
        Context applicationContext = getApplicationContext();
        this.a = applicationContext;
        this.f1750a = new xt1(applicationContext);
        Button button = (Button) findViewById(2131230812);
        this.f1749a = button;
        button.setOnClickListener(this.f1748a);
        ((TextView) findViewById(2131231185)).setText(Html.fromHtml(wx1.a(-481357737260443340L)));
    }

    public void onResume() {
        super.onResume();
        if (this.f1750a.d(wx1.a(-481359639930955468L), false)) {
            T();
        }
    }
}
