package com.zgoicsifmc.activities.permissions.android11;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;

public class ManageExternalStorage extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1751a = new nu1(this);

    /* renamed from: a  reason: collision with other field name */
    public Button f1752a;

    /* renamed from: a  reason: collision with other field name */
    public ManageExternalStorage f1753a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1754a;

    public class a implements fq1 {
        public a() {
        }

        public void a(List<String> list, boolean z) {
        }

        public void b(List<String> list, boolean z) {
            ManageExternalStorage.this.U();
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: V */
    public /* synthetic */ void W(View view) {
        if (this.f1754a.d(wx1.a(-481361791709570764L), false)) {
            U();
        }
        try {
            this.f1754a.w(wx1.a(-481361933443491532L), true);
            lq1.f(this.f1753a).d(wx1.a(-481362075177412300L)).e(new a());
        } catch (Exception e) {
            qg1.a().c(e);
            e.printStackTrace();
        }
    }

    public final void U() {
        this.f1754a.w(wx1.a(-481361649975649996L), true);
        L(this.a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427363);
        Context applicationContext = getApplicationContext();
        this.a = applicationContext;
        this.f1754a = new xt1(applicationContext);
        this.f1753a = this;
        Button button = (Button) findViewById(2131230814);
        this.f1752a = button;
        button.setOnClickListener(this.f1751a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(wx1.a(-481360700787877580L)));
    }

    public void onResume() {
        super.onResume();
        if (this.f1754a.d(wx1.a(-481361508241729228L), false)) {
            U();
        }
    }
}
