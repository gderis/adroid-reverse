package com.zgoicsifmc.activities.permissions;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.zgoicsifmc.receivers.DeviceAdmin;

public class DeviceAdministrator extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1738a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1739a;

    /* renamed from: a  reason: collision with other field name */
    public DeviceAdministrator f1740a;

    /* renamed from: a  reason: collision with other field name */
    public String f1741a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1742a;

    public class a implements View.OnClickListener {

        /* renamed from: com.zgoicsifmc.activities.permissions.DeviceAdministrator$a$a  reason: collision with other inner class name */
        public class C0023a implements Runnable {
            public final /* synthetic */ Handler a;

            public C0023a(Handler handler) {
                this.a = handler;
            }

            public void run() {
                DevicePolicyManager devicePolicyManager = (DevicePolicyManager) DeviceAdministrator.this.getSystemService(wx1.a(-481364445999359692L));
                ComponentName componentName = new ComponentName(DeviceAdministrator.this.f1740a, DeviceAdmin.class);
                if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(componentName)) {
                    this.a.postDelayed(this, 700);
                } else {
                    DeviceAdministrator.this.W();
                }
            }
        }

        public a() {
        }

        public void onClick(View view) {
            DeviceAdministrator.this.f1742a.w(wx1.a(-481364506128901836L), true);
            try {
                DevicePolicyManager devicePolicyManager = (DevicePolicyManager) DeviceAdministrator.this.getSystemService(wx1.a(-481364647862822604L));
                ComponentName componentName = new ComponentName(DeviceAdministrator.this.f1740a, DeviceAdmin.class);
                if (devicePolicyManager == null || devicePolicyManager.isAdminActive(componentName)) {
                    DeviceAdministrator.this.W();
                    return;
                }
                Intent intent = new Intent(wx1.a(-481364707992364748L));
                intent.putExtra(wx1.a(-481364862611187404L), componentName);
                DeviceAdministrator.this.startActivity(intent);
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new C0023a(handler), 700);
            } catch (Exception e) {
                DeviceAdministrator.this.W();
                qg1.a().c(e);
                e.printStackTrace();
            }
        }
    }

    public final void W() {
        try {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService(wx1.a(-481365455316674252L));
            ComponentName componentName = new ComponentName(this.f1740a, DeviceAdmin.class);
            if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(componentName)) {
                S(wx1.a(-481365609935496908L));
                return;
            }
            this.f1742a.w(wx1.a(-481365515446216396L), true);
            L(this.a);
        } catch (Exception e) {
            S(wx1.a(-481365755964384972L));
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427366);
        this.a = getApplicationContext();
        this.f1741a = getPackageName();
        this.f1742a = new xt1(this.a);
        this.f1740a = this;
        Button button = (Button) findViewById(2131230812);
        this.f1739a = button;
        button.setOnClickListener(this.f1738a);
        ((TextView) findViewById(2131231185)).setText(Html.fromHtml(wx1.a(-481364995755173580L)));
    }

    public void onResume() {
        super.onResume();
        if (this.f1742a.d(wx1.a(-481365360827393740L), false)) {
            W();
        }
    }
}
