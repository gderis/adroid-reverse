package com.zgoicsifmc.activities.permissions;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AutoStart extends ku1 {
    public ComponentName a;

    /* renamed from: a  reason: collision with other field name */
    public Context f1734a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1735a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1736a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1737a;

    public class a implements View.OnClickListener {
        public a() {
        }

        public void onClick(View view) {
            int i = Build.VERSION.SDK_INT;
            if (i < 23) {
                AutoStart.this.V();
            }
            try {
                AutoStart.this.f1737a.w(wx1.a(-481364201186223820L), true);
                if (i >= 23) {
                    AutoStart autoStart = AutoStart.this;
                    if (autoStart.a != null) {
                        Intent intent = new Intent();
                        intent.setComponent(AutoStart.this.a);
                        AutoStart.this.startActivity(intent);
                        return;
                    }
                    autoStart.V();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public final void V() {
        this.f1737a.w(wx1.a(-481364364394981068L), true);
        L(this.f1734a);
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427361);
        Context applicationContext = getApplicationContext();
        this.f1734a = applicationContext;
        this.f1737a = new xt1(applicationContext);
        Button button = (Button) findViewById(2131230814);
        this.f1736a = button;
        button.setOnClickListener(this.f1735a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(getString(2131624123)));
        this.a = kx1.b(this.f1734a);
    }

    public void onResume() {
        super.onResume();
        if (this.f1737a.d(wx1.a(-481364282790602444L), false)) {
            V();
        }
    }
}
