package com.zgoicsifmc.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;
import com.zgoicsifmc.receivers.DeviceAdmin;
import defpackage.u61;
import java.util.List;

public class PermissionActivity extends ku1 {
    public static final String a = wx1.a(-481352729328576204L);
    public static final String b = wx1.a(-481352823817856716L);
    public static final String c = wx1.a(-481352926897071820L);
    public static final String d = wx1.a(-481353012796417740L);
    public static final String e = wx1.a(-481353115875632844L);
    public static final String f = wx1.a(-481353214659880652L);
    public static final String g = wx1.a(-481353287674324684L);
    public static final String h = wx1.a(-481353360688768716L);
    public static final String i = wx1.a(-481353455178049228L);

    /* renamed from: a  reason: collision with other field name */
    public AlertDialog f1670a;

    /* renamed from: a  reason: collision with other field name */
    public Context f1671a;

    /* renamed from: a  reason: collision with other field name */
    public SwitchCompat f1672a;

    /* renamed from: a  reason: collision with other field name */
    public PermissionActivity f1673a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1674a;

    /* renamed from: b  reason: collision with other field name */
    public SwitchCompat f1675b;

    /* renamed from: c  reason: collision with other field name */
    public SwitchCompat f1676c;

    /* renamed from: d  reason: collision with other field name */
    public SwitchCompat f1677d;

    /* renamed from: e  reason: collision with other field name */
    public SwitchCompat f1678e;

    /* renamed from: f  reason: collision with other field name */
    public SwitchCompat f1679f;

    /* renamed from: g  reason: collision with other field name */
    public SwitchCompat f1680g;

    /* renamed from: h  reason: collision with other field name */
    public SwitchCompat f1681h;

    /* renamed from: i  reason: collision with other field name */
    public SwitchCompat f1682i;
    public SwitchCompat j;

    /* renamed from: j  reason: collision with other field name */
    public String f1683j;

    public class a implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        /* renamed from: com.zgoicsifmc.activities.PermissionActivity$a$a  reason: collision with other inner class name */
        public class C0010a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$a$a$a  reason: collision with other inner class name */
            public class C0011a implements Runnable {
                public final /* synthetic */ Handler a;

                public C0011a(Handler handler) {
                    this.a = handler;
                }

                public void run() {
                    if (!PermissionActivity.this.X()) {
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                    PermissionActivity.this.finish();
                }
            }

            public C0010a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1674a.w(wx1.a(-481345762891622092L), true);
                try {
                    Intent intent = new Intent();
                    intent.setAction(Build.VERSION.SDK_INT >= 22 ? wx1.a(-481345857380902604L) : wx1.a(-481346093604103884L));
                    PermissionActivity.this.startActivity(intent);
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
                if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481346329827305164L))) {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new C0011a(handler), 500);
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1682i.setClickable(true);
                PermissionActivity.this.f1682i.setChecked(false);
            }
        }

        public a(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1682i.setClickable(false);
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new C0010a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class b implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$b$a$a  reason: collision with other inner class name */
            public class C0012a implements Runnable {
                public final /* synthetic */ Handler a;

                /* renamed from: a  reason: collision with other field name */
                public final /* synthetic */ PowerManager f1687a;

                /* renamed from: a  reason: collision with other field name */
                public final /* synthetic */ String f1689a;

                public C0012a(PowerManager powerManager, String str, Handler handler) {
                    this.f1687a = powerManager;
                    this.f1689a = str;
                    this.a = handler;
                }

                public void run() {
                    if (!this.f1687a.isIgnoringBatteryOptimizations(this.f1689a)) {
                        PermissionActivity.this.f1680g.setClickable(true);
                        PermissionActivity.this.f1680g.setChecked(false);
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.f1680g.setClickable(false);
                    PermissionActivity.this.f1680g.setChecked(true);
                }
            }

            public a() {
            }

            @SuppressLint({"BatteryLife"})
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    PermissionActivity.this.f1674a.w(wx1.a(-481346359892076236L), true);
                    if (Build.VERSION.SDK_INT >= 23) {
                        Intent intent = new Intent();
                        String packageName = PermissionActivity.this.getPackageName();
                        intent.setAction(wx1.a(-481346458676324044L));
                        intent.setData(Uri.parse(wx1.a(-481346690604558028L) + packageName));
                        PermissionActivity.this.startActivity(intent);
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(new C0012a((PowerManager) PermissionActivity.this.getSystemService(wx1.a(-481346432906520268L)), packageName, handler), 500);
                        return;
                    }
                    PermissionActivity.this.f1680g.setClickable(false);
                    PermissionActivity.this.f1680g.setChecked(true);
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
            }
        }

        /* renamed from: com.zgoicsifmc.activities.PermissionActivity$b$b  reason: collision with other inner class name */
        public class C0013b implements DialogInterface.OnClickListener {
            public C0013b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1680g.setClickable(true);
                PermissionActivity.this.f1680g.setChecked(false);
            }
        }

        public b(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1674a.w(wx1.a(-481346729259263692L), true);
            this.a.setTitle(2131624000);
            this.a.setMessage(2131624104);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new C0013b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class c implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$c$a$a  reason: collision with other inner class name */
            public class C0014a implements Runnable {
                public final /* synthetic */ Handler a;

                public C0014a(Handler handler) {
                    this.a = handler;
                }

                public void run() {
                    if (!Settings.System.canWrite(PermissionActivity.this.f1671a)) {
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                    PermissionActivity.this.finish();
                }
            }

            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    PermissionActivity.this.f1674a.w(wx1.a(-481346802273707724L), true);
                    try {
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481346905352922828L))) {
                                Handler handler = new Handler(Looper.getMainLooper());
                                handler.postDelayed(new C0014a(handler), 500);
                            }
                            Intent intent = new Intent();
                            intent.setAction(wx1.a(-481346935417693900L));
                            intent.setData(Uri.parse(wx1.a(-481347132986189516L) + PermissionActivity.this.getPackageName()));
                            PermissionActivity.this.startActivity(intent);
                            return;
                        }
                        d7.l((Activity) PermissionActivity.this.f1671a, new String[]{wx1.a(-481347171640895180L)}, 5000);
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1676c.setClickable(true);
                PermissionActivity.this.f1676c.setChecked(false);
            }
        }

        public c(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1676c.setClickable(false);
            if (Build.VERSION.SDK_INT < 23) {
                PermissionActivity.this.f1676c.setClickable(false);
                PermissionActivity.this.f1676c.setChecked(true);
            }
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class d implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {
            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1674a.w(wx1.a(-481347317669783244L), true);
                try {
                    if (Build.VERSION.SDK_INT >= 23) {
                        Intent intent = new Intent();
                        intent.setComponent(kx1.b(PermissionActivity.this.f1671a));
                        PermissionActivity.this.startActivity(intent);
                    }
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1675b.setClickable(true);
                PermissionActivity.this.f1675b.setChecked(false);
            }
        }

        public d(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class e implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$e$a$a  reason: collision with other inner class name */
            public class C0015a implements Runnable {
                public final /* synthetic */ Handler a;

                public C0015a(Handler handler) {
                    this.a = handler;
                }

                public void run() {
                    DevicePolicyManager devicePolicyManager = (DevicePolicyManager) PermissionActivity.this.getSystemService(wx1.a(-481347403569129164L));
                    ComponentName componentName = new ComponentName(PermissionActivity.this.f1673a, DeviceAdmin.class);
                    if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(componentName)) {
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                    PermissionActivity.this.finish();
                }
            }

            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1674a.w(wx1.a(-481347463698671308L), true);
                try {
                    DevicePolicyManager devicePolicyManager = (DevicePolicyManager) PermissionActivity.this.getSystemService(wx1.a(-481347562482919116L));
                    ComponentName componentName = new ComponentName(PermissionActivity.this.f1673a, DeviceAdmin.class);
                    if (devicePolicyManager != null && !devicePolicyManager.isAdminActive(componentName)) {
                        Intent intent = new Intent(wx1.a(-481347622612461260L));
                        intent.putExtra(wx1.a(-481347777231283916L), componentName);
                        PermissionActivity.this.startActivity(intent);
                        if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481347910375270092L))) {
                            Handler handler = new Handler(Looper.getMainLooper());
                            handler.postDelayed(new C0015a(handler), 500);
                            return;
                        }
                        PermissionActivity.this.f1677d.setChecked(true);
                    }
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1677d.setClickable(true);
                PermissionActivity.this.f1677d.setChecked(false);
            }
        }

        public e(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class f implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$f$a$a  reason: collision with other inner class name */
            public class C0016a implements Runnable {
                public final /* synthetic */ Handler a;

                public C0016a(Handler handler) {
                    this.a = handler;
                }

                public void run() {
                    if (!Settings.canDrawOverlays(PermissionActivity.this.f1671a)) {
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                    PermissionActivity.this.finish();
                }
            }

            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1678e.setClickable(false);
                PermissionActivity.this.f1678e.setChecked(true);
                PermissionActivity.this.f1674a.w(wx1.a(-481347940440041164L), true);
                if (Build.VERSION.SDK_INT >= 23) {
                    if (Settings.canDrawOverlays(PermissionActivity.this.f1671a) && !Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481348013454485196L))) {
                        PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                        PermissionActivity.this.finish();
                    } else if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481348043519256268L))) {
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(new C0016a(handler), 500);
                    }
                    Intent intent = new Intent();
                    intent.setAction(wx1.a(-481348073584027340L));
                    intent.setData(Uri.parse(wx1.a(-481348288332392140L) + PermissionActivity.this.getPackageName()));
                    PermissionActivity.this.startActivity(intent);
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1678e.setClickable(true);
                PermissionActivity.this.f1678e.setChecked(false);
            }
        }

        public f(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1678e.setClickable(false);
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class g implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {
            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1674a.w(wx1.a(-481348326987097804L), true);
                Intent intent = new Intent();
                wx1.a(-481348421476378316L);
                wx1.a(-481348520260626124L);
                intent.setClassName(wx1.a(-481348717829121740L), wx1.a(-481348816613369548L));
                PermissionActivity.this.startActivity(intent);
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1679f.setClickable(true);
                PermissionActivity.this.f1679f.setChecked(false);
            }
        }

        public g(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1679f.setClickable(false);
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class h implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$h$a$a  reason: collision with other inner class name */
            public class C0017a implements fq1 {
                public C0017a() {
                }

                public void a(List<String> list, boolean z) {
                    PermissionActivity.this.f1681h.setClickable(true);
                    PermissionActivity.this.f1681h.setChecked(false);
                }

                public void b(List<String> list, boolean z) {
                    PermissionActivity.this.f1681h.setClickable(false);
                    PermissionActivity.this.f1681h.setChecked(true);
                }
            }

            public class b implements Runnable {
                public final /* synthetic */ Handler a;

                public b(Handler handler) {
                    this.a = handler;
                }

                public void run() {
                    if (!Environment.isExternalStorageManager()) {
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                    PermissionActivity.this.finish();
                }
            }

            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    if (PermissionActivity.this.f1674a.d(wx1.a(-481349108671145676L), false)) {
                        PermissionActivity.this.f1681h.setClickable(false);
                        PermissionActivity.this.f1681h.setChecked(true);
                    }
                    PermissionActivity.this.f1674a.w(wx1.a(-481349250405066444L), true);
                    if (Build.VERSION.SDK_INT >= 30) {
                        lq1.f(PermissionActivity.this.f1673a).d(wx1.a(-481349392138987212L)).e(new C0017a());
                    } else {
                        PermissionActivity.this.f1681h.setClickable(false);
                        PermissionActivity.this.f1681h.setChecked(true);
                    }
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
                if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481349576822580940L)) && Build.VERSION.SDK_INT >= 30) {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new b(handler), 500);
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1681h.setClickable(true);
                PermissionActivity.this.f1681h.setChecked(false);
            }
        }

        public h(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1681h.setClickable(false);
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    public class i implements fq1 {
        public i() {
        }

        public void a(List<String> list, boolean z) {
        }

        public void b(List<String> list, boolean z) {
        }
    }

    public class j implements Runnable {
        public final /* synthetic */ Handler a;

        public j(Handler handler) {
            this.a = handler;
        }

        public void run() {
            if (r7.a(PermissionActivity.this.f1671a, wx1.a(-481349606887352012L)) == 0) {
                PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                PermissionActivity.this.finish();
                return;
            }
            this.a.postDelayed(this, 500);
        }
    }

    public class k implements View.OnTouchListener {
        public k() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class l implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public l(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            if (!PermissionActivity.this.f1672a.isChecked() || !PermissionActivity.this.f1677d.isChecked() || !PermissionActivity.this.f1675b.isChecked() || !PermissionActivity.this.f1678e.isChecked() || !PermissionActivity.this.f1676c.isChecked() || !PermissionActivity.this.f1679f.isChecked() || !PermissionActivity.this.f1680g.isChecked() || !PermissionActivity.this.f1681h.isChecked() || !PermissionActivity.this.f1682i.isChecked() || !PermissionActivity.this.j.isChecked()) {
                this.a.setTitle(2131623971);
                this.a.setMessage(2131623972);
                AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
                PermissionActivity.this.f1670a.show();
                return;
            }
            PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1673a, FinalActivity.class));
        }
    }

    public class m implements i81<u61.a> {
        public m() {
        }

        public void a(n81<u61.a> n81) {
            if (!n81.n()) {
                return;
            }
            if (n81.j().c()) {
                PermissionActivity.this.f1679f.setChecked(false);
                PermissionActivity.this.f1679f.setClickable(true);
                return;
            }
            PermissionActivity.this.f1679f.setClickable(false);
            PermissionActivity.this.f1679f.setChecked(true);
        }
    }

    public class n implements View.OnTouchListener {
        public n() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class o implements View.OnTouchListener {
        public o() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class p implements View.OnTouchListener {
        public p() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class q implements View.OnTouchListener {
        public q() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class r implements View.OnTouchListener {
        public r() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class s implements View.OnTouchListener {
        public s() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class t implements View.OnTouchListener {
        public t() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return motionEvent.getActionMasked() == 2;
        }
    }

    public class u implements View.OnClickListener {
        public final /* synthetic */ AlertDialog.Builder a;

        public class a implements DialogInterface.OnClickListener {

            /* renamed from: com.zgoicsifmc.activities.PermissionActivity$u$a$a  reason: collision with other inner class name */
            public class C0018a implements Runnable {
                public final /* synthetic */ Handler a;

                public C0018a(Handler handler) {
                    this.a = handler;
                }

                public void run() {
                    String string = Settings.Secure.getString(PermissionActivity.this.getContentResolver(), wx1.a(-481349804455847628L));
                    if (string == null || !string.contains(PermissionActivity.this.f1683j)) {
                        this.a.postDelayed(this, 500);
                        return;
                    }
                    PermissionActivity.this.startActivity(new Intent(PermissionActivity.this.f1671a, PermissionActivity.class));
                    PermissionActivity.this.finish();
                }
            }

            public a() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481349937599833804L))) {
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(new C0018a(handler), 500);
                    }
                    Intent intent = new Intent();
                    intent.setAction(wx1.a(-481349967664604876L));
                    PermissionActivity.this.startActivity(intent);
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
            }
        }

        public class b implements DialogInterface.OnClickListener {
            public b() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                PermissionActivity.this.f1672a.setClickable(true);
                PermissionActivity.this.f1672a.setChecked(false);
            }
        }

        public u(AlertDialog.Builder builder) {
            this.a = builder;
        }

        public void onClick(View view) {
            PermissionActivity.this.f1672a.setClickable(false);
            this.a.setTitle(2131624000);
            this.a.setMessage(2131623999);
            this.a.setPositiveButton(2131624136, new a());
            this.a.setNegativeButton(2131624135, new b());
            AlertDialog unused = PermissionActivity.this.f1670a = this.a.create();
            PermissionActivity.this.f1670a.show();
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: Y */
    public /* synthetic */ void Z(DialogInterface dialogInterface, int i2) {
        this.j.setChecked(true);
        this.f1674a.w(wx1.a(-481352398616094412L), true);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                lq1.f(this.f1673a).d(wx1.a(-481352501695309516L)).e(new i());
            }
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        }
        if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481352699263805132L)) && Build.VERSION.SDK_INT >= 29) {
            Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new j(handler), 500);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: a0 */
    public /* synthetic */ void b0(DialogInterface dialogInterface, int i2) {
        this.j.setClickable(true);
        this.j.setChecked(false);
    }

    /* access modifiers changed from: private */
    /* renamed from: c0 */
    public /* synthetic */ void d0(AlertDialog.Builder builder, View view) {
        builder.setTitle(2131624000);
        builder.setMessage(2131624106);
        builder.setPositiveButton(2131624136, new gu1(this));
        builder.setNegativeButton(2131624135, new fu1(this));
        AlertDialog create = builder.create();
        this.f1670a = create;
        create.show();
    }

    public static /* synthetic */ void e0(boolean[] zArr, n81 n81) {
        if (n81.n()) {
            zArr[0] = !((u61.a) n81.j()).c();
        }
    }

    public final boolean X() {
        String string = Settings.Secure.getString(getContentResolver(), wx1.a(-481352265472108236L));
        return string != null && string.contains(getPackageName());
    }

    public final void f0(String str, SwitchCompat switchCompat) {
        boolean[] zArr = {this.f1674a.d(str, false)};
        if (str.equals(wx1.a(-481351007046690508L)) && Build.VERSION.SDK_INT < 29) {
            zArr[0] = true;
        }
        if (str.equals(wx1.a(-481351110125905612L)) && !Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481351196025251532L))) {
            zArr[0] = true;
        }
        if (str.equals(wx1.a(-481351226090022604L))) {
            try {
                t61.a(this).p().b(new eu1(zArr));
            } catch (Exception e2) {
                zArr[0] = true;
                e2.printStackTrace();
            }
        }
        switchCompat.setChecked(zArr[0]);
        switchCompat.setClickable(!zArr[0]);
    }

    public void onBackPressed() {
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427359);
        Button button = (Button) findViewById(2131230809);
        this.f1671a = getApplicationContext();
        this.f1683j = getPackageName();
        this.f1674a = new xt1(this.f1671a);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        this.f1673a = this;
        SwitchCompat switchCompat = (SwitchCompat) findViewById(2131231110);
        this.f1672a = switchCompat;
        switchCompat.setChecked(false);
        this.f1672a.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener) null);
        this.f1682i = (SwitchCompat) findViewById(2131231116);
        f0(wx1.a(-481350139463296716L), this.f1682i);
        this.j = (SwitchCompat) findViewById(2131231114);
        f0(wx1.a(-481350233952577228L), this.j);
        this.f1675b = (SwitchCompat) findViewById(2131231112);
        f0(wx1.a(-481350337031792332L), this.f1675b);
        this.f1676c = (SwitchCompat) findViewById(2131231119);
        f0(wx1.a(-481350422931138252L), this.f1676c);
        this.f1677d = (SwitchCompat) findViewById(2131231111);
        f0(wx1.a(-481350526010353356L), this.f1677d);
        this.f1678e = (SwitchCompat) findViewById(2131231117);
        f0(wx1.a(-481350624794601164L), this.f1678e);
        this.f1680g = (SwitchCompat) findViewById(2131231113);
        f0(wx1.a(-481350697809045196L), this.f1680g);
        this.f1679f = (SwitchCompat) findViewById(2131231118);
        f0(wx1.a(-481350770823489228L), this.f1679f);
        this.f1681h = (SwitchCompat) findViewById(2131231115);
        f0(wx1.a(-481350865312769740L), this.f1681h);
        button.setOnClickListener((View.OnClickListener) null);
        this.f1672a.setOnTouchListener(new k());
        this.f1680g.setOnTouchListener(new n());
        this.f1675b.setOnTouchListener(new o());
        this.f1678e.setOnTouchListener(new p());
        this.f1681h.setOnTouchListener(new q());
        this.f1677d.setOnTouchListener(new r());
        this.f1679f.setOnTouchListener(new s());
        this.f1676c.setOnTouchListener(new t());
        this.f1672a.setOnClickListener(new u(builder));
        this.f1682i.setOnClickListener(new a(builder));
        this.f1680g.setOnClickListener(new b(builder));
        this.f1676c.setOnClickListener(new c(builder));
        this.f1675b.setOnClickListener(new d(builder));
        this.f1677d.setOnClickListener(new e(builder));
        this.f1678e.setOnClickListener(new f(builder));
        this.f1679f.setOnClickListener(new g(builder));
        this.f1681h.setOnClickListener(new h(builder));
        this.j.setOnClickListener(new du1(this, builder));
        button.setOnClickListener(new l(builder));
    }

    public void onResume() {
        super.onResume();
        if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481351320579303116L))) {
            String string = Settings.Secure.getString(getContentResolver(), wx1.a(-481351350644074188L));
            if (string == null || !string.contains(this.f1683j)) {
                this.f1672a.setChecked(false);
                this.f1672a.setClickable(true);
            } else {
                this.f1672a.setChecked(true);
                this.f1672a.setClickable(false);
                this.f1672a.setHighlightColor(-16711936);
            }
        }
        f0(wx1.a(-481351483788060364L), this.f1682i);
        f0(wx1.a(-481351578277340876L), this.j);
        f0(wx1.a(-481351681356555980L), this.f1676c);
        f0(wx1.a(-481351784435771084L), this.f1677d);
        f0(wx1.a(-481351883220018892L), this.f1678e);
        f0(wx1.a(-481351956234462924L), this.f1680g);
        f0(wx1.a(-481352029248906956L), this.f1679f);
        f0(wx1.a(-481352123738187468L), this.f1681h);
        t61.a(this).p().b(new m());
    }
}
