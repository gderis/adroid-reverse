package com.zgoicsifmc.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.zgoicsifmc.App;
import com.zgoicsifmc.tasks.PhotogalleryWorker;
import com.zgoicsifmc.tasks._SyncWorker;
import defpackage.gj;
import defpackage.ij;
import defpackage.sj;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class DebugActivity extends ku1 {
    public final View.OnClickListener a = new b();

    /* renamed from: a  reason: collision with other field name */
    public Button f1655a;
    public final View.OnClickListener b = new c();

    /* renamed from: b  reason: collision with other field name */
    public Button f1656b;
    public final View.OnClickListener c = new d();

    /* renamed from: c  reason: collision with other field name */
    public Button f1657c;
    public final View.OnClickListener d = new e();

    /* renamed from: d  reason: collision with other field name */
    public Button f1658d;
    public final View.OnClickListener e = new f();

    /* renamed from: e  reason: collision with other field name */
    public Button f1659e;

    public class a implements Runnable {
        public final /* synthetic */ Handler a;

        public a(Handler handler) {
            this.a = handler;
        }

        public void run() {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(wx1.a(-481342816544057036L), Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(wx1.a(-481342855198762700L)));
            Calendar instance = Calendar.getInstance();
            instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481342872378631884L)));
            dv1 dv1 = new dv1();
            dv1.i(UUID.randomUUID());
            dv1.f(wx1.a(-481342889558501068L));
            dv1.g(ox1.b(instance.getTimeInMillis()));
            dv1.j(String.format(wx1.a(-481342923918239436L), new Object[]{ox1.c(instance.getTimeInMillis())}));
            dv1.h(instance.getTimeInMillis());
            FlowManager.f(dv1.class).C(dv1);
            zu1 zu1 = new zu1();
            String format = String.format(wx1.a(-481342958277977804L), new Object[]{ox1.c(instance.getTimeInMillis())});
            zu1.l(UUID.randomUUID());
            zu1.o(wx1.a(-481343035587389132L));
            zu1.m(format);
            zu1.q(1);
            zu1.j(ox1.c(instance.getTimeInMillis()));
            zu1.k(instance.getTimeInMillis());
            zu1.p(simpleDateFormat.format(Long.valueOf(instance.getTimeInMillis())));
            zu1.n(format.replaceAll(wx1.a(-481343100011898572L), wx1.a(-481343155846473420L)));
            FlowManager.f(zu1.class).C(zu1);
            zv1 zv1 = new zv1();
            String format2 = String.format(wx1.a(-481343160141440716L), new Object[]{ox1.c(instance.getTimeInMillis())});
            zv1.l(UUID.randomUUID());
            zv1.o(wx1.a(-481343233155884748L));
            zv1.m(format2);
            zv1.q(1);
            zv1.j(ox1.c(instance.getTimeInMillis()));
            zv1.k(instance.getTimeInMillis());
            zv1.p(simpleDateFormat.format(Long.valueOf(instance.getTimeInMillis())));
            zv1.n(format2.replaceAll(wx1.a(-481343293285426892L), wx1.a(-481343349120001740L)));
            FlowManager.f(zv1.class).C(zv1);
            this.a.postDelayed(this, 10000);
        }
    }

    public class b implements View.OnClickListener {

        public class a implements j32 {

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ xt1 f1661a;

            /* renamed from: com.zgoicsifmc.activities.DebugActivity$b$a$a  reason: collision with other inner class name */
            public class C0008a implements Runnable {
                public C0008a() {
                }

                public void run() {
                    DebugActivity.this.R(2131624019);
                }
            }

            public a(xt1 xt1) {
                this.f1661a = xt1;
            }

            public void a(i32 i32, IOException iOException) {
                DebugActivity.this.runOnUiThread(new C0008a());
                iOException.printStackTrace();
            }

            public void b(i32 i32, i42 i42) {
                if (!i42.N()) {
                    try {
                        o82.d(new JSONObject(i42.a().w()).toString(), new Object[0]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject jSONObject = new JSONObject(i42.a().w());
                        o82.d(jSONObject.toString(), new Object[0]);
                        this.f1661a.v(wx1.a(-481343374889805516L), jSONObject.getString(wx1.a(-481343353414969036L)));
                        this.f1661a.v(wx1.a(-481343396364641996L), wx1.a(-481343422134445772L));
                        App.e().m(true);
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }

        public b() {
        }

        public void onClick(View view) {
            try {
                xt1 xt1 = new xt1(DebugActivity.this.getApplicationContext());
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(wx1.a(-481343538098562764L), wx1.a(-481343563868366540L));
                jSONObject.put(wx1.a(-481343679832483532L), xt1.c(wx1.a(-481343697012352716L), wx1.a(-481343714192221900L)));
                jSONObject.put(wx1.a(-481343718487189196L), xt1.c(wx1.a(-481343782911698636L), wx1.a(-481343847336208076L)));
                jSONObject.put(wx1.a(-481343851631175372L), wx1.a(-481343890285881036L));
                jSONObject.put(wx1.a(-481343920350652108L), xt1.c(wx1.a(-481343950415423180L), wx1.a(-481343980480194252L)));
                o82.d(jSONObject.toString(), new Object[0]);
                vt1.a().d(xt1.i(wx1.a(-481343984775161548L)), jSONObject).F(new a(xt1));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class c implements View.OnClickListener {

        public class a implements j32 {

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ xt1 f1662a;

            public a(xt1 xt1) {
                this.f1662a = xt1;
            }

            /* access modifiers changed from: private */
            /* renamed from: c */
            public /* synthetic */ void d() {
                DebugActivity.this.R(2131624019);
            }

            public void a(i32 i32, IOException iOException) {
                DebugActivity.this.runOnUiThread(new au1(this));
                iOException.printStackTrace();
            }

            @SuppressLint({"ApplySharedPref"})
            public void b(i32 i32, i42 i42) {
                if (!i42.N()) {
                    try {
                        o82.d(new JSONObject(i42.a().w()).toString(), new Object[0]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject jSONObject = new JSONObject(i42.a().w());
                        o82.d(jSONObject.toString(), new Object[0]);
                        this.f1662a.v(wx1.a(-481344070674507468L), jSONObject.getString(wx1.a(-481344049199670988L)));
                        this.f1662a.v(wx1.a(-481344092149343948L), wx1.a(-481344117919147724L));
                        App.e().m(true);
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }

        public c() {
        }

        public void onClick(View view) {
            try {
                xt1 xt1 = new xt1(DebugActivity.this.getApplicationContext());
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(wx1.a(-481344233883264716L), wx1.a(-481344259653068492L));
                jSONObject.put(wx1.a(-481344375617185484L), xt1.c(wx1.a(-481344392797054668L), wx1.a(-481344409976923852L)));
                jSONObject.put(wx1.a(-481344414271891148L), xt1.c(wx1.a(-481344478696400588L), wx1.a(-481344543120910028L)));
                jSONObject.put(wx1.a(-481344547415877324L), wx1.a(-481344586070582988L));
                jSONObject.put(wx1.a(-481344616135354060L), xt1.c(wx1.a(-481344646200125132L), wx1.a(-481344676264896204L)));
                o82.d(jSONObject.toString(), new Object[0]);
                vt1.a().d(xt1.i(wx1.a(-481344680559863500L)), jSONObject).F(new a(xt1));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class d implements View.OnClickListener {
        public d() {
        }

        public void onClick(View view) {
            ij.a aVar = new ij.a();
            aVar.e(wx1.a(-481344757869274828L), true);
            gj a2 = new gj.a().b(rj.CONNECTED).a();
            ak.g(App.e().getApplicationContext()).a(wx1.a(-481344783639078604L), kj.KEEP, (sj) ((sj.a) ((sj.a) new sj.a(_SyncWorker.class).f(aVar.a())).e(a2)).b()).a();
        }
    }

    public class e implements View.OnClickListener {
        public e() {
        }

        public void onClick(View view) {
            ij.a aVar = new ij.a();
            aVar.e(wx1.a(-481344805113915084L), true);
            gj a2 = new gj.a().b(rj.CONNECTED).a();
            ak.g(App.e().getApplicationContext()).a(wx1.a(-481344830883718860L), kj.KEEP, (sj) ((sj.a) ((sj.a) new sj.a(PhotogalleryWorker.class).f(aVar.a())).e(a2)).b()).a();
        }
    }

    public class f implements View.OnClickListener {
        public f() {
        }

        public void onClick(View view) {
            new hx1(DebugActivity.this.getApplicationContext(), wx1.a(-481344886718293708L), new HashMap());
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427356);
        Button button = (Button) findViewById(2131230818);
        this.f1655a = button;
        button.setOnClickListener(this.b);
        Button button2 = (Button) findViewById(2131230816);
        this.f1656b = button2;
        button2.setOnClickListener(this.a);
        Button button3 = (Button) findViewById(2131230820);
        this.f1657c = button3;
        button3.setOnClickListener(this.c);
        Button button4 = (Button) findViewById(2131230821);
        this.f1658d = button4;
        button4.setOnClickListener(this.e);
        Button button5 = (Button) findViewById(2131230817);
        this.f1659e = button5;
        button5.setOnClickListener(this.d);
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new a(handler), 10000);
    }
}
