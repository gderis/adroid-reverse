package com.zgoicsifmc.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignUpActivity extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public SharedPreferences f1707a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1708a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1709a;

    /* renamed from: a  reason: collision with other field name */
    public EditText f1710a;
    public EditText b;

    public class a implements View.OnClickListener {
        static {
            Class<SignUpActivity> cls = SignUpActivity.class;
        }

        public a() {
        }

        public void onClick(View view) {
            try {
                ((InputMethodManager) view.getContext().getSystemService(wx1.a(-481369449636259532L))).hideSoftInputFromWindow(view.getWindowToken(), 0);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!TextUtils.isEmpty(SignUpActivity.this.f1710a.getText().toString().toLowerCase().trim()) && !TextUtils.isEmpty(SignUpActivity.this.b.getText().toString().trim())) {
                Intent intent = new Intent(SignUpActivity.this.a, SignUpConfirmActivity.class);
                intent.putExtra(wx1.a(-481369505470834380L), SignUpActivity.this.f1710a.getText().toString().toLowerCase().trim());
                intent.putExtra(wx1.a(-481369531240638156L), SignUpActivity.this.b.getText().toString().trim());
                SignUpActivity.this.startActivity(intent);
                SignUpActivity.this.finish();
            }
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427368);
        this.a = getApplicationContext();
        this.f1710a = (EditText) findViewById(2131231209);
        this.b = (EditText) findViewById(2131231211);
        this.f1707a = getSharedPreferences(wx1.a(-481369569895343820L), 0);
        Button button = (Button) findViewById(2131230819);
        this.f1709a = button;
        button.setOnClickListener(this.f1708a);
        String stringExtra = getIntent().getStringExtra(wx1.a(-481369677269526220L));
        String stringExtra2 = getIntent().getStringExtra(wx1.a(-481369703039329996L));
        if (stringExtra != null && !stringExtra.equals(wx1.a(-481369741694035660L))) {
            this.f1710a.setText(stringExtra);
        }
        if (stringExtra2 != null && !stringExtra2.equals(wx1.a(-481369745989002956L))) {
            this.b.setText(stringExtra2);
        }
        ((TextView) findViewById(2131231148)).setText(Html.fromHtml(getString(2131624129)));
    }
}
