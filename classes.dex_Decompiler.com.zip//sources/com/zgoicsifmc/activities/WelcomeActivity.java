package com.zgoicsifmc.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.zgoicsifmc.App;
import com.zgoicsifmc.services.ScreenLockUnlock;
import java.util.ArrayList;

public class WelcomeActivity extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1722a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1723a;

    /* renamed from: a  reason: collision with other field name */
    public EditText f1724a;
    public final View.OnClickListener b = new b();

    /* renamed from: b  reason: collision with other field name */
    public Button f1725b;

    /* renamed from: b  reason: collision with other field name */
    public EditText f1726b;
    public final View.OnClickListener c = new c();

    /* renamed from: c  reason: collision with other field name */
    public Button f1727c;

    public class a implements View.OnClickListener {
        public a() {
        }

        public void onClick(View view) {
            WelcomeActivity.this.startActivity(new Intent(WelcomeActivity.this.a, LoginActivity.class));
            WelcomeActivity.this.finish();
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public void onClick(View view) {
            WelcomeActivity.this.startActivity(new Intent(WelcomeActivity.this.a, SignUpActivity.class));
            WelcomeActivity.this.finish();
        }
    }

    public class c implements View.OnClickListener {
        public c() {
        }

        public void onClick(View view) {
            WelcomeActivity.this.startActivity(new Intent(WelcomeActivity.this.a, TermsActivity.class));
            WelcomeActivity.this.finish();
        }
    }

    public static boolean T(Context context, String[] strArr) {
        if (context == null || strArr == null) {
            return true;
        }
        for (String a2 : strArr) {
            if (r7.a(context, a2) != 0) {
                return false;
            }
        }
        return true;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427372);
        this.a = getApplicationContext();
        if (App.k()) {
            finishAffinity();
            System.exit(0);
        }
        Button button = (Button) findViewById(2131230819);
        this.f1725b = button;
        button.setOnClickListener(this.b);
        Button button2 = (Button) findViewById(2131230816);
        this.f1723a = button2;
        button2.setOnClickListener(this.f1722a);
        Button button3 = (Button) findViewById(2131230813);
        this.f1727c = button3;
        button3.setOnClickListener(this.c);
        this.f1727c.setVisibility(8);
        this.f1724a = (EditText) findViewById(2131231209);
        this.f1726b = (EditText) findViewById(2131231211);
        ((TextView) findViewById(2131231140)).setText(Html.fromHtml(getString(2131624127)));
        ((TextView) findViewById(2131231142)).setText(Html.fromHtml(getString(2131624128)));
        ((TextView) findViewById(2131231148)).setText(Html.fromHtml(getString(2131624129)));
        new jx1().b();
        try {
            startService(new Intent(this, ScreenLockUnlock.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
        xt1 xt1 = new xt1(this.a);
        if (!xt1.d(wx1.a(-481370484723377868L), false) && xt1.c(wx1.a(-481370527673050828L), wx1.a(-481370549147887308L)).isEmpty()) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(wx1.a(-481370686586840780L));
            arrayList.add(wx1.a(-481370858385532620L));
            arrayList.add(wx1.a(-481371038774159052L));
            arrayList.add(wx1.a(-481371210572850892L));
            arrayList.add(wx1.a(-481371369486640844L));
            arrayList.add(wx1.a(-481371489745725132L));
            arrayList.add(wx1.a(-481371610004809420L));
            arrayList.add(wx1.a(-481371751738730188L));
            arrayList.add(wx1.a(-481371893472650956L));
            arrayList.add(wx1.a(-481372048091473612L));
            arrayList.add(wx1.a(-481372228480100044L));
            arrayList.add(wx1.a(-481372387393889996L));
            arrayList.add(wx1.a(-481372499063039692L));
            arrayList.add(wx1.a(-481372666566764236L));
            arrayList.add(wx1.a(-481372846955390668L));
            arrayList.add(wx1.a(-481373044523886284L));
            int i = Build.VERSION.SDK_INT;
            if (i >= 23) {
                arrayList.add(wx1.a(-481373181962839756L));
            }
            if (i >= 29) {
                arrayList.add(wx1.a(-481373422481008332L));
            }
            String[] strArr = (String[]) arrayList.toArray(new String[0]);
            if (!T(this, strArr)) {
                d7.l(this, strArr, 1);
            }
        } else if (Build.VERSION.SDK_INT >= 29) {
            App.e().m(false);
            startActivity(new Intent(wx1.a(-481370553442854604L)));
            finish();
        } else {
            Q(Boolean.FALSE);
        }
    }
}
