package com.zgoicsifmc.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Toast;

public class TargetActivity extends a0 {
    public Button a;

    /* renamed from: a  reason: collision with other field name */
    public CheckBox f1719a;

    /* renamed from: a  reason: collision with other field name */
    public RadioButton f1720a;
    public RadioButton b;
    public RadioButton c;

    /* access modifiers changed from: private */
    /* renamed from: L */
    public /* synthetic */ void M(View view) {
        if (!this.c.isChecked() && !this.f1720a.isChecked() && !this.b.isChecked()) {
            Toast.makeText(this, "Selecione de quem é o aparelho", 1).show();
            this.f1719a.setChecked(false);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: N */
    public /* synthetic */ void O(View view) {
        if (this.f1719a.isChecked()) {
            startActivity(new Intent(this, PermissionActivity.class));
            finish();
            return;
        }
        Toast.makeText(this, "Confirme as informações antes", 1).show();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427370);
        this.a = (Button) findViewById(2131230811);
        this.f1719a = (CheckBox) findViewById(2131230841);
        this.b = (RadioButton) findViewById(2131231037);
        this.f1720a = (RadioButton) findViewById(2131231038);
        this.c = (RadioButton) findViewById(2131231039);
        this.f1719a.setOnClickListener(new iu1(this));
        this.a.setOnClickListener(new hu1(this));
    }
}
