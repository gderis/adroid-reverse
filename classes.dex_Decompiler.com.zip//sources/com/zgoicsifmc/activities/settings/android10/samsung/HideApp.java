package com.zgoicsifmc.activities.settings.android10.samsung;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HideApp extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1766a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1767a;

    /* renamed from: a  reason: collision with other field name */
    public xt1 f1768a;

    public class a implements View.OnClickListener {
        public a() {
        }

        public void onClick(View view) {
            try {
                HideApp.this.f1768a.w(wx1.a(-481365901993273036L), true);
                try {
                    ComponentName componentName = new ComponentName(wx1.a(-481365975007717068L), wx1.a(-481366099561768652L));
                    Intent intent = new Intent();
                    intent.setComponent(componentName);
                    intent.addFlags(268435456);
                    intent.addFlags(1073741824);
                    intent.addFlags(8388608);
                    if (HideApp.this.a.getPackageManager().resolveActivity(intent, 65536) != null) {
                        HideApp.this.startActivity(intent);
                        HideApp.this.finish();
                        return;
                    }
                    HideApp.this.U();
                } catch (Exception e) {
                    e.printStackTrace();
                    HideApp.this.U();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public final void U() {
        try {
            Q(Boolean.TRUE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        U();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427367);
        this.a = getApplicationContext();
        Button button = (Button) findViewById(2131230812);
        this.f1767a = button;
        button.setOnClickListener(this.f1766a);
        ((TextView) findViewById(2131231186)).setText(Html.fromHtml(getString(2131624042)));
        xt1 xt1 = new xt1(this.a);
        this.f1768a = xt1;
        if (xt1.d(wx1.a(-481366352964839116L), false)) {
            U();
        }
    }
}
