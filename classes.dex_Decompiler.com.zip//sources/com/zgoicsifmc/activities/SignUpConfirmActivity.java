package com.zgoicsifmc.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import java.io.IOException;
import org.json.JSONObject;

public class SignUpConfirmActivity extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1711a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1712a;

    /* renamed from: a  reason: collision with other field name */
    public TextView f1713a;

    /* renamed from: a  reason: collision with other field name */
    public String f1714a;

    /* renamed from: a  reason: collision with other field name */
    public nx1 f1715a;
    public final View.OnClickListener b = new b();

    /* renamed from: b  reason: collision with other field name */
    public Button f1716b;

    /* renamed from: b  reason: collision with other field name */
    public String f1717b;

    public class a implements View.OnClickListener {

        /* renamed from: com.zgoicsifmc.activities.SignUpConfirmActivity$a$a  reason: collision with other inner class name */
        public class C0020a implements j32 {

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ xt1 f1718a;

            /* renamed from: com.zgoicsifmc.activities.SignUpConfirmActivity$a$a$a  reason: collision with other inner class name */
            public class C0021a implements Runnable {
                public C0021a() {
                }

                public void run() {
                    SignUpConfirmActivity.this.f1715a.a();
                    SignUpConfirmActivity.this.R(2131624019);
                }
            }

            /* renamed from: com.zgoicsifmc.activities.SignUpConfirmActivity$a$a$b */
            public class b implements Runnable {
                public b() {
                }

                public void run() {
                    SignUpConfirmActivity.this.f1715a.a();
                    SignUpConfirmActivity.this.f1712a.setEnabled(true);
                }
            }

            public C0020a(xt1 xt1) {
                this.f1718a = xt1;
            }

            public void a(i32 i32, IOException iOException) {
                SignUpConfirmActivity.this.runOnUiThread(new C0021a());
                iOException.printStackTrace();
            }

            /* JADX WARNING: Can't wrap try/catch for region: R(5:10|11|12|13|19) */
            /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x009a */
            @android.annotation.SuppressLint({"ApplySharedPref"})
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void b(defpackage.i32 r5, defpackage.i42 r6) {
                /*
                    r4 = this;
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r5 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this
                    com.zgoicsifmc.activities.SignUpConfirmActivity r5 = com.zgoicsifmc.activities.SignUpConfirmActivity.this
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a$a$b r0 = new com.zgoicsifmc.activities.SignUpConfirmActivity$a$a$b
                    r0.<init>()
                    r5.runOnUiThread(r0)
                    boolean r5 = r6.N()
                    r0 = 0
                    if (r5 != 0) goto L_0x0059
                    org.json.JSONObject r5 = new org.json.JSONObject     // Catch:{ Exception -> 0x004c }
                    j42 r6 = r6.a()     // Catch:{ Exception -> 0x004c }
                    java.lang.String r6 = r6.w()     // Catch:{ Exception -> 0x004c }
                    r5.<init>(r6)     // Catch:{ Exception -> 0x004c }
                    java.lang.String r6 = r5.toString()     // Catch:{ Exception -> 0x004c }
                    java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x004c }
                    defpackage.o82.d(r6, r0)     // Catch:{ Exception -> 0x004c }
                    r0 = -481369750283970252(0xf951d4c334b49934, double:-2.4694160146625586E276)
                    java.lang.String r6 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x004c }
                    org.json.JSONArray r5 = r5.getJSONArray(r6)     // Catch:{ Exception -> 0x004c }
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r6 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x004c }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r6 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x004c }
                    r0 = -481369780348741324(0xf951d4bc34b49934, double:-2.469401222415687E276)
                    java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x004c }
                    java.lang.String r5 = r5.join(r0)     // Catch:{ Exception -> 0x004c }
                    r6.S(r5)     // Catch:{ Exception -> 0x004c }
                    goto L_0x00fa
                L_0x004c:
                    r5 = move-exception
                    qg1 r6 = defpackage.qg1.a()
                    r6.c(r5)
                    r5.printStackTrace()
                    goto L_0x00fa
                L_0x0059:
                    r5 = 2131624020(0x7f0e0054, float:1.8875208E38)
                    org.json.JSONObject r1 = new org.json.JSONObject     // Catch:{ Exception -> 0x00e8 }
                    j42 r6 = r6.a()     // Catch:{ Exception -> 0x00e8 }
                    java.lang.String r6 = r6.w()     // Catch:{ Exception -> 0x00e8 }
                    r1.<init>(r6)     // Catch:{ Exception -> 0x00e8 }
                    java.lang.String r6 = r1.toString()     // Catch:{ Exception -> 0x00e8 }
                    java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x00e8 }
                    defpackage.o82.d(r6, r0)     // Catch:{ Exception -> 0x00e8 }
                    r2 = -481369788938675916(0xf951d4ba34b49934, double:-2.4693969960594377E276)
                    java.lang.String r6 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00e8 }
                    java.lang.String r6 = r1.getString(r6)     // Catch:{ Exception -> 0x00e8 }
                    boolean r0 = r6.isEmpty()     // Catch:{ Exception -> 0x00e8 }
                    if (r0 != 0) goto L_0x00e0
                    qg1 r0 = defpackage.qg1.a()     // Catch:{ Exception -> 0x009a }
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r1 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x009a }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r1 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x009a }
                    java.lang.String r1 = r1.f1714a     // Catch:{ Exception -> 0x009a }
                    java.lang.String r1 = r1.toLowerCase()     // Catch:{ Exception -> 0x009a }
                    java.lang.String r1 = r1.trim()     // Catch:{ Exception -> 0x009a }
                    r0.d(r1)     // Catch:{ Exception -> 0x009a }
                L_0x009a:
                    xt1 r0 = r4.f1718a     // Catch:{ Exception -> 0x00e8 }
                    r1 = -481369810413512396(0xf951d4b534b49934, double:-2.469386430168815E276)
                    java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r2 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r2 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x00e8 }
                    java.lang.String r2 = r2.f1714a     // Catch:{ Exception -> 0x00e8 }
                    java.lang.String r2 = r2.toLowerCase()     // Catch:{ Exception -> 0x00e8 }
                    java.lang.String r2 = r2.trim()     // Catch:{ Exception -> 0x00e8 }
                    r0.v(r1, r2)     // Catch:{ Exception -> 0x00e8 }
                    xt1 r0 = r4.f1718a     // Catch:{ Exception -> 0x00e8 }
                    r1 = -481369836183316172(0xf951d4af34b49934, double:-2.4693737511000677E276)
                    java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x00e8 }
                    r0.v(r1, r6)     // Catch:{ Exception -> 0x00e8 }
                    android.content.Intent r6 = new android.content.Intent     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r0 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r0 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x00e8 }
                    android.content.Context r0 = r0.a     // Catch:{ Exception -> 0x00e8 }
                    java.lang.Class<com.zgoicsifmc.activities.TermsActivity> r1 = com.zgoicsifmc.activities.TermsActivity.class
                    r6.<init>(r0, r1)     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r0 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r0 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x00e8 }
                    r0.startActivity(r6)     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r6 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r6 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x00e8 }
                    r6.finish()     // Catch:{ Exception -> 0x00e8 }
                    goto L_0x00fa
                L_0x00e0:
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r6 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this     // Catch:{ Exception -> 0x00e8 }
                    com.zgoicsifmc.activities.SignUpConfirmActivity r6 = com.zgoicsifmc.activities.SignUpConfirmActivity.this     // Catch:{ Exception -> 0x00e8 }
                    r6.R(r5)     // Catch:{ Exception -> 0x00e8 }
                    goto L_0x00fa
                L_0x00e8:
                    r6 = move-exception
                    com.zgoicsifmc.activities.SignUpConfirmActivity$a r0 = com.zgoicsifmc.activities.SignUpConfirmActivity.a.this
                    com.zgoicsifmc.activities.SignUpConfirmActivity r0 = com.zgoicsifmc.activities.SignUpConfirmActivity.this
                    r0.R(r5)
                    qg1 r5 = defpackage.qg1.a()
                    r5.c(r6)
                    r6.printStackTrace()
                L_0x00fa:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.activities.SignUpConfirmActivity.a.C0020a.b(i32, i42):void");
            }
        }

        static {
            Class<SignUpConfirmActivity> cls = SignUpConfirmActivity.class;
        }

        public a() {
        }

        public void onClick(View view) {
            try {
                ((InputMethodManager) view.getContext().getSystemService(wx1.a(-481369857658152652L))).hideSoftInputFromWindow(view.getWindowToken(), 0);
            } catch (Exception e) {
                e.printStackTrace();
            }
            SignUpConfirmActivity.this.f1715a.b();
            SignUpConfirmActivity.this.f1712a.setEnabled(false);
            try {
                xt1 xt1 = new xt1(SignUpConfirmActivity.this.a);
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(wx1.a(-481369913492727500L), SignUpConfirmActivity.this.f1714a.toLowerCase().trim());
                jSONObject.put(wx1.a(-481369939262531276L), xt1.c(wx1.a(-481369956442400460L), wx1.a(-481369973622269644L)));
                jSONObject.put(wx1.a(-481369977917236940L), xt1.c(wx1.a(-481370042341746380L), wx1.a(-481370106766255820L)));
                jSONObject.put(wx1.a(-481370111061223116L), SignUpConfirmActivity.this.f1717b);
                jSONObject.put(wx1.a(-481370149715928780L), xt1.c(wx1.a(-481370179780699852L), wx1.a(-481370209845470924L)));
                o82.d(jSONObject.toString(), new Object[0]);
                vt1.a().d(xt1.i(wx1.a(-481370214140438220L)), jSONObject).F(new C0020a(xt1));
            } catch (Exception e2) {
                qg1.a().c(e2);
                e2.printStackTrace();
            }
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public void onClick(View view) {
            Intent intent = new Intent(SignUpConfirmActivity.this.a, SignUpActivity.class);
            intent.putExtra(wx1.a(-481370291449849548L), SignUpConfirmActivity.this.f1714a.toLowerCase().trim());
            intent.putExtra(wx1.a(-481370317219653324L), SignUpConfirmActivity.this.f1717b.trim());
            SignUpConfirmActivity.this.startActivity(intent);
            SignUpConfirmActivity.this.finish();
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(this.a, SignUpActivity.class);
        intent.putExtra(wx1.a(-481370420298868428L), this.f1714a.toLowerCase().trim());
        intent.putExtra(wx1.a(-481370446068672204L), this.f1717b.trim());
        startActivity(intent);
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427369);
        this.a = getApplicationContext();
        Button button = (Button) findViewById(2131230819);
        this.f1712a = button;
        button.setOnClickListener(this.f1711a);
        Button button2 = (Button) findViewById(2131230810);
        this.f1716b = button2;
        button2.setOnClickListener(this.b);
        this.f1715a = new nx1(this);
        this.f1714a = getIntent().getStringExtra(wx1.a(-481370355874358988L));
        this.f1717b = getIntent().getStringExtra(wx1.a(-481370381644162764L));
        ((TextView) findViewById(2131231143)).setText(Html.fromHtml(getString(2131624040)));
        TextView textView = (TextView) findViewById(2131231179);
        this.f1713a = textView;
        textView.setText(this.f1714a);
    }
}
