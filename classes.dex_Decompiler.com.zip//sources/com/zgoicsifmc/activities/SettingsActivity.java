package com.zgoicsifmc.activities;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1704a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1705a;

    /* renamed from: a  reason: collision with other field name */
    public SettingsActivity f1706a;

    public class a implements View.OnClickListener {

        /* renamed from: com.zgoicsifmc.activities.SettingsActivity$a$a  reason: collision with other inner class name */
        public class C0019a implements fq1 {
            public C0019a() {
            }

            public void a(List<String> list, boolean z) {
            }

            public void b(List<String> list, boolean z) {
                try {
                    uw1 uw1 = new uw1();
                    xt1 xt1 = new xt1(SettingsActivity.this.a);
                    xt1.q();
                    xt1.E();
                    uw1.a(SettingsActivity.this.a, xt1, true);
                } catch (Exception e) {
                    qg1.a().c(e);
                    e.printStackTrace();
                }
                SettingsActivity settingsActivity = SettingsActivity.this;
                settingsActivity.L(settingsActivity.a);
            }
        }

        public a() {
        }

        public void onClick(View view) {
            try {
                ArrayList arrayList = new ArrayList();
                arrayList.add(wx1.a(-481366425979283148L));
                arrayList.add(wx1.a(-481366597777974988L));
                arrayList.add(wx1.a(-481366773871634124L));
                arrayList.add(wx1.a(-481366954260260556L));
                arrayList.add(wx1.a(-481367126058952396L));
                arrayList.add(wx1.a(-481367306447578828L));
                arrayList.add(wx1.a(-481367482541237964L));
                arrayList.add(wx1.a(-481367594210387660L));
                arrayList.add(wx1.a(-481367731649341132L));
                arrayList.add(wx1.a(-481367851908425420L));
                arrayList.add(wx1.a(-481367993642346188L));
                arrayList.add(wx1.a(-481368135376266956L));
                lq1.f(SettingsActivity.this.f1706a).c(arrayList).e(new C0019a());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427363);
        this.a = getApplicationContext();
        this.f1706a = this;
        Button button = (Button) findViewById(2131230814);
        this.f1705a = button;
        button.setOnClickListener(this.f1704a);
        ((TextView) findViewById(2131231183)).setText(Html.fromHtml(wx1.a(-481368289995089612L)));
    }
}
