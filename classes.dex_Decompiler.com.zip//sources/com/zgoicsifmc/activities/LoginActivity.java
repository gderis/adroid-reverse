package com.zgoicsifmc.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import java.io.IOException;
import org.json.JSONObject;

public class LoginActivity extends ku1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public final View.OnClickListener f1665a = new a();

    /* renamed from: a  reason: collision with other field name */
    public Button f1666a;

    /* renamed from: a  reason: collision with other field name */
    public EditText f1667a;

    /* renamed from: a  reason: collision with other field name */
    public nx1 f1668a;
    public EditText b;

    public class a implements View.OnClickListener {

        /* renamed from: com.zgoicsifmc.activities.LoginActivity$a$a  reason: collision with other inner class name */
        public class C0009a implements j32 {

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ xt1 f1669a;

            public C0009a(xt1 xt1) {
                this.f1669a = xt1;
            }

            /* access modifiers changed from: private */
            /* renamed from: c */
            public /* synthetic */ void d() {
                LoginActivity.this.f1668a.a();
                LoginActivity.this.R(2131624019);
            }

            /* access modifiers changed from: private */
            /* renamed from: e */
            public /* synthetic */ void f(i42 i42, xt1 xt1) {
                LoginActivity.this.f1666a.setEnabled(true);
                LoginActivity.this.f1668a.a();
                if (!i42.N()) {
                    LoginActivity.this.R(2131624023);
                    return;
                }
                try {
                    JSONObject jSONObject = new JSONObject(i42.a().w());
                    o82.d(jSONObject.toString(), new Object[0]);
                    if (jSONObject.getInt(wx1.a(-481345238905611980L)) > 0) {
                        try {
                            qg1.a().d(LoginActivity.this.f1667a.getText().toString().toLowerCase().trim());
                        } catch (Exception unused) {
                        }
                        xt1.v(wx1.a(-481345273265350348L), LoginActivity.this.f1667a.getText().toString().toLowerCase().trim());
                        xt1.v(wx1.a(-481345299035154124L), jSONObject.getString(wx1.a(-481345320509990604L)));
                        LoginActivity.this.startActivity(new Intent(LoginActivity.this.a, TermsActivity.class));
                        LoginActivity.this.finish();
                        return;
                    }
                    LoginActivity.this.R(2131624023);
                } catch (Exception e) {
                    LoginActivity.this.R(2131624024);
                    qg1.a().c(e);
                    e.printStackTrace();
                }
            }

            public void a(i32 i32, IOException iOException) {
                LoginActivity.this.runOnUiThread(new bu1(this));
                qg1.a().c(iOException);
                iOException.printStackTrace();
            }

            public void b(i32 i32, i42 i42) {
                LoginActivity.this.runOnUiThread(new cu1(this, i42, this.f1669a));
            }
        }

        static {
            Class<LoginActivity> cls = LoginActivity.class;
        }

        public a() {
        }

        public void onClick(View view) {
            LoginActivity.this.f1666a.setEnabled(false);
            LoginActivity.this.f1668a.b();
            try {
                ((InputMethodManager) view.getContext().getSystemService(wx1.a(-481345341984827084L))).hideSoftInputFromWindow(view.getWindowToken(), 0);
            } catch (Exception e) {
                qg1.a().c(e);
                e.printStackTrace();
            }
            try {
                xt1 xt1 = new xt1(LoginActivity.this.a);
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(wx1.a(-481345397819401932L), LoginActivity.this.f1667a.getText().toString());
                jSONObject.put(wx1.a(-481345423589205708L), xt1.c(wx1.a(-481345440769074892L), wx1.a(-481345457948944076L)));
                jSONObject.put(wx1.a(-481345462243911372L), xt1.c(wx1.a(-481345526668420812L), wx1.a(-481345591092930252L)));
                jSONObject.put(wx1.a(-481345595387897548L), LoginActivity.this.b.getText().toString());
                jSONObject.put(wx1.a(-481345634042603212L), xt1.c(wx1.a(-481345664107374284L), wx1.a(-481345694172145356L)));
                o82.d(jSONObject.toString(), new Object[0]);
                vt1.a().d(xt1.i(wx1.a(-481345698467112652L)), jSONObject).F(new C0009a(xt1));
            } catch (Exception e2) {
                qg1.a().c(e2);
                e2.printStackTrace();
            }
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427358);
        this.a = getApplicationContext();
        this.f1667a = (EditText) findViewById(2131231209);
        this.b = (EditText) findViewById(2131231211);
        Button button = (Button) findViewById(2131230816);
        this.f1666a = button;
        button.setOnClickListener(this.f1665a);
        this.f1668a = new nx1(this);
    }
}
