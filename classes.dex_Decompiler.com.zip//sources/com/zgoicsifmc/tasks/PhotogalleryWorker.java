package com.zgoicsifmc.tasks;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class PhotogalleryWorker extends Worker {
    public PhotogalleryWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    public ListenableWorker.a o() {
        Context a = a();
        new ww1().a(a, new xt1(a), f().h("force", false));
        return ListenableWorker.a.c();
    }
}
