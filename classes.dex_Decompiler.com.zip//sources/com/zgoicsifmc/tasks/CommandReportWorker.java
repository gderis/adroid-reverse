package com.zgoicsifmc.tasks;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.zgoicsifmc.App;
import org.json.JSONObject;

public class CommandReportWorker extends Worker {
    public CommandReportWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    public ListenableWorker.a o() {
        j42 a;
        Context a2 = a();
        String j = f().j("command");
        xt1 xt1 = new xt1(a2);
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("email", xt1.c("email", ""));
            jSONObject.put("uid", xt1.c("uid", ""));
            jSONObject.put("firebase_token", xt1.c("firebase_token", ""));
            jSONObject.put("uuid", App.h());
            jSONObject.put("command", j);
            jSONObject.put("datetime", ox1.c(ox1.g()));
            o82.d(jSONObject.toString(), new Object[0]);
            String e = xt1.e("/mobile/report");
            o82.d(e, new Object[0]);
            a = vt1.a().d(e, jSONObject).E().a();
            o82.d(a.toString(), new Object[0]);
            a.close();
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        } catch (Throwable th) {
            if (a != null) {
                a.close();
            }
            throw th;
        }
        return ListenableWorker.a.c();
    }
}
