package com.zgoicsifmc;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;
import com.raizlabs.android.dbflow.config.FlowManager;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import org.json.JSONObject;

public class App extends Application {
    public static App a;

    /* renamed from: a  reason: collision with other field name */
    public static final String f1647a = wx1.a(-481386208598648524L);

    /* renamed from: a  reason: collision with other field name */
    public static final HashMap<String, Boolean> f1648a = new HashMap<>();
    public static String b;

    /* renamed from: b  reason: collision with other field name */
    public static final HashMap<String, Boolean> f1649b = new HashMap<>();

    /* renamed from: b  reason: collision with other field name */
    public static boolean f1650b = false;
    public static final HashMap<String, Long> c = new HashMap<>();

    /* renamed from: c  reason: collision with other field name */
    public static boolean f1651c = false;
    public static boolean d;
    public static boolean e;

    /* renamed from: a  reason: collision with other field name */
    public yn f1652a;

    public class a implements Runnable {
        public final /* synthetic */ Handler a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ xt1 f1654a;
        public final /* synthetic */ boolean b;

        /* renamed from: com.zgoicsifmc.App$a$a  reason: collision with other inner class name */
        public class C0007a implements j32 {
            public C0007a() {
            }

            public void a(i32 i32, IOException iOException) {
                iOException.printStackTrace();
            }

            public void b(i32 i32, i42 i42) {
                try {
                    App.this.d(new JSONObject(i42.a().w()));
                    boolean unused = App.e = false;
                    a.this.f1654a.B(wx1.a(-481383863546504908L));
                } catch (Exception e) {
                    boolean unused2 = App.e = false;
                    qg1.a().c(e);
                    e.printStackTrace();
                }
            }
        }

        public a(boolean z, xt1 xt1, Handler handler) {
            this.b = z;
            this.f1654a = xt1;
            this.a = handler;
        }

        public void run() {
            if ((!App.l() && !App.e) || this.b) {
                boolean unused = App.e = true;
                try {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(wx1.a(-481383893611275980L), this.f1654a.c(wx1.a(-481383919381079756L), wx1.a(-481383945150883532L)));
                    jSONObject.put(wx1.a(-481383949445850828L), this.f1654a.c(wx1.a(-481383966625720012L), wx1.a(-481383983805589196L)));
                    jSONObject.put(wx1.a(-481383988100556492L), this.f1654a.c(wx1.a(-481384052525065932L), wx1.a(-481384116949575372L)));
                    jSONObject.put(wx1.a(-481384121244542668L), this.f1654a.c(wx1.a(-481384159899248332L), wx1.a(-481384198553953996L)));
                    jSONObject.put(wx1.a(-481384202848921292L), this.f1654a.c(wx1.a(-481384232913692364L), wx1.a(-481384262978463436L)));
                    jSONObject.put(wx1.a(-481384267273430732L), this.f1654a.c(wx1.a(-481384284453299916L), wx1.a(-481384301633169100L)));
                    jSONObject.put(wx1.a(-481384305928136396L), this.f1654a.c(wx1.a(-481384340287874764L), wx1.a(-481384374647613132L)));
                    jSONObject.put(wx1.a(-481384378942580428L), this.f1654a.c(wx1.a(-481384404712384204L), wx1.a(-481384430482187980L)));
                    jSONObject.put(wx1.a(-481384434777155276L), wx1.a(-481384482021795532L));
                    jSONObject.put(wx1.a(-481384507791599308L), this.f1654a.b(wx1.a(-481384542151337676L), 0));
                    jSONObject.put(wx1.a(-481384576511076044L), this.f1654a.c(wx1.a(-481384610870814412L), wx1.a(-481384645230552780L)));
                    jSONObject.put(wx1.a(-481384649525520076L), this.f1654a.d(wx1.a(-481384679590291148L), false));
                    jSONObject.put(wx1.a(-481384709655062220L), this.f1654a.d(wx1.a(-481384726834931404L), false));
                    jSONObject.put(wx1.a(-481384744014800588L), this.f1654a.c(wx1.a(-481384778374538956L), wx1.a(-481384812734277324L)));
                    jSONObject.put(wx1.a(-481384817029244620L), this.f1654a.c(wx1.a(-481384859978917580L), wx1.a(-481384902928590540L)));
                    jSONObject.put(wx1.a(-481384907223557836L), this.f1654a.g());
                    jSONObject.put(wx1.a(-481384945878263500L), this.f1654a.k());
                    jSONObject.put(wx1.a(-481384988827936460L), this.f1654a.h());
                    o82.d(jSONObject.toString(), new Object[0]);
                    vt1.a().d(this.f1654a.e(wx1.a(-481385074727282380L)), jSONObject).F(new C0007a());
                } catch (Exception unused2) {
                }
            }
            if (!App.l()) {
                this.a.postDelayed(this, 120000);
            }
        }
    }

    public static synchronized App e() {
        App app;
        synchronized (App.class) {
            if (a == null) {
                a = new App();
            }
            app = a;
        }
        return app;
    }

    public static String g(Context context) {
        String networkCountryIso;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(wx1.a(-481385663137801932L));
            String simCountryIso = telephonyManager.getSimCountryIso();
            if (simCountryIso != null && simCountryIso.length() == 2) {
                return simCountryIso.toUpperCase(Locale.US);
            }
            if (!(telephonyManager.getPhoneType() == 2 || (networkCountryIso = telephonyManager.getNetworkCountryIso()) == null || networkCountryIso.length() != 2)) {
                return networkCountryIso.toUpperCase(Locale.US);
            }
            return wx1.a(-481385688907605708L);
        } catch (Exception unused) {
        }
    }

    public static String h() {
        String str = b;
        if (str == null || str.isEmpty()) {
            b = new xt1(e().getApplicationContext()).c(wx1.a(-481386178533877452L), wx1.a(-481386200008713932L));
        }
        String str2 = b;
        return str2 == null ? wx1.a(-481386204303681228L) : str2;
    }

    public static void i() {
        if (!l()) {
            p(true);
            new jx1().b();
            o82.d(wx1.a(-481385139151791820L), new Object[0]);
        }
    }

    public static boolean j() {
        return f1650b;
    }

    public static boolean k() {
        String str = Build.FINGERPRINT;
        if (!str.contains(wx1.a(-481385233641072332L)) && !str.contains(wx1.a(-481385268000810700L))) {
            String str2 = Build.MODEL;
            return str2.contains(wx1.a(-481385302360549068L)) || str2.contains(wx1.a(-481385349605189324L)) || str2.contains(wx1.a(-481385388259894988L)) || Build.MANUFACTURER.contains(wx1.a(-481385499929044684L)) || (Build.BRAND.contains(wx1.a(-481385547173684940L)) && Build.DEVICE.contains(wx1.a(-481385581533423308L))) || wx1.a(-481385615893161676L).equals(Build.PRODUCT);
        }
    }

    public static boolean l() {
        return f1651c;
    }

    public static void n(boolean z) {
        f1650b = z;
    }

    public static void o(boolean z) {
        d = z;
    }

    public static void p(boolean z) {
        f1651c = z;
    }

    public <T> void c(xn<T> xnVar) {
        xnVar.M(new on(60000, 1, 1.0f));
        f().a(xnVar);
    }

    public void d(JSONObject jSONObject) {
        try {
            xt1 xt1 = new xt1(e().getApplicationContext());
            o82.d(jSONObject.toString(), new Object[0]);
            xt1.v(wx1.a(-481385723267344076L), jSONObject.getString(wx1.a(-481385753332115148L)));
            i();
            try {
                JSONObject jSONObject2 = jSONObject.getJSONObject(wx1.a(-481385783396886220L));
                Iterator<String> keys = jSONObject2.keys();
                while (keys.hasNext()) {
                    String next = keys.next();
                    xt1.D(next, jSONObject2.getInt(next));
                }
                JSONObject jSONObject3 = jSONObject.getJSONObject(wx1.a(-481385809166689996L));
                Iterator<String> keys2 = jSONObject3.keys();
                while (keys2.hasNext()) {
                    String next2 = keys2.next();
                    xt1.C(next2, (long) jSONObject3.getInt(next2));
                }
            } catch (Exception e2) {
                qg1.a().c(e2);
                e2.printStackTrace();
            }
            try {
                if (!jSONObject.getString(wx1.a(-481385830641526476L)).isEmpty()) {
                    xt1.v(wx1.a(-481385877886166732L), jSONObject.getString(wx1.a(-481385925130806988L)));
                }
            } catch (Exception unused) {
            }
            try {
                if (!jSONObject.getString(wx1.a(-481385972375447244L)).isEmpty()) {
                    xt1.v(wx1.a(-481386023915054796L), jSONObject.getString(wx1.a(-481386075454662348L)));
                }
            } catch (Exception unused2) {
            }
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }

    public yn f() {
        if (this.f1652a == null) {
            this.f1652a = wo.a(getApplicationContext().getApplicationContext());
        }
        return this.f1652a;
    }

    public void m(boolean z) {
        try {
            xt1 xt1 = new xt1(e().getApplicationContext());
            if (xt1.a(wx1.a(-481385693202573004L), z)) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new a(z, xt1, handler), 5000);
            }
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        }
    }

    public void onCreate() {
        super.onCreate();
        a = this;
        this.f1652a = f();
        try {
            if (!j()) {
                n(true);
                xt1 xt1 = new xt1(this);
                xt1.q();
                xt1.E();
                FlowManager.n(this);
            }
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        }
    }
}
