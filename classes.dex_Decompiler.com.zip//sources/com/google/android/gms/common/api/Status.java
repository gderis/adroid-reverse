package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.internal.ReflectedParcelable;

public final class Status extends w10 implements rw, ReflectedParcelable {
    @RecentlyNonNull
    public static final Parcelable.Creator<Status> CREATOR = new z00();
    @RecentlyNonNull
    public static final Status a = new Status(0);
    @RecentlyNonNull
    public static final Status b = new Status(14);
    @RecentlyNonNull
    public static final Status c = new Status(8);
    @RecentlyNonNull
    public static final Status d = new Status(15);
    @RecentlyNonNull
    public static final Status e = new Status(16);
    public static final Status f = new Status(17);
    @RecentlyNonNull
    public static final Status g = new Status(18);

    /* renamed from: a  reason: collision with other field name */
    public final int f1303a;

    /* renamed from: a  reason: collision with other field name */
    public final PendingIntent f1304a;

    /* renamed from: a  reason: collision with other field name */
    public final String f1305a;

    /* renamed from: a  reason: collision with other field name */
    public final wv f1306a;

    /* renamed from: b  reason: collision with other field name */
    public final int f1307b;

    public Status(int i) {
        this(i, (String) null);
    }

    public Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this(i, i2, str, pendingIntent, (wv) null);
    }

    public Status(int i, int i2, String str, PendingIntent pendingIntent, wv wvVar) {
        this.f1303a = i;
        this.f1307b = i2;
        this.f1305a = str;
        this.f1304a = pendingIntent;
        this.f1306a = wvVar;
    }

    public Status(int i, String str) {
        this(1, i, str, (PendingIntent) null);
    }

    public Status(int i, String str, PendingIntent pendingIntent) {
        this(1, i, str, pendingIntent);
    }

    public Status(@RecentlyNonNull wv wvVar, @RecentlyNonNull String str) {
        this(wvVar, str, 17);
    }

    @Deprecated
    public Status(@RecentlyNonNull wv wvVar, @RecentlyNonNull String str, int i) {
        this(1, i, str, wvVar.C0(), wvVar);
    }

    @RecentlyNullable
    public final wv A0() {
        return this.f1306a;
    }

    public final int B0() {
        return this.f1307b;
    }

    @RecentlyNullable
    public final String C0() {
        return this.f1305a;
    }

    public final boolean D0() {
        return this.f1304a != null;
    }

    public final boolean E0() {
        return this.f1307b <= 0;
    }

    public final void F0(@RecentlyNonNull Activity activity, int i) {
        if (D0()) {
            activity.startIntentSenderForResult(((PendingIntent) s10.j(this.f1304a)).getIntentSender(), i, (Intent) null, 0, 0, 0);
        }
    }

    @RecentlyNonNull
    public final String G0() {
        String str = this.f1305a;
        return str != null ? str : kw.a(this.f1307b);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f1303a == status.f1303a && this.f1307b == status.f1307b && q10.a(this.f1305a, status.f1305a) && q10.a(this.f1304a, status.f1304a) && q10.a(this.f1306a, status.f1306a);
    }

    public final int hashCode() {
        return q10.b(Integer.valueOf(this.f1303a), Integer.valueOf(this.f1307b), this.f1305a, this.f1304a, this.f1306a);
    }

    @RecentlyNonNull
    public final String toString() {
        return q10.c(this).a("statusCode", G0()).a("resolution", this.f1304a).toString();
    }

    @RecentlyNonNull
    public final Status v() {
        return this;
    }

    public final void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.l(parcel, 1, B0());
        y10.r(parcel, 2, C0(), false);
        y10.p(parcel, 3, this.f1304a, i, false);
        y10.p(parcel, 4, A0(), i, false);
        y10.l(parcel, 1000, this.f1303a);
        y10.b(parcel, a2);
    }
}
