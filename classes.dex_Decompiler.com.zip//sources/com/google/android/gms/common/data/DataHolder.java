package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.annotation.KeepName;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;

@KeepName
public final class DataHolder extends w10 implements Closeable {
    @RecentlyNonNull
    public static final Parcelable.Creator<DataHolder> CREATOR = new b10();
    public static final a a = new a10(new String[0], (String) null);

    /* renamed from: a  reason: collision with other field name */
    public final int f1320a;

    /* renamed from: a  reason: collision with other field name */
    public Bundle f1321a;

    /* renamed from: a  reason: collision with other field name */
    public int[] f1322a;

    /* renamed from: a  reason: collision with other field name */
    public final CursorWindow[] f1323a;

    /* renamed from: a  reason: collision with other field name */
    public final String[] f1324a;
    public final int b;

    /* renamed from: b  reason: collision with other field name */
    public final Bundle f1325b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1326b = false;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1327c = true;

    public static class a {
        public final String a;

        /* renamed from: a  reason: collision with other field name */
        public final ArrayList<HashMap<String, Object>> f1328a;

        /* renamed from: a  reason: collision with other field name */
        public final HashMap<Object, Integer> f1329a;

        /* renamed from: a  reason: collision with other field name */
        public boolean f1330a;

        /* renamed from: a  reason: collision with other field name */
        public final String[] f1331a;
        public String b;

        public a(String[] strArr, String str) {
            this.f1331a = (String[]) s10.j(strArr);
            this.f1328a = new ArrayList<>();
            this.a = null;
            this.f1329a = new HashMap<>();
            this.f1330a = false;
            this.b = null;
        }

        public /* synthetic */ a(String[] strArr, String str, a10 a10) {
            this(strArr, (String) null);
        }
    }

    public DataHolder(int i, String[] strArr, CursorWindow[] cursorWindowArr, int i2, Bundle bundle) {
        this.f1320a = i;
        this.f1324a = strArr;
        this.f1323a = cursorWindowArr;
        this.b = i2;
        this.f1325b = bundle;
    }

    @RecentlyNullable
    public final Bundle A0() {
        return this.f1325b;
    }

    public final int B0() {
        return this.b;
    }

    public final void C0() {
        this.f1321a = new Bundle();
        int i = 0;
        int i2 = 0;
        while (true) {
            String[] strArr = this.f1324a;
            if (i2 >= strArr.length) {
                break;
            }
            this.f1321a.putInt(strArr[i2], i2);
            i2++;
        }
        this.f1322a = new int[this.f1323a.length];
        int i3 = 0;
        while (true) {
            CursorWindow[] cursorWindowArr = this.f1323a;
            if (i < cursorWindowArr.length) {
                this.f1322a[i] = i3;
                i3 += this.f1323a[i].getNumRows() - (i3 - cursorWindowArr[i].getStartPosition());
                i++;
            } else {
                this.c = i3;
                return;
            }
        }
    }

    public final void close() {
        synchronized (this) {
            if (!this.f1326b) {
                this.f1326b = true;
                int i = 0;
                while (true) {
                    CursorWindow[] cursorWindowArr = this.f1323a;
                    if (i >= cursorWindowArr.length) {
                        break;
                    }
                    cursorWindowArr[i].close();
                    i++;
                }
            }
        }
    }

    public final void finalize() {
        try {
            if (this.f1327c && this.f1323a.length > 0 && !isClosed()) {
                close();
                String obj = toString();
                StringBuilder sb = new StringBuilder(String.valueOf(obj).length() + 178);
                sb.append("Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: ");
                sb.append(obj);
                sb.append(")");
                sb.toString();
            }
        } finally {
            super.finalize();
        }
    }

    public final boolean isClosed() {
        boolean z;
        synchronized (this) {
            z = this.f1326b;
        }
        return z;
    }

    public final void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.s(parcel, 1, this.f1324a, false);
        y10.u(parcel, 2, this.f1323a, i, false);
        y10.l(parcel, 3, B0());
        y10.e(parcel, 4, A0(), false);
        y10.l(parcel, 1000, this.f1320a);
        y10.b(parcel, a2);
        if ((i & 1) != 0) {
            close();
        }
    }
}
