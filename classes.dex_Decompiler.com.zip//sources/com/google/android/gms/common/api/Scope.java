package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.internal.ReflectedParcelable;

public final class Scope extends w10 implements ReflectedParcelable {
    @RecentlyNonNull
    public static final Parcelable.Creator<Scope> CREATOR = new y00();
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final String f1302a;

    public Scope(int i, String str) {
        s10.g(str, "scopeUri must not be null or empty");
        this.a = i;
        this.f1302a = str;
    }

    public Scope(@RecentlyNonNull String str) {
        this(1, str);
    }

    @RecentlyNonNull
    public final String A0() {
        return this.f1302a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Scope)) {
            return false;
        }
        return this.f1302a.equals(((Scope) obj).f1302a);
    }

    public final int hashCode() {
        return this.f1302a.hashCode();
    }

    @RecentlyNonNull
    public final String toString() {
        return this.f1302a;
    }

    public final void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.l(parcel, 1, this.a);
        y10.r(parcel, 2, A0(), false);
        y10.b(parcel, a2);
    }
}
