package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import defpackage.nw;
import defpackage.rw;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@KeepName
public abstract class BasePendingResult<R extends rw> extends nw<R> {
    public static final ThreadLocal<Boolean> a = new g00();

    /* renamed from: a  reason: collision with other field name */
    public Status f1308a;

    /* renamed from: a  reason: collision with other field name */
    public final a<R> f1309a;

    /* renamed from: a  reason: collision with other field name */
    public final Object f1310a;

    /* renamed from: a  reason: collision with other field name */
    public final WeakReference<mw> f1311a;

    /* renamed from: a  reason: collision with other field name */
    public final ArrayList<nw.a> f1312a;

    /* renamed from: a  reason: collision with other field name */
    public final CountDownLatch f1313a;

    /* renamed from: a  reason: collision with other field name */
    public final AtomicReference<uz> f1314a;

    /* renamed from: a  reason: collision with other field name */
    public m10 f1315a;

    /* renamed from: a  reason: collision with other field name */
    public R f1316a;

    /* renamed from: a  reason: collision with other field name */
    public volatile rz<R> f1317a;

    /* renamed from: a  reason: collision with other field name */
    public sw<? super R> f1318a;

    /* renamed from: a  reason: collision with other field name */
    public volatile boolean f1319a;
    public boolean b;
    public boolean c;
    public boolean d;
    @KeepName
    public b mResultGuardian;

    public static class a<R extends rw> extends z60 {
        public a(@RecentlyNonNull Looper looper) {
            super(looper);
        }

        public final void a(@RecentlyNonNull sw<? super R> swVar, @RecentlyNonNull R r) {
            sendMessage(obtainMessage(1, new Pair((sw) s10.j(BasePendingResult.p(swVar)), r)));
        }

        public void handleMessage(@RecentlyNonNull Message message) {
            int i = message.what;
            if (i == 1) {
                Pair pair = (Pair) message.obj;
                sw swVar = (sw) pair.first;
                rw rwVar = (rw) pair.second;
                try {
                    swVar.g(rwVar);
                } catch (RuntimeException e) {
                    BasePendingResult.m(rwVar);
                    throw e;
                }
            } else if (i != 2) {
                StringBuilder sb = new StringBuilder(45);
                sb.append("Don't know how to handle message: ");
                sb.append(i);
                Log.wtf("BasePendingResult", sb.toString(), new Exception());
            } else {
                ((BasePendingResult) message.obj).h(Status.d);
            }
        }
    }

    public final class b {
        public b() {
        }

        public /* synthetic */ b(BasePendingResult basePendingResult, g00 g00) {
            this();
        }

        public final void finalize() {
            BasePendingResult.m(BasePendingResult.this.f1316a);
            super.finalize();
        }
    }

    @Deprecated
    public BasePendingResult() {
        this.f1310a = new Object();
        this.f1313a = new CountDownLatch(1);
        this.f1312a = new ArrayList<>();
        this.f1314a = new AtomicReference<>();
        this.d = false;
        this.f1309a = new a<>(Looper.getMainLooper());
        this.f1311a = new WeakReference<>((Object) null);
    }

    public BasePendingResult(mw mwVar) {
        this.f1310a = new Object();
        this.f1313a = new CountDownLatch(1);
        this.f1312a = new ArrayList<>();
        this.f1314a = new AtomicReference<>();
        this.d = false;
        this.f1309a = new a<>(mwVar != null ? mwVar.i() : Looper.getMainLooper());
        this.f1311a = new WeakReference<>(mwVar);
    }

    public static void m(rw rwVar) {
        if (rwVar instanceof ow) {
            try {
                ((ow) rwVar).a();
            } catch (RuntimeException unused) {
                String valueOf = String.valueOf(rwVar);
                StringBuilder sb = new StringBuilder(valueOf.length() + 18);
                sb.append("Unable to release ");
                sb.append(valueOf);
                sb.toString();
            }
        }
    }

    public static <R extends rw> sw<R> p(sw<R> swVar) {
        return swVar;
    }

    public final void b(@RecentlyNonNull nw.a aVar) {
        s10.b(aVar != null, "Callback cannot be null.");
        synchronized (this.f1310a) {
            if (i()) {
                aVar.a(this.f1308a);
            } else {
                this.f1312a.add(aVar);
            }
        }
    }

    @RecentlyNonNull
    public final R c(long j, @RecentlyNonNull TimeUnit timeUnit) {
        if (j > 0) {
            s10.i("await must not be called on the UI thread when time is greater than zero.");
        }
        boolean z = true;
        s10.n(!this.f1319a, "Result has already been consumed.");
        if (this.f1317a != null) {
            z = false;
        }
        s10.n(z, "Cannot await if then() has been called.");
        try {
            if (!this.f1313a.await(j, timeUnit)) {
                h(Status.d);
            }
        } catch (InterruptedException unused) {
            h(Status.b);
        }
        s10.n(i(), "Result is not ready.");
        return s();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:8|(2:10|11)|12|13|14|15) */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0027, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x0013 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d() {
        /*
            r2 = this;
            java.lang.Object r0 = r2.f1310a
            monitor-enter(r0)
            boolean r1 = r2.b     // Catch:{ all -> 0x0028 }
            if (r1 != 0) goto L_0x0026
            boolean r1 = r2.f1319a     // Catch:{ all -> 0x0028 }
            if (r1 == 0) goto L_0x000c
            goto L_0x0026
        L_0x000c:
            m10 r1 = r2.f1315a     // Catch:{ all -> 0x0028 }
            if (r1 == 0) goto L_0x0013
            r1.cancel()     // Catch:{ RemoteException -> 0x0013 }
        L_0x0013:
            R r1 = r2.f1316a     // Catch:{ all -> 0x0028 }
            m(r1)     // Catch:{ all -> 0x0028 }
            r1 = 1
            r2.b = r1     // Catch:{ all -> 0x0028 }
            com.google.android.gms.common.api.Status r1 = com.google.android.gms.common.api.Status.e     // Catch:{ all -> 0x0028 }
            rw r1 = r2.g(r1)     // Catch:{ all -> 0x0028 }
            r2.r(r1)     // Catch:{ all -> 0x0028 }
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return
        L_0x0026:
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return
        L_0x0028:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.api.internal.BasePendingResult.d():void");
    }

    public boolean e() {
        boolean z;
        synchronized (this.f1310a) {
            z = this.b;
        }
        return z;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x003e, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(defpackage.sw<? super R> r6) {
        /*
            r5 = this;
            java.lang.Object r0 = r5.f1310a
            monitor-enter(r0)
            if (r6 != 0) goto L_0x000a
            r6 = 0
            r5.f1318a = r6     // Catch:{ all -> 0x003f }
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            return
        L_0x000a:
            boolean r1 = r5.f1319a     // Catch:{ all -> 0x003f }
            r2 = 1
            r3 = 0
            if (r1 != 0) goto L_0x0012
            r1 = 1
            goto L_0x0013
        L_0x0012:
            r1 = 0
        L_0x0013:
            java.lang.String r4 = "Result has already been consumed."
            defpackage.s10.n(r1, r4)     // Catch:{ all -> 0x003f }
            rz<R> r1 = r5.f1317a     // Catch:{ all -> 0x003f }
            if (r1 != 0) goto L_0x001d
            goto L_0x001e
        L_0x001d:
            r2 = 0
        L_0x001e:
            java.lang.String r1 = "Cannot set callbacks if then() has been called."
            defpackage.s10.n(r2, r1)     // Catch:{ all -> 0x003f }
            boolean r1 = r5.e()     // Catch:{ all -> 0x003f }
            if (r1 == 0) goto L_0x002b
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            return
        L_0x002b:
            boolean r1 = r5.i()     // Catch:{ all -> 0x003f }
            if (r1 == 0) goto L_0x003b
            com.google.android.gms.common.api.internal.BasePendingResult$a<R> r1 = r5.f1309a     // Catch:{ all -> 0x003f }
            rw r2 = r5.s()     // Catch:{ all -> 0x003f }
            r1.a(r6, r2)     // Catch:{ all -> 0x003f }
            goto L_0x003d
        L_0x003b:
            r5.f1318a = r6     // Catch:{ all -> 0x003f }
        L_0x003d:
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            return
        L_0x003f:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.api.internal.BasePendingResult.f(sw):void");
    }

    public abstract R g(@RecentlyNonNull Status status);

    @Deprecated
    public final void h(@RecentlyNonNull Status status) {
        synchronized (this.f1310a) {
            if (!i()) {
                j(g(status));
                this.c = true;
            }
        }
    }

    public final boolean i() {
        return this.f1313a.getCount() == 0;
    }

    public final void j(@RecentlyNonNull R r) {
        synchronized (this.f1310a) {
            if (this.c || this.b) {
                m(r);
                return;
            }
            i();
            boolean z = true;
            s10.n(!i(), "Results have already been set");
            if (this.f1319a) {
                z = false;
            }
            s10.n(z, "Result has already been consumed");
            r(r);
        }
    }

    public final void n(uz uzVar) {
        this.f1314a.set(uzVar);
    }

    public final boolean o() {
        boolean e;
        synchronized (this.f1310a) {
            if (((mw) this.f1311a.get()) == null || !this.d) {
                d();
            }
            e = e();
        }
        return e;
    }

    public final void q() {
        this.d = this.d || a.get().booleanValue();
    }

    public final void r(R r) {
        this.f1316a = r;
        this.f1308a = r.v();
        this.f1315a = null;
        this.f1313a.countDown();
        if (this.b) {
            this.f1318a = null;
        } else {
            sw<? super R> swVar = this.f1318a;
            if (swVar != null) {
                this.f1309a.removeMessages(2);
                this.f1309a.a(swVar, s());
            } else if (this.f1316a instanceof ow) {
                this.mResultGuardian = new b(this, (g00) null);
            }
        }
        ArrayList<nw.a> arrayList = this.f1312a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            nw.a aVar = arrayList.get(i);
            i++;
            aVar.a(this.f1308a);
        }
        this.f1312a.clear();
    }

    public final R s() {
        R r;
        synchronized (this.f1310a) {
            s10.n(!this.f1319a, "Result has already been consumed.");
            s10.n(i(), "Result is not ready.");
            r = this.f1316a;
            this.f1316a = null;
            this.f1318a = null;
            this.f1319a = true;
        }
        uz andSet = this.f1314a.getAndSet((Object) null);
        if (andSet != null) {
            andSet.a(this);
        }
        return (rw) s10.j(r);
    }
}
