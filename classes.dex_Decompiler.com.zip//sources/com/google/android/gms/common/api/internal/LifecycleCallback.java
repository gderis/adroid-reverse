package com.google.android.gms.common.api.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Keep;
import androidx.annotation.RecentlyNonNull;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class LifecycleCallback {
    @RecentlyNonNull
    public final fx a;

    public LifecycleCallback(@RecentlyNonNull fx fxVar) {
        this.a = fxVar;
    }

    @RecentlyNonNull
    public static fx c(@RecentlyNonNull Activity activity) {
        return d(new ex(activity));
    }

    @RecentlyNonNull
    public static fx d(@RecentlyNonNull ex exVar) {
        if (exVar.c()) {
            return u00.H1(exVar.b());
        }
        if (exVar.d()) {
            return t00.e(exVar.a());
        }
        throw new IllegalArgumentException("Can't get fragment for unexpected activity.");
    }

    @Keep
    private static fx getChimeraLifecycleFragmentImpl(ex exVar) {
        throw new IllegalStateException("Method not available in SDK.");
    }

    public void a(@RecentlyNonNull String str, @RecentlyNonNull FileDescriptor fileDescriptor, @RecentlyNonNull PrintWriter printWriter, @RecentlyNonNull String[] strArr) {
    }

    @RecentlyNonNull
    public Activity b() {
        return this.a.d();
    }

    public void e(int i, int i2, @RecentlyNonNull Intent intent) {
    }

    public void f(Bundle bundle) {
    }

    public void g() {
    }

    public void h() {
    }

    public void i(@RecentlyNonNull Bundle bundle) {
    }

    public void j() {
    }

    public void k() {
    }
}
