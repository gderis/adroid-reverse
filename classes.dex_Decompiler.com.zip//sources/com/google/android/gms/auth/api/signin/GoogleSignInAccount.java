package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class GoogleSignInAccount extends w10 implements ReflectedParcelable {
    @RecentlyNonNull
    public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new ou();
    public static g40 a = j40.d();

    /* renamed from: a  reason: collision with other field name */
    public final int f1296a;

    /* renamed from: a  reason: collision with other field name */
    public long f1297a;

    /* renamed from: a  reason: collision with other field name */
    public Uri f1298a;

    /* renamed from: a  reason: collision with other field name */
    public String f1299a;

    /* renamed from: a  reason: collision with other field name */
    public List<Scope> f1300a;

    /* renamed from: a  reason: collision with other field name */
    public Set<Scope> f1301a = new HashSet();
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;

    public GoogleSignInAccount(int i, String str, String str2, String str3, String str4, Uri uri, String str5, long j, String str6, List<Scope> list, String str7, String str8) {
        this.f1296a = i;
        this.f1299a = str;
        this.b = str2;
        this.c = str3;
        this.d = str4;
        this.f1298a = uri;
        this.e = str5;
        this.f1297a = j;
        this.f = str6;
        this.f1300a = list;
        this.g = str7;
        this.h = str8;
    }

    @RecentlyNullable
    public static GoogleSignInAccount K0(String str) {
        String str2 = null;
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        String optString = jSONObject.optString("photoUrl");
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            hashSet.add(new Scope(jSONArray.getString(i)));
        }
        GoogleSignInAccount L0 = L0(jSONObject.optString("id"), jSONObject.has("tokenId") ? jSONObject.optString("tokenId") : null, jSONObject.has("email") ? jSONObject.optString("email") : null, jSONObject.has("displayName") ? jSONObject.optString("displayName") : null, jSONObject.has("givenName") ? jSONObject.optString("givenName") : null, jSONObject.has("familyName") ? jSONObject.optString("familyName") : null, parse, Long.valueOf(parseLong), jSONObject.getString("obfuscatedIdentifier"), hashSet);
        if (jSONObject.has("serverAuthCode")) {
            str2 = jSONObject.optString("serverAuthCode");
        }
        L0.e = str2;
        return L0;
    }

    public static GoogleSignInAccount L0(String str, String str2, String str3, String str4, String str5, String str6, Uri uri, Long l, String str7, Set<Scope> set) {
        return new GoogleSignInAccount(3, str, str2, str3, str4, uri, (String) null, (l == null ? Long.valueOf(a.b() / 1000) : l).longValue(), s10.f(str7), new ArrayList((Collection) s10.j(set)), str5, str6);
    }

    @RecentlyNullable
    public Account A0() {
        if (this.c == null) {
            return null;
        }
        return new Account(this.c, "com.google");
    }

    @RecentlyNullable
    public String B0() {
        return this.d;
    }

    @RecentlyNullable
    public String C0() {
        return this.c;
    }

    @RecentlyNullable
    public String D0() {
        return this.h;
    }

    @RecentlyNullable
    public String E0() {
        return this.g;
    }

    @RecentlyNullable
    public String F0() {
        return this.f1299a;
    }

    @RecentlyNullable
    public String G0() {
        return this.b;
    }

    @RecentlyNullable
    public Uri H0() {
        return this.f1298a;
    }

    public Set<Scope> I0() {
        HashSet hashSet = new HashSet(this.f1300a);
        hashSet.addAll(this.f1301a);
        return hashSet;
    }

    @RecentlyNullable
    public String J0() {
        return this.e;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GoogleSignInAccount)) {
            return false;
        }
        GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) obj;
        return googleSignInAccount.f.equals(this.f) && googleSignInAccount.I0().equals(I0());
    }

    public int hashCode() {
        return ((this.f.hashCode() + 527) * 31) + I0().hashCode();
    }

    public void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.l(parcel, 1, this.f1296a);
        y10.r(parcel, 2, F0(), false);
        y10.r(parcel, 3, G0(), false);
        y10.r(parcel, 4, C0(), false);
        y10.r(parcel, 5, B0(), false);
        y10.p(parcel, 6, H0(), i, false);
        y10.r(parcel, 7, J0(), false);
        y10.n(parcel, 8, this.f1297a);
        y10.r(parcel, 9, this.f, false);
        y10.v(parcel, 10, this.f1300a, false);
        y10.r(parcel, 11, E0(), false);
        y10.r(parcel, 12, D0(), false);
        y10.b(parcel, a2);
    }
}
