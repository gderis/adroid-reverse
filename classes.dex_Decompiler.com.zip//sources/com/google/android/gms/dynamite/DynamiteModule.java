package com.google.android.gms.dynamite;

import android.content.Context;
import android.database.Cursor;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.os.SystemClock;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.util.DynamiteApi;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import javax.annotation.concurrent.GuardedBy;

public final class DynamiteModule {
    @GuardedBy("DynamiteModule.class")
    public static int a = -1;

    /* renamed from: a  reason: collision with other field name */
    public static final b.C0006b f1332a = new x50();
    @RecentlyNonNull

    /* renamed from: a  reason: collision with other field name */
    public static final b f1333a = new a60();
    @GuardedBy("DynamiteModule.class")

    /* renamed from: a  reason: collision with other field name */
    public static h60 f1334a;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: a  reason: collision with other field name */
    public static j60 f1335a;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: a  reason: collision with other field name */
    public static Boolean f1336a;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: a  reason: collision with other field name */
    public static String f1337a;

    /* renamed from: a  reason: collision with other field name */
    public static final ThreadLocal<c> f1338a = new ThreadLocal<>();
    @RecentlyNonNull
    public static final b b = new z50();

    /* renamed from: b  reason: collision with other field name */
    public static final ThreadLocal<Long> f1339b = new w50();
    @RecentlyNonNull
    public static final b c = new c60();
    @RecentlyNonNull
    public static final b d = new b60();
    @RecentlyNonNull
    public static final b e = new e60();
    @RecentlyNonNull
    public static final b f = new d60();
    public static final b g = new f60();

    /* renamed from: a  reason: collision with other field name */
    public final Context f1340a;

    @DynamiteApi
    public static class DynamiteLoaderClassLoader {
        @GuardedBy("DynamiteLoaderClassLoader.class")
        @RecentlyNullable
        public static ClassLoader sClassLoader;
    }

    public static class a extends Exception {
        public a(String str) {
            super(str);
        }

        public a(String str, Throwable th) {
            super(str, th);
        }

        public /* synthetic */ a(String str, Throwable th, w50 w50) {
            this(str, th);
        }

        public /* synthetic */ a(String str, w50 w50) {
            this(str);
        }
    }

    public interface b {

        public static class a {
            public int a = 0;
            public int b = 0;
            public int c = 0;
        }

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$b  reason: collision with other inner class name */
        public interface C0006b {
            int a(Context context, String str);

            int b(Context context, String str, boolean z);
        }

        a a(Context context, String str, C0006b bVar);
    }

    public static class c {
        public Cursor a;

        public c() {
        }

        public /* synthetic */ c(w50 w50) {
            this();
        }
    }

    public static class d implements b.C0006b {
        public final int a;
        public final int b = 0;

        public d(int i, int i2) {
            this.a = i;
        }

        public final int a(Context context, String str) {
            return this.a;
        }

        public final int b(Context context, String str, boolean z) {
            return 0;
        }
    }

    public DynamiteModule(Context context) {
        this.f1340a = (Context) s10.j(context);
    }

    public static int a(@RecentlyNonNull Context context, @RecentlyNonNull String str) {
        try {
            ClassLoader classLoader = context.getApplicationContext().getClassLoader();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 61);
            sb.append("com.google.android.gms.dynamite.descriptors.");
            sb.append(str);
            sb.append(".ModuleDescriptor");
            Class<?> loadClass = classLoader.loadClass(sb.toString());
            Field declaredField = loadClass.getDeclaredField("MODULE_ID");
            Field declaredField2 = loadClass.getDeclaredField("MODULE_VERSION");
            if (q10.a(declaredField.get((Object) null), str)) {
                return declaredField2.getInt((Object) null);
            }
            String valueOf = String.valueOf(declaredField.get((Object) null));
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 51 + String.valueOf(str).length());
            sb2.append("Module descriptor id '");
            sb2.append(valueOf);
            sb2.append("' didn't match expected id '");
            sb2.append(str);
            sb2.append("'");
            sb2.toString();
            return 0;
        } catch (ClassNotFoundException unused) {
            StringBuilder sb3 = new StringBuilder(String.valueOf(str).length() + 45);
            sb3.append("Local module descriptor class for ");
            sb3.append(str);
            sb3.append(" not found.");
            sb3.toString();
            return 0;
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            if (valueOf2.length() != 0) {
                "Failed to load module descriptor class: ".concat(valueOf2);
            } else {
                new String("Failed to load module descriptor class: ");
            }
            return 0;
        }
    }

    public static int b(@RecentlyNonNull Context context, @RecentlyNonNull String str) {
        return e(context, str, false);
    }

    @RecentlyNonNull
    public static DynamiteModule d(@RecentlyNonNull Context context, @RecentlyNonNull b bVar, @RecentlyNonNull String str) {
        b.a a2;
        Context context2 = context;
        b bVar2 = bVar;
        String str2 = str;
        ThreadLocal<c> threadLocal = f1338a;
        c cVar = threadLocal.get();
        c cVar2 = new c((w50) null);
        threadLocal.set(cVar2);
        ThreadLocal<Long> threadLocal2 = f1339b;
        long longValue = threadLocal2.get().longValue();
        try {
            threadLocal2.set(Long.valueOf(SystemClock.elapsedRealtime()));
            a2 = bVar2.a(context2, str2, f1332a);
            int i = a2.a;
            int i2 = a2.b;
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 68 + String.valueOf(str).length());
            sb.append("Considering local module ");
            sb.append(str2);
            sb.append(":");
            sb.append(i);
            sb.append(" and remote module ");
            sb.append(str2);
            sb.append(":");
            sb.append(i2);
            sb.toString();
            int i3 = a2.c;
            if (i3 == 0 || ((i3 == -1 && a2.a == 0) || (i3 == 1 && a2.b == 0))) {
                int i4 = a2.a;
                int i5 = a2.b;
                StringBuilder sb2 = new StringBuilder(91);
                sb2.append("No acceptable module found. Local version is ");
                sb2.append(i4);
                sb2.append(" and remote version is ");
                sb2.append(i5);
                sb2.append(".");
                throw new a(sb2.toString(), (w50) null);
            } else if (i3 == -1) {
                DynamiteModule f2 = f(context2, str2);
                if (longValue == 0) {
                    threadLocal2.remove();
                } else {
                    threadLocal2.set(Long.valueOf(longValue));
                }
                Cursor cursor = cVar2.a;
                if (cursor != null) {
                    cursor.close();
                }
                threadLocal.set(cVar);
                return f2;
            } else if (i3 == 1) {
                DynamiteModule g2 = g(context2, str2, a2.b);
                if (longValue == 0) {
                    threadLocal2.remove();
                } else {
                    threadLocal2.set(Long.valueOf(longValue));
                }
                Cursor cursor2 = cVar2.a;
                if (cursor2 != null) {
                    cursor2.close();
                }
                threadLocal.set(cVar);
                return g2;
            } else {
                int i6 = a2.c;
                StringBuilder sb3 = new StringBuilder(47);
                sb3.append("VersionPolicy returned invalid code:");
                sb3.append(i6);
                throw new a(sb3.toString(), (w50) null);
            }
        } catch (a e2) {
            String valueOf = String.valueOf(e2.getMessage());
            if (valueOf.length() != 0) {
                "Failed to load remote module: ".concat(valueOf);
            } else {
                new String("Failed to load remote module: ");
            }
            int i7 = a2.a;
            if (i7 == 0 || bVar2.a(context2, str2, new d(i7, 0)).c != -1) {
                throw new a("Remote load failed. No local fallback found.", e2, (w50) null);
            }
            DynamiteModule f3 = f(context2, str2);
            int i8 = (longValue > 0 ? 1 : (longValue == 0 ? 0 : -1));
            ThreadLocal<Long> threadLocal3 = f1339b;
            if (i8 == 0) {
                threadLocal3.remove();
            } else {
                threadLocal3.set(Long.valueOf(longValue));
            }
            Cursor cursor3 = cVar2.a;
            if (cursor3 != null) {
                cursor3.close();
            }
            f1338a.set(cVar);
            return f3;
        } catch (Throwable th) {
            int i9 = (longValue > 0 ? 1 : (longValue == 0 ? 0 : -1));
            ThreadLocal<Long> threadLocal4 = f1339b;
            if (i9 == 0) {
                threadLocal4.remove();
            } else {
                threadLocal4.set(Long.valueOf(longValue));
            }
            Cursor cursor4 = cVar2.a;
            if (cursor4 != null) {
                cursor4.close();
            }
            f1338a.set(cVar);
            throw th;
        }
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:659)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:23:0x0054=Splitter:B:23:0x0054, B:18:0x0039=Splitter:B:18:0x0039, B:39:0x0099=Splitter:B:39:0x0099} */
    public static int e(@androidx.annotation.RecentlyNonNull android.content.Context r8, @androidx.annotation.RecentlyNonNull java.lang.String r9, boolean r10) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)     // Catch:{ all -> 0x00fc }
            java.lang.Boolean r1 = f1336a     // Catch:{ all -> 0x00f9 }
            if (r1 != 0) goto L_0x00cc
            android.content.Context r1 = r8.getApplicationContext()     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            java.lang.ClassLoader r1 = r1.getClassLoader()     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule$DynamiteLoaderClassLoader> r2 = com.google.android.gms.dynamite.DynamiteModule.DynamiteLoaderClassLoader.class
            java.lang.String r2 = r2.getName()     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            java.lang.Class r1 = r1.loadClass(r2)     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            java.lang.String r2 = "sClassLoader"
            java.lang.reflect.Field r1 = r1.getDeclaredField(r2)     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            java.lang.Class r2 = r1.getDeclaringClass()     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            monitor-enter(r2)     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
            r3 = 0
            java.lang.Object r4 = r1.get(r3)     // Catch:{ all -> 0x00a6 }
            java.lang.ClassLoader r4 = (java.lang.ClassLoader) r4     // Catch:{ all -> 0x00a6 }
            if (r4 == 0) goto L_0x003c
            java.lang.ClassLoader r1 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x00a6 }
            if (r4 != r1) goto L_0x0036
        L_0x0033:
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x00a6 }
            goto L_0x00a4
        L_0x0036:
            j(r4)     // Catch:{ a -> 0x0039 }
        L_0x0039:
            java.lang.Boolean r1 = java.lang.Boolean.TRUE     // Catch:{ all -> 0x00a6 }
            goto L_0x00a4
        L_0x003c:
            java.lang.String r4 = "com.google.android.gms"
            android.content.Context r5 = r8.getApplicationContext()     // Catch:{ all -> 0x00a6 }
            java.lang.String r5 = r5.getPackageName()     // Catch:{ all -> 0x00a6 }
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x00a6 }
            if (r4 == 0) goto L_0x0054
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x00a6 }
            r1.set(r3, r4)     // Catch:{ all -> 0x00a6 }
            goto L_0x0033
        L_0x0054:
            int r4 = n(r8, r9, r10)     // Catch:{ a -> 0x009c }
            java.lang.String r5 = f1337a     // Catch:{ a -> 0x009c }
            if (r5 == 0) goto L_0x0099
            boolean r5 = r5.isEmpty()     // Catch:{ a -> 0x009c }
            if (r5 == 0) goto L_0x0063
            goto L_0x0099
        L_0x0063:
            int r5 = android.os.Build.VERSION.SDK_INT     // Catch:{ a -> 0x009c }
            r6 = 29
            if (r5 < r6) goto L_0x007b
            dalvik.system.DelegateLastClassLoader r5 = new dalvik.system.DelegateLastClassLoader     // Catch:{ a -> 0x009c }
            java.lang.String r6 = f1337a     // Catch:{ a -> 0x009c }
            java.lang.Object r6 = defpackage.s10.j(r6)     // Catch:{ a -> 0x009c }
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ a -> 0x009c }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x009c }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x009c }
            goto L_0x008c
        L_0x007b:
            y50 r5 = new y50     // Catch:{ a -> 0x009c }
            java.lang.String r6 = f1337a     // Catch:{ a -> 0x009c }
            java.lang.Object r6 = defpackage.s10.j(r6)     // Catch:{ a -> 0x009c }
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ a -> 0x009c }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x009c }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x009c }
        L_0x008c:
            j(r5)     // Catch:{ a -> 0x009c }
            r1.set(r3, r5)     // Catch:{ a -> 0x009c }
            java.lang.Boolean r5 = java.lang.Boolean.TRUE     // Catch:{ a -> 0x009c }
            f1336a = r5     // Catch:{ a -> 0x009c }
            monitor-exit(r2)     // Catch:{ all -> 0x00a6 }
            monitor-exit(r0)     // Catch:{ all -> 0x00f9 }
            return r4
        L_0x0099:
            monitor-exit(r2)     // Catch:{ all -> 0x00a6 }
            monitor-exit(r0)     // Catch:{ all -> 0x00f9 }
            return r4
        L_0x009c:
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x00a6 }
            r1.set(r3, r4)     // Catch:{ all -> 0x00a6 }
            goto L_0x0033
        L_0x00a4:
            monitor-exit(r2)     // Catch:{ all -> 0x00a6 }
            goto L_0x00ca
        L_0x00a6:
            r1 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x00a6 }
            throw r1     // Catch:{ ClassNotFoundException -> 0x00ad, IllegalAccessException -> 0x00ab, NoSuchFieldException -> 0x00a9 }
        L_0x00a9:
            r1 = move-exception
            goto L_0x00ae
        L_0x00ab:
            r1 = move-exception
            goto L_0x00ae
        L_0x00ad:
            r1 = move-exception
        L_0x00ae:
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ all -> 0x00f9 }
            int r2 = r1.length()     // Catch:{ all -> 0x00f9 }
            int r2 = r2 + 30
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x00f9 }
            r3.<init>(r2)     // Catch:{ all -> 0x00f9 }
            java.lang.String r2 = "Failed to load module via V2: "
            r3.append(r2)     // Catch:{ all -> 0x00f9 }
            r3.append(r1)     // Catch:{ all -> 0x00f9 }
            r3.toString()     // Catch:{ all -> 0x00f9 }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x00f9 }
        L_0x00ca:
            f1336a = r1     // Catch:{ all -> 0x00f9 }
        L_0x00cc:
            monitor-exit(r0)     // Catch:{ all -> 0x00f9 }
            boolean r0 = r1.booleanValue()     // Catch:{ all -> 0x00fc }
            if (r0 == 0) goto L_0x00f4
            int r8 = n(r8, r9, r10)     // Catch:{ a -> 0x00d8 }
            return r8
        L_0x00d8:
            r9 = move-exception
            java.lang.String r10 = "Failed to retrieve remote module version: "
            java.lang.String r9 = r9.getMessage()     // Catch:{ all -> 0x00fc }
            java.lang.String r9 = java.lang.String.valueOf(r9)     // Catch:{ all -> 0x00fc }
            int r0 = r9.length()     // Catch:{ all -> 0x00fc }
            if (r0 == 0) goto L_0x00ed
            r10.concat(r9)     // Catch:{ all -> 0x00fc }
            goto L_0x00f2
        L_0x00ed:
            java.lang.String r9 = new java.lang.String     // Catch:{ all -> 0x00fc }
            r9.<init>(r10)     // Catch:{ all -> 0x00fc }
        L_0x00f2:
            r8 = 0
            return r8
        L_0x00f4:
            int r8 = l(r8, r9, r10)     // Catch:{ all -> 0x00fc }
            return r8
        L_0x00f9:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00f9 }
            throw r9     // Catch:{ all -> 0x00fc }
        L_0x00fc:
            r9 = move-exception
            defpackage.i40.a(r8, r9)
            goto L_0x0102
        L_0x0101:
            throw r9
        L_0x0102:
            goto L_0x0101
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.e(android.content.Context, java.lang.String, boolean):int");
    }

    public static DynamiteModule f(Context context, String str) {
        String valueOf = String.valueOf(str);
        if (valueOf.length() != 0) {
            "Selected local version of ".concat(valueOf);
        } else {
            new String("Selected local version of ");
        }
        return new DynamiteModule(context.getApplicationContext());
    }

    public static DynamiteModule g(Context context, String str, int i) {
        Boolean bool;
        u50 u50;
        try {
            synchronized (DynamiteModule.class) {
                bool = f1336a;
            }
            if (bool == null) {
                throw new a("Failed to determine which loading route to use.", (w50) null);
            } else if (bool.booleanValue()) {
                return m(context, str, i);
            } else {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
                sb.append("Selected remote version of ");
                sb.append(str);
                sb.append(", version >= ");
                sb.append(i);
                sb.toString();
                h60 h = h(context);
                if (h != null) {
                    int l = h.l();
                    if (l >= 3) {
                        c cVar = f1338a.get();
                        if (cVar != null) {
                            u50 = h.g(v50.e(context), str, i, v50.e(cVar.a));
                        } else {
                            throw new a("No cached result cursor holder", (w50) null);
                        }
                    } else {
                        u50 = l == 2 ? h.z(v50.e(context), str, i) : h.R(v50.e(context), str, i);
                    }
                    if (v50.d(u50) != null) {
                        return new DynamiteModule((Context) v50.d(u50));
                    }
                    throw new a("Failed to load remote module.", (w50) null);
                }
                throw new a("Failed to create IDynamiteLoader.", (w50) null);
            }
        } catch (RemoteException e2) {
            throw new a("Failed to load remote module.", e2, (w50) null);
        } catch (a e3) {
            throw e3;
        } catch (Throwable th) {
            i40.a(context, th);
            throw new a("Failed to load remote module.", th, (w50) null);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0058, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static defpackage.h60 h(android.content.Context r4) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)
            h60 r1 = f1334a     // Catch:{ all -> 0x0059 }
            if (r1 == 0) goto L_0x0009
            monitor-exit(r0)     // Catch:{ all -> 0x0059 }
            return r1
        L_0x0009:
            r1 = 0
            java.lang.String r2 = "com.google.android.gms"
            r3 = 3
            android.content.Context r4 = r4.createPackageContext(r2, r3)     // Catch:{ Exception -> 0x003d }
            java.lang.ClassLoader r4 = r4.getClassLoader()     // Catch:{ Exception -> 0x003d }
            java.lang.String r2 = "com.google.android.gms.chimera.container.DynamiteLoaderImpl"
            java.lang.Class r4 = r4.loadClass(r2)     // Catch:{ Exception -> 0x003d }
            java.lang.Object r4 = r4.newInstance()     // Catch:{ Exception -> 0x003d }
            android.os.IBinder r4 = (android.os.IBinder) r4     // Catch:{ Exception -> 0x003d }
            if (r4 != 0) goto L_0x0025
            r2 = r1
            goto L_0x0037
        L_0x0025:
            java.lang.String r2 = "com.google.android.gms.dynamite.IDynamiteLoader"
            android.os.IInterface r2 = r4.queryLocalInterface(r2)     // Catch:{ Exception -> 0x003d }
            boolean r3 = r2 instanceof defpackage.h60     // Catch:{ Exception -> 0x003d }
            if (r3 == 0) goto L_0x0032
            h60 r2 = (defpackage.h60) r2     // Catch:{ Exception -> 0x003d }
            goto L_0x0037
        L_0x0032:
            g60 r2 = new g60     // Catch:{ Exception -> 0x003d }
            r2.<init>(r4)     // Catch:{ Exception -> 0x003d }
        L_0x0037:
            if (r2 == 0) goto L_0x0057
            f1334a = r2     // Catch:{ Exception -> 0x003d }
            monitor-exit(r0)     // Catch:{ all -> 0x0059 }
            return r2
        L_0x003d:
            r4 = move-exception
            java.lang.String r2 = "Failed to load IDynamiteLoader from GmsCore: "
            java.lang.String r4 = r4.getMessage()     // Catch:{ all -> 0x0059 }
            java.lang.String r4 = java.lang.String.valueOf(r4)     // Catch:{ all -> 0x0059 }
            int r3 = r4.length()     // Catch:{ all -> 0x0059 }
            if (r3 == 0) goto L_0x0052
            r2.concat(r4)     // Catch:{ all -> 0x0059 }
            goto L_0x0057
        L_0x0052:
            java.lang.String r4 = new java.lang.String     // Catch:{ all -> 0x0059 }
            r4.<init>(r2)     // Catch:{ all -> 0x0059 }
        L_0x0057:
            monitor-exit(r0)     // Catch:{ all -> 0x0059 }
            return r1
        L_0x0059:
            r4 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0059 }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.h(android.content.Context):h60");
    }

    public static Boolean i() {
        Boolean valueOf;
        synchronized (DynamiteModule.class) {
            valueOf = Boolean.valueOf(a >= 2);
        }
        return valueOf;
    }

    @GuardedBy("DynamiteModule.class")
    public static void j(ClassLoader classLoader) {
        j60 j60;
        try {
            IBinder iBinder = (IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(new Class[0]).newInstance(new Object[0]);
            if (iBinder == null) {
                j60 = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
                j60 = queryLocalInterface instanceof j60 ? (j60) queryLocalInterface : new i60(iBinder);
            }
            f1335a = j60;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e2) {
            throw new a("Failed to instantiate dynamite loader", e2, (w50) null);
        }
    }

    public static boolean k(Cursor cursor) {
        c cVar = f1338a.get();
        if (cVar == null || cVar.a != null) {
            return false;
        }
        cVar.a = cursor;
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:41:0x007d A[Catch:{ all -> 0x006a }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0081 A[Catch:{ all -> 0x006a }] */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0088  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x008e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int l(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            h60 r0 = h(r8)
            r6 = 0
            if (r0 != 0) goto L_0x0008
            return r6
        L_0x0008:
            r7 = 0
            int r1 = r0.l()     // Catch:{ RemoteException -> 0x006c }
            r2 = 3
            if (r1 < r2) goto L_0x0055
            u50 r1 = defpackage.v50.e(r8)     // Catch:{ RemoteException -> 0x006c }
            java.lang.ThreadLocal<java.lang.Long> r8 = f1339b     // Catch:{ RemoteException -> 0x006c }
            java.lang.Object r8 = r8.get()     // Catch:{ RemoteException -> 0x006c }
            java.lang.Long r8 = (java.lang.Long) r8     // Catch:{ RemoteException -> 0x006c }
            long r4 = r8.longValue()     // Catch:{ RemoteException -> 0x006c }
            r2 = r9
            r3 = r10
            u50 r8 = r0.W(r1, r2, r3, r4)     // Catch:{ RemoteException -> 0x006c }
            java.lang.Object r8 = defpackage.v50.d(r8)     // Catch:{ RemoteException -> 0x006c }
            android.database.Cursor r8 = (android.database.Cursor) r8     // Catch:{ RemoteException -> 0x006c }
            if (r8 == 0) goto L_0x004f
            boolean r9 = r8.moveToFirst()     // Catch:{ RemoteException -> 0x004c, all -> 0x0049 }
            if (r9 != 0) goto L_0x0035
            goto L_0x004f
        L_0x0035:
            int r9 = r8.getInt(r6)     // Catch:{ RemoteException -> 0x004c, all -> 0x0049 }
            if (r9 <= 0) goto L_0x0042
            boolean r10 = k(r8)     // Catch:{ RemoteException -> 0x004c, all -> 0x0049 }
            if (r10 == 0) goto L_0x0042
            goto L_0x0043
        L_0x0042:
            r7 = r8
        L_0x0043:
            if (r7 == 0) goto L_0x0048
            r7.close()
        L_0x0048:
            return r9
        L_0x0049:
            r9 = move-exception
            r7 = r8
            goto L_0x008c
        L_0x004c:
            r9 = move-exception
            r7 = r8
            goto L_0x006d
        L_0x004f:
            if (r8 == 0) goto L_0x0054
            r8.close()
        L_0x0054:
            return r6
        L_0x0055:
            r2 = 2
            if (r1 != r2) goto L_0x0061
            u50 r8 = defpackage.v50.e(r8)     // Catch:{ RemoteException -> 0x006c }
            int r8 = r0.P(r8, r9, r10)     // Catch:{ RemoteException -> 0x006c }
            return r8
        L_0x0061:
            u50 r8 = defpackage.v50.e(r8)     // Catch:{ RemoteException -> 0x006c }
            int r8 = r0.w(r8, r9, r10)     // Catch:{ RemoteException -> 0x006c }
            return r8
        L_0x006a:
            r9 = move-exception
            goto L_0x008c
        L_0x006c:
            r9 = move-exception
        L_0x006d:
            java.lang.String r8 = "Failed to retrieve remote module version: "
            java.lang.String r9 = r9.getMessage()     // Catch:{ all -> 0x006a }
            java.lang.String r9 = java.lang.String.valueOf(r9)     // Catch:{ all -> 0x006a }
            int r10 = r9.length()     // Catch:{ all -> 0x006a }
            if (r10 == 0) goto L_0x0081
            r8.concat(r9)     // Catch:{ all -> 0x006a }
            goto L_0x0086
        L_0x0081:
            java.lang.String r9 = new java.lang.String     // Catch:{ all -> 0x006a }
            r9.<init>(r8)     // Catch:{ all -> 0x006a }
        L_0x0086:
            if (r7 == 0) goto L_0x008b
            r7.close()
        L_0x008b:
            return r6
        L_0x008c:
            if (r7 == 0) goto L_0x0091
            r7.close()
        L_0x0091:
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.l(android.content.Context, java.lang.String, boolean):int");
    }

    public static DynamiteModule m(Context context, String str, int i) {
        j60 j60;
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
        sb.append("Selected remote version of ");
        sb.append(str);
        sb.append(", version >= ");
        sb.append(i);
        sb.toString();
        synchronized (DynamiteModule.class) {
            j60 = f1335a;
        }
        if (j60 != null) {
            c cVar = f1338a.get();
            if (cVar == null || cVar.a == null) {
                throw new a("No result cursor", (w50) null);
            }
            Context applicationContext = context.getApplicationContext();
            Cursor cursor = cVar.a;
            v50.e(null);
            boolean booleanValue = i().booleanValue();
            u50 e2 = v50.e(applicationContext);
            u50 e3 = v50.e(cursor);
            Context context2 = (Context) v50.d(booleanValue ? j60.C(e2, str, i, e3) : j60.g(e2, str, i, e3));
            if (context2 != null) {
                return new DynamiteModule(context2);
            }
            throw new a("Failed to get module context", (w50) null);
        }
        throw new a("DynamiteLoaderV2 was not cached.", (w50) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0073, code lost:
        if (k(r10) != false) goto L_0x007a;
     */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x00a6  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int n(android.content.Context r10, java.lang.String r11, boolean r12) {
        /*
            r0 = 0
            java.lang.ThreadLocal<java.lang.Long> r1 = f1339b     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            java.lang.Object r1 = r1.get()     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            java.lang.Long r1 = (java.lang.Long) r1     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            long r1 = r1.longValue()     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            android.content.ContentResolver r3 = r10.getContentResolver()     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            if (r12 == 0) goto L_0x0016
            java.lang.String r10 = "api_force_staging"
            goto L_0x0018
        L_0x0016:
            java.lang.String r10 = "api"
        L_0x0018:
            android.net.Uri$Builder r12 = new android.net.Uri$Builder     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            r12.<init>()     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            java.lang.String r4 = "content"
            android.net.Uri$Builder r12 = r12.scheme(r4)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            java.lang.String r4 = "com.google.android.gms.chimera"
            android.net.Uri$Builder r12 = r12.authority(r4)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            android.net.Uri$Builder r10 = r12.path(r10)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            android.net.Uri$Builder r10 = r10.appendPath(r11)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            java.lang.String r11 = "requestStartTime"
            java.lang.String r12 = java.lang.String.valueOf(r1)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            android.net.Uri$Builder r10 = r10.appendQueryParameter(r11, r12)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            android.net.Uri r4 = r10.build()     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            android.database.Cursor r10 = r3.query(r4, r5, r6, r7, r8)     // Catch:{ Exception -> 0x0093, all -> 0x0091 }
            if (r10 == 0) goto L_0x0089
            boolean r11 = r10.moveToFirst()     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
            if (r11 == 0) goto L_0x0089
            r11 = 0
            int r11 = r10.getInt(r11)     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
            if (r11 <= 0) goto L_0x0079
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r12 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r12)     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
            r1 = 2
            java.lang.String r1 = r10.getString(r1)     // Catch:{ all -> 0x0076 }
            f1337a = r1     // Catch:{ all -> 0x0076 }
            java.lang.String r1 = "loaderVersion"
            int r1 = r10.getColumnIndex(r1)     // Catch:{ all -> 0x0076 }
            if (r1 < 0) goto L_0x006e
            int r1 = r10.getInt(r1)     // Catch:{ all -> 0x0076 }
            a = r1     // Catch:{ all -> 0x0076 }
        L_0x006e:
            monitor-exit(r12)     // Catch:{ all -> 0x0076 }
            boolean r12 = k(r10)     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
            if (r12 == 0) goto L_0x0079
            goto L_0x007a
        L_0x0076:
            r11 = move-exception
            monitor-exit(r12)     // Catch:{ all -> 0x0076 }
            throw r11     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
        L_0x0079:
            r0 = r10
        L_0x007a:
            if (r0 == 0) goto L_0x007f
            r0.close()
        L_0x007f:
            return r11
        L_0x0080:
            r11 = move-exception
            r0 = r10
            r10 = r11
            goto L_0x00a4
        L_0x0084:
            r11 = move-exception
            r9 = r11
            r11 = r10
            r10 = r9
            goto L_0x0095
        L_0x0089:
            com.google.android.gms.dynamite.DynamiteModule$a r11 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
            java.lang.String r12 = "Failed to connect to dynamite module ContentResolver."
            r11.<init>((java.lang.String) r12, (defpackage.w50) r0)     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
            throw r11     // Catch:{ Exception -> 0x0084, all -> 0x0080 }
        L_0x0091:
            r10 = move-exception
            goto L_0x00a4
        L_0x0093:
            r10 = move-exception
            r11 = r0
        L_0x0095:
            boolean r12 = r10 instanceof com.google.android.gms.dynamite.DynamiteModule.a     // Catch:{ all -> 0x00a2 }
            if (r12 == 0) goto L_0x009a
            throw r10     // Catch:{ all -> 0x00a2 }
        L_0x009a:
            com.google.android.gms.dynamite.DynamiteModule$a r12 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00a2 }
            java.lang.String r1 = "V2 version check failed"
            r12.<init>(r1, r10, r0)     // Catch:{ all -> 0x00a2 }
            throw r12     // Catch:{ all -> 0x00a2 }
        L_0x00a2:
            r10 = move-exception
            r0 = r11
        L_0x00a4:
            if (r0 == 0) goto L_0x00a9
            r0.close()
        L_0x00a9:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.n(android.content.Context, java.lang.String, boolean):int");
    }

    @RecentlyNonNull
    public final IBinder c(@RecentlyNonNull String str) {
        try {
            return (IBinder) this.f1340a.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e2) {
            String valueOf = String.valueOf(str);
            throw new a(valueOf.length() != 0 ? "Failed to instantiate module class: ".concat(valueOf) : new String("Failed to instantiate module class: "), e2, (w50) null);
        }
    }
}
