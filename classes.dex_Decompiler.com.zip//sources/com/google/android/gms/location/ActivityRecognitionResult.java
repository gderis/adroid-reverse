package com.google.android.gms.location;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.lang.reflect.Array;
import java.util.List;

public class ActivityRecognitionResult extends w10 implements ReflectedParcelable {
    @RecentlyNonNull
    public static final Parcelable.Creator<ActivityRecognitionResult> CREATOR = new pu0();
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public long f1341a;

    /* renamed from: a  reason: collision with other field name */
    public Bundle f1342a;

    /* renamed from: a  reason: collision with other field name */
    public List<ct0> f1343a;
    public long b;

    public ActivityRecognitionResult(@RecentlyNonNull List<ct0> list, long j, long j2, int i, Bundle bundle) {
        boolean z = true;
        s10.b(list != null && list.size() > 0, "Must have at least 1 detected activity");
        s10.b((j <= 0 || j2 <= 0) ? false : z, "Must set times");
        this.f1343a = list;
        this.f1341a = j;
        this.b = j2;
        this.a = i;
        this.f1342a = bundle;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0027, code lost:
        if ((r0 instanceof com.google.android.gms.location.ActivityRecognitionResult) != false) goto L_0x0022;
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x002c A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x002d  */
    @androidx.annotation.RecentlyNullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.location.ActivityRecognitionResult A0(@androidx.annotation.RecentlyNonNull android.content.Intent r3) {
        /*
            boolean r0 = C0(r3)
            r1 = 0
            if (r0 != 0) goto L_0x0009
        L_0x0007:
            r0 = r1
            goto L_0x002a
        L_0x0009:
            android.os.Bundle r0 = r3.getExtras()
            if (r0 != 0) goto L_0x0010
            goto L_0x0007
        L_0x0010:
            java.lang.String r2 = "com.google.android.location.internal.EXTRA_ACTIVITY_RESULT"
            java.lang.Object r0 = r0.get(r2)
            boolean r2 = r0 instanceof byte[]
            if (r2 == 0) goto L_0x0025
            byte[] r0 = (byte[]) r0
            android.os.Parcelable$Creator<com.google.android.gms.location.ActivityRecognitionResult> r2 = CREATOR
            z10 r0 = defpackage.a20.a(r0, r2)
        L_0x0022:
            com.google.android.gms.location.ActivityRecognitionResult r0 = (com.google.android.gms.location.ActivityRecognitionResult) r0
            goto L_0x002a
        L_0x0025:
            boolean r2 = r0 instanceof com.google.android.gms.location.ActivityRecognitionResult
            if (r2 == 0) goto L_0x0007
            goto L_0x0022
        L_0x002a:
            if (r0 == 0) goto L_0x002d
            return r0
        L_0x002d:
            java.util.List r3 = D0(r3)
            if (r3 == 0) goto L_0x0047
            boolean r0 = r3.isEmpty()
            if (r0 == 0) goto L_0x003a
            goto L_0x0047
        L_0x003a:
            int r0 = r3.size()
            int r0 = r0 + -1
            java.lang.Object r3 = r3.get(r0)
            com.google.android.gms.location.ActivityRecognitionResult r3 = (com.google.android.gms.location.ActivityRecognitionResult) r3
            return r3
        L_0x0047:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.location.ActivityRecognitionResult.A0(android.content.Intent):com.google.android.gms.location.ActivityRecognitionResult");
    }

    public static boolean C0(Intent intent) {
        if (intent == null) {
            return false;
        }
        if (intent.hasExtra("com.google.android.location.internal.EXTRA_ACTIVITY_RESULT")) {
            return true;
        }
        List<ActivityRecognitionResult> D0 = D0(intent);
        return D0 != null && !D0.isEmpty();
    }

    @RecentlyNullable
    public static List<ActivityRecognitionResult> D0(@RecentlyNonNull Intent intent) {
        if (intent != null && intent.hasExtra("com.google.android.location.internal.EXTRA_ACTIVITY_RESULT_LIST")) {
            return a20.b(intent, "com.google.android.location.internal.EXTRA_ACTIVITY_RESULT_LIST", CREATOR);
        }
        return null;
    }

    public static boolean E0(Bundle bundle, Bundle bundle2) {
        int length;
        if (bundle == null) {
            return bundle2 == null;
        }
        if (bundle2 == null || bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            if (!bundle2.containsKey(str)) {
                return false;
            }
            Object obj = bundle.get(str);
            Object obj2 = bundle2.get(str);
            if (obj == null) {
                if (obj2 != null) {
                    return false;
                }
            } else if (obj instanceof Bundle) {
                if (!E0(bundle.getBundle(str), bundle2.getBundle(str))) {
                    return false;
                }
            } else if (obj.getClass().isArray()) {
                if (obj2 != null && obj2.getClass().isArray() && (length = Array.getLength(obj)) == Array.getLength(obj2)) {
                    int i = 0;
                    while (i < length) {
                        if (q10.a(Array.get(obj, i), Array.get(obj2, i))) {
                            i++;
                        }
                    }
                    continue;
                }
                return false;
            } else if (!obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    @RecentlyNonNull
    public ct0 B0() {
        return this.f1343a.get(0);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && ActivityRecognitionResult.class == obj.getClass()) {
            ActivityRecognitionResult activityRecognitionResult = (ActivityRecognitionResult) obj;
            return this.f1341a == activityRecognitionResult.f1341a && this.b == activityRecognitionResult.b && this.a == activityRecognitionResult.a && q10.a(this.f1343a, activityRecognitionResult.f1343a) && E0(this.f1342a, activityRecognitionResult.f1342a);
        }
    }

    public final int hashCode() {
        return q10.b(Long.valueOf(this.f1341a), Long.valueOf(this.b), Integer.valueOf(this.a), this.f1343a, this.f1342a);
    }

    @RecentlyNonNull
    public String toString() {
        String valueOf = String.valueOf(this.f1343a);
        long j = this.f1341a;
        long j2 = this.b;
        StringBuilder sb = new StringBuilder(valueOf.length() + 124);
        sb.append("ActivityRecognitionResult [probableActivities=");
        sb.append(valueOf);
        sb.append(", timeMillis=");
        sb.append(j);
        sb.append(", elapsedRealtimeMillis=");
        sb.append(j2);
        sb.append("]");
        return sb.toString();
    }

    public void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.v(parcel, 1, this.f1343a, false);
        y10.n(parcel, 2, this.f1341a);
        y10.n(parcel, 3, this.b);
        y10.l(parcel, 4, this.a);
        y10.e(parcel, 5, this.f1342a, false);
        y10.b(parcel, a2);
    }
}
