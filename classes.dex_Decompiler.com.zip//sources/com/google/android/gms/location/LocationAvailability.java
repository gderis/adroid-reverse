package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;

public final class LocationAvailability extends w10 implements ReflectedParcelable {
    @RecentlyNonNull
    public static final Parcelable.Creator<LocationAvailability> CREATOR = new bu0();
    @Deprecated
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public long f1344a;

    /* renamed from: a  reason: collision with other field name */
    public lu0[] f1345a;
    @Deprecated
    public int b;
    public int c;

    public LocationAvailability(int i, int i2, int i3, long j, lu0[] lu0Arr) {
        this.c = i;
        this.a = i2;
        this.b = i3;
        this.f1344a = j;
        this.f1345a = lu0Arr;
    }

    public boolean A0() {
        return this.c < 1000;
    }

    public boolean equals(@RecentlyNonNull Object obj) {
        if (obj instanceof LocationAvailability) {
            LocationAvailability locationAvailability = (LocationAvailability) obj;
            return this.a == locationAvailability.a && this.b == locationAvailability.b && this.f1344a == locationAvailability.f1344a && this.c == locationAvailability.c && Arrays.equals(this.f1345a, locationAvailability.f1345a);
        }
    }

    public int hashCode() {
        return q10.b(Integer.valueOf(this.c), Integer.valueOf(this.a), Integer.valueOf(this.b), Long.valueOf(this.f1344a), this.f1345a);
    }

    @RecentlyNonNull
    public String toString() {
        boolean A0 = A0();
        StringBuilder sb = new StringBuilder(48);
        sb.append("LocationAvailability[isLocationAvailable: ");
        sb.append(A0);
        sb.append("]");
        return sb.toString();
    }

    public void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.l(parcel, 1, this.a);
        y10.l(parcel, 2, this.b);
        y10.n(parcel, 3, this.f1344a);
        y10.l(parcel, 4, this.c);
        y10.u(parcel, 5, this.f1345a, i, false);
        y10.b(parcel, a2);
    }
}
