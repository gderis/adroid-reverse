package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.internal.ReflectedParcelable;

public final class LocationRequest extends w10 implements ReflectedParcelable {
    @RecentlyNonNull
    public static final Parcelable.Creator<LocationRequest> CREATOR = new cu0();
    public float a;

    /* renamed from: a  reason: collision with other field name */
    public int f1346a;

    /* renamed from: a  reason: collision with other field name */
    public long f1347a;
    public int b;

    /* renamed from: b  reason: collision with other field name */
    public long f1348b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1349b;
    public long c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1350c;
    public long d;

    @Deprecated
    public LocationRequest() {
        this.f1346a = 102;
        this.f1347a = 3600000;
        this.f1348b = 600000;
        this.f1349b = false;
        this.c = Long.MAX_VALUE;
        this.b = Integer.MAX_VALUE;
        this.a = 0.0f;
        this.d = 0;
        this.f1350c = false;
    }

    public LocationRequest(int i, long j, long j2, boolean z, long j3, int i2, float f, long j4, boolean z2) {
        this.f1346a = i;
        this.f1347a = j;
        this.f1348b = j2;
        this.f1349b = z;
        this.c = j3;
        this.b = i2;
        this.a = f;
        this.d = j4;
        this.f1350c = z2;
    }

    @RecentlyNonNull
    public static LocationRequest A0() {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.H0(true);
        return locationRequest;
    }

    public static void I0(long j) {
        if (j < 0) {
            StringBuilder sb = new StringBuilder(38);
            sb.append("invalid interval: ");
            sb.append(j);
            throw new IllegalArgumentException(sb.toString());
        }
    }

    public long B0() {
        long j = this.d;
        long j2 = this.f1347a;
        return j < j2 ? j2 : j;
    }

    @RecentlyNonNull
    public LocationRequest C0(long j) {
        I0(j);
        this.f1349b = true;
        this.f1348b = j;
        return this;
    }

    @RecentlyNonNull
    public LocationRequest D0(long j) {
        I0(j);
        this.f1347a = j;
        if (!this.f1349b) {
            double d2 = (double) j;
            Double.isNaN(d2);
            this.f1348b = (long) (d2 / 6.0d);
        }
        return this;
    }

    @RecentlyNonNull
    public LocationRequest E0(int i) {
        if (i > 0) {
            this.b = i;
            return this;
        }
        StringBuilder sb = new StringBuilder(31);
        sb.append("invalid numUpdates: ");
        sb.append(i);
        throw new IllegalArgumentException(sb.toString());
    }

    @RecentlyNonNull
    public LocationRequest F0(int i) {
        if (i == 100 || i == 102 || i == 104 || i == 105) {
            this.f1346a = i;
            return this;
        }
        StringBuilder sb = new StringBuilder(28);
        sb.append("invalid quality: ");
        sb.append(i);
        throw new IllegalArgumentException(sb.toString());
    }

    @RecentlyNonNull
    public LocationRequest G0(float f) {
        if (f >= 0.0f) {
            this.a = f;
            return this;
        }
        StringBuilder sb = new StringBuilder(37);
        sb.append("invalid displacement: ");
        sb.append(f);
        throw new IllegalArgumentException(sb.toString());
    }

    @RecentlyNonNull
    public LocationRequest H0(boolean z) {
        this.f1350c = z;
        return this;
    }

    public boolean equals(Object obj) {
        if (obj instanceof LocationRequest) {
            LocationRequest locationRequest = (LocationRequest) obj;
            return this.f1346a == locationRequest.f1346a && this.f1347a == locationRequest.f1347a && this.f1348b == locationRequest.f1348b && this.f1349b == locationRequest.f1349b && this.c == locationRequest.c && this.b == locationRequest.b && this.a == locationRequest.a && B0() == locationRequest.B0() && this.f1350c == locationRequest.f1350c;
        }
    }

    public int hashCode() {
        return q10.b(Integer.valueOf(this.f1346a), Long.valueOf(this.f1347a), Float.valueOf(this.a), Long.valueOf(this.d));
    }

    @RecentlyNonNull
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Request[");
        int i = this.f1346a;
        sb.append(i != 100 ? i != 102 ? i != 104 ? i != 105 ? "???" : "PRIORITY_NO_POWER" : "PRIORITY_LOW_POWER" : "PRIORITY_BALANCED_POWER_ACCURACY" : "PRIORITY_HIGH_ACCURACY");
        if (this.f1346a != 105) {
            sb.append(" requested=");
            sb.append(this.f1347a);
            sb.append("ms");
        }
        sb.append(" fastest=");
        sb.append(this.f1348b);
        sb.append("ms");
        if (this.d > this.f1347a) {
            sb.append(" maxWait=");
            sb.append(this.d);
            sb.append("ms");
        }
        if (this.a > 0.0f) {
            sb.append(" smallestDisplacement=");
            sb.append(this.a);
            sb.append("m");
        }
        long j = this.c;
        if (j != Long.MAX_VALUE) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            sb.append(" expireIn=");
            sb.append(j - elapsedRealtime);
            sb.append("ms");
        }
        if (this.b != Integer.MAX_VALUE) {
            sb.append(" num=");
            sb.append(this.b);
        }
        sb.append(']');
        return sb.toString();
    }

    public void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.l(parcel, 1, this.f1346a);
        y10.n(parcel, 2, this.f1347a);
        y10.n(parcel, 3, this.f1348b);
        y10.c(parcel, 4, this.f1349b);
        y10.n(parcel, 5, this.c);
        y10.l(parcel, 6, this.b);
        y10.i(parcel, 7, this.a);
        y10.n(parcel, 8, this.d);
        y10.c(parcel, 9, this.f1350c);
        y10.b(parcel, a2);
    }
}
