package com.google.android.gms.measurement;

import android.annotation.TargetApi;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;

@TargetApi(24)
public final class AppMeasurementJobService extends JobService implements t41 {
    public u41<AppMeasurementJobService> a;

    public final boolean a(int i) {
        throw new UnsupportedOperationException();
    }

    public final void b(Intent intent) {
    }

    @TargetApi(24)
    public final void c(JobParameters jobParameters, boolean z) {
        jobFinished(jobParameters, false);
    }

    public final u41<AppMeasurementJobService> d() {
        if (this.a == null) {
            this.a = new u41<>(this);
        }
        return this.a;
    }

    public void onCreate() {
        super.onCreate();
        d().a();
    }

    public void onDestroy() {
        d().b();
        super.onDestroy();
    }

    public void onRebind(Intent intent) {
        d().h(intent);
    }

    public boolean onStartJob(JobParameters jobParameters) {
        d().g(jobParameters);
        return true;
    }

    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }

    public boolean onUnbind(Intent intent) {
        d().f(intent);
        return true;
    }
}
