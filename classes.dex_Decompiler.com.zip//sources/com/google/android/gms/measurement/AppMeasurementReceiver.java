package com.google.android.gms.measurement;

import android.content.Context;
import android.content.Intent;

public final class AppMeasurementReceiver extends wd implements h01 {
    public i01 a;

    public void a(Context context, Intent intent) {
        wd.c(context, intent);
    }

    public void onReceive(Context context, Intent intent) {
        if (this.a == null) {
            this.a = new i01(this);
        }
        this.a.a(context, intent);
    }
}
