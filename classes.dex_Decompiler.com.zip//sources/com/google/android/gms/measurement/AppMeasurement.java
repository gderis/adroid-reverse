package com.google.android.gms.measurement;

import android.os.Bundle;
import androidx.annotation.Keep;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Deprecated
public class AppMeasurement {
    public static volatile AppMeasurement a;

    /* renamed from: a  reason: collision with other field name */
    public final a31 f1351a;

    /* renamed from: a  reason: collision with other field name */
    public final w01 f1352a;

    public static class ConditionalUserProperty {
        @Keep
        public boolean mActive;
        @Keep
        public String mAppId;
        @Keep
        public long mCreationTimestamp;
        @Keep
        public String mExpiredEventName;
        @Keep
        public Bundle mExpiredEventParams;
        @Keep
        public String mName;
        @Keep
        public String mOrigin;
        @Keep
        public long mTimeToLive;
        @Keep
        public String mTimedOutEventName;
        @Keep
        public Bundle mTimedOutEventParams;
        @Keep
        public String mTriggerEventName;
        @Keep
        public long mTriggerTimeout;
        @Keep
        public String mTriggeredEventName;
        @Keep
        public Bundle mTriggeredEventParams;
        @Keep
        public long mTriggeredTimestamp;
        @Keep
        public Object mValue;

        public ConditionalUserProperty() {
        }

        public ConditionalUserProperty(Bundle bundle) {
            Class cls = Long.class;
            Class cls2 = String.class;
            s10.j(bundle);
            this.mAppId = (String) t11.b(bundle, "app_id", cls2, null);
            this.mOrigin = (String) t11.b(bundle, "origin", cls2, null);
            this.mName = (String) t11.b(bundle, "name", cls2, null);
            this.mValue = t11.b(bundle, "value", Object.class, null);
            this.mTriggerEventName = (String) t11.b(bundle, "trigger_event_name", cls2, null);
            this.mTriggerTimeout = ((Long) t11.b(bundle, "trigger_timeout", cls, 0L)).longValue();
            this.mTimedOutEventName = (String) t11.b(bundle, "timed_out_event_name", cls2, null);
            this.mTimedOutEventParams = (Bundle) t11.b(bundle, "timed_out_event_params", Bundle.class, null);
            this.mTriggeredEventName = (String) t11.b(bundle, "triggered_event_name", cls2, null);
            this.mTriggeredEventParams = (Bundle) t11.b(bundle, "triggered_event_params", Bundle.class, null);
            this.mTimeToLive = ((Long) t11.b(bundle, "time_to_live", cls, 0L)).longValue();
            this.mExpiredEventName = (String) t11.b(bundle, "expired_event_name", cls2, null);
            this.mExpiredEventParams = (Bundle) t11.b(bundle, "expired_event_params", Bundle.class, null);
            this.mActive = ((Boolean) t11.b(bundle, "active", Boolean.class, Boolean.FALSE)).booleanValue();
            this.mCreationTimestamp = ((Long) t11.b(bundle, "creation_timestamp", cls, 0L)).longValue();
            this.mTriggeredTimestamp = ((Long) t11.b(bundle, "triggered_timestamp", cls, 0L)).longValue();
        }

        public final Bundle a() {
            Bundle bundle = new Bundle();
            String str = this.mAppId;
            if (str != null) {
                bundle.putString("app_id", str);
            }
            String str2 = this.mOrigin;
            if (str2 != null) {
                bundle.putString("origin", str2);
            }
            String str3 = this.mName;
            if (str3 != null) {
                bundle.putString("name", str3);
            }
            Object obj = this.mValue;
            if (obj != null) {
                t11.a(bundle, obj);
            }
            String str4 = this.mTriggerEventName;
            if (str4 != null) {
                bundle.putString("trigger_event_name", str4);
            }
            bundle.putLong("trigger_timeout", this.mTriggerTimeout);
            String str5 = this.mTimedOutEventName;
            if (str5 != null) {
                bundle.putString("timed_out_event_name", str5);
            }
            Bundle bundle2 = this.mTimedOutEventParams;
            if (bundle2 != null) {
                bundle.putBundle("timed_out_event_params", bundle2);
            }
            String str6 = this.mTriggeredEventName;
            if (str6 != null) {
                bundle.putString("triggered_event_name", str6);
            }
            Bundle bundle3 = this.mTriggeredEventParams;
            if (bundle3 != null) {
                bundle.putBundle("triggered_event_params", bundle3);
            }
            bundle.putLong("time_to_live", this.mTimeToLive);
            String str7 = this.mExpiredEventName;
            if (str7 != null) {
                bundle.putString("expired_event_name", str7);
            }
            Bundle bundle4 = this.mExpiredEventParams;
            if (bundle4 != null) {
                bundle.putBundle("expired_event_params", bundle4);
            }
            bundle.putLong("creation_timestamp", this.mCreationTimestamp);
            bundle.putBoolean("active", this.mActive);
            bundle.putLong("triggered_timestamp", this.mTriggeredTimestamp);
            return bundle;
        }
    }

    public AppMeasurement(a31 a31) {
        s10.j(a31);
        this.f1351a = a31;
        this.f1352a = null;
    }

    public AppMeasurement(w01 w01) {
        s10.j(w01);
        this.f1352a = w01;
        this.f1351a = null;
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    @java.lang.Deprecated
    @androidx.annotation.Keep
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.measurement.AppMeasurement getInstance(android.content.Context r14) {
        /*
            com.google.android.gms.measurement.AppMeasurement r0 = a
            if (r0 != 0) goto L_0x005d
            java.lang.Class<com.google.android.gms.measurement.AppMeasurement> r0 = com.google.android.gms.measurement.AppMeasurement.class
            monitor-enter(r0)
            com.google.android.gms.measurement.AppMeasurement r1 = a     // Catch:{ all -> 0x005a }
            if (r1 != 0) goto L_0x0058
            r1 = 0
            java.lang.String r2 = "com.google.firebase.analytics.FirebaseAnalytics"
            java.lang.Class r2 = java.lang.Class.forName(r2)     // Catch:{ ClassNotFoundException -> 0x0032 }
            r3 = 2
            java.lang.Class[] r4 = new java.lang.Class[r3]     // Catch:{  }
            java.lang.Class<android.content.Context> r5 = android.content.Context.class
            r6 = 0
            r4[r6] = r5     // Catch:{  }
            java.lang.Class<android.os.Bundle> r5 = android.os.Bundle.class
            r7 = 1
            r4[r7] = r5     // Catch:{  }
            java.lang.String r5 = "getScionFrontendApiImplementation"
            java.lang.reflect.Method r2 = r2.getDeclaredMethod(r5, r4)     // Catch:{  }
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{  }
            r3[r6] = r14     // Catch:{  }
            r3[r7] = r1     // Catch:{  }
            java.lang.Object r2 = r2.invoke(r1, r3)     // Catch:{  }
            a31 r2 = (defpackage.a31) r2     // Catch:{  }
            goto L_0x0033
        L_0x0032:
            r2 = r1
        L_0x0033:
            if (r2 == 0) goto L_0x003d
            com.google.android.gms.measurement.AppMeasurement r14 = new com.google.android.gms.measurement.AppMeasurement     // Catch:{ all -> 0x005a }
            r14.<init>((defpackage.a31) r2)     // Catch:{ all -> 0x005a }
            a = r14     // Catch:{ all -> 0x005a }
            goto L_0x0058
        L_0x003d:
            ud0 r13 = new ud0     // Catch:{ all -> 0x005a }
            r3 = 0
            r5 = 0
            r7 = 1
            r8 = 0
            r9 = 0
            r10 = 0
            r11 = 0
            r12 = 0
            r2 = r13
            r2.<init>(r3, r5, r7, r8, r9, r10, r11, r12)     // Catch:{ all -> 0x005a }
            w01 r14 = defpackage.w01.h(r14, r13, r1)     // Catch:{ all -> 0x005a }
            com.google.android.gms.measurement.AppMeasurement r1 = new com.google.android.gms.measurement.AppMeasurement     // Catch:{ all -> 0x005a }
            r1.<init>((defpackage.w01) r14)     // Catch:{ all -> 0x005a }
            a = r1     // Catch:{ all -> 0x005a }
        L_0x0058:
            monitor-exit(r0)     // Catch:{ all -> 0x005a }
            goto L_0x005d
        L_0x005a:
            r14 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x005a }
            throw r14
        L_0x005d:
            com.google.android.gms.measurement.AppMeasurement r14 = a
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.measurement.AppMeasurement.getInstance(android.content.Context):com.google.android.gms.measurement.AppMeasurement");
    }

    @Keep
    public void beginAdUnitExposure(String str) {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            a31.m(str);
            return;
        }
        s10.j(this.f1352a);
        this.f1352a.g().i(str, this.f1352a.b().c());
    }

    @Keep
    public void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            a31.i(str, str2, bundle);
            return;
        }
        s10.j(this.f1352a);
        this.f1352a.F().B(str, str2, bundle);
    }

    @Keep
    public void endAdUnitExposure(String str) {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            a31.d(str);
            return;
        }
        s10.j(this.f1352a);
        this.f1352a.g().j(str, this.f1352a.b().c());
    }

    @Keep
    public long generateEventId() {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.a();
        }
        s10.j(this.f1352a);
        return this.f1352a.G().h0();
    }

    @Keep
    public String getAppInstanceId() {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.e();
        }
        s10.j(this.f1352a);
        return this.f1352a.F().q();
    }

    @Keep
    public List<ConditionalUserProperty> getConditionalUserProperties(String str, String str2) {
        List<Bundle> list;
        a31 a31 = this.f1351a;
        if (a31 != null) {
            list = a31.g(str, str2);
        } else {
            s10.j(this.f1352a);
            list = this.f1352a.F().C(str, str2);
        }
        ArrayList arrayList = new ArrayList(list == null ? 0 : list.size());
        for (Bundle conditionalUserProperty : list) {
            arrayList.add(new ConditionalUserProperty(conditionalUserProperty));
        }
        return arrayList;
    }

    @Keep
    public String getCurrentScreenClass() {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.c();
        }
        s10.j(this.f1352a);
        return this.f1352a.F().F();
    }

    @Keep
    public String getCurrentScreenName() {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.l();
        }
        s10.j(this.f1352a);
        return this.f1352a.F().E();
    }

    @Keep
    public String getGmpAppId() {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.h();
        }
        s10.j(this.f1352a);
        return this.f1352a.F().G();
    }

    @Keep
    public int getMaxUserProperties(String str) {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.f(str);
        }
        s10.j(this.f1352a);
        this.f1352a.F().y(str);
        return 25;
    }

    @Keep
    public Map<String, Object> getUserProperties(String str, String str2, boolean z) {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            return a31.j(str, str2, z);
        }
        s10.j(this.f1352a);
        return this.f1352a.F().D(str, str2, z);
    }

    @Keep
    public void logEventInternal(String str, String str2, Bundle bundle) {
        a31 a31 = this.f1351a;
        if (a31 != null) {
            a31.b(str, str2, bundle);
            return;
        }
        s10.j(this.f1352a);
        this.f1352a.F().X(str, str2, bundle);
    }

    @Keep
    public void setConditionalUserProperty(ConditionalUserProperty conditionalUserProperty) {
        s10.j(conditionalUserProperty);
        a31 a31 = this.f1351a;
        if (a31 != null) {
            a31.k(conditionalUserProperty.a());
            return;
        }
        s10.j(this.f1352a);
        this.f1352a.F().z(conditionalUserProperty.a());
    }
}
