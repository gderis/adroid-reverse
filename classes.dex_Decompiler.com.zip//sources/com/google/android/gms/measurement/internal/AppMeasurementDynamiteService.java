package com.google.android.gms.measurement.internal;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.util.DynamiteApi;
import java.util.Map;
import org.checkerframework.checker.nullness.qual.EnsuresNonNull;

@DynamiteApi
public class AppMeasurementDynamiteService extends kd0 {
    public final Map<Integer, y11> a = new o4();

    /* renamed from: a  reason: collision with other field name */
    public w01 f1353a = null;

    public void beginAdUnitExposure(String str, long j) {
        c();
        this.f1353a.g().i(str, j);
    }

    @EnsuresNonNull({"scion"})
    public final void c() {
        if (this.f1353a == null) {
            throw new IllegalStateException("Attempting to perform action before initialize.");
        }
    }

    public void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        c();
        this.f1353a.F().B(str, str2, bundle);
    }

    public void clearMeasurementEnabled(long j) {
        c();
        this.f1353a.F().T((Boolean) null);
    }

    public final void d(od0 od0, String str) {
        c();
        this.f1353a.G().R(od0, str);
    }

    public void endAdUnitExposure(String str, long j) {
        c();
        this.f1353a.g().j(str, j);
    }

    public void generateEventId(od0 od0) {
        c();
        long h0 = this.f1353a.G().h0();
        c();
        this.f1353a.G().S(od0, h0);
    }

    public void getAppInstanceId(od0 od0) {
        c();
        this.f1353a.f().r(new d21(this, od0));
    }

    public void getCachedAppInstanceId(od0 od0) {
        c();
        d(od0, this.f1353a.F().q());
    }

    public void getConditionalUserProperties(String str, String str2, od0 od0) {
        c();
        this.f1353a.f().r(new c61(this, od0, str, str2));
    }

    public void getCurrentScreenClass(od0 od0) {
        c();
        d(od0, this.f1353a.F().F());
    }

    public void getCurrentScreenName(od0 od0) {
        c();
        d(od0, this.f1353a.F().E());
    }

    public void getGmpAppId(od0 od0) {
        c();
        d(od0, this.f1353a.F().G());
    }

    public void getMaxUserProperties(String str, od0 od0) {
        c();
        this.f1353a.F().y(str);
        c();
        this.f1353a.G().T(od0, 25);
    }

    public void getTestFlag(od0 od0, int i) {
        c();
        if (i == 0) {
            this.f1353a.G().R(od0, this.f1353a.F().P());
        } else if (i == 1) {
            this.f1353a.G().S(od0, this.f1353a.F().Q().longValue());
        } else if (i == 2) {
            z51 G = this.f1353a.G();
            double doubleValue = this.f1353a.F().S().doubleValue();
            Bundle bundle = new Bundle();
            bundle.putDouble("r", doubleValue);
            try {
                od0.F0(bundle);
            } catch (RemoteException e) {
                G.a.c().r().b("Error returning double value to wrapper", e);
            }
        } else if (i == 3) {
            this.f1353a.G().T(od0, this.f1353a.F().R().intValue());
        } else if (i == 4) {
            this.f1353a.G().V(od0, this.f1353a.F().O().booleanValue());
        }
    }

    public void getUserProperties(String str, String str2, boolean z, od0 od0) {
        c();
        this.f1353a.f().r(new d41(this, od0, str, str2, z));
    }

    public void initForTests(Map map) {
        c();
    }

    public void initialize(u50 u50, ud0 ud0, long j) {
        w01 w01 = this.f1353a;
        if (w01 == null) {
            this.f1353a = w01.h((Context) s10.j((Context) v50.d(u50)), ud0, Long.valueOf(j));
        } else {
            w01.c().r().a("Attempting to initialize multiple times");
        }
    }

    public void isDataCollectionEnabled(od0 od0) {
        c();
        this.f1353a.f().r(new d61(this, od0));
    }

    public void logEvent(String str, String str2, Bundle bundle, boolean z, boolean z2, long j) {
        c();
        this.f1353a.F().a0(str, str2, bundle, z, z2, j);
    }

    public void logEventAndBundle(String str, String str2, Bundle bundle, od0 od0, long j) {
        Bundle bundle2;
        c();
        s10.f(str2);
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle2.putString("_o", "app");
        this.f1353a.f().r(new d31(this, od0, new pv0(str2, new nv0(bundle), "app", j), str));
    }

    public void logHealthData(int i, String str, u50 u50, u50 u502, u50 u503) {
        c();
        Object obj = null;
        Object d = u50 == null ? null : v50.d(u50);
        Object d2 = u502 == null ? null : v50.d(u502);
        if (u503 != null) {
            obj = v50.d(u503);
        }
        this.f1353a.c().y(i, true, false, str, d, d2, obj);
    }

    public void onActivityCreated(u50 u50, Bundle bundle, long j) {
        c();
        y21 y21 = this.f1353a.F().f6147a;
        if (y21 != null) {
            this.f1353a.F().N();
            y21.onActivityCreated((Activity) v50.d(u50), bundle);
        }
    }

    public void onActivityDestroyed(u50 u50, long j) {
        c();
        y21 y21 = this.f1353a.F().f6147a;
        if (y21 != null) {
            this.f1353a.F().N();
            y21.onActivityDestroyed((Activity) v50.d(u50));
        }
    }

    public void onActivityPaused(u50 u50, long j) {
        c();
        y21 y21 = this.f1353a.F().f6147a;
        if (y21 != null) {
            this.f1353a.F().N();
            y21.onActivityPaused((Activity) v50.d(u50));
        }
    }

    public void onActivityResumed(u50 u50, long j) {
        c();
        y21 y21 = this.f1353a.F().f6147a;
        if (y21 != null) {
            this.f1353a.F().N();
            y21.onActivityResumed((Activity) v50.d(u50));
        }
    }

    public void onActivitySaveInstanceState(u50 u50, od0 od0, long j) {
        c();
        y21 y21 = this.f1353a.F().f6147a;
        Bundle bundle = new Bundle();
        if (y21 != null) {
            this.f1353a.F().N();
            y21.onActivitySaveInstanceState((Activity) v50.d(u50), bundle);
        }
        try {
            od0.F0(bundle);
        } catch (RemoteException e) {
            this.f1353a.c().r().b("Error returning bundle value to wrapper", e);
        }
    }

    public void onActivityStarted(u50 u50, long j) {
        c();
        if (this.f1353a.F().f6147a != null) {
            this.f1353a.F().N();
            Activity activity = (Activity) v50.d(u50);
        }
    }

    public void onActivityStopped(u50 u50, long j) {
        c();
        if (this.f1353a.F().f6147a != null) {
            this.f1353a.F().N();
            Activity activity = (Activity) v50.d(u50);
        }
    }

    public void performAction(Bundle bundle, od0 od0, long j) {
        c();
        od0.F0((Bundle) null);
    }

    public void registerOnMeasurementEventListener(rd0 rd0) {
        y11 y11;
        c();
        synchronized (this.a) {
            y11 = this.a.get(Integer.valueOf(rd0.t0()));
            if (y11 == null) {
                y11 = new f61(this, rd0);
                this.a.put(Integer.valueOf(rd0.t0()), y11);
            }
        }
        this.f1353a.F().w(y11);
    }

    public void resetAnalyticsData(long j) {
        c();
        this.f1353a.F().s(j);
    }

    public void setConditionalUserProperty(Bundle bundle, long j) {
        c();
        if (bundle == null) {
            this.f1353a.c().o().a("Conditional user property must not be null");
        } else {
            this.f1353a.F().A(bundle, j);
        }
    }

    public void setConsent(Bundle bundle, long j) {
        c();
        z21 F = this.f1353a.F();
        jp0.b();
        if (!F.a.z().w((String) null, bz0.C0) || TextUtils.isEmpty(F.a.a().q())) {
            F.U(bundle, 0, j);
        } else {
            F.a.c().t().a("Using developer consent only; google app id found");
        }
    }

    public void setConsentThirdParty(Bundle bundle, long j) {
        c();
        this.f1353a.F().U(bundle, -20, j);
    }

    public void setCurrentScreen(u50 u50, String str, String str2, long j) {
        c();
        this.f1353a.Q().v((Activity) v50.d(u50), str, str2);
    }

    public void setDataCollectionEnabled(boolean z) {
        c();
        z21 F = this.f1353a.F();
        F.j();
        F.a.f().r(new c21(F, z));
    }

    public void setDefaultEventParameters(Bundle bundle) {
        c();
        z21 F = this.f1353a.F();
        F.a.f().r(new a21(F, bundle == null ? null : new Bundle(bundle)));
    }

    public void setEventInterceptor(rd0 rd0) {
        c();
        e61 e61 = new e61(this, rd0);
        if (this.f1353a.f().o()) {
            this.f1353a.F().v(e61);
        } else {
            this.f1353a.f().r(new e51(this, e61));
        }
    }

    public void setInstanceIdProvider(td0 td0) {
        c();
    }

    public void setMeasurementEnabled(boolean z, long j) {
        c();
        this.f1353a.F().T(Boolean.valueOf(z));
    }

    public void setMinimumSessionDuration(long j) {
        c();
    }

    public void setSessionTimeoutDuration(long j) {
        c();
        z21 F = this.f1353a.F();
        F.a.f().r(new f21(F, j));
    }

    public void setUserId(String str, long j) {
        c();
        if (!this.f1353a.z().w((String) null, bz0.A0) || str == null || str.length() != 0) {
            this.f1353a.F().d0((String) null, "_id", str, true, j);
        } else {
            this.f1353a.c().r().a("User ID must be non-empty");
        }
    }

    public void setUserProperty(String str, String str2, u50 u50, boolean z, long j) {
        c();
        this.f1353a.F().d0(str, str2, v50.d(u50), z, j);
    }

    public void unregisterOnMeasurementEventListener(rd0 rd0) {
        y11 remove;
        c();
        synchronized (this.a) {
            remove = this.a.remove(Integer.valueOf(rd0.t0()));
        }
        if (remove == null) {
            remove = new f61(this, rd0);
        }
        this.f1353a.F().x(remove);
    }
}
