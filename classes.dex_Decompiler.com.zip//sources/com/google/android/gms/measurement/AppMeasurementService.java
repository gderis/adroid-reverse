package com.google.android.gms.measurement;

import android.app.Service;
import android.app.job.JobParameters;
import android.content.Intent;
import android.os.IBinder;

public final class AppMeasurementService extends Service implements t41 {
    public u41<AppMeasurementService> a;

    public final boolean a(int i) {
        return stopSelfResult(i);
    }

    public final void b(Intent intent) {
        wd.b(intent);
    }

    public final void c(JobParameters jobParameters, boolean z) {
        throw new UnsupportedOperationException();
    }

    public final u41<AppMeasurementService> d() {
        if (this.a == null) {
            this.a = new u41<>(this);
        }
        return this.a;
    }

    public IBinder onBind(Intent intent) {
        return d().e(intent);
    }

    public void onCreate() {
        super.onCreate();
        d().a();
    }

    public void onDestroy() {
        d().b();
        super.onDestroy();
    }

    public void onRebind(Intent intent) {
        d().h(intent);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        d().c(intent, i, i2);
        return 2;
    }

    public boolean onUnbind(Intent intent) {
        d().f(intent);
        return true;
    }
}
