package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BottomAppBar extends Toolbar implements CoordinatorLayout.b {
    public static final int m = w91.Widget_MaterialComponents_BottomAppBar;
    public Animator a;

    /* renamed from: a  reason: collision with other field name */
    public AnimatorListenerAdapter f1388a;

    /* renamed from: a  reason: collision with other field name */
    public Behavior f1389a;

    /* renamed from: a  reason: collision with other field name */
    public final hd1 f1390a;

    /* renamed from: a  reason: collision with other field name */
    public ia1<FloatingActionButton> f1391a;
    public Animator b;
    public ArrayList<g> c;
    public boolean e;
    public boolean f;
    public boolean g;
    public final int n;
    public int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public int u;

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {
        public final Rect a = new Rect();

        /* renamed from: a  reason: collision with other field name */
        public final View.OnLayoutChangeListener f1392a = new a();

        /* renamed from: a  reason: collision with other field name */
        public WeakReference<BottomAppBar> f1393a;
        public int d;

        public class a implements View.OnLayoutChangeListener {
            public a() {
            }

            public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                BottomAppBar bottomAppBar = (BottomAppBar) Behavior.this.f1393a.get();
                if (bottomAppBar == null || !(view instanceof FloatingActionButton)) {
                    view.removeOnLayoutChangeListener(this);
                    return;
                }
                FloatingActionButton floatingActionButton = (FloatingActionButton) view;
                floatingActionButton.j(Behavior.this.a);
                int height = Behavior.this.a.height();
                bottomAppBar.x0(height);
                CoordinatorLayout.f fVar = (CoordinatorLayout.f) view.getLayoutParams();
                if (Behavior.this.d == 0) {
                    fVar.bottomMargin = bottomAppBar.getBottomInset() + (bottomAppBar.getResources().getDimensionPixelOffset(q91.mtrl_bottomappbar_fab_bottom_margin) - ((floatingActionButton.getMeasuredHeight() - height) / 2));
                    fVar.leftMargin = bottomAppBar.getLeftInset();
                    fVar.rightMargin = bottomAppBar.getRightInset();
                    if (nc1.d(floatingActionButton)) {
                        fVar.leftMargin += bottomAppBar.n;
                    } else {
                        fVar.rightMargin += bottomAppBar.n;
                    }
                }
            }
        }

        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        /* renamed from: M */
        public boolean l(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, int i) {
            this.f1393a = new WeakReference<>(bottomAppBar);
            View d0 = bottomAppBar.n0();
            if (d0 != null && !ya.T(d0)) {
                CoordinatorLayout.f fVar = (CoordinatorLayout.f) d0.getLayoutParams();
                fVar.b = 49;
                this.d = fVar.bottomMargin;
                if (d0 instanceof FloatingActionButton) {
                    FloatingActionButton floatingActionButton = (FloatingActionButton) d0;
                    floatingActionButton.addOnLayoutChangeListener(this.f1392a);
                    bottomAppBar.f0(floatingActionButton);
                }
                bottomAppBar.v0();
            }
            coordinatorLayout.I(bottomAppBar, i);
            return super.l(coordinatorLayout, bottomAppBar, i);
        }

        /* renamed from: N */
        public boolean A(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, View view, View view2, int i, int i2) {
            return bottomAppBar.getHideOnScroll() && super.A(coordinatorLayout, bottomAppBar, view, view2, i, i2);
        }
    }

    public class a extends AnimatorListenerAdapter {
        public a() {
        }

        public void onAnimationEnd(Animator animator) {
            BottomAppBar.this.k0();
            Animator unused = BottomAppBar.this.a = null;
        }

        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.l0();
        }
    }

    public class b extends FloatingActionButton.b {
        public final /* synthetic */ int a;

        public class a extends FloatingActionButton.b {
            public a() {
            }

            public void b(FloatingActionButton floatingActionButton) {
                BottomAppBar.this.k0();
            }
        }

        public b(int i) {
            this.a = i;
        }

        public void a(FloatingActionButton floatingActionButton) {
            floatingActionButton.setTranslationX(BottomAppBar.this.p0(this.a));
            floatingActionButton.s(new a());
        }
    }

    public class c extends AnimatorListenerAdapter {
        public c() {
        }

        public void onAnimationEnd(Animator animator) {
            BottomAppBar.this.k0();
            boolean unused = BottomAppBar.this.f = false;
            Animator unused2 = BottomAppBar.this.b = null;
        }

        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.l0();
        }
    }

    public class d extends AnimatorListenerAdapter {
        public final /* synthetic */ int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ ActionMenuView f1395a;

        /* renamed from: a  reason: collision with other field name */
        public boolean f1397a;
        public final /* synthetic */ boolean b;

        public d(ActionMenuView actionMenuView, int i, boolean z) {
            this.f1395a = actionMenuView;
            this.a = i;
            this.b = z;
        }

        public void onAnimationCancel(Animator animator) {
            this.f1397a = true;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f1397a) {
                boolean z = BottomAppBar.this.r != 0;
                BottomAppBar bottomAppBar = BottomAppBar.this;
                bottomAppBar.t0(bottomAppBar.r);
                BottomAppBar.this.z0(this.f1395a, this.a, this.b, z);
            }
        }
    }

    public class e implements Runnable {
        public final /* synthetic */ int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ ActionMenuView f1398a;
        public final /* synthetic */ boolean b;

        public e(ActionMenuView actionMenuView, int i, boolean z) {
            this.f1398a = actionMenuView;
            this.a = i;
            this.b = z;
        }

        public void run() {
            ActionMenuView actionMenuView = this.f1398a;
            actionMenuView.setTranslationX((float) BottomAppBar.this.o0(actionMenuView, this.a, this.b));
        }
    }

    public class f extends AnimatorListenerAdapter {
        public f() {
        }

        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.f1388a.onAnimationStart(animator);
            FloatingActionButton X = BottomAppBar.this.m0();
            if (X != null) {
                X.setTranslationX(BottomAppBar.this.getFabTranslationX());
            }
        }
    }

    public interface g {
        void a(BottomAppBar bottomAppBar);

        void b(BottomAppBar bottomAppBar);
    }

    public static class h extends gc {
        public static final Parcelable.Creator<h> CREATOR = new a();
        public int a;
        public boolean b;

        public static class a implements Parcelable.ClassLoaderCreator<h> {
            /* renamed from: a */
            public h createFromParcel(Parcel parcel) {
                return new h(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public h createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new h(parcel, classLoader);
            }

            /* renamed from: c */
            public h[] newArray(int i) {
                return new h[i];
            }
        }

        public h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.a = parcel.readInt();
            this.b = parcel.readInt() != 0;
        }

        public h(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.a);
            parcel.writeInt(this.b ? 1 : 0);
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    /* access modifiers changed from: private */
    public int getBottomInset() {
        return this.s;
    }

    /* access modifiers changed from: private */
    public float getFabTranslationX() {
        return p0(this.o);
    }

    private float getFabTranslationY() {
        return -getTopEdgeTreatment().c();
    }

    /* access modifiers changed from: private */
    public int getLeftInset() {
        return this.u;
    }

    /* access modifiers changed from: private */
    public int getRightInset() {
        return this.t;
    }

    private oa1 getTopEdgeTreatment() {
        return (oa1) this.f1390a.C().p();
    }

    public final void f0(FloatingActionButton floatingActionButton) {
        floatingActionButton.e(this.f1388a);
        floatingActionButton.f(new f());
        floatingActionButton.g(this.f1391a);
    }

    public final void g0() {
        Animator animator = this.b;
        if (animator != null) {
            animator.cancel();
        }
        Animator animator2 = this.a;
        if (animator2 != null) {
            animator2.cancel();
        }
    }

    public ColorStateList getBackgroundTint() {
        return this.f1390a.E();
    }

    public Behavior getBehavior() {
        if (this.f1389a == null) {
            this.f1389a = new Behavior();
        }
        return this.f1389a;
    }

    public float getCradleVerticalOffset() {
        return getTopEdgeTreatment().c();
    }

    public int getFabAlignmentMode() {
        return this.o;
    }

    public int getFabAnimationMode() {
        return this.p;
    }

    public float getFabCradleMargin() {
        return getTopEdgeTreatment().d();
    }

    public float getFabCradleRoundedCornerRadius() {
        return getTopEdgeTreatment().e();
    }

    public boolean getHideOnScroll() {
        return this.e;
    }

    public void h0(int i, List<Animator> list) {
        FloatingActionButton m0 = m0();
        if (m0 != null && !m0.n()) {
            l0();
            m0.l(new b(i));
        }
    }

    public final void i0(int i, List<Animator> list) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(m0(), "translationX", new float[]{p0(i)});
        ofFloat.setDuration(300);
        list.add(ofFloat);
    }

    public final void j0(int i, boolean z, List<Animator> list) {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView != null) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{1.0f});
            if (Math.abs(actionMenuView.getTranslationX() - ((float) o0(actionMenuView, i, z))) > 1.0f) {
                ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{0.0f});
                ofFloat2.addListener(new d(actionMenuView, i, z));
                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.setDuration(150);
                animatorSet.playSequentially(new Animator[]{ofFloat2, ofFloat});
                list.add(animatorSet);
            } else if (actionMenuView.getAlpha() < 1.0f) {
                list.add(ofFloat);
            }
        }
    }

    public final void k0() {
        ArrayList<g> arrayList;
        int i = this.q - 1;
        this.q = i;
        if (i == 0 && (arrayList = this.c) != null) {
            Iterator<g> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().b(this);
            }
        }
    }

    public final void l0() {
        ArrayList<g> arrayList;
        int i = this.q;
        this.q = i + 1;
        if (i == 0 && (arrayList = this.c) != null) {
            Iterator<g> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().a(this);
            }
        }
    }

    public final FloatingActionButton m0() {
        View n0 = n0();
        if (n0 instanceof FloatingActionButton) {
            return (FloatingActionButton) n0;
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:6:0x001e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View n0() {
        /*
            r4 = this;
            android.view.ViewParent r0 = r4.getParent()
            boolean r0 = r0 instanceof androidx.coordinatorlayout.widget.CoordinatorLayout
            r1 = 0
            if (r0 != 0) goto L_0x000a
            return r1
        L_0x000a:
            android.view.ViewParent r0 = r4.getParent()
            androidx.coordinatorlayout.widget.CoordinatorLayout r0 = (androidx.coordinatorlayout.widget.CoordinatorLayout) r0
            java.util.List r0 = r0.s(r4)
            java.util.Iterator r0 = r0.iterator()
        L_0x0018:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x002d
            java.lang.Object r2 = r0.next()
            android.view.View r2 = (android.view.View) r2
            boolean r3 = r2 instanceof com.google.android.material.floatingactionbutton.FloatingActionButton
            if (r3 != 0) goto L_0x002c
            boolean r3 = r2 instanceof com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
            if (r3 == 0) goto L_0x0018
        L_0x002c:
            return r2
        L_0x002d:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomappbar.BottomAppBar.n0():android.view.View");
    }

    public int o0(ActionMenuView actionMenuView, int i, boolean z) {
        if (i != 1 || !z) {
            return 0;
        }
        boolean d2 = nc1.d(this);
        int measuredWidth = d2 ? getMeasuredWidth() : 0;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if ((childAt.getLayoutParams() instanceof Toolbar.e) && (((Toolbar.e) childAt.getLayoutParams()).a & 8388615) == 8388611) {
                measuredWidth = d2 ? Math.min(measuredWidth, childAt.getLeft()) : Math.max(measuredWidth, childAt.getRight());
            }
        }
        return measuredWidth - ((d2 ? actionMenuView.getRight() : actionMenuView.getLeft()) + (d2 ? this.t : -this.u));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        id1.f(this, this.f1390a);
        if (getParent() instanceof ViewGroup) {
            ((ViewGroup) getParent()).setClipChildren(false);
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            g0();
            v0();
        }
        u0();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        h hVar = (h) parcelable;
        super.onRestoreInstanceState(hVar.a());
        this.o = hVar.a;
        this.g = hVar.b;
    }

    public Parcelable onSaveInstanceState() {
        h hVar = new h(super.onSaveInstanceState());
        hVar.a = this.o;
        hVar.b = this.g;
        return hVar;
    }

    public final float p0(int i) {
        boolean d2 = nc1.d(this);
        int i2 = 1;
        if (i != 1) {
            return 0.0f;
        }
        int measuredWidth = (getMeasuredWidth() / 2) - (this.n + (d2 ? this.u : this.t));
        if (d2) {
            i2 = -1;
        }
        return (float) (measuredWidth * i2);
    }

    public final boolean q0() {
        FloatingActionButton m0 = m0();
        return m0 != null && m0.o();
    }

    public final void r0(int i, boolean z) {
        if (!ya.T(this)) {
            this.f = false;
            t0(this.r);
            return;
        }
        Animator animator = this.b;
        if (animator != null) {
            animator.cancel();
        }
        ArrayList arrayList = new ArrayList();
        if (!q0()) {
            i = 0;
            z = false;
        }
        j0(i, z, arrayList);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(arrayList);
        this.b = animatorSet;
        animatorSet.addListener(new c());
        this.b.start();
    }

    public final void s0(int i) {
        if (this.o != i && ya.T(this)) {
            Animator animator = this.a;
            if (animator != null) {
                animator.cancel();
            }
            ArrayList arrayList = new ArrayList();
            if (this.p == 1) {
                i0(i, arrayList);
            } else {
                h0(i, arrayList);
            }
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(arrayList);
            this.a = animatorSet;
            animatorSet.addListener(new a());
            this.a.start();
        }
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        m8.o(this.f1390a, colorStateList);
    }

    public void setCradleVerticalOffset(float f2) {
        if (f2 != getCradleVerticalOffset()) {
            getTopEdgeTreatment().g(f2);
            this.f1390a.invalidateSelf();
            v0();
        }
    }

    public void setElevation(float f2) {
        this.f1390a.V(f2);
        getBehavior().G(this, this.f1390a.B() - this.f1390a.A());
    }

    public void setFabAlignmentMode(int i) {
        w0(i, 0);
    }

    public void setFabAnimationMode(int i) {
        this.p = i;
    }

    public void setFabCradleMargin(float f2) {
        if (f2 != getFabCradleMargin()) {
            getTopEdgeTreatment().h(f2);
            this.f1390a.invalidateSelf();
        }
    }

    public void setFabCradleRoundedCornerRadius(float f2) {
        if (f2 != getFabCradleRoundedCornerRadius()) {
            getTopEdgeTreatment().i(f2);
            this.f1390a.invalidateSelf();
        }
    }

    public void setHideOnScroll(boolean z) {
        this.e = z;
    }

    public void setSubtitle(CharSequence charSequence) {
    }

    public void setTitle(CharSequence charSequence) {
    }

    public void t0(int i) {
        if (i != 0) {
            this.r = 0;
            getMenu().clear();
            x(i);
        }
    }

    public final void u0() {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView != null && this.b == null) {
            actionMenuView.setAlpha(1.0f);
            if (!q0()) {
                y0(actionMenuView, 0, false);
            } else {
                y0(actionMenuView, this.o, this.g);
            }
        }
    }

    public final void v0() {
        getTopEdgeTreatment().k(getFabTranslationX());
        View n0 = n0();
        this.f1390a.X((!this.g || !q0()) ? 0.0f : 1.0f);
        if (n0 != null) {
            n0.setTranslationY(getFabTranslationY());
            n0.setTranslationX(getFabTranslationX());
        }
    }

    public void w0(int i, int i2) {
        this.r = i2;
        this.f = true;
        r0(i, this.g);
        s0(i);
        this.o = i;
    }

    public boolean x0(int i) {
        float f2 = (float) i;
        if (f2 == getTopEdgeTreatment().f()) {
            return false;
        }
        getTopEdgeTreatment().j(f2);
        this.f1390a.invalidateSelf();
        return true;
    }

    public final void y0(ActionMenuView actionMenuView, int i, boolean z) {
        z0(actionMenuView, i, z, false);
    }

    public final void z0(ActionMenuView actionMenuView, int i, boolean z, boolean z2) {
        e eVar = new e(actionMenuView, i, z);
        if (z2) {
            actionMenuView.post(eVar);
        } else {
            eVar.run();
        }
    }
}
