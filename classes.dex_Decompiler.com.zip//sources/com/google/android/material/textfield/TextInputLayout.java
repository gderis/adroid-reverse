package com.google.android.material.textfield;

import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class TextInputLayout extends LinearLayout {
    public static final int a = w91.Widget_Design_TextInputLayout;

    /* renamed from: a  reason: collision with other field name */
    public final ae1 f1502a;

    /* renamed from: a  reason: collision with other field name */
    public ValueAnimator f1503a;

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f1504a;

    /* renamed from: a  reason: collision with other field name */
    public PorterDuff.Mode f1505a;

    /* renamed from: a  reason: collision with other field name */
    public final Rect f1506a;

    /* renamed from: a  reason: collision with other field name */
    public final RectF f1507a;

    /* renamed from: a  reason: collision with other field name */
    public Typeface f1508a;

    /* renamed from: a  reason: collision with other field name */
    public Drawable f1509a;

    /* renamed from: a  reason: collision with other field name */
    public final SparseArray<zd1> f1510a;

    /* renamed from: a  reason: collision with other field name */
    public View.OnLongClickListener f1511a;

    /* renamed from: a  reason: collision with other field name */
    public EditText f1512a;

    /* renamed from: a  reason: collision with other field name */
    public final FrameLayout f1513a;

    /* renamed from: a  reason: collision with other field name */
    public final LinearLayout f1514a;

    /* renamed from: a  reason: collision with other field name */
    public TextView f1515a;

    /* renamed from: a  reason: collision with other field name */
    public final CheckableImageButton f1516a;

    /* renamed from: a  reason: collision with other field name */
    public final dc1 f1517a;

    /* renamed from: a  reason: collision with other field name */
    public hd1 f1518a;

    /* renamed from: a  reason: collision with other field name */
    public CharSequence f1519a;

    /* renamed from: a  reason: collision with other field name */
    public final LinkedHashSet<f> f1520a;

    /* renamed from: a  reason: collision with other field name */
    public ld1 f1521a;
    public int b;

    /* renamed from: b  reason: collision with other field name */
    public ColorStateList f1522b;

    /* renamed from: b  reason: collision with other field name */
    public PorterDuff.Mode f1523b;

    /* renamed from: b  reason: collision with other field name */
    public final Rect f1524b;

    /* renamed from: b  reason: collision with other field name */
    public Drawable f1525b;

    /* renamed from: b  reason: collision with other field name */
    public View.OnLongClickListener f1526b;

    /* renamed from: b  reason: collision with other field name */
    public final FrameLayout f1527b;

    /* renamed from: b  reason: collision with other field name */
    public final LinearLayout f1528b;

    /* renamed from: b  reason: collision with other field name */
    public TextView f1529b;

    /* renamed from: b  reason: collision with other field name */
    public final CheckableImageButton f1530b;

    /* renamed from: b  reason: collision with other field name */
    public hd1 f1531b;

    /* renamed from: b  reason: collision with other field name */
    public CharSequence f1532b;

    /* renamed from: b  reason: collision with other field name */
    public final LinkedHashSet<g> f1533b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1534b;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public ColorStateList f1535c;

    /* renamed from: c  reason: collision with other field name */
    public Drawable f1536c;

    /* renamed from: c  reason: collision with other field name */
    public View.OnLongClickListener f1537c;

    /* renamed from: c  reason: collision with other field name */
    public final TextView f1538c;

    /* renamed from: c  reason: collision with other field name */
    public final CheckableImageButton f1539c;

    /* renamed from: c  reason: collision with other field name */
    public CharSequence f1540c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1541c;
    public int d;

    /* renamed from: d  reason: collision with other field name */
    public ColorStateList f1542d;

    /* renamed from: d  reason: collision with other field name */
    public final TextView f1543d;

    /* renamed from: d  reason: collision with other field name */
    public CharSequence f1544d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f1545d;
    public int e;

    /* renamed from: e  reason: collision with other field name */
    public ColorStateList f1546e;

    /* renamed from: e  reason: collision with other field name */
    public CharSequence f1547e;

    /* renamed from: e  reason: collision with other field name */
    public boolean f1548e;
    public final int f;

    /* renamed from: f  reason: collision with other field name */
    public ColorStateList f1549f;

    /* renamed from: f  reason: collision with other field name */
    public boolean f1550f;
    public int g;

    /* renamed from: g  reason: collision with other field name */
    public ColorStateList f1551g;

    /* renamed from: g  reason: collision with other field name */
    public boolean f1552g;
    public int h;

    /* renamed from: h  reason: collision with other field name */
    public ColorStateList f1553h;

    /* renamed from: h  reason: collision with other field name */
    public boolean f1554h;
    public int i;

    /* renamed from: i  reason: collision with other field name */
    public ColorStateList f1555i;

    /* renamed from: i  reason: collision with other field name */
    public boolean f1556i;
    public int j;

    /* renamed from: j  reason: collision with other field name */
    public boolean f1557j;
    public int k;

    /* renamed from: k  reason: collision with other field name */
    public boolean f1558k;
    public int l;

    /* renamed from: l  reason: collision with other field name */
    public boolean f1559l;
    public int m;

    /* renamed from: m  reason: collision with other field name */
    public boolean f1560m;
    public int n;

    /* renamed from: n  reason: collision with other field name */
    public boolean f1561n;
    public int o;

    /* renamed from: o  reason: collision with other field name */
    public boolean f1562o;
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public int u;
    public int v;
    public int w;
    public int x;

    public class a implements TextWatcher {
        public a() {
        }

        public void afterTextChanged(Editable editable) {
            TextInputLayout textInputLayout = TextInputLayout.this;
            textInputLayout.u0(!textInputLayout.f1562o);
            TextInputLayout textInputLayout2 = TextInputLayout.this;
            if (textInputLayout2.f1534b) {
                textInputLayout2.n0(editable.length());
            }
            if (TextInputLayout.this.f1545d) {
                TextInputLayout.this.y0(editable.length());
            }
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            TextInputLayout.this.f1530b.performClick();
            TextInputLayout.this.f1530b.jumpDrawablesToCurrentState();
        }
    }

    public class c implements Runnable {
        public c() {
        }

        public void run() {
            TextInputLayout.this.f1512a.requestLayout();
        }
    }

    public class d implements ValueAnimator.AnimatorUpdateListener {
        public d() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TextInputLayout.this.f1517a.V(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    public static class e extends da {
        public final TextInputLayout a;

        public e(TextInputLayout textInputLayout) {
            this.a = textInputLayout;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0083, code lost:
            if (r3 != null) goto L_0x0085;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void g(android.view.View r14, defpackage.jb r15) {
            /*
                r13 = this;
                super.g(r14, r15)
                com.google.android.material.textfield.TextInputLayout r14 = r13.a
                android.widget.EditText r14 = r14.getEditText()
                if (r14 == 0) goto L_0x0010
                android.text.Editable r0 = r14.getText()
                goto L_0x0011
            L_0x0010:
                r0 = 0
            L_0x0011:
                com.google.android.material.textfield.TextInputLayout r1 = r13.a
                java.lang.CharSequence r1 = r1.getHint()
                com.google.android.material.textfield.TextInputLayout r2 = r13.a
                java.lang.CharSequence r2 = r2.getError()
                com.google.android.material.textfield.TextInputLayout r3 = r13.a
                java.lang.CharSequence r3 = r3.getPlaceholderText()
                com.google.android.material.textfield.TextInputLayout r4 = r13.a
                int r4 = r4.getCounterMaxLength()
                com.google.android.material.textfield.TextInputLayout r5 = r13.a
                java.lang.CharSequence r5 = r5.getCounterOverflowDescription()
                boolean r6 = android.text.TextUtils.isEmpty(r0)
                r7 = 1
                r6 = r6 ^ r7
                boolean r8 = android.text.TextUtils.isEmpty(r1)
                r8 = r8 ^ r7
                com.google.android.material.textfield.TextInputLayout r9 = r13.a
                boolean r9 = r9.N()
                r9 = r9 ^ r7
                boolean r10 = android.text.TextUtils.isEmpty(r2)
                r10 = r10 ^ r7
                if (r10 != 0) goto L_0x0051
                boolean r11 = android.text.TextUtils.isEmpty(r5)
                if (r11 != 0) goto L_0x004f
                goto L_0x0051
            L_0x004f:
                r11 = 0
                goto L_0x0052
            L_0x0051:
                r11 = 1
            L_0x0052:
                if (r8 == 0) goto L_0x0059
                java.lang.String r1 = r1.toString()
                goto L_0x005b
            L_0x0059:
                java.lang.String r1 = ""
            L_0x005b:
                java.lang.String r8 = ", "
                if (r6 == 0) goto L_0x0063
                r15.r0(r0)
                goto L_0x0088
            L_0x0063:
                boolean r12 = android.text.TextUtils.isEmpty(r1)
                if (r12 != 0) goto L_0x0083
                r15.r0(r1)
                if (r9 == 0) goto L_0x0088
                if (r3 == 0) goto L_0x0088
                java.lang.StringBuilder r9 = new java.lang.StringBuilder
                r9.<init>()
                r9.append(r1)
                r9.append(r8)
                r9.append(r3)
                java.lang.String r3 = r9.toString()
                goto L_0x0085
            L_0x0083:
                if (r3 == 0) goto L_0x0088
            L_0x0085:
                r15.r0(r3)
            L_0x0088:
                boolean r3 = android.text.TextUtils.isEmpty(r1)
                if (r3 != 0) goto L_0x00b4
                int r3 = android.os.Build.VERSION.SDK_INT
                r9 = 26
                if (r3 < r9) goto L_0x0098
                r15.g0(r1)
                goto L_0x00af
            L_0x0098:
                if (r6 == 0) goto L_0x00ac
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                r3.<init>()
                r3.append(r0)
                r3.append(r8)
                r3.append(r1)
                java.lang.String r1 = r3.toString()
            L_0x00ac:
                r15.r0(r1)
            L_0x00af:
                r1 = r6 ^ 1
                r15.o0(r1)
            L_0x00b4:
                if (r0 == 0) goto L_0x00bd
                int r0 = r0.length()
                if (r0 != r4) goto L_0x00bd
                goto L_0x00be
            L_0x00bd:
                r4 = -1
            L_0x00be:
                r15.h0(r4)
                if (r11 == 0) goto L_0x00ca
                if (r10 == 0) goto L_0x00c6
                goto L_0x00c7
            L_0x00c6:
                r2 = r5
            L_0x00c7:
                r15.c0(r2)
            L_0x00ca:
                int r15 = android.os.Build.VERSION.SDK_INT
                r0 = 17
                if (r15 < r0) goto L_0x00d7
                if (r14 == 0) goto L_0x00d7
                int r15 = defpackage.s91.textinput_helper_text
                r14.setLabelFor(r15)
            L_0x00d7:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.e.g(android.view.View, jb):void");
        }
    }

    public interface f {
        void a(TextInputLayout textInputLayout);
    }

    public interface g {
        void a(TextInputLayout textInputLayout, int i);
    }

    public static class h extends gc {
        public static final Parcelable.Creator<h> CREATOR = new a();
        public CharSequence a;
        public CharSequence b;

        /* renamed from: b  reason: collision with other field name */
        public boolean f1563b;
        public CharSequence c;
        public CharSequence d;

        public static class a implements Parcelable.ClassLoaderCreator<h> {
            /* renamed from: a */
            public h createFromParcel(Parcel parcel) {
                return new h(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public h createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new h(parcel, classLoader);
            }

            /* renamed from: c */
            public h[] newArray(int i) {
                return new h[i];
            }
        }

        public h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.a = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f1563b = parcel.readInt() != 1 ? false : true;
            this.b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.c = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.d = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        }

        public h(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "TextInputLayout.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " error=" + this.a + " hint=" + this.b + " helperText=" + this.c + " placeholderText=" + this.d + "}";
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            TextUtils.writeToParcel(this.a, parcel, i);
            parcel.writeInt(this.f1563b ? 1 : 0);
            TextUtils.writeToParcel(this.b, parcel, i);
            TextUtils.writeToParcel(this.c, parcel, i);
            TextUtils.writeToParcel(this.d, parcel, i);
        }
    }

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.textInputStyle);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TextInputLayout(android.content.Context r24, android.util.AttributeSet r25, int r26) {
        /*
            r23 = this;
            r0 = r23
            r7 = r25
            r8 = r26
            int r9 = a
            r1 = r24
            android.content.Context r1 = defpackage.ee1.c(r1, r7, r8, r9)
            r0.<init>(r1, r7, r8)
            ae1 r1 = new ae1
            r1.<init>(r0)
            r0.f1502a = r1
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r0.f1506a = r1
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r0.f1524b = r1
            android.graphics.RectF r1 = new android.graphics.RectF
            r1.<init>()
            r0.f1507a = r1
            java.util.LinkedHashSet r1 = new java.util.LinkedHashSet
            r1.<init>()
            r0.f1520a = r1
            r10 = 0
            r0.o = r10
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r0.f1510a = r1
            java.util.LinkedHashSet r1 = new java.util.LinkedHashSet
            r1.<init>()
            r0.f1533b = r1
            dc1 r1 = new dc1
            r1.<init>(r0)
            r0.f1517a = r1
            android.content.Context r11 = r23.getContext()
            r12 = 1
            r0.setOrientation(r12)
            r0.setWillNotDraw(r10)
            r0.setAddStatesFromChildren(r12)
            android.widget.FrameLayout r2 = new android.widget.FrameLayout
            r2.<init>(r11)
            r0.f1513a = r2
            r2.setAddStatesFromChildren(r12)
            r0.addView(r2)
            android.widget.LinearLayout r3 = new android.widget.LinearLayout
            r3.<init>(r11)
            r0.f1514a = r3
            r3.setOrientation(r10)
            android.widget.FrameLayout$LayoutParams r4 = new android.widget.FrameLayout$LayoutParams
            r13 = -2
            r14 = -1
            r5 = 8388611(0x800003, float:1.1754948E-38)
            r4.<init>(r13, r14, r5)
            r3.setLayoutParams(r4)
            r2.addView(r3)
            android.widget.LinearLayout r15 = new android.widget.LinearLayout
            r15.<init>(r11)
            r0.f1528b = r15
            r15.setOrientation(r10)
            android.widget.FrameLayout$LayoutParams r3 = new android.widget.FrameLayout$LayoutParams
            r4 = 8388613(0x800005, float:1.175495E-38)
            r3.<init>(r13, r14, r4)
            r15.setLayoutParams(r3)
            r2.addView(r15)
            android.widget.FrameLayout r2 = new android.widget.FrameLayout
            r2.<init>(r11)
            r0.f1527b = r2
            android.widget.FrameLayout$LayoutParams r3 = new android.widget.FrameLayout$LayoutParams
            r3.<init>(r13, r14)
            r2.setLayoutParams(r3)
            android.animation.TimeInterpolator r2 = defpackage.y91.a
            r1.a0(r2)
            r1.X(r2)
            r2 = 8388659(0x800033, float:1.1755015E-38)
            r1.L(r2)
            int[] r3 = defpackage.x91.TextInputLayout
            r1 = 5
            int[] r6 = new int[r1]
            int r5 = defpackage.x91.TextInputLayout_counterTextAppearance
            r6[r10] = r5
            int r4 = defpackage.x91.TextInputLayout_counterOverflowTextAppearance
            r6[r12] = r4
            int r2 = defpackage.x91.TextInputLayout_errorTextAppearance
            r1 = 2
            r6[r1] = r2
            int r13 = defpackage.x91.TextInputLayout_helperTextTextAppearance
            r14 = 3
            r6[r14] = r13
            int r14 = defpackage.x91.TextInputLayout_hintTextAppearance
            r16 = 4
            r6[r16] = r14
            r1 = r11
            r17 = r2
            r2 = r25
            r18 = r4
            r4 = r26
            r19 = r5
            r5 = r9
            s3 r1 = defpackage.mc1.i(r1, r2, r3, r4, r5, r6)
            int r2 = defpackage.x91.TextInputLayout_hintEnabled
            boolean r2 = r1.a(r2, r12)
            r0.f1548e = r2
            int r2 = defpackage.x91.TextInputLayout_android_hint
            java.lang.CharSequence r2 = r1.p(r2)
            r0.setHint((java.lang.CharSequence) r2)
            int r2 = defpackage.x91.TextInputLayout_hintAnimationEnabled
            boolean r2 = r1.a(r2, r12)
            r0.f1560m = r2
            int r2 = defpackage.x91.TextInputLayout_expandedHintEnabled
            boolean r2 = r1.a(r2, r12)
            r0.f1559l = r2
            ld1$b r2 = defpackage.ld1.e(r11, r7, r8, r9)
            ld1 r2 = r2.m()
            r0.f1521a = r2
            android.content.res.Resources r2 = r11.getResources()
            int r3 = defpackage.q91.mtrl_textinput_box_label_cutout_padding
            int r2 = r2.getDimensionPixelOffset(r3)
            r0.f = r2
            int r2 = defpackage.x91.TextInputLayout_boxCollapsedPaddingTop
            int r2 = r1.e(r2, r10)
            r0.h = r2
            int r2 = defpackage.x91.TextInputLayout_boxStrokeWidth
            android.content.res.Resources r3 = r11.getResources()
            int r4 = defpackage.q91.mtrl_textinput_box_stroke_width_default
            int r3 = r3.getDimensionPixelSize(r4)
            int r2 = r1.f(r2, r3)
            r0.j = r2
            int r2 = defpackage.x91.TextInputLayout_boxStrokeWidthFocused
            android.content.res.Resources r3 = r11.getResources()
            int r4 = defpackage.q91.mtrl_textinput_box_stroke_width_focused
            int r3 = r3.getDimensionPixelSize(r4)
            int r2 = r1.f(r2, r3)
            r0.k = r2
            int r2 = r0.j
            r0.i = r2
            int r2 = defpackage.x91.TextInputLayout_boxCornerRadiusTopStart
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r2 = r1.d(r2, r3)
            int r4 = defpackage.x91.TextInputLayout_boxCornerRadiusTopEnd
            float r4 = r1.d(r4, r3)
            int r5 = defpackage.x91.TextInputLayout_boxCornerRadiusBottomEnd
            float r5 = r1.d(r5, r3)
            int r6 = defpackage.x91.TextInputLayout_boxCornerRadiusBottomStart
            float r3 = r1.d(r6, r3)
            ld1 r6 = r0.f1521a
            ld1$b r6 = r6.v()
            r7 = 0
            int r8 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1))
            if (r8 < 0) goto L_0x0172
            r6.A(r2)
        L_0x0172:
            int r2 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r2 < 0) goto L_0x0179
            r6.E(r4)
        L_0x0179:
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 < 0) goto L_0x0180
            r6.w(r5)
        L_0x0180:
            int r2 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r2 < 0) goto L_0x0187
            r6.s(r3)
        L_0x0187:
            ld1 r2 = r6.m()
            r0.f1521a = r2
            int r2 = defpackage.x91.TextInputLayout_boxBackgroundColor
            android.content.res.ColorStateList r2 = defpackage.tc1.b(r11, r1, r2)
            if (r2 == 0) goto L_0x01eb
            int r3 = r2.getDefaultColor()
            r0.t = r3
            r0.m = r3
            boolean r3 = r2.isStateful()
            r4 = -16842910(0xfffffffffefeff62, float:-1.6947497E38)
            if (r3 == 0) goto L_0x01c7
            int[] r3 = new int[r12]
            r3[r10] = r4
            r5 = -1
            int r3 = r2.getColorForState(r3, r5)
            r0.u = r3
            r3 = 2
            int[] r4 = new int[r3]
            r4 = {16842908, 16842910} // fill-array
            int r4 = r2.getColorForState(r4, r5)
            r0.v = r4
            int[] r4 = new int[r3]
            r4 = {16843623, 16842910} // fill-array
            int r2 = r2.getColorForState(r4, r5)
            goto L_0x01e8
        L_0x01c7:
            r3 = 2
            r5 = -1
            int r2 = r0.t
            r0.v = r2
            int r2 = defpackage.p91.mtrl_filled_background_color
            android.content.res.ColorStateList r2 = defpackage.l0.c(r11, r2)
            int[] r6 = new int[r12]
            r6[r10] = r4
            int r4 = r2.getColorForState(r6, r5)
            r0.u = r4
            int[] r4 = new int[r12]
            r6 = 16843623(0x1010367, float:2.3696E-38)
            r4[r10] = r6
            int r2 = r2.getColorForState(r4, r5)
        L_0x01e8:
            r0.w = r2
            goto L_0x01f6
        L_0x01eb:
            r3 = 2
            r0.m = r10
            r0.t = r10
            r0.u = r10
            r0.v = r10
            r0.w = r10
        L_0x01f6:
            int r2 = defpackage.x91.TextInputLayout_android_textColorHint
            boolean r4 = r1.s(r2)
            if (r4 == 0) goto L_0x0206
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.f1553h = r2
            r0.f1551g = r2
        L_0x0206:
            int r2 = defpackage.x91.TextInputLayout_boxStrokeColor
            android.content.res.ColorStateList r4 = defpackage.tc1.b(r11, r1, r2)
            int r2 = r1.b(r2, r10)
            r0.s = r2
            int r2 = defpackage.p91.mtrl_textinput_default_box_stroke_color
            int r2 = defpackage.r7.d(r11, r2)
            r0.q = r2
            int r2 = defpackage.p91.mtrl_textinput_disabled_color
            int r2 = defpackage.r7.d(r11, r2)
            r0.x = r2
            int r2 = defpackage.p91.mtrl_textinput_hovered_box_stroke_color
            int r2 = defpackage.r7.d(r11, r2)
            r0.r = r2
            if (r4 == 0) goto L_0x022f
            r0.setBoxStrokeColorStateList(r4)
        L_0x022f:
            int r2 = defpackage.x91.TextInputLayout_boxStrokeErrorColor
            boolean r4 = r1.s(r2)
            if (r4 == 0) goto L_0x023e
            android.content.res.ColorStateList r2 = defpackage.tc1.b(r11, r1, r2)
            r0.setBoxStrokeErrorColor(r2)
        L_0x023e:
            r2 = -1
            int r4 = r1.n(r14, r2)
            if (r4 == r2) goto L_0x024c
            int r2 = r1.n(r14, r10)
            r0.setHintTextAppearance(r2)
        L_0x024c:
            r2 = r17
            int r2 = r1.n(r2, r10)
            int r4 = defpackage.x91.TextInputLayout_errorContentDescription
            java.lang.CharSequence r4 = r1.p(r4)
            int r5 = defpackage.x91.TextInputLayout_errorEnabled
            boolean r5 = r1.a(r5, r10)
            android.content.Context r6 = r23.getContext()
            android.view.LayoutInflater r6 = android.view.LayoutInflater.from(r6)
            int r7 = defpackage.u91.design_text_input_end_icon
            android.view.View r6 = r6.inflate(r7, r15, r10)
            com.google.android.material.internal.CheckableImageButton r6 = (com.google.android.material.internal.CheckableImageButton) r6
            r0.f1539c = r6
            int r8 = defpackage.s91.text_input_error_icon
            r6.setId(r8)
            r8 = 8
            r6.setVisibility(r8)
            boolean r9 = defpackage.tc1.g(r11)
            if (r9 == 0) goto L_0x0289
            android.view.ViewGroup$LayoutParams r9 = r6.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r9 = (android.view.ViewGroup.MarginLayoutParams) r9
            defpackage.ka.d(r9, r10)
        L_0x0289:
            int r9 = defpackage.x91.TextInputLayout_errorIconDrawable
            boolean r14 = r1.s(r9)
            if (r14 == 0) goto L_0x0298
            android.graphics.drawable.Drawable r9 = r1.g(r9)
            r0.setErrorIconDrawable((android.graphics.drawable.Drawable) r9)
        L_0x0298:
            int r9 = defpackage.x91.TextInputLayout_errorIconTint
            boolean r14 = r1.s(r9)
            if (r14 == 0) goto L_0x02a7
            android.content.res.ColorStateList r9 = defpackage.tc1.b(r11, r1, r9)
            r0.setErrorIconTintList(r9)
        L_0x02a7:
            int r9 = defpackage.x91.TextInputLayout_errorIconTintMode
            boolean r14 = r1.s(r9)
            r15 = 0
            if (r14 == 0) goto L_0x02bc
            r14 = -1
            int r9 = r1.k(r9, r14)
            android.graphics.PorterDuff$Mode r9 = defpackage.nc1.e(r9, r15)
            r0.setErrorIconTintMode(r9)
        L_0x02bc:
            android.content.res.Resources r9 = r23.getResources()
            int r14 = defpackage.v91.error_icon_content_description
            java.lang.CharSequence r9 = r9.getText(r14)
            r6.setContentDescription(r9)
            defpackage.ya.x0(r6, r3)
            r6.setClickable(r10)
            r6.setPressable(r10)
            r6.setFocusable(r10)
            int r6 = r1.n(r13, r10)
            int r9 = defpackage.x91.TextInputLayout_helperTextEnabled
            boolean r9 = r1.a(r9, r10)
            int r13 = defpackage.x91.TextInputLayout_helperText
            java.lang.CharSequence r13 = r1.p(r13)
            int r14 = defpackage.x91.TextInputLayout_placeholderTextAppearance
            int r14 = r1.n(r14, r10)
            int r3 = defpackage.x91.TextInputLayout_placeholderText
            java.lang.CharSequence r3 = r1.p(r3)
            int r12 = defpackage.x91.TextInputLayout_prefixTextAppearance
            int r12 = r1.n(r12, r10)
            int r15 = defpackage.x91.TextInputLayout_prefixText
            java.lang.CharSequence r15 = r1.p(r15)
            int r8 = defpackage.x91.TextInputLayout_suffixTextAppearance
            int r8 = r1.n(r8, r10)
            int r10 = defpackage.x91.TextInputLayout_suffixText
            java.lang.CharSequence r10 = r1.p(r10)
            r20 = r8
            int r8 = defpackage.x91.TextInputLayout_counterEnabled
            r21 = r10
            r10 = 0
            boolean r8 = r1.a(r8, r10)
            int r10 = defpackage.x91.TextInputLayout_counterMaxLength
            r22 = r8
            r8 = -1
            int r10 = r1.k(r10, r8)
            r0.setCounterMaxLength(r10)
            r8 = r19
            r10 = 0
            int r8 = r1.n(r8, r10)
            r0.d = r8
            r8 = r18
            int r8 = r1.n(r8, r10)
            r0.c = r8
            android.content.Context r8 = r23.getContext()
            android.view.LayoutInflater r8 = android.view.LayoutInflater.from(r8)
            r18 = r12
            int r12 = defpackage.u91.design_text_input_start_icon
            r19 = r15
            android.widget.LinearLayout r15 = r0.f1514a
            android.view.View r8 = r8.inflate(r12, r15, r10)
            com.google.android.material.internal.CheckableImageButton r8 = (com.google.android.material.internal.CheckableImageButton) r8
            r0.f1516a = r8
            r12 = 8
            r8.setVisibility(r12)
            boolean r12 = defpackage.tc1.g(r11)
            if (r12 == 0) goto L_0x035d
            android.view.ViewGroup$LayoutParams r8 = r8.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r8 = (android.view.ViewGroup.MarginLayoutParams) r8
            defpackage.ka.c(r8, r10)
        L_0x035d:
            r8 = 0
            r0.setStartIconOnClickListener(r8)
            r0.setStartIconOnLongClickListener(r8)
            int r8 = defpackage.x91.TextInputLayout_startIconDrawable
            boolean r10 = r1.s(r8)
            if (r10 == 0) goto L_0x038c
            android.graphics.drawable.Drawable r8 = r1.g(r8)
            r0.setStartIconDrawable((android.graphics.drawable.Drawable) r8)
            int r8 = defpackage.x91.TextInputLayout_startIconContentDescription
            boolean r10 = r1.s(r8)
            if (r10 == 0) goto L_0x0382
            java.lang.CharSequence r8 = r1.p(r8)
            r0.setStartIconContentDescription((java.lang.CharSequence) r8)
        L_0x0382:
            int r8 = defpackage.x91.TextInputLayout_startIconCheckable
            r10 = 1
            boolean r8 = r1.a(r8, r10)
            r0.setStartIconCheckable(r8)
        L_0x038c:
            int r8 = defpackage.x91.TextInputLayout_startIconTint
            boolean r10 = r1.s(r8)
            if (r10 == 0) goto L_0x039b
            android.content.res.ColorStateList r8 = defpackage.tc1.b(r11, r1, r8)
            r0.setStartIconTintList(r8)
        L_0x039b:
            int r8 = defpackage.x91.TextInputLayout_startIconTintMode
            boolean r10 = r1.s(r8)
            if (r10 == 0) goto L_0x03b0
            r10 = -1
            int r8 = r1.k(r8, r10)
            r10 = 0
            android.graphics.PorterDuff$Mode r8 = defpackage.nc1.e(r8, r10)
            r0.setStartIconTintMode(r8)
        L_0x03b0:
            int r8 = defpackage.x91.TextInputLayout_boxBackgroundMode
            r10 = 0
            int r8 = r1.k(r8, r10)
            r0.setBoxBackgroundMode(r8)
            android.content.Context r8 = r23.getContext()
            android.view.LayoutInflater r8 = android.view.LayoutInflater.from(r8)
            android.widget.FrameLayout r12 = r0.f1527b
            android.view.View r7 = r8.inflate(r7, r12, r10)
            com.google.android.material.internal.CheckableImageButton r7 = (com.google.android.material.internal.CheckableImageButton) r7
            r0.f1530b = r7
            android.widget.FrameLayout r7 = r0.f1527b
            com.google.android.material.internal.CheckableImageButton r8 = r0.f1530b
            r7.addView(r8)
            com.google.android.material.internal.CheckableImageButton r7 = r0.f1530b
            r8 = 8
            r7.setVisibility(r8)
            boolean r7 = defpackage.tc1.g(r11)
            if (r7 == 0) goto L_0x03ed
            com.google.android.material.internal.CheckableImageButton r7 = r0.f1530b
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r7 = (android.view.ViewGroup.MarginLayoutParams) r7
            r8 = 0
            defpackage.ka.d(r7, r8)
            goto L_0x03ee
        L_0x03ed:
            r8 = 0
        L_0x03ee:
            android.util.SparseArray<zd1> r7 = r0.f1510a
            wd1 r10 = new wd1
            r10.<init>(r0)
            r12 = -1
            r7.append(r12, r10)
            android.util.SparseArray<zd1> r7 = r0.f1510a
            ce1 r10 = new ce1
            r10.<init>(r0)
            r7.append(r8, r10)
            android.util.SparseArray<zd1> r7 = r0.f1510a
            de1 r8 = new de1
            r8.<init>(r0)
            r10 = 1
            r7.append(r10, r8)
            android.util.SparseArray<zd1> r7 = r0.f1510a
            vd1 r8 = new vd1
            r8.<init>(r0)
            r10 = 2
            r7.append(r10, r8)
            android.util.SparseArray<zd1> r7 = r0.f1510a
            yd1 r8 = new yd1
            r8.<init>(r0)
            r10 = 3
            r7.append(r10, r8)
            int r7 = defpackage.x91.TextInputLayout_endIconMode
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x045d
            r8 = 0
            int r7 = r1.k(r7, r8)
            r0.setEndIconMode(r7)
            int r7 = defpackage.x91.TextInputLayout_endIconDrawable
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x0443
            android.graphics.drawable.Drawable r7 = r1.g(r7)
            r0.setEndIconDrawable((android.graphics.drawable.Drawable) r7)
        L_0x0443:
            int r7 = defpackage.x91.TextInputLayout_endIconContentDescription
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x0452
            java.lang.CharSequence r7 = r1.p(r7)
            r0.setEndIconContentDescription((java.lang.CharSequence) r7)
        L_0x0452:
            int r7 = defpackage.x91.TextInputLayout_endIconCheckable
            r8 = 1
            boolean r7 = r1.a(r7, r8)
            r0.setEndIconCheckable(r7)
            goto L_0x04a3
        L_0x045d:
            int r7 = defpackage.x91.TextInputLayout_passwordToggleEnabled
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x04a3
            r8 = 0
            boolean r7 = r1.a(r7, r8)
            r0.setEndIconMode(r7)
            int r7 = defpackage.x91.TextInputLayout_passwordToggleDrawable
            android.graphics.drawable.Drawable r7 = r1.g(r7)
            r0.setEndIconDrawable((android.graphics.drawable.Drawable) r7)
            int r7 = defpackage.x91.TextInputLayout_passwordToggleContentDescription
            java.lang.CharSequence r7 = r1.p(r7)
            r0.setEndIconContentDescription((java.lang.CharSequence) r7)
            int r7 = defpackage.x91.TextInputLayout_passwordToggleTint
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x048e
            android.content.res.ColorStateList r7 = defpackage.tc1.b(r11, r1, r7)
            r0.setEndIconTintList(r7)
        L_0x048e:
            int r7 = defpackage.x91.TextInputLayout_passwordToggleTintMode
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x04a3
            r8 = -1
            int r7 = r1.k(r7, r8)
            r8 = 0
            android.graphics.PorterDuff$Mode r7 = defpackage.nc1.e(r7, r8)
            r0.setEndIconTintMode(r7)
        L_0x04a3:
            int r7 = defpackage.x91.TextInputLayout_passwordToggleEnabled
            boolean r7 = r1.s(r7)
            if (r7 != 0) goto L_0x04cf
            int r7 = defpackage.x91.TextInputLayout_endIconTint
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x04ba
            android.content.res.ColorStateList r7 = defpackage.tc1.b(r11, r1, r7)
            r0.setEndIconTintList(r7)
        L_0x04ba:
            int r7 = defpackage.x91.TextInputLayout_endIconTintMode
            boolean r8 = r1.s(r7)
            if (r8 == 0) goto L_0x04cf
            r8 = -1
            int r7 = r1.k(r7, r8)
            r8 = 0
            android.graphics.PorterDuff$Mode r7 = defpackage.nc1.e(r7, r8)
            r0.setEndIconTintMode(r7)
        L_0x04cf:
            v2 r7 = new v2
            r7.<init>(r11)
            r0.f1538c = r7
            int r8 = defpackage.s91.textinput_prefix_text
            r7.setId(r8)
            android.widget.FrameLayout$LayoutParams r8 = new android.widget.FrameLayout$LayoutParams
            r10 = -2
            r8.<init>(r10, r10)
            r7.setLayoutParams(r8)
            r8 = 1
            defpackage.ya.q0(r7, r8)
            android.widget.LinearLayout r8 = r0.f1514a
            com.google.android.material.internal.CheckableImageButton r10 = r0.f1516a
            r8.addView(r10)
            android.widget.LinearLayout r8 = r0.f1514a
            r8.addView(r7)
            v2 r7 = new v2
            r7.<init>(r11)
            r0.f1543d = r7
            int r8 = defpackage.s91.textinput_suffix_text
            r7.setId(r8)
            android.widget.FrameLayout$LayoutParams r8 = new android.widget.FrameLayout$LayoutParams
            r10 = 80
            r11 = -2
            r8.<init>(r11, r11, r10)
            r7.setLayoutParams(r8)
            r8 = 1
            defpackage.ya.q0(r7, r8)
            android.widget.LinearLayout r8 = r0.f1528b
            r8.addView(r7)
            android.widget.LinearLayout r7 = r0.f1528b
            com.google.android.material.internal.CheckableImageButton r8 = r0.f1539c
            r7.addView(r8)
            android.widget.LinearLayout r7 = r0.f1528b
            android.widget.FrameLayout r8 = r0.f1527b
            r7.addView(r8)
            r0.setHelperTextEnabled(r9)
            r0.setHelperText(r13)
            r0.setHelperTextTextAppearance(r6)
            r0.setErrorEnabled(r5)
            r0.setErrorTextAppearance(r2)
            r0.setErrorContentDescription(r4)
            int r2 = r0.d
            r0.setCounterTextAppearance(r2)
            int r2 = r0.c
            r0.setCounterOverflowTextAppearance(r2)
            r0.setPlaceholderText(r3)
            r0.setPlaceholderTextAppearance(r14)
            r2 = r19
            r0.setPrefixText(r2)
            r2 = r18
            r0.setPrefixTextAppearance(r2)
            r2 = r21
            r0.setSuffixText(r2)
            r2 = r20
            r0.setSuffixTextAppearance(r2)
            int r2 = defpackage.x91.TextInputLayout_errorTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x0567
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setErrorTextColor(r2)
        L_0x0567:
            int r2 = defpackage.x91.TextInputLayout_helperTextTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x0576
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setHelperTextColor(r2)
        L_0x0576:
            int r2 = defpackage.x91.TextInputLayout_hintTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x0585
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setHintTextColor(r2)
        L_0x0585:
            int r2 = defpackage.x91.TextInputLayout_counterTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x0594
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setCounterTextColor(r2)
        L_0x0594:
            int r2 = defpackage.x91.TextInputLayout_counterOverflowTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x05a3
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setCounterOverflowTextColor(r2)
        L_0x05a3:
            int r2 = defpackage.x91.TextInputLayout_placeholderTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x05b2
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setPlaceholderTextColor(r2)
        L_0x05b2:
            int r2 = defpackage.x91.TextInputLayout_prefixTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x05c1
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setPrefixTextColor(r2)
        L_0x05c1:
            int r2 = defpackage.x91.TextInputLayout_suffixTextColor
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x05d0
            android.content.res.ColorStateList r2 = r1.c(r2)
            r0.setSuffixTextColor(r2)
        L_0x05d0:
            r2 = r22
            r0.setCounterEnabled(r2)
            int r2 = defpackage.x91.TextInputLayout_android_enabled
            r3 = 1
            boolean r2 = r1.a(r2, r3)
            r0.setEnabled(r2)
            r1.w()
            r1 = 2
            defpackage.ya.x0(r0, r1)
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 26
            if (r1 < r2) goto L_0x05ef
            defpackage.ya.y0(r0, r3)
        L_0x05ef:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public static void U(ViewGroup viewGroup, boolean z) {
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            childAt.setEnabled(z);
            if (childAt instanceof ViewGroup) {
                U((ViewGroup) childAt, z);
            }
        }
    }

    public static void b0(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        boolean O = ya.O(checkableImageButton);
        boolean z = false;
        int i2 = 1;
        boolean z2 = onLongClickListener != null;
        if (O || z2) {
            z = true;
        }
        checkableImageButton.setFocusable(z);
        checkableImageButton.setClickable(O);
        checkableImageButton.setPressable(O);
        checkableImageButton.setLongClickable(z2);
        if (!z) {
            i2 = 2;
        }
        ya.x0(checkableImageButton, i2);
    }

    public static void c0(CheckableImageButton checkableImageButton, View.OnClickListener onClickListener, View.OnLongClickListener onLongClickListener) {
        checkableImageButton.setOnClickListener(onClickListener);
        b0(checkableImageButton, onLongClickListener);
    }

    public static void d0(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        b0(checkableImageButton, onLongClickListener);
    }

    private zd1 getEndIconDelegate() {
        zd1 zd1 = this.f1510a.get(this.o);
        return zd1 != null ? zd1 : this.f1510a.get(0);
    }

    private CheckableImageButton getEndIconToUpdateDummyDrawable() {
        if (this.f1539c.getVisibility() == 0) {
            return this.f1539c;
        }
        if (!I() || !K()) {
            return null;
        }
        return this.f1530b;
    }

    public static void o0(Context context, TextView textView, int i2, int i3, boolean z) {
        textView.setContentDescription(context.getString(z ? v91.character_counter_overflowed_content_description : v91.character_counter_content_description, new Object[]{Integer.valueOf(i2), Integer.valueOf(i3)}));
    }

    private void setEditText(EditText editText) {
        if (this.f1512a == null) {
            if (this.o != 3) {
                boolean z = editText instanceof TextInputEditText;
            }
            this.f1512a = editText;
            S();
            setTextInputAccessibilityDelegate(new e(this));
            this.f1517a.b0(this.f1512a.getTypeface());
            this.f1517a.T(this.f1512a.getTextSize());
            int gravity = this.f1512a.getGravity();
            this.f1517a.L((gravity & -113) | 48);
            this.f1517a.S(gravity);
            this.f1512a.addTextChangedListener(new a());
            if (this.f1551g == null) {
                this.f1551g = this.f1512a.getHintTextColors();
            }
            if (this.f1548e) {
                if (TextUtils.isEmpty(this.f1547e)) {
                    CharSequence hint = this.f1512a.getHint();
                    this.f1519a = hint;
                    setHint(hint);
                    this.f1512a.setHint((CharSequence) null);
                }
                this.f1550f = true;
            }
            if (this.f1515a != null) {
                n0(this.f1512a.getText().length());
            }
            r0();
            this.f1502a.e();
            this.f1514a.bringToFront();
            this.f1528b.bringToFront();
            this.f1527b.bringToFront();
            this.f1539c.bringToFront();
            B();
            z0();
            C0();
            if (!isEnabled()) {
                editText.setEnabled(false);
            }
            v0(false, true);
            return;
        }
        throw new IllegalArgumentException("We already have an EditText, can only have one");
    }

    private void setErrorIconVisible(boolean z) {
        int i2 = 0;
        this.f1539c.setVisibility(z ? 0 : 8);
        FrameLayout frameLayout = this.f1527b;
        if (z) {
            i2 = 8;
        }
        frameLayout.setVisibility(i2);
        C0();
        if (!I()) {
            q0();
        }
    }

    private void setHintInternal(CharSequence charSequence) {
        if (!TextUtils.equals(charSequence, this.f1547e)) {
            this.f1547e = charSequence;
            this.f1517a.Z(charSequence);
            if (!this.f1558k) {
                T();
            }
        }
    }

    private void setPlaceholderTextEnabled(boolean z) {
        if (this.f1545d != z) {
            if (z) {
                v2 v2Var = new v2(getContext());
                this.f1529b = v2Var;
                v2Var.setId(s91.textinput_placeholder);
                ya.q0(this.f1529b, 1);
                setPlaceholderTextAppearance(this.e);
                setPlaceholderTextColor(this.f1504a);
                g();
            } else {
                Z();
                this.f1529b = null;
            }
            this.f1545d = z;
        }
    }

    public final boolean A() {
        return this.f1548e && !TextUtils.isEmpty(this.f1547e) && (this.f1518a instanceof xd1);
    }

    public final void A0() {
        this.f1538c.setVisibility((this.f1540c == null || N()) ? 8 : 0);
        q0();
    }

    public final void B() {
        Iterator it = this.f1520a.iterator();
        while (it.hasNext()) {
            ((f) it.next()).a(this);
        }
    }

    public final void B0(boolean z, boolean z2) {
        int defaultColor = this.f1555i.getDefaultColor();
        int colorForState = this.f1555i.getColorForState(new int[]{16843623, 16842910}, defaultColor);
        int colorForState2 = this.f1555i.getColorForState(new int[]{16843518, 16842910}, defaultColor);
        if (z) {
            this.l = colorForState2;
        } else if (z2) {
            this.l = colorForState;
        } else {
            this.l = defaultColor;
        }
    }

    public final void C(int i2) {
        Iterator it = this.f1533b.iterator();
        while (it.hasNext()) {
            ((g) it.next()).a(this, i2);
        }
    }

    public final void C0() {
        if (this.f1512a != null) {
            ya.A0(this.f1543d, getContext().getResources().getDimensionPixelSize(q91.material_input_text_to_prefix_suffix_padding), this.f1512a.getPaddingTop(), (K() || L()) ? 0 : ya.H(this.f1512a), this.f1512a.getPaddingBottom());
        }
    }

    public final void D(Canvas canvas) {
        hd1 hd1 = this.f1531b;
        if (hd1 != null) {
            Rect bounds = hd1.getBounds();
            bounds.top = bounds.bottom - this.i;
            this.f1531b.draw(canvas);
        }
    }

    public final void D0() {
        int visibility = this.f1543d.getVisibility();
        int i2 = 0;
        boolean z = this.f1544d != null && !N();
        TextView textView = this.f1543d;
        if (!z) {
            i2 = 8;
        }
        textView.setVisibility(i2);
        if (visibility != this.f1543d.getVisibility()) {
            getEndIconDelegate().c(z);
        }
        q0();
    }

    public final void E(Canvas canvas) {
        if (this.f1548e) {
            this.f1517a.j(canvas);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0012, code lost:
        r0 = r6.f1512a;
     */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00be  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void E0() {
        /*
            r6 = this;
            hd1 r0 = r6.f1518a
            if (r0 == 0) goto L_0x00db
            int r0 = r6.g
            if (r0 != 0) goto L_0x000a
            goto L_0x00db
        L_0x000a:
            boolean r0 = r6.isFocused()
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x001f
            android.widget.EditText r0 = r6.f1512a
            if (r0 == 0) goto L_0x001d
            boolean r0 = r0.hasFocus()
            if (r0 == 0) goto L_0x001d
            goto L_0x001f
        L_0x001d:
            r0 = 0
            goto L_0x0020
        L_0x001f:
            r0 = 1
        L_0x0020:
            boolean r3 = r6.isHovered()
            if (r3 != 0) goto L_0x0033
            android.widget.EditText r3 = r6.f1512a
            if (r3 == 0) goto L_0x0031
            boolean r3 = r3.isHovered()
            if (r3 == 0) goto L_0x0031
            goto L_0x0033
        L_0x0031:
            r3 = 0
            goto L_0x0034
        L_0x0033:
            r3 = 1
        L_0x0034:
            boolean r4 = r6.isEnabled()
            if (r4 != 0) goto L_0x003f
            int r4 = r6.x
        L_0x003c:
            r6.l = r4
            goto L_0x0075
        L_0x003f:
            ae1 r4 = r6.f1502a
            boolean r4 = r4.k()
            if (r4 == 0) goto L_0x0056
            android.content.res.ColorStateList r4 = r6.f1555i
            if (r4 == 0) goto L_0x004f
        L_0x004b:
            r6.B0(r0, r3)
            goto L_0x0075
        L_0x004f:
            ae1 r4 = r6.f1502a
            int r4 = r4.o()
            goto L_0x003c
        L_0x0056:
            boolean r4 = r6.f1541c
            if (r4 == 0) goto L_0x0068
            android.widget.TextView r4 = r6.f1515a
            if (r4 == 0) goto L_0x0068
            android.content.res.ColorStateList r5 = r6.f1555i
            if (r5 == 0) goto L_0x0063
            goto L_0x004b
        L_0x0063:
            int r4 = r4.getCurrentTextColor()
            goto L_0x003c
        L_0x0068:
            if (r0 == 0) goto L_0x006d
            int r4 = r6.s
            goto L_0x003c
        L_0x006d:
            if (r3 == 0) goto L_0x0072
            int r4 = r6.r
            goto L_0x003c
        L_0x0072:
            int r4 = r6.q
            goto L_0x003c
        L_0x0075:
            android.graphics.drawable.Drawable r4 = r6.getErrorIconDrawable()
            if (r4 == 0) goto L_0x008c
            ae1 r4 = r6.f1502a
            boolean r4 = r4.x()
            if (r4 == 0) goto L_0x008c
            ae1 r4 = r6.f1502a
            boolean r4 = r4.k()
            if (r4 == 0) goto L_0x008c
            r1 = 1
        L_0x008c:
            r6.setErrorIconVisible(r1)
            r6.W()
            r6.Y()
            r6.V()
            zd1 r1 = r6.getEndIconDelegate()
            boolean r1 = r1.d()
            if (r1 == 0) goto L_0x00ab
            ae1 r1 = r6.f1502a
            boolean r1 = r1.k()
            r6.j0(r1)
        L_0x00ab:
            if (r0 == 0) goto L_0x00b6
            boolean r1 = r6.isEnabled()
            if (r1 == 0) goto L_0x00b6
            int r1 = r6.k
            goto L_0x00b8
        L_0x00b6:
            int r1 = r6.j
        L_0x00b8:
            r6.i = r1
            int r1 = r6.g
            if (r1 != r2) goto L_0x00d8
            boolean r1 = r6.isEnabled()
            if (r1 != 0) goto L_0x00c9
            int r0 = r6.u
        L_0x00c6:
            r6.m = r0
            goto L_0x00d8
        L_0x00c9:
            if (r3 == 0) goto L_0x00d0
            if (r0 != 0) goto L_0x00d0
            int r0 = r6.w
            goto L_0x00c6
        L_0x00d0:
            if (r0 == 0) goto L_0x00d5
            int r0 = r6.v
            goto L_0x00c6
        L_0x00d5:
            int r0 = r6.t
            goto L_0x00c6
        L_0x00d8:
            r6.j()
        L_0x00db:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.E0():void");
    }

    public final void F(boolean z) {
        ValueAnimator valueAnimator = this.f1503a;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.f1503a.cancel();
        }
        if (!z || !this.f1560m) {
            this.f1517a.V(0.0f);
        } else {
            i(0.0f);
        }
        if (A() && ((xd1) this.f1518a).i0()) {
            y();
        }
        this.f1558k = true;
        J();
        A0();
        D0();
    }

    public final int G(int i2, boolean z) {
        int compoundPaddingLeft = i2 + this.f1512a.getCompoundPaddingLeft();
        return (this.f1540c == null || z) ? compoundPaddingLeft : (compoundPaddingLeft - this.f1538c.getMeasuredWidth()) + this.f1538c.getPaddingLeft();
    }

    public final int H(int i2, boolean z) {
        int compoundPaddingRight = i2 - this.f1512a.getCompoundPaddingRight();
        return (this.f1540c == null || !z) ? compoundPaddingRight : compoundPaddingRight + (this.f1538c.getMeasuredWidth() - this.f1538c.getPaddingRight());
    }

    public final boolean I() {
        return this.o != 0;
    }

    public final void J() {
        TextView textView = this.f1529b;
        if (textView != null && this.f1545d) {
            textView.setText((CharSequence) null);
            this.f1529b.setVisibility(4);
        }
    }

    public boolean K() {
        return this.f1527b.getVisibility() == 0 && this.f1530b.getVisibility() == 0;
    }

    public final boolean L() {
        return this.f1539c.getVisibility() == 0;
    }

    public boolean M() {
        return this.f1502a.y();
    }

    public final boolean N() {
        return this.f1558k;
    }

    public boolean O() {
        return this.f1550f;
    }

    public final boolean P() {
        return this.g == 1 && (Build.VERSION.SDK_INT < 16 || this.f1512a.getMinLines() <= 1);
    }

    public boolean Q() {
        return this.f1516a.getVisibility() == 0;
    }

    public final int[] R(CheckableImageButton checkableImageButton) {
        int[] drawableState = getDrawableState();
        int[] drawableState2 = checkableImageButton.getDrawableState();
        int length = drawableState.length;
        int[] copyOf = Arrays.copyOf(drawableState, drawableState.length + drawableState2.length);
        System.arraycopy(drawableState2, 0, copyOf, length, drawableState2.length);
        return copyOf;
    }

    public final void S() {
        p();
        a0();
        E0();
        k0();
        h();
        if (this.g != 0) {
            t0();
        }
    }

    public final void T() {
        if (A()) {
            RectF rectF = this.f1507a;
            this.f1517a.m(rectF, this.f1512a.getWidth(), this.f1512a.getGravity());
            l(rectF);
            rectF.offset((float) (-getPaddingLeft()), (float) (-getPaddingTop()));
            ((xd1) this.f1518a).o0(rectF);
        }
    }

    public void V() {
        X(this.f1530b, this.f1546e);
    }

    public void W() {
        X(this.f1539c, this.f1549f);
    }

    public final void X(CheckableImageButton checkableImageButton, ColorStateList colorStateList) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (checkableImageButton.getDrawable() != null && colorStateList != null && colorStateList.isStateful()) {
            int colorForState = colorStateList.getColorForState(R(checkableImageButton), colorStateList.getDefaultColor());
            Drawable mutate = m8.r(drawable).mutate();
            m8.o(mutate, ColorStateList.valueOf(colorForState));
            checkableImageButton.setImageDrawable(mutate);
        }
    }

    public void Y() {
        X(this.f1516a, this.f1542d);
    }

    public final void Z() {
        TextView textView = this.f1529b;
        if (textView != null) {
            textView.setVisibility(8);
        }
    }

    public final void a0() {
        if (h0()) {
            ya.r0(this.f1512a, this.f1518a);
        }
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof EditText) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
            layoutParams2.gravity = (layoutParams2.gravity & -113) | 16;
            this.f1513a.addView(view, layoutParams2);
            this.f1513a.setLayoutParams(layoutParams);
            t0();
            setEditText((EditText) view);
            return;
        }
        super.addView(view, i2, layoutParams);
    }

    @TargetApi(26)
    public void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i2) {
        EditText editText = this.f1512a;
        if (editText == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i2);
            return;
        }
        if (this.f1519a != null) {
            boolean z = this.f1550f;
            this.f1550f = false;
            CharSequence hint = editText.getHint();
            this.f1512a.setHint(this.f1519a);
            try {
                super.dispatchProvideAutofillStructure(viewStructure, i2);
            } finally {
                this.f1512a.setHint(hint);
                this.f1550f = z;
            }
        } else {
            viewStructure.setAutofillId(getAutofillId());
            onProvideAutofillStructure(viewStructure, i2);
            onProvideAutofillVirtualStructure(viewStructure, i2);
            viewStructure.setChildCount(this.f1513a.getChildCount());
            for (int i3 = 0; i3 < this.f1513a.getChildCount(); i3++) {
                View childAt = this.f1513a.getChildAt(i3);
                ViewStructure newChild = viewStructure.newChild(i3);
                childAt.dispatchProvideAutofillStructure(newChild, i2);
                if (childAt == this.f1512a) {
                    newChild.setHint(getHint());
                }
            }
        }
    }

    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        this.f1562o = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.f1562o = false;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        E(canvas);
        D(canvas);
    }

    public void drawableStateChanged() {
        if (!this.f1561n) {
            boolean z = true;
            this.f1561n = true;
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            dc1 dc1 = this.f1517a;
            boolean Y = dc1 != null ? dc1.Y(drawableState) | false : false;
            if (this.f1512a != null) {
                if (!ya.T(this) || !isEnabled()) {
                    z = false;
                }
                u0(z);
            }
            r0();
            E0();
            if (Y) {
                invalidate();
            }
            this.f1561n = false;
        }
    }

    public void e(f fVar) {
        this.f1520a.add(fVar);
        if (this.f1512a != null) {
            fVar.a(this);
        }
    }

    public void e0(TextView textView, int i2) {
        boolean z = true;
        try {
            yb.n(textView, i2);
            if (Build.VERSION.SDK_INT < 23 || textView.getTextColors().getDefaultColor() != -65281) {
                z = false;
            }
        } catch (Exception unused) {
        }
        if (z) {
            yb.n(textView, w91.TextAppearance_AppCompat_Caption);
            textView.setTextColor(r7.d(getContext(), p91.design_error));
        }
    }

    public void f(g gVar) {
        this.f1533b.add(gVar);
    }

    public final boolean f0() {
        return (this.f1539c.getVisibility() == 0 || ((I() && K()) || this.f1544d != null)) && this.f1528b.getMeasuredWidth() > 0;
    }

    public final void g() {
        TextView textView = this.f1529b;
        if (textView != null) {
            this.f1513a.addView(textView);
            this.f1529b.setVisibility(0);
        }
    }

    public final boolean g0() {
        return !(getStartIconDrawable() == null && this.f1540c == null) && this.f1514a.getMeasuredWidth() > 0;
    }

    public int getBaseline() {
        EditText editText = this.f1512a;
        return editText != null ? editText.getBaseline() + getPaddingTop() + v() : super.getBaseline();
    }

    public hd1 getBoxBackground() {
        int i2 = this.g;
        if (i2 == 1 || i2 == 2) {
            return this.f1518a;
        }
        throw new IllegalStateException();
    }

    public int getBoxBackgroundColor() {
        return this.m;
    }

    public int getBoxBackgroundMode() {
        return this.g;
    }

    public float getBoxCornerRadiusBottomEnd() {
        return this.f1518a.s();
    }

    public float getBoxCornerRadiusBottomStart() {
        return this.f1518a.t();
    }

    public float getBoxCornerRadiusTopEnd() {
        return this.f1518a.G();
    }

    public float getBoxCornerRadiusTopStart() {
        return this.f1518a.F();
    }

    public int getBoxStrokeColor() {
        return this.s;
    }

    public ColorStateList getBoxStrokeErrorColor() {
        return this.f1555i;
    }

    public int getBoxStrokeWidth() {
        return this.j;
    }

    public int getBoxStrokeWidthFocused() {
        return this.k;
    }

    public int getCounterMaxLength() {
        return this.b;
    }

    public CharSequence getCounterOverflowDescription() {
        TextView textView;
        if (!this.f1534b || !this.f1541c || (textView = this.f1515a) == null) {
            return null;
        }
        return textView.getContentDescription();
    }

    public ColorStateList getCounterOverflowTextColor() {
        return this.f1522b;
    }

    public ColorStateList getCounterTextColor() {
        return this.f1522b;
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.f1551g;
    }

    public EditText getEditText() {
        return this.f1512a;
    }

    public CharSequence getEndIconContentDescription() {
        return this.f1530b.getContentDescription();
    }

    public Drawable getEndIconDrawable() {
        return this.f1530b.getDrawable();
    }

    public int getEndIconMode() {
        return this.o;
    }

    public CheckableImageButton getEndIconView() {
        return this.f1530b;
    }

    public CharSequence getError() {
        if (this.f1502a.x()) {
            return this.f1502a.n();
        }
        return null;
    }

    public CharSequence getErrorContentDescription() {
        return this.f1502a.m();
    }

    public int getErrorCurrentTextColors() {
        return this.f1502a.o();
    }

    public Drawable getErrorIconDrawable() {
        return this.f1539c.getDrawable();
    }

    public final int getErrorTextCurrentColor() {
        return this.f1502a.o();
    }

    public CharSequence getHelperText() {
        if (this.f1502a.y()) {
            return this.f1502a.q();
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        return this.f1502a.r();
    }

    public CharSequence getHint() {
        if (this.f1548e) {
            return this.f1547e;
        }
        return null;
    }

    public final float getHintCollapsedTextHeight() {
        return this.f1517a.o();
    }

    public final int getHintCurrentCollapsedTextColor() {
        return this.f1517a.r();
    }

    public ColorStateList getHintTextColor() {
        return this.f1553h;
    }

    @Deprecated
    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.f1530b.getContentDescription();
    }

    @Deprecated
    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.f1530b.getDrawable();
    }

    public CharSequence getPlaceholderText() {
        if (this.f1545d) {
            return this.f1532b;
        }
        return null;
    }

    public int getPlaceholderTextAppearance() {
        return this.e;
    }

    public ColorStateList getPlaceholderTextColor() {
        return this.f1504a;
    }

    public CharSequence getPrefixText() {
        return this.f1540c;
    }

    public ColorStateList getPrefixTextColor() {
        return this.f1538c.getTextColors();
    }

    public TextView getPrefixTextView() {
        return this.f1538c;
    }

    public CharSequence getStartIconContentDescription() {
        return this.f1516a.getContentDescription();
    }

    public Drawable getStartIconDrawable() {
        return this.f1516a.getDrawable();
    }

    public CharSequence getSuffixText() {
        return this.f1544d;
    }

    public ColorStateList getSuffixTextColor() {
        return this.f1543d.getTextColors();
    }

    public TextView getSuffixTextView() {
        return this.f1543d;
    }

    public Typeface getTypeface() {
        return this.f1508a;
    }

    public final void h() {
        EditText editText;
        int I;
        int dimensionPixelSize;
        int H;
        Resources resources;
        int i2;
        if (this.f1512a != null && this.g == 1) {
            if (tc1.h(getContext())) {
                editText = this.f1512a;
                I = ya.I(editText);
                dimensionPixelSize = getResources().getDimensionPixelSize(q91.material_filled_edittext_font_2_0_padding_top);
                H = ya.H(this.f1512a);
                resources = getResources();
                i2 = q91.material_filled_edittext_font_2_0_padding_bottom;
            } else if (tc1.g(getContext())) {
                editText = this.f1512a;
                I = ya.I(editText);
                dimensionPixelSize = getResources().getDimensionPixelSize(q91.material_filled_edittext_font_1_3_padding_top);
                H = ya.H(this.f1512a);
                resources = getResources();
                i2 = q91.material_filled_edittext_font_1_3_padding_bottom;
            } else {
                return;
            }
            ya.A0(editText, I, dimensionPixelSize, H, resources.getDimensionPixelSize(i2));
        }
    }

    public final boolean h0() {
        EditText editText = this.f1512a;
        return (editText == null || this.f1518a == null || editText.getBackground() != null || this.g == 0) ? false : true;
    }

    public void i(float f2) {
        if (this.f1517a.v() != f2) {
            if (this.f1503a == null) {
                ValueAnimator valueAnimator = new ValueAnimator();
                this.f1503a = valueAnimator;
                valueAnimator.setInterpolator(y91.b);
                this.f1503a.setDuration(167);
                this.f1503a.addUpdateListener(new d());
            }
            this.f1503a.setFloatValues(new float[]{this.f1517a.v(), f2});
            this.f1503a.start();
        }
    }

    public final void i0() {
        TextView textView = this.f1529b;
        if (textView != null && this.f1545d) {
            textView.setText(this.f1532b);
            this.f1529b.setVisibility(0);
            this.f1529b.bringToFront();
        }
    }

    public final void j() {
        hd1 hd1 = this.f1518a;
        if (hd1 != null) {
            hd1.setShapeAppearanceModel(this.f1521a);
            if (w()) {
                this.f1518a.b0((float) this.i, this.l);
            }
            int q2 = q();
            this.m = q2;
            this.f1518a.W(ColorStateList.valueOf(q2));
            if (this.o == 3) {
                this.f1512a.getBackground().invalidateSelf();
            }
            k();
            invalidate();
        }
    }

    public final void j0(boolean z) {
        if (!z || getEndIconDrawable() == null) {
            m();
            return;
        }
        Drawable mutate = m8.r(getEndIconDrawable()).mutate();
        m8.n(mutate, this.f1502a.o());
        this.f1530b.setImageDrawable(mutate);
    }

    public final void k() {
        if (this.f1531b != null) {
            if (x()) {
                this.f1531b.W(ColorStateList.valueOf(this.l));
            }
            invalidate();
        }
    }

    public final void k0() {
        Resources resources;
        int i2;
        if (this.g == 1) {
            if (tc1.h(getContext())) {
                resources = getResources();
                i2 = q91.material_font_2_0_box_collapsed_padding_top;
            } else if (tc1.g(getContext())) {
                resources = getResources();
                i2 = q91.material_font_1_3_box_collapsed_padding_top;
            } else {
                return;
            }
            this.h = resources.getDimensionPixelSize(i2);
        }
    }

    public final void l(RectF rectF) {
        float f2 = rectF.left;
        int i2 = this.f;
        rectF.left = f2 - ((float) i2);
        rectF.top -= (float) i2;
        rectF.right += (float) i2;
        rectF.bottom += (float) i2;
    }

    public final void l0(Rect rect) {
        hd1 hd1 = this.f1531b;
        if (hd1 != null) {
            int i2 = rect.bottom;
            hd1.setBounds(rect.left, i2 - this.k, rect.right, i2);
        }
    }

    public final void m() {
        n(this.f1530b, this.f1556i, this.f1546e, this.f1557j, this.f1523b);
    }

    public final void m0() {
        if (this.f1515a != null) {
            EditText editText = this.f1512a;
            n0(editText == null ? 0 : editText.getText().length());
        }
    }

    public final void n(CheckableImageButton checkableImageButton, boolean z, ColorStateList colorStateList, boolean z2, PorterDuff.Mode mode) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (drawable != null && (z || z2)) {
            drawable = m8.r(drawable).mutate();
            if (z) {
                m8.o(drawable, colorStateList);
            }
            if (z2) {
                m8.p(drawable, mode);
            }
        }
        if (checkableImageButton.getDrawable() != drawable) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    public void n0(int i2) {
        boolean z = this.f1541c;
        int i3 = this.b;
        if (i3 == -1) {
            this.f1515a.setText(String.valueOf(i2));
            this.f1515a.setContentDescription((CharSequence) null);
            this.f1541c = false;
        } else {
            this.f1541c = i2 > i3;
            o0(getContext(), this.f1515a, i2, this.b, this.f1541c);
            if (z != this.f1541c) {
                p0();
            }
            this.f1515a.setText(p9.c().j(getContext().getString(v91.character_counter_pattern, new Object[]{Integer.valueOf(i2), Integer.valueOf(this.b)})));
        }
        if (this.f1512a != null && z != this.f1541c) {
            u0(false);
            E0();
            r0();
        }
    }

    public final void o() {
        n(this.f1516a, this.f1552g, this.f1542d, this.f1554h, this.f1505a);
    }

    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        EditText editText = this.f1512a;
        if (editText != null) {
            Rect rect = this.f1506a;
            ec1.a(this, editText, rect);
            l0(rect);
            if (this.f1548e) {
                this.f1517a.T(this.f1512a.getTextSize());
                int gravity = this.f1512a.getGravity();
                this.f1517a.L((gravity & -113) | 48);
                this.f1517a.S(gravity);
                this.f1517a.H(r(rect));
                this.f1517a.P(u(rect));
                this.f1517a.E();
                if (A() && !this.f1558k) {
                    T();
                }
            }
        }
    }

    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        boolean s0 = s0();
        boolean q0 = q0();
        if (s0 || q0) {
            this.f1512a.post(new c());
        }
        w0();
        z0();
        C0();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        h hVar = (h) parcelable;
        super.onRestoreInstanceState(hVar.a());
        setError(hVar.a);
        if (hVar.f1563b) {
            this.f1530b.post(new b());
        }
        setHint(hVar.b);
        setHelperText(hVar.c);
        setPlaceholderText(hVar.d);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        h hVar = new h(super.onSaveInstanceState());
        if (this.f1502a.k()) {
            hVar.a = getError();
        }
        hVar.f1563b = I() && this.f1530b.isChecked();
        hVar.b = getHint();
        hVar.c = getHelperText();
        hVar.d = getPlaceholderText();
        return hVar;
    }

    public final void p() {
        int i2 = this.g;
        if (i2 == 0) {
            this.f1518a = null;
        } else if (i2 == 1) {
            this.f1518a = new hd1(this.f1521a);
            this.f1531b = new hd1();
            return;
        } else if (i2 == 2) {
            this.f1518a = (!this.f1548e || (this.f1518a instanceof xd1)) ? new hd1(this.f1521a) : new xd1(this.f1521a);
        } else {
            throw new IllegalArgumentException(this.g + " is illegal; only @BoxBackgroundMode constants are supported.");
        }
        this.f1531b = null;
    }

    public final void p0() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        TextView textView = this.f1515a;
        if (textView != null) {
            e0(textView, this.f1541c ? this.c : this.d);
            if (!this.f1541c && (colorStateList2 = this.f1522b) != null) {
                this.f1515a.setTextColor(colorStateList2);
            }
            if (this.f1541c && (colorStateList = this.f1535c) != null) {
                this.f1515a.setTextColor(colorStateList);
            }
        }
    }

    public final int q() {
        return this.g == 1 ? ab1.e(ab1.d(this, o91.colorSurface, 0), this.m) : this.m;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00d3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean q0() {
        /*
            r10 = this;
            android.widget.EditText r0 = r10.f1512a
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            boolean r0 = r10.g0()
            r2 = 0
            r3 = 3
            r4 = 2
            r5 = 1
            if (r0 == 0) goto L_0x0049
            android.widget.LinearLayout r0 = r10.f1514a
            int r0 = r0.getMeasuredWidth()
            android.widget.EditText r6 = r10.f1512a
            int r6 = r6.getPaddingLeft()
            int r0 = r0 - r6
            android.graphics.drawable.Drawable r6 = r10.f1509a
            if (r6 == 0) goto L_0x0025
            int r6 = r10.n
            if (r6 == r0) goto L_0x0031
        L_0x0025:
            android.graphics.drawable.ColorDrawable r6 = new android.graphics.drawable.ColorDrawable
            r6.<init>()
            r10.f1509a = r6
            r10.n = r0
            r6.setBounds(r1, r1, r0, r5)
        L_0x0031:
            android.widget.EditText r0 = r10.f1512a
            android.graphics.drawable.Drawable[] r0 = defpackage.yb.a(r0)
            r6 = r0[r1]
            android.graphics.drawable.Drawable r7 = r10.f1509a
            if (r6 == r7) goto L_0x0062
            android.widget.EditText r6 = r10.f1512a
            r8 = r0[r5]
            r9 = r0[r4]
            r0 = r0[r3]
            defpackage.yb.i(r6, r7, r8, r9, r0)
            goto L_0x0060
        L_0x0049:
            android.graphics.drawable.Drawable r0 = r10.f1509a
            if (r0 == 0) goto L_0x0062
            android.widget.EditText r0 = r10.f1512a
            android.graphics.drawable.Drawable[] r0 = defpackage.yb.a(r0)
            android.widget.EditText r6 = r10.f1512a
            r7 = r0[r5]
            r8 = r0[r4]
            r0 = r0[r3]
            defpackage.yb.i(r6, r2, r7, r8, r0)
            r10.f1509a = r2
        L_0x0060:
            r0 = 1
            goto L_0x0063
        L_0x0062:
            r0 = 0
        L_0x0063:
            boolean r6 = r10.f0()
            if (r6 == 0) goto L_0x00d3
            android.widget.TextView r2 = r10.f1543d
            int r2 = r2.getMeasuredWidth()
            android.widget.EditText r6 = r10.f1512a
            int r6 = r6.getPaddingRight()
            int r2 = r2 - r6
            com.google.android.material.internal.CheckableImageButton r6 = r10.getEndIconToUpdateDummyDrawable()
            if (r6 == 0) goto L_0x008c
            int r7 = r6.getMeasuredWidth()
            int r2 = r2 + r7
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r6 = (android.view.ViewGroup.MarginLayoutParams) r6
            int r6 = defpackage.ka.b(r6)
            int r2 = r2 + r6
        L_0x008c:
            android.widget.EditText r6 = r10.f1512a
            android.graphics.drawable.Drawable[] r6 = defpackage.yb.a(r6)
            android.graphics.drawable.Drawable r7 = r10.f1525b
            if (r7 == 0) goto L_0x00ad
            int r8 = r10.p
            if (r8 == r2) goto L_0x00ad
            r10.p = r2
            r7.setBounds(r1, r1, r2, r5)
            android.widget.EditText r0 = r10.f1512a
            r1 = r6[r1]
            r2 = r6[r5]
            android.graphics.drawable.Drawable r4 = r10.f1525b
            r3 = r6[r3]
            defpackage.yb.i(r0, r1, r2, r4, r3)
            goto L_0x00f4
        L_0x00ad:
            if (r7 != 0) goto L_0x00bb
            android.graphics.drawable.ColorDrawable r7 = new android.graphics.drawable.ColorDrawable
            r7.<init>()
            r10.f1525b = r7
            r10.p = r2
            r7.setBounds(r1, r1, r2, r5)
        L_0x00bb:
            r2 = r6[r4]
            android.graphics.drawable.Drawable r7 = r10.f1525b
            if (r2 == r7) goto L_0x00d1
            r0 = r6[r4]
            r10.f1536c = r0
            android.widget.EditText r0 = r10.f1512a
            r1 = r6[r1]
            r2 = r6[r5]
            r3 = r6[r3]
            defpackage.yb.i(r0, r1, r2, r7, r3)
            goto L_0x00f4
        L_0x00d1:
            r5 = r0
            goto L_0x00f4
        L_0x00d3:
            android.graphics.drawable.Drawable r6 = r10.f1525b
            if (r6 == 0) goto L_0x00f5
            android.widget.EditText r6 = r10.f1512a
            android.graphics.drawable.Drawable[] r6 = defpackage.yb.a(r6)
            r4 = r6[r4]
            android.graphics.drawable.Drawable r7 = r10.f1525b
            if (r4 != r7) goto L_0x00f1
            android.widget.EditText r0 = r10.f1512a
            r1 = r6[r1]
            r4 = r6[r5]
            android.graphics.drawable.Drawable r7 = r10.f1536c
            r3 = r6[r3]
            defpackage.yb.i(r0, r1, r4, r7, r3)
            goto L_0x00f2
        L_0x00f1:
            r5 = r0
        L_0x00f2:
            r10.f1525b = r2
        L_0x00f4:
            r0 = r5
        L_0x00f5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.q0():boolean");
    }

    public final Rect r(Rect rect) {
        int i2;
        int i3;
        if (this.f1512a != null) {
            Rect rect2 = this.f1524b;
            boolean z = ya.C(this) == 1;
            rect2.bottom = rect.bottom;
            int i4 = this.g;
            if (i4 == 1) {
                rect2.left = G(rect.left, z);
                i2 = rect.top + this.h;
            } else if (i4 != 2) {
                rect2.left = G(rect.left, z);
                i2 = getPaddingTop();
            } else {
                rect2.left = rect.left + this.f1512a.getPaddingLeft();
                rect2.top = rect.top - v();
                i3 = rect.right - this.f1512a.getPaddingRight();
                rect2.right = i3;
                return rect2;
            }
            rect2.top = i2;
            i3 = H(rect.right, z);
            rect2.right = i3;
            return rect2;
        }
        throw new IllegalStateException();
    }

    public void r0() {
        Drawable background;
        TextView textView;
        int currentTextColor;
        EditText editText = this.f1512a;
        if (editText != null && this.g == 0 && (background = editText.getBackground()) != null) {
            if (a3.a(background)) {
                background = background.mutate();
            }
            if (this.f1502a.k()) {
                currentTextColor = this.f1502a.o();
            } else if (!this.f1541c || (textView = this.f1515a) == null) {
                m8.c(background);
                this.f1512a.refreshDrawableState();
                return;
            } else {
                currentTextColor = textView.getCurrentTextColor();
            }
            background.setColorFilter(e2.e(currentTextColor, PorterDuff.Mode.SRC_IN));
        }
    }

    public final int s(Rect rect, Rect rect2, float f2) {
        return P() ? (int) (((float) rect2.top) + f2) : rect.bottom - this.f1512a.getCompoundPaddingBottom();
    }

    public final boolean s0() {
        int max;
        if (this.f1512a == null || this.f1512a.getMeasuredHeight() >= (max = Math.max(this.f1528b.getMeasuredHeight(), this.f1514a.getMeasuredHeight()))) {
            return false;
        }
        this.f1512a.setMinimumHeight(max);
        return true;
    }

    public void setBoxBackgroundColor(int i2) {
        if (this.m != i2) {
            this.m = i2;
            this.t = i2;
            this.v = i2;
            this.w = i2;
            j();
        }
    }

    public void setBoxBackgroundColorResource(int i2) {
        setBoxBackgroundColor(r7.d(getContext(), i2));
    }

    public void setBoxBackgroundColorStateList(ColorStateList colorStateList) {
        int defaultColor = colorStateList.getDefaultColor();
        this.t = defaultColor;
        this.m = defaultColor;
        this.u = colorStateList.getColorForState(new int[]{-16842910}, -1);
        this.v = colorStateList.getColorForState(new int[]{16842908, 16842910}, -1);
        this.w = colorStateList.getColorForState(new int[]{16843623, 16842910}, -1);
        j();
    }

    public void setBoxBackgroundMode(int i2) {
        if (i2 != this.g) {
            this.g = i2;
            if (this.f1512a != null) {
                S();
            }
        }
    }

    public void setBoxStrokeColor(int i2) {
        if (this.s != i2) {
            this.s = i2;
            E0();
        }
    }

    public void setBoxStrokeColorStateList(ColorStateList colorStateList) {
        int defaultColor;
        if (colorStateList.isStateful()) {
            this.q = colorStateList.getDefaultColor();
            this.x = colorStateList.getColorForState(new int[]{-16842910}, -1);
            this.r = colorStateList.getColorForState(new int[]{16843623, 16842910}, -1);
            defaultColor = colorStateList.getColorForState(new int[]{16842908, 16842910}, -1);
        } else {
            if (this.s != colorStateList.getDefaultColor()) {
                defaultColor = colorStateList.getDefaultColor();
            }
            E0();
        }
        this.s = defaultColor;
        E0();
    }

    public void setBoxStrokeErrorColor(ColorStateList colorStateList) {
        if (this.f1555i != colorStateList) {
            this.f1555i = colorStateList;
            E0();
        }
    }

    public void setBoxStrokeWidth(int i2) {
        this.j = i2;
        E0();
    }

    public void setBoxStrokeWidthFocused(int i2) {
        this.k = i2;
        E0();
    }

    public void setBoxStrokeWidthFocusedResource(int i2) {
        setBoxStrokeWidthFocused(getResources().getDimensionPixelSize(i2));
    }

    public void setBoxStrokeWidthResource(int i2) {
        setBoxStrokeWidth(getResources().getDimensionPixelSize(i2));
    }

    public void setCounterEnabled(boolean z) {
        if (this.f1534b != z) {
            if (z) {
                v2 v2Var = new v2(getContext());
                this.f1515a = v2Var;
                v2Var.setId(s91.textinput_counter);
                Typeface typeface = this.f1508a;
                if (typeface != null) {
                    this.f1515a.setTypeface(typeface);
                }
                this.f1515a.setMaxLines(1);
                this.f1502a.d(this.f1515a, 2);
                ka.d((ViewGroup.MarginLayoutParams) this.f1515a.getLayoutParams(), getResources().getDimensionPixelOffset(q91.mtrl_textinput_counter_margin_start));
                p0();
                m0();
            } else {
                this.f1502a.z(this.f1515a, 2);
                this.f1515a = null;
            }
            this.f1534b = z;
        }
    }

    public void setCounterMaxLength(int i2) {
        if (this.b != i2) {
            if (i2 <= 0) {
                i2 = -1;
            }
            this.b = i2;
            if (this.f1534b) {
                m0();
            }
        }
    }

    public void setCounterOverflowTextAppearance(int i2) {
        if (this.c != i2) {
            this.c = i2;
            p0();
        }
    }

    public void setCounterOverflowTextColor(ColorStateList colorStateList) {
        if (this.f1535c != colorStateList) {
            this.f1535c = colorStateList;
            p0();
        }
    }

    public void setCounterTextAppearance(int i2) {
        if (this.d != i2) {
            this.d = i2;
            p0();
        }
    }

    public void setCounterTextColor(ColorStateList colorStateList) {
        if (this.f1522b != colorStateList) {
            this.f1522b = colorStateList;
            p0();
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.f1551g = colorStateList;
        this.f1553h = colorStateList;
        if (this.f1512a != null) {
            u0(false);
        }
    }

    public void setEnabled(boolean z) {
        U(this, z);
        super.setEnabled(z);
    }

    public void setEndIconActivated(boolean z) {
        this.f1530b.setActivated(z);
    }

    public void setEndIconCheckable(boolean z) {
        this.f1530b.setCheckable(z);
    }

    public void setEndIconContentDescription(int i2) {
        setEndIconContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setEndIconContentDescription(CharSequence charSequence) {
        if (getEndIconContentDescription() != charSequence) {
            this.f1530b.setContentDescription(charSequence);
        }
    }

    public void setEndIconDrawable(int i2) {
        setEndIconDrawable(i2 != 0 ? l0.d(getContext(), i2) : null);
    }

    public void setEndIconDrawable(Drawable drawable) {
        this.f1530b.setImageDrawable(drawable);
        V();
    }

    public void setEndIconMode(int i2) {
        int i3 = this.o;
        this.o = i2;
        C(i3);
        setEndIconVisible(i2 != 0);
        if (getEndIconDelegate().b(this.g)) {
            getEndIconDelegate().a();
            m();
            return;
        }
        throw new IllegalStateException("The current box background mode " + this.g + " is not supported by the end icon mode " + i2);
    }

    public void setEndIconOnClickListener(View.OnClickListener onClickListener) {
        c0(this.f1530b, onClickListener, this.f1526b);
    }

    public void setEndIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f1526b = onLongClickListener;
        d0(this.f1530b, onLongClickListener);
    }

    public void setEndIconTintList(ColorStateList colorStateList) {
        if (this.f1546e != colorStateList) {
            this.f1546e = colorStateList;
            this.f1556i = true;
            m();
        }
    }

    public void setEndIconTintMode(PorterDuff.Mode mode) {
        if (this.f1523b != mode) {
            this.f1523b = mode;
            this.f1557j = true;
            m();
        }
    }

    public void setEndIconVisible(boolean z) {
        if (K() != z) {
            this.f1530b.setVisibility(z ? 0 : 8);
            C0();
            q0();
        }
    }

    public void setError(CharSequence charSequence) {
        if (!this.f1502a.x()) {
            if (!TextUtils.isEmpty(charSequence)) {
                setErrorEnabled(true);
            } else {
                return;
            }
        }
        if (!TextUtils.isEmpty(charSequence)) {
            this.f1502a.M(charSequence);
        } else {
            this.f1502a.t();
        }
    }

    public void setErrorContentDescription(CharSequence charSequence) {
        this.f1502a.B(charSequence);
    }

    public void setErrorEnabled(boolean z) {
        this.f1502a.C(z);
    }

    public void setErrorIconDrawable(int i2) {
        setErrorIconDrawable(i2 != 0 ? l0.d(getContext(), i2) : null);
        W();
    }

    public void setErrorIconDrawable(Drawable drawable) {
        this.f1539c.setImageDrawable(drawable);
        setErrorIconVisible(drawable != null && this.f1502a.x());
    }

    public void setErrorIconOnClickListener(View.OnClickListener onClickListener) {
        c0(this.f1539c, onClickListener, this.f1537c);
    }

    public void setErrorIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f1537c = onLongClickListener;
        d0(this.f1539c, onLongClickListener);
    }

    public void setErrorIconTintList(ColorStateList colorStateList) {
        this.f1549f = colorStateList;
        Drawable drawable = this.f1539c.getDrawable();
        if (drawable != null) {
            drawable = m8.r(drawable).mutate();
            m8.o(drawable, colorStateList);
        }
        if (this.f1539c.getDrawable() != drawable) {
            this.f1539c.setImageDrawable(drawable);
        }
    }

    public void setErrorIconTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f1539c.getDrawable();
        if (drawable != null) {
            drawable = m8.r(drawable).mutate();
            m8.p(drawable, mode);
        }
        if (this.f1539c.getDrawable() != drawable) {
            this.f1539c.setImageDrawable(drawable);
        }
    }

    public void setErrorTextAppearance(int i2) {
        this.f1502a.D(i2);
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        this.f1502a.E(colorStateList);
    }

    public void setExpandedHintEnabled(boolean z) {
        if (this.f1559l != z) {
            this.f1559l = z;
            u0(false);
        }
    }

    public void setHelperText(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (!M()) {
                setHelperTextEnabled(true);
            }
            this.f1502a.N(charSequence);
        } else if (M()) {
            setHelperTextEnabled(false);
        }
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        this.f1502a.H(colorStateList);
    }

    public void setHelperTextEnabled(boolean z) {
        this.f1502a.G(z);
    }

    public void setHelperTextTextAppearance(int i2) {
        this.f1502a.F(i2);
    }

    public void setHint(int i2) {
        setHint(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setHint(CharSequence charSequence) {
        if (this.f1548e) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z) {
        this.f1560m = z;
    }

    public void setHintEnabled(boolean z) {
        if (z != this.f1548e) {
            this.f1548e = z;
            if (!z) {
                this.f1550f = false;
                if (!TextUtils.isEmpty(this.f1547e) && TextUtils.isEmpty(this.f1512a.getHint())) {
                    this.f1512a.setHint(this.f1547e);
                }
                setHintInternal((CharSequence) null);
            } else {
                CharSequence hint = this.f1512a.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.f1547e)) {
                        setHint(hint);
                    }
                    this.f1512a.setHint((CharSequence) null);
                }
                this.f1550f = true;
            }
            if (this.f1512a != null) {
                t0();
            }
        }
    }

    public void setHintTextAppearance(int i2) {
        this.f1517a.I(i2);
        this.f1553h = this.f1517a.n();
        if (this.f1512a != null) {
            u0(false);
            t0();
        }
    }

    public void setHintTextColor(ColorStateList colorStateList) {
        if (this.f1553h != colorStateList) {
            if (this.f1551g == null) {
                this.f1517a.K(colorStateList);
            }
            this.f1553h = colorStateList;
            if (this.f1512a != null) {
                u0(false);
            }
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(int i2) {
        setPasswordVisibilityToggleContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.f1530b.setContentDescription(charSequence);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(int i2) {
        setPasswordVisibilityToggleDrawable(i2 != 0 ? l0.d(getContext(), i2) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.f1530b.setImageDrawable(drawable);
    }

    @Deprecated
    public void setPasswordVisibilityToggleEnabled(boolean z) {
        if (z && this.o != 1) {
            setEndIconMode(1);
        } else if (!z) {
            setEndIconMode(0);
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        this.f1546e = colorStateList;
        this.f1556i = true;
        m();
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        this.f1523b = mode;
        this.f1557j = true;
        m();
    }

    public void setPlaceholderText(CharSequence charSequence) {
        if (!this.f1545d || !TextUtils.isEmpty(charSequence)) {
            if (!this.f1545d) {
                setPlaceholderTextEnabled(true);
            }
            this.f1532b = charSequence;
        } else {
            setPlaceholderTextEnabled(false);
        }
        x0();
    }

    public void setPlaceholderTextAppearance(int i2) {
        this.e = i2;
        TextView textView = this.f1529b;
        if (textView != null) {
            yb.n(textView, i2);
        }
    }

    public void setPlaceholderTextColor(ColorStateList colorStateList) {
        if (this.f1504a != colorStateList) {
            this.f1504a = colorStateList;
            TextView textView = this.f1529b;
            if (textView != null && colorStateList != null) {
                textView.setTextColor(colorStateList);
            }
        }
    }

    public void setPrefixText(CharSequence charSequence) {
        this.f1540c = TextUtils.isEmpty(charSequence) ? null : charSequence;
        this.f1538c.setText(charSequence);
        A0();
    }

    public void setPrefixTextAppearance(int i2) {
        yb.n(this.f1538c, i2);
    }

    public void setPrefixTextColor(ColorStateList colorStateList) {
        this.f1538c.setTextColor(colorStateList);
    }

    public void setStartIconCheckable(boolean z) {
        this.f1516a.setCheckable(z);
    }

    public void setStartIconContentDescription(int i2) {
        setStartIconContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setStartIconContentDescription(CharSequence charSequence) {
        if (getStartIconContentDescription() != charSequence) {
            this.f1516a.setContentDescription(charSequence);
        }
    }

    public void setStartIconDrawable(int i2) {
        setStartIconDrawable(i2 != 0 ? l0.d(getContext(), i2) : null);
    }

    public void setStartIconDrawable(Drawable drawable) {
        this.f1516a.setImageDrawable(drawable);
        if (drawable != null) {
            setStartIconVisible(true);
            Y();
            return;
        }
        setStartIconVisible(false);
        setStartIconOnClickListener((View.OnClickListener) null);
        setStartIconOnLongClickListener((View.OnLongClickListener) null);
        setStartIconContentDescription((CharSequence) null);
    }

    public void setStartIconOnClickListener(View.OnClickListener onClickListener) {
        c0(this.f1516a, onClickListener, this.f1511a);
    }

    public void setStartIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f1511a = onLongClickListener;
        d0(this.f1516a, onLongClickListener);
    }

    public void setStartIconTintList(ColorStateList colorStateList) {
        if (this.f1542d != colorStateList) {
            this.f1542d = colorStateList;
            this.f1552g = true;
            o();
        }
    }

    public void setStartIconTintMode(PorterDuff.Mode mode) {
        if (this.f1505a != mode) {
            this.f1505a = mode;
            this.f1554h = true;
            o();
        }
    }

    public void setStartIconVisible(boolean z) {
        if (Q() != z) {
            this.f1516a.setVisibility(z ? 0 : 8);
            z0();
            q0();
        }
    }

    public void setSuffixText(CharSequence charSequence) {
        this.f1544d = TextUtils.isEmpty(charSequence) ? null : charSequence;
        this.f1543d.setText(charSequence);
        D0();
    }

    public void setSuffixTextAppearance(int i2) {
        yb.n(this.f1543d, i2);
    }

    public void setSuffixTextColor(ColorStateList colorStateList) {
        this.f1543d.setTextColor(colorStateList);
    }

    public void setTextInputAccessibilityDelegate(e eVar) {
        EditText editText = this.f1512a;
        if (editText != null) {
            ya.o0(editText, eVar);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.f1508a) {
            this.f1508a = typeface;
            this.f1517a.b0(typeface);
            this.f1502a.J(typeface);
            TextView textView = this.f1515a;
            if (textView != null) {
                textView.setTypeface(typeface);
            }
        }
    }

    public final int t(Rect rect, float f2) {
        return P() ? (int) (((float) rect.centerY()) - (f2 / 2.0f)) : rect.top + this.f1512a.getCompoundPaddingTop();
    }

    public final void t0() {
        if (this.g != 1) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f1513a.getLayoutParams();
            int v2 = v();
            if (v2 != layoutParams.topMargin) {
                layoutParams.topMargin = v2;
                this.f1513a.requestLayout();
            }
        }
    }

    public final Rect u(Rect rect) {
        if (this.f1512a != null) {
            Rect rect2 = this.f1524b;
            float u2 = this.f1517a.u();
            rect2.left = rect.left + this.f1512a.getCompoundPaddingLeft();
            rect2.top = t(rect, u2);
            rect2.right = rect.right - this.f1512a.getCompoundPaddingRight();
            rect2.bottom = s(rect, rect2, u2);
            return rect2;
        }
        throw new IllegalStateException();
    }

    public void u0(boolean z) {
        v0(z, false);
    }

    public final int v() {
        float o2;
        if (!this.f1548e) {
            return 0;
        }
        int i2 = this.g;
        if (i2 == 0 || i2 == 1) {
            o2 = this.f1517a.o();
        } else if (i2 != 2) {
            return 0;
        } else {
            o2 = this.f1517a.o() / 2.0f;
        }
        return (int) o2;
    }

    public final void v0(boolean z, boolean z2) {
        ColorStateList colorStateList;
        dc1 dc1;
        TextView textView;
        boolean isEnabled = isEnabled();
        EditText editText = this.f1512a;
        boolean z3 = editText != null && !TextUtils.isEmpty(editText.getText());
        EditText editText2 = this.f1512a;
        boolean z4 = editText2 != null && editText2.hasFocus();
        boolean k2 = this.f1502a.k();
        ColorStateList colorStateList2 = this.f1551g;
        if (colorStateList2 != null) {
            this.f1517a.K(colorStateList2);
            this.f1517a.R(this.f1551g);
        }
        if (!isEnabled) {
            ColorStateList colorStateList3 = this.f1551g;
            int colorForState = colorStateList3 != null ? colorStateList3.getColorForState(new int[]{-16842910}, this.x) : this.x;
            this.f1517a.K(ColorStateList.valueOf(colorForState));
            this.f1517a.R(ColorStateList.valueOf(colorForState));
        } else if (k2) {
            this.f1517a.K(this.f1502a.p());
        } else {
            if (this.f1541c && (textView = this.f1515a) != null) {
                dc1 = this.f1517a;
                colorStateList = textView.getTextColors();
            } else if (z4 && (colorStateList = this.f1553h) != null) {
                dc1 = this.f1517a;
            }
            dc1.K(colorStateList);
        }
        if (z3 || !this.f1559l || (isEnabled() && z4)) {
            if (z2 || this.f1558k) {
                z(z);
            }
        } else if (z2 || !this.f1558k) {
            F(z);
        }
    }

    public final boolean w() {
        return this.g == 2 && x();
    }

    public final void w0() {
        EditText editText;
        if (this.f1529b != null && (editText = this.f1512a) != null) {
            this.f1529b.setGravity(editText.getGravity());
            this.f1529b.setPadding(this.f1512a.getCompoundPaddingLeft(), this.f1512a.getCompoundPaddingTop(), this.f1512a.getCompoundPaddingRight(), this.f1512a.getCompoundPaddingBottom());
        }
    }

    public final boolean x() {
        return this.i > -1 && this.l != 0;
    }

    public final void x0() {
        EditText editText = this.f1512a;
        y0(editText == null ? 0 : editText.getText().length());
    }

    public final void y() {
        if (A()) {
            ((xd1) this.f1518a).l0();
        }
    }

    public final void y0(int i2) {
        if (i2 != 0 || this.f1558k) {
            J();
        } else {
            i0();
        }
    }

    public final void z(boolean z) {
        ValueAnimator valueAnimator = this.f1503a;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.f1503a.cancel();
        }
        if (!z || !this.f1560m) {
            this.f1517a.V(1.0f);
        } else {
            i(1.0f);
        }
        this.f1558k = false;
        if (A()) {
            T();
        }
        x0();
        A0();
        D0();
    }

    public final void z0() {
        if (this.f1512a != null) {
            ya.A0(this.f1538c, Q() ? 0 : ya.I(this.f1512a), this.f1512a.getCompoundPaddingTop(), getContext().getResources().getDimensionPixelSize(q91.material_input_text_to_prefix_suffix_padding), this.f1512a.getCompoundPaddingBottom());
        }
    }
}
