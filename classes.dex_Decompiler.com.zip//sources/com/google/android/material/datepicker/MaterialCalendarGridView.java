package com.google.android.material.datepicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.ListAdapter;
import java.util.Calendar;

public final class MaterialCalendarGridView extends GridView {
    public final Calendar a;
    public final boolean b;

    public class a extends da {
        public a() {
        }

        public void g(View view, jb jbVar) {
            super.g(view, jbVar);
            jbVar.Y((Object) null);
        }
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = tb1.k();
        if (jb1.k2(getContext())) {
            setNextFocusLeftId(s91.cancel_button);
            setNextFocusRightId(s91.confirm_button);
        }
        this.b = jb1.l2(getContext());
        ya.o0(this, new a());
    }

    public static int c(View view) {
        return view.getLeft() + (view.getWidth() / 2);
    }

    public static boolean d(Long l, Long l2, Long l3, Long l4) {
        return l == null || l2 == null || l3 == null || l4 == null || l3.longValue() > l2.longValue() || l4.longValue() < l.longValue();
    }

    public final void a(int i, Rect rect) {
        int b2;
        if (i == 33) {
            b2 = getAdapter().i();
        } else if (i == 130) {
            b2 = getAdapter().b();
        } else {
            super.onFocusChanged(true, i, rect);
            return;
        }
        setSelection(b2);
    }

    /* renamed from: b */
    public nb1 getAdapter() {
        return (nb1) super.getAdapter();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getAdapter().notifyDataSetChanged();
    }

    public final void onDraw(Canvas canvas) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        MaterialCalendarGridView materialCalendarGridView = this;
        super.onDraw(canvas);
        nb1 b2 = getAdapter();
        eb1<?> eb1 = b2.f4124a;
        db1 db1 = b2.f4123a;
        Long c = b2.getItem(b2.b());
        Long c2 = b2.getItem(b2.i());
        for (y9 next : eb1.K()) {
            F f = next.a;
            if (f != null) {
                if (next.b != null) {
                    long longValue = ((Long) f).longValue();
                    long longValue2 = ((Long) next.b).longValue();
                    if (!d(c, c2, Long.valueOf(longValue), Long.valueOf(longValue2))) {
                        boolean d = nc1.d(this);
                        if (longValue < c.longValue()) {
                            i2 = b2.b();
                            if (b2.f(i2)) {
                                i = 0;
                            } else {
                                View childAt = materialCalendarGridView.getChildAt(i2 - 1);
                                i = !d ? childAt.getRight() : childAt.getLeft();
                            }
                        } else {
                            materialCalendarGridView.a.setTimeInMillis(longValue);
                            i2 = b2.a(materialCalendarGridView.a.get(5));
                            i = c(materialCalendarGridView.getChildAt(i2));
                        }
                        if (longValue2 > c2.longValue()) {
                            i4 = Math.min(b2.i(), getChildCount() - 1);
                            if (b2.g(i4)) {
                                i3 = getWidth();
                            } else {
                                View childAt2 = materialCalendarGridView.getChildAt(i4);
                                i3 = !d ? childAt2.getRight() : childAt2.getLeft();
                            }
                        } else {
                            materialCalendarGridView.a.setTimeInMillis(longValue2);
                            i4 = b2.a(materialCalendarGridView.a.get(5));
                            i3 = c(materialCalendarGridView.getChildAt(i4));
                        }
                        int itemId = (int) b2.getItemId(i2);
                        int itemId2 = (int) b2.getItemId(i4);
                        while (itemId <= itemId2) {
                            int numColumns = getNumColumns() * itemId;
                            int numColumns2 = (getNumColumns() + numColumns) - 1;
                            View childAt3 = materialCalendarGridView.getChildAt(numColumns);
                            int top = childAt3.getTop() + db1.f1958a.c();
                            int bottom = childAt3.getBottom() - db1.f1958a.b();
                            if (!d) {
                                i6 = numColumns > i2 ? 0 : i;
                                i5 = i4 > numColumns2 ? getWidth() : i3;
                            } else {
                                int i7 = i4 > numColumns2 ? 0 : i3;
                                i5 = numColumns > i2 ? getWidth() : i;
                                i6 = i7;
                            }
                            canvas.drawRect((float) i6, (float) top, (float) i5, (float) bottom, db1.a);
                            itemId++;
                            materialCalendarGridView = this;
                            b2 = b2;
                        }
                    }
                }
            }
            materialCalendarGridView = this;
        }
    }

    public void onFocusChanged(boolean z, int i, Rect rect) {
        if (z) {
            a(i, rect);
        } else {
            super.onFocusChanged(false, i, rect);
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (!super.onKeyDown(i, keyEvent)) {
            return false;
        }
        if (getSelectedItemPosition() == -1 || getSelectedItemPosition() >= getAdapter().b()) {
            return true;
        }
        if (19 != i) {
            return false;
        }
        setSelection(getAdapter().b());
        return true;
    }

    public void onMeasure(int i, int i2) {
        if (this.b) {
            super.onMeasure(i, View.MeasureSpec.makeMeasureSpec(16777215, Integer.MIN_VALUE));
            getLayoutParams().height = getMeasuredHeight();
            return;
        }
        super.onMeasure(i, i2);
    }

    public final void setAdapter(ListAdapter listAdapter) {
        if (listAdapter instanceof nb1) {
            super.setAdapter(listAdapter);
        } else {
            throw new IllegalArgumentException(String.format("%1$s must have its Adapter set to a %2$s", new Object[]{MaterialCalendarGridView.class.getCanonicalName(), nb1.class.getCanonicalName()}));
        }
    }

    public void setSelection(int i) {
        if (i < getAdapter().b()) {
            i = getAdapter().b();
        }
        super.setSelection(i);
    }
}
