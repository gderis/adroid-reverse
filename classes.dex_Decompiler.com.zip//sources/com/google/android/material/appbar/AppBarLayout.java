package com.google.android.material.appbar;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import defpackage.jb;
import defpackage.mb;
import java.lang.ref.WeakReference;
import java.util.List;

public class AppBarLayout extends LinearLayout implements CoordinatorLayout.b {
    public static final int a = w91.Widget_Design_AppBarLayout;

    /* renamed from: a  reason: collision with other field name */
    public ValueAnimator f1354a;

    /* renamed from: a  reason: collision with other field name */
    public Drawable f1355a;

    /* renamed from: a  reason: collision with other field name */
    public gb f1356a;

    /* renamed from: a  reason: collision with other field name */
    public WeakReference<View> f1357a;

    /* renamed from: a  reason: collision with other field name */
    public List<b> f1358a;

    /* renamed from: a  reason: collision with other field name */
    public int[] f1359a;
    public int b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1360b;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1361c;
    public int d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f1362d;
    public int e;

    /* renamed from: e  reason: collision with other field name */
    public boolean f1363e;
    public int f;

    /* renamed from: f  reason: collision with other field name */
    public boolean f1364f;
    public int g;

    public static class BaseBehavior<T extends AppBarLayout> extends ja1<T> {
        public float a;

        /* renamed from: a  reason: collision with other field name */
        public ValueAnimator f1365a;

        /* renamed from: a  reason: collision with other field name */
        public d f1366a;

        /* renamed from: a  reason: collision with other field name */
        public WeakReference<View> f1367a;
        public boolean b;
        public int f;
        public int g;
        public int h = -1;

        public class a implements ValueAnimator.AnimatorUpdateListener {
            public final /* synthetic */ CoordinatorLayout a;

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ AppBarLayout f1369a;

            public a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
                this.a = coordinatorLayout;
                this.f1369a = appBarLayout;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                BaseBehavior.this.P(this.a, this.f1369a, ((Integer) valueAnimator.getAnimatedValue()).intValue());
            }
        }

        public class b implements mb {
            public final /* synthetic */ int a;

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ View f1370a;

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ CoordinatorLayout f1371a;

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ AppBarLayout f1373a;

            public b(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i) {
                this.f1371a = coordinatorLayout;
                this.f1373a = appBarLayout;
                this.f1370a = view;
                this.a = i;
            }

            public boolean a(View view, mb.a aVar) {
                BaseBehavior.this.q(this.f1371a, this.f1373a, this.f1370a, 0, this.a, new int[]{0, 0}, 1);
                return true;
            }
        }

        public class c implements mb {

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ AppBarLayout f1374a;

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ boolean f1375a;

            public c(AppBarLayout appBarLayout, boolean z) {
                this.f1374a = appBarLayout;
                this.f1375a = z;
            }

            public boolean a(View view, mb.a aVar) {
                this.f1374a.setExpanded(this.f1375a);
                return true;
            }
        }

        public static abstract class d<T extends AppBarLayout> {
        }

        public static class e extends gc {
            public static final Parcelable.Creator<e> CREATOR = new a();
            public float a;

            /* renamed from: a  reason: collision with other field name */
            public int f1376a;
            public boolean b;

            public static class a implements Parcelable.ClassLoaderCreator<e> {
                /* renamed from: a */
                public e createFromParcel(Parcel parcel) {
                    return new e(parcel, (ClassLoader) null);
                }

                /* renamed from: b */
                public e createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return new e(parcel, classLoader);
                }

                /* renamed from: c */
                public e[] newArray(int i) {
                    return new e[i];
                }
            }

            public e(Parcel parcel, ClassLoader classLoader) {
                super(parcel, classLoader);
                this.f1376a = parcel.readInt();
                this.a = parcel.readFloat();
                this.b = parcel.readByte() != 0;
            }

            public e(Parcelable parcelable) {
                super(parcelable);
            }

            public void writeToParcel(Parcel parcel, int i) {
                super.writeToParcel(parcel, i);
                parcel.writeInt(this.f1376a);
                parcel.writeFloat(this.a);
                parcel.writeByte(this.b ? (byte) 1 : 0);
            }
        }

        public BaseBehavior() {
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public static boolean Y(int i, int i2) {
            return (i & i2) == i2;
        }

        public static View a0(AppBarLayout appBarLayout, int i) {
            int abs = Math.abs(i);
            int childCount = appBarLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = appBarLayout.getChildAt(i2);
                if (abs >= childAt.getTop() && abs <= childAt.getBottom()) {
                    return childAt;
                }
            }
            return null;
        }

        public int M() {
            return E() + this.f;
        }

        public final void S(CoordinatorLayout coordinatorLayout, T t, View view) {
            if (M() != (-t.getTotalScrollRange()) && view.canScrollVertically(1)) {
                T(coordinatorLayout, t, jb.a.m, false);
            }
            if (M() == 0) {
                return;
            }
            if (view.canScrollVertically(-1)) {
                int i = -t.getDownNestedPreScrollRange();
                if (i != 0) {
                    ya.k0(coordinatorLayout, jb.a.n, (CharSequence) null, new b(coordinatorLayout, t, view, i));
                    return;
                }
                return;
            }
            T(coordinatorLayout, t, jb.a.n, true);
        }

        public final void T(CoordinatorLayout coordinatorLayout, T t, jb.a aVar, boolean z) {
            ya.k0(coordinatorLayout, aVar, (CharSequence) null, new c(t, z));
        }

        public final void U(CoordinatorLayout coordinatorLayout, T t, int i, float f2) {
            int abs = Math.abs(M() - i);
            float abs2 = Math.abs(f2);
            V(coordinatorLayout, t, i, abs2 > 0.0f ? Math.round((((float) abs) / abs2) * 1000.0f) * 3 : (int) (((((float) abs) / ((float) t.getHeight())) + 1.0f) * 150.0f));
        }

        public final void V(CoordinatorLayout coordinatorLayout, T t, int i, int i2) {
            int M = M();
            if (M == i) {
                ValueAnimator valueAnimator = this.f1365a;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.f1365a.cancel();
                    return;
                }
                return;
            }
            ValueAnimator valueAnimator2 = this.f1365a;
            if (valueAnimator2 == null) {
                ValueAnimator valueAnimator3 = new ValueAnimator();
                this.f1365a = valueAnimator3;
                valueAnimator3.setInterpolator(y91.e);
                this.f1365a.addUpdateListener(new a(coordinatorLayout, t));
            } else {
                valueAnimator2.cancel();
            }
            this.f1365a.setDuration((long) Math.min(i2, 600));
            this.f1365a.setIntValues(new int[]{M, i});
            this.f1365a.start();
        }

        /* renamed from: W */
        public boolean H(T t) {
            if (this.f1366a == null) {
                WeakReference<View> weakReference = this.f1367a;
                if (weakReference == null) {
                    return true;
                }
                View view = (View) weakReference.get();
                return view != null && view.isShown() && !view.canScrollVertically(-1);
            }
            throw null;
        }

        public final boolean X(CoordinatorLayout coordinatorLayout, T t, View view) {
            return t.h() && coordinatorLayout.getHeight() - view.getHeight() <= t.getHeight();
        }

        public final View Z(CoordinatorLayout coordinatorLayout) {
            int childCount = coordinatorLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = coordinatorLayout.getChildAt(i);
                if ((childAt instanceof na) || (childAt instanceof ListView) || (childAt instanceof ScrollView)) {
                    return childAt;
                }
            }
            return null;
        }

        public final int b0(T t, int i) {
            int childCount = t.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = t.getChildAt(i2);
                int top = childAt.getTop();
                int bottom = childAt.getBottom();
                c cVar = (c) childAt.getLayoutParams();
                if (Y(cVar.a(), 32)) {
                    top -= cVar.topMargin;
                    bottom += cVar.bottomMargin;
                }
                int i3 = -i;
                if (top <= i3 && bottom >= i3) {
                    return i2;
                }
            }
            return -1;
        }

        /* renamed from: c0 */
        public int K(T t) {
            return -t.getDownNestedScrollRange();
        }

        /* renamed from: d0 */
        public int L(T t) {
            return t.getTotalScrollRange();
        }

        public final int e0(T t, int i) {
            int abs = Math.abs(i);
            int childCount = t.getChildCount();
            int i2 = 0;
            int i3 = 0;
            while (true) {
                if (i3 >= childCount) {
                    break;
                }
                View childAt = t.getChildAt(i3);
                c cVar = (c) childAt.getLayoutParams();
                Interpolator b2 = cVar.b();
                if (abs < childAt.getTop() || abs > childAt.getBottom()) {
                    i3++;
                } else if (b2 != null) {
                    int a2 = cVar.a();
                    if ((a2 & 1) != 0) {
                        i2 = 0 + childAt.getHeight() + cVar.topMargin + cVar.bottomMargin;
                        if ((a2 & 2) != 0) {
                            i2 -= ya.D(childAt);
                        }
                    }
                    if (ya.z(childAt)) {
                        i2 -= t.getTopInset();
                    }
                    if (i2 > 0) {
                        float f2 = (float) i2;
                        return Integer.signum(i) * (childAt.getTop() + Math.round(f2 * b2.getInterpolation(((float) (abs - childAt.getTop())) / f2)));
                    }
                }
            }
            return i;
        }

        /* renamed from: f0 */
        public void N(CoordinatorLayout coordinatorLayout, T t) {
            q0(coordinatorLayout, t);
            if (t.j()) {
                t.p(t.r(Z(coordinatorLayout)));
            }
        }

        /* renamed from: g0 */
        public boolean l(CoordinatorLayout coordinatorLayout, T t, int i) {
            boolean l = super.l(coordinatorLayout, t, i);
            int pendingAction = t.getPendingAction();
            int i2 = this.h;
            if (i2 >= 0 && (pendingAction & 8) == 0) {
                View childAt = t.getChildAt(i2);
                P(coordinatorLayout, t, (-childAt.getBottom()) + (this.b ? ya.D(childAt) + t.getTopInset() : Math.round(((float) childAt.getHeight()) * this.a)));
            } else if (pendingAction != 0) {
                boolean z = (pendingAction & 4) != 0;
                if ((pendingAction & 2) != 0) {
                    int i3 = -t.getUpNestedPreScrollRange();
                    if (z) {
                        U(coordinatorLayout, t, i3, 0.0f);
                    } else {
                        P(coordinatorLayout, t, i3);
                    }
                } else if ((pendingAction & 1) != 0) {
                    if (z) {
                        U(coordinatorLayout, t, 0, 0.0f);
                    } else {
                        P(coordinatorLayout, t, 0);
                    }
                }
            }
            t.l();
            this.h = -1;
            G(w8.b(E(), -t.getTotalScrollRange(), 0));
            s0(coordinatorLayout, t, E(), 0, true);
            t.k(E());
            r0(coordinatorLayout, t);
            return l;
        }

        /* renamed from: h0 */
        public boolean m(CoordinatorLayout coordinatorLayout, T t, int i, int i2, int i3, int i4) {
            if (((CoordinatorLayout.f) t.getLayoutParams()).height != -2) {
                return super.m(coordinatorLayout, t, i, i2, i3, i4);
            }
            coordinatorLayout.J(t, i, i2, View.MeasureSpec.makeMeasureSpec(0, 0), i4);
            return true;
        }

        /* renamed from: i0 */
        public void q(CoordinatorLayout coordinatorLayout, T t, View view, int i, int i2, int[] iArr, int i3) {
            int i4;
            int i5;
            if (i2 != 0) {
                if (i2 < 0) {
                    int i6 = -t.getTotalScrollRange();
                    i5 = i6;
                    i4 = t.getDownNestedPreScrollRange() + i6;
                } else {
                    i5 = -t.getUpNestedPreScrollRange();
                    i4 = 0;
                }
                if (i5 != i4) {
                    iArr[1] = O(coordinatorLayout, t, i2, i5, i4);
                }
            }
            if (t.j()) {
                t.p(t.r(view));
            }
        }

        /* renamed from: j0 */
        public void t(CoordinatorLayout coordinatorLayout, T t, View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
            if (i4 < 0) {
                iArr[1] = O(coordinatorLayout, t, i4, -t.getDownNestedScrollRange(), 0);
            }
            if (i4 == 0) {
                r0(coordinatorLayout, t);
            }
        }

        /* renamed from: k0 */
        public void x(CoordinatorLayout coordinatorLayout, T t, Parcelable parcelable) {
            if (parcelable instanceof e) {
                e eVar = (e) parcelable;
                super.x(coordinatorLayout, t, eVar.a());
                this.h = eVar.f1376a;
                this.a = eVar.a;
                this.b = eVar.b;
                return;
            }
            super.x(coordinatorLayout, t, parcelable);
            this.h = -1;
        }

        /* renamed from: l0 */
        public Parcelable y(CoordinatorLayout coordinatorLayout, T t) {
            Parcelable y = super.y(coordinatorLayout, t);
            int E = E();
            int childCount = t.getChildCount();
            boolean z = false;
            int i = 0;
            while (i < childCount) {
                View childAt = t.getChildAt(i);
                int bottom = childAt.getBottom() + E;
                if (childAt.getTop() + E > 0 || bottom < 0) {
                    i++;
                } else {
                    e eVar = new e(y);
                    eVar.f1376a = i;
                    if (bottom == ya.D(childAt) + t.getTopInset()) {
                        z = true;
                    }
                    eVar.b = z;
                    eVar.a = ((float) bottom) / ((float) childAt.getHeight());
                    return eVar;
                }
            }
            return y;
        }

        /* renamed from: m0 */
        public boolean A(CoordinatorLayout coordinatorLayout, T t, View view, View view2, int i, int i2) {
            ValueAnimator valueAnimator;
            boolean z = (i & 2) != 0 && (t.j() || X(coordinatorLayout, t, view));
            if (z && (valueAnimator = this.f1365a) != null) {
                valueAnimator.cancel();
            }
            this.f1367a = null;
            this.g = i2;
            return z;
        }

        /* renamed from: n0 */
        public void C(CoordinatorLayout coordinatorLayout, T t, View view, int i) {
            if (this.g == 0 || i == 1) {
                q0(coordinatorLayout, t);
                if (t.j()) {
                    t.p(t.r(view));
                }
            }
            this.f1367a = new WeakReference<>(view);
        }

        /* renamed from: o0 */
        public int Q(CoordinatorLayout coordinatorLayout, T t, int i, int i2, int i3) {
            int M = M();
            int i4 = 0;
            if (i2 == 0 || M < i2 || M > i3) {
                this.f = 0;
            } else {
                int b2 = w8.b(i, i2, i3);
                if (M != b2) {
                    int e0 = t.f() ? e0(t, b2) : b2;
                    boolean G = G(e0);
                    i4 = M - b2;
                    this.f = b2 - e0;
                    if (!G && t.f()) {
                        coordinatorLayout.f(t);
                    }
                    t.k(E());
                    s0(coordinatorLayout, t, b2, b2 < M ? -1 : 1, false);
                }
            }
            r0(coordinatorLayout, t);
            return i4;
        }

        public final boolean p0(CoordinatorLayout coordinatorLayout, T t) {
            List<View> s = coordinatorLayout.s(t);
            int size = s.size();
            for (int i = 0; i < size; i++) {
                CoordinatorLayout.c f2 = ((CoordinatorLayout.f) s.get(i).getLayoutParams()).f();
                if (f2 instanceof ScrollingViewBehavior) {
                    return ((ScrollingViewBehavior) f2).K() != 0;
                }
            }
            return false;
        }

        public final void q0(CoordinatorLayout coordinatorLayout, T t) {
            int M = M();
            int b0 = b0(t, M);
            if (b0 >= 0) {
                View childAt = t.getChildAt(b0);
                c cVar = (c) childAt.getLayoutParams();
                int a2 = cVar.a();
                if ((a2 & 17) == 17) {
                    int i = -childAt.getTop();
                    int i2 = -childAt.getBottom();
                    if (b0 == t.getChildCount() - 1) {
                        i2 += t.getTopInset();
                    }
                    if (Y(a2, 2)) {
                        i2 += ya.D(childAt);
                    } else if (Y(a2, 5)) {
                        int D = ya.D(childAt) + i2;
                        if (M < D) {
                            i = D;
                        } else {
                            i2 = D;
                        }
                    }
                    if (Y(a2, 32)) {
                        i += cVar.topMargin;
                        i2 -= cVar.bottomMargin;
                    }
                    if (M < (i2 + i) / 2) {
                        i = i2;
                    }
                    U(coordinatorLayout, t, w8.b(i, -t.getTotalScrollRange(), 0), 0.0f);
                }
            }
        }

        public final void r0(CoordinatorLayout coordinatorLayout, T t) {
            ya.i0(coordinatorLayout, jb.a.m.b());
            ya.i0(coordinatorLayout, jb.a.n.b());
            View Z = Z(coordinatorLayout);
            if (Z != null && t.getTotalScrollRange() != 0 && (((CoordinatorLayout.f) Z.getLayoutParams()).f() instanceof ScrollingViewBehavior)) {
                S(coordinatorLayout, t, Z);
            }
        }

        public final void s0(CoordinatorLayout coordinatorLayout, T t, int i, int i2, boolean z) {
            View a0 = a0(t, i);
            if (a0 != null) {
                int a2 = ((c) a0.getLayoutParams()).a();
                boolean z2 = false;
                if ((a2 & 1) != 0) {
                    int D = ya.D(a0);
                    if (i2 <= 0 || (a2 & 12) == 0 ? !((a2 & 2) == 0 || (-i) < (a0.getBottom() - D) - t.getTopInset()) : (-i) >= (a0.getBottom() - D) - t.getTopInset()) {
                        z2 = true;
                    }
                }
                if (t.j()) {
                    z2 = t.r(Z(coordinatorLayout));
                }
                boolean p = t.p(z2);
                if (z || (p && p0(coordinatorLayout, t))) {
                    t.jumpDrawablesToCurrentState();
                }
            }
        }
    }

    public static class Behavior extends BaseBehavior<AppBarLayout> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public /* bridge */ /* synthetic */ int E() {
            return super.E();
        }

        public /* bridge */ /* synthetic */ boolean G(int i) {
            return super.G(i);
        }

        public /* bridge */ /* synthetic */ boolean g0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i) {
            return super.l(coordinatorLayout, appBarLayout, i);
        }

        public /* bridge */ /* synthetic */ boolean h0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, int i2, int i3, int i4) {
            return super.m(coordinatorLayout, appBarLayout, i, i2, i3, i4);
        }

        public /* bridge */ /* synthetic */ void i0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int i2, int[] iArr, int i3) {
            super.q(coordinatorLayout, appBarLayout, view, i, i2, iArr, i3);
        }

        public /* bridge */ /* synthetic */ void j0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
            super.t(coordinatorLayout, appBarLayout, view, i, i2, i3, i4, i5, iArr);
        }

        public /* bridge */ /* synthetic */ void k0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Parcelable parcelable) {
            super.x(coordinatorLayout, appBarLayout, parcelable);
        }

        public /* bridge */ /* synthetic */ Parcelable l0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            return super.y(coordinatorLayout, appBarLayout);
        }

        public /* bridge */ /* synthetic */ boolean m0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, View view2, int i, int i2) {
            return super.A(coordinatorLayout, appBarLayout, view, view2, i, i2);
        }

        public /* bridge */ /* synthetic */ void n0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i) {
            super.C(coordinatorLayout, appBarLayout, view, i);
        }
    }

    public static class ScrollingViewBehavior extends ka1 {
        public ScrollingViewBehavior() {
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.ScrollingViewBehavior_Layout);
            O(obtainStyledAttributes.getDimensionPixelSize(x91.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
            obtainStyledAttributes.recycle();
        }

        public static int R(AppBarLayout appBarLayout) {
            CoordinatorLayout.c f = ((CoordinatorLayout.f) appBarLayout.getLayoutParams()).f();
            if (f instanceof BaseBehavior) {
                return ((BaseBehavior) f).M();
            }
            return 0;
        }

        public float J(View view) {
            int i;
            if (view instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view;
                int totalScrollRange = appBarLayout.getTotalScrollRange();
                int downNestedPreScrollRange = appBarLayout.getDownNestedPreScrollRange();
                int R = R(appBarLayout);
                if ((downNestedPreScrollRange == 0 || totalScrollRange + R > downNestedPreScrollRange) && (i = totalScrollRange - downNestedPreScrollRange) != 0) {
                    return (((float) R) / ((float) i)) + 1.0f;
                }
            }
            return 0.0f;
        }

        public int L(View view) {
            return view instanceof AppBarLayout ? ((AppBarLayout) view).getTotalScrollRange() : super.L(view);
        }

        /* renamed from: Q */
        public AppBarLayout H(List<View> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                View view = list.get(i);
                if (view instanceof AppBarLayout) {
                    return (AppBarLayout) view;
                }
            }
            return null;
        }

        public final void S(View view, View view2) {
            CoordinatorLayout.c f = ((CoordinatorLayout.f) view2.getLayoutParams()).f();
            if (f instanceof BaseBehavior) {
                ya.Z(view, (((view2.getBottom() - view.getTop()) + ((BaseBehavior) f).f) + M()) - I(view2));
            }
        }

        public final void T(View view, View view2) {
            if (view2 instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view2;
                if (appBarLayout.j()) {
                    appBarLayout.p(appBarLayout.r(view));
                }
            }
        }

        public boolean e(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return view2 instanceof AppBarLayout;
        }

        public boolean h(CoordinatorLayout coordinatorLayout, View view, View view2) {
            S(view, view2);
            T(view, view2);
            return false;
        }

        public void i(CoordinatorLayout coordinatorLayout, View view, View view2) {
            if (view2 instanceof AppBarLayout) {
                ya.i0(coordinatorLayout, jb.a.m.b());
                ya.i0(coordinatorLayout, jb.a.n.b());
            }
        }

        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, View view, int i) {
            return super.l(coordinatorLayout, view, i);
        }

        public /* bridge */ /* synthetic */ boolean m(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            return super.m(coordinatorLayout, view, i, i2, i3, i4);
        }

        public boolean w(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z) {
            AppBarLayout Q = H(coordinatorLayout.r(view));
            if (Q != null) {
                rect.offset(view.getLeft(), view.getTop());
                Rect rect2 = this.a;
                rect2.set(0, 0, coordinatorLayout.getWidth(), coordinatorLayout.getHeight());
                if (!rect2.contains(rect)) {
                    Q.m(false, !z);
                    return true;
                }
            }
            return false;
        }
    }

    public class a implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ hd1 f1377a;

        public a(hd1 hd1) {
            this.f1377a = hd1;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.f1377a.V(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    public interface b<T extends AppBarLayout> {
        void a(T t, int i);
    }

    public static class c extends LinearLayout.LayoutParams {
        public int a = 1;

        /* renamed from: a  reason: collision with other field name */
        public Interpolator f1378a;

        public c(int i, int i2) {
            super(i, i2);
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.AppBarLayout_Layout);
            this.a = obtainStyledAttributes.getInt(x91.AppBarLayout_Layout_layout_scrollFlags, 0);
            int i = x91.AppBarLayout_Layout_layout_scrollInterpolator;
            if (obtainStyledAttributes.hasValue(i)) {
                this.f1378a = AnimationUtils.loadInterpolator(context, obtainStyledAttributes.getResourceId(i, 0));
            }
            obtainStyledAttributes.recycle();
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public c(LinearLayout.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public int a() {
            return this.a;
        }

        public Interpolator b() {
            return this.f1378a;
        }

        public boolean c() {
            int i = this.a;
            return (i & 1) == 1 && (i & 10) != 0;
        }
    }

    public final void a() {
        WeakReference<View> weakReference = this.f1357a;
        if (weakReference != null) {
            weakReference.clear();
        }
        this.f1357a = null;
    }

    public final View b(View view) {
        int i;
        if (this.f1357a == null && (i = this.g) != -1) {
            View findViewById = view != null ? view.findViewById(i) : null;
            if (findViewById == null && (getParent() instanceof ViewGroup)) {
                findViewById = ((ViewGroup) getParent()).findViewById(this.g);
            }
            if (findViewById != null) {
                this.f1357a = new WeakReference<>(findViewById);
            }
        }
        WeakReference<View> weakReference = this.f1357a;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    /* renamed from: c */
    public c generateDefaultLayoutParams() {
        return new c(-1, -2);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof c;
    }

    /* renamed from: d */
    public c generateLayoutParams(AttributeSet attributeSet) {
        return new c(getContext(), attributeSet);
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (q()) {
            int save = canvas.save();
            canvas.translate(0.0f, (float) (-this.b));
            this.f1355a.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f1355a;
        if (drawable != null && drawable.isStateful() && drawable.setState(drawableState)) {
            invalidateDrawable(drawable);
        }
    }

    /* renamed from: e */
    public c generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (Build.VERSION.SDK_INT < 19 || !(layoutParams instanceof LinearLayout.LayoutParams)) ? layoutParams instanceof ViewGroup.MarginLayoutParams ? new c((ViewGroup.MarginLayoutParams) layoutParams) : new c(layoutParams) : new c((LinearLayout.LayoutParams) layoutParams);
    }

    public boolean f() {
        return this.f1360b;
    }

    public final boolean g() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            if (((c) getChildAt(i).getLayoutParams()).c()) {
                return true;
            }
        }
        return false;
    }

    public CoordinatorLayout.c<AppBarLayout> getBehavior() {
        return new Behavior();
    }

    public int getDownNestedPreScrollRange() {
        int i;
        int D;
        int i2 = this.d;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            c cVar = (c) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = cVar.a;
            if ((i4 & 5) == 5) {
                int i5 = cVar.topMargin + cVar.bottomMargin;
                if ((i4 & 8) != 0) {
                    D = ya.D(childAt);
                } else if ((i4 & 2) != 0) {
                    D = measuredHeight - ya.D(childAt);
                } else {
                    i = i5 + measuredHeight;
                    if (childCount == 0 && ya.z(childAt)) {
                        i = Math.min(i, measuredHeight - getTopInset());
                    }
                    i3 += i;
                }
                i = i5 + D;
                i = Math.min(i, measuredHeight - getTopInset());
                i3 += i;
            } else if (i3 > 0) {
                break;
            }
        }
        int max = Math.max(0, i3);
        this.d = max;
        return max;
    }

    public int getDownNestedScrollRange() {
        int i = this.e;
        if (i != -1) {
            return i;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            c cVar = (c) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + cVar.topMargin + cVar.bottomMargin;
            int i4 = cVar.a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += measuredHeight;
            if ((i4 & 2) != 0) {
                i3 -= ya.D(childAt);
                break;
            }
            i2++;
        }
        int max = Math.max(0, i3);
        this.e = max;
        return max;
    }

    public int getLiftOnScrollTargetViewId() {
        return this.g;
    }

    public final int getMinimumHeightForVisibleOverlappingContent() {
        int topInset = getTopInset();
        int D = ya.D(this);
        if (D == 0) {
            int childCount = getChildCount();
            D = childCount >= 1 ? ya.D(getChildAt(childCount - 1)) : 0;
            if (D == 0) {
                return getHeight() / 3;
            }
        }
        return (D * 2) + topInset;
    }

    public int getPendingAction() {
        return this.f;
    }

    public Drawable getStatusBarForeground() {
        return this.f1355a;
    }

    @Deprecated
    public float getTargetElevation() {
        return 0.0f;
    }

    public final int getTopInset() {
        gb gbVar = this.f1356a;
        if (gbVar != null) {
            return gbVar.i();
        }
        return 0;
    }

    public final int getTotalScrollRange() {
        int i = this.c;
        if (i != -1) {
            return i;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            c cVar = (c) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = cVar.a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += measuredHeight + cVar.topMargin + cVar.bottomMargin;
            if (i2 == 0 && ya.z(childAt)) {
                i3 -= getTopInset();
            }
            if ((i4 & 2) != 0) {
                i3 -= ya.D(childAt);
                break;
            }
            i2++;
        }
        int max = Math.max(0, i3);
        this.c = max;
        return max;
    }

    public int getUpNestedPreScrollRange() {
        return getTotalScrollRange();
    }

    public boolean h() {
        return getTotalScrollRange() != 0;
    }

    public final void i() {
        this.c = -1;
        this.d = -1;
        this.e = -1;
    }

    public boolean j() {
        return this.f1364f;
    }

    public void k(int i) {
        this.b = i;
        if (!willNotDraw()) {
            ya.f0(this);
        }
        List<b> list = this.f1358a;
        if (list != null) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                b bVar = this.f1358a.get(i2);
                if (bVar != null) {
                    bVar.a(this, i);
                }
            }
        }
    }

    public void l() {
        this.f = 0;
    }

    public void m(boolean z, boolean z2) {
        n(z, z2, true);
    }

    public final void n(boolean z, boolean z2, boolean z3) {
        int i = 0;
        int i2 = (z ? 1 : 2) | (z2 ? 4 : 0);
        if (z3) {
            i = 8;
        }
        this.f = i2 | i;
        requestLayout();
    }

    public final boolean o(boolean z) {
        if (this.f1362d == z) {
            return false;
        }
        this.f1362d = z;
        refreshDrawableState();
        return true;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        id1.e(this);
    }

    public int[] onCreateDrawableState(int i) {
        if (this.f1359a == null) {
            this.f1359a = new int[4];
        }
        int[] iArr = this.f1359a;
        int[] onCreateDrawableState = super.onCreateDrawableState(i + iArr.length);
        boolean z = this.f1362d;
        int i2 = o91.state_liftable;
        if (!z) {
            i2 = -i2;
        }
        iArr[0] = i2;
        iArr[1] = (!z || !this.f1363e) ? -o91.state_lifted : o91.state_lifted;
        int i3 = o91.state_collapsible;
        if (!z) {
            i3 = -i3;
        }
        iArr[2] = i3;
        iArr[3] = (!z || !this.f1363e) ? -o91.state_collapsed : o91.state_collapsed;
        return LinearLayout.mergeDrawableStates(onCreateDrawableState, iArr);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        boolean z2 = true;
        if (ya.z(this) && s()) {
            int topInset = getTopInset();
            for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
                ya.Z(getChildAt(childCount), topInset);
            }
        }
        i();
        this.f1360b = false;
        int childCount2 = getChildCount();
        int i5 = 0;
        while (true) {
            if (i5 >= childCount2) {
                break;
            } else if (((c) getChildAt(i5).getLayoutParams()).b() != null) {
                this.f1360b = true;
                break;
            } else {
                i5++;
            }
        }
        Drawable drawable = this.f1355a;
        if (drawable != null) {
            drawable.setBounds(0, 0, getWidth(), getTopInset());
        }
        if (!this.f1361c) {
            if (!this.f1364f && !g()) {
                z2 = false;
            }
            o(z2);
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i2);
        if (mode != 1073741824 && ya.z(this) && s()) {
            int measuredHeight = getMeasuredHeight();
            if (mode == Integer.MIN_VALUE) {
                measuredHeight = w8.b(getMeasuredHeight() + getTopInset(), 0, View.MeasureSpec.getSize(i2));
            } else if (mode == 0) {
                measuredHeight += getTopInset();
            }
            setMeasuredDimension(getMeasuredWidth(), measuredHeight);
        }
        i();
    }

    public boolean p(boolean z) {
        if (this.f1363e == z) {
            return false;
        }
        this.f1363e = z;
        refreshDrawableState();
        if (!this.f1364f || !(getBackground() instanceof hd1)) {
            return true;
        }
        t((hd1) getBackground(), z);
        return true;
    }

    public final boolean q() {
        return this.f1355a != null && getTopInset() > 0;
    }

    public boolean r(View view) {
        View b2 = b(view);
        if (b2 != null) {
            view = b2;
        }
        return view != null && (view.canScrollVertically(-1) || view.getScrollY() > 0);
    }

    public final boolean s() {
        if (getChildCount() <= 0) {
            return false;
        }
        View childAt = getChildAt(0);
        return childAt.getVisibility() != 8 && !ya.z(childAt);
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        id1.d(this, f2);
    }

    public void setExpanded(boolean z) {
        m(z, ya.T(this));
    }

    public void setLiftOnScroll(boolean z) {
        this.f1364f = z;
    }

    public void setLiftOnScrollTargetViewId(int i) {
        this.g = i;
        a();
    }

    public void setOrientation(int i) {
        if (i == 1) {
            super.setOrientation(i);
            return;
        }
        throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
    }

    public void setStatusBarForeground(Drawable drawable) {
        Drawable drawable2 = this.f1355a;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f1355a = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.f1355a.setState(getDrawableState());
                }
                m8.m(this.f1355a, ya.C(this));
                this.f1355a.setVisible(getVisibility() == 0, false);
                this.f1355a.setCallback(this);
            }
            u();
            ya.f0(this);
        }
    }

    public void setStatusBarForegroundColor(int i) {
        setStatusBarForeground(new ColorDrawable(i));
    }

    public void setStatusBarForegroundResource(int i) {
        setStatusBarForeground(l0.d(getContext(), i));
    }

    @Deprecated
    public void setTargetElevation(float f2) {
        if (Build.VERSION.SDK_INT >= 21) {
            na1.a(this, f2);
        }
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f1355a;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
    }

    public final void t(hd1 hd1, boolean z) {
        float dimension = getResources().getDimension(q91.design_appbar_elevation);
        float f2 = z ? 0.0f : dimension;
        if (!z) {
            dimension = 0.0f;
        }
        ValueAnimator valueAnimator = this.f1354a;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{f2, dimension});
        this.f1354a = ofFloat;
        ofFloat.setDuration((long) getResources().getInteger(t91.app_bar_elevation_anim_duration));
        this.f1354a.setInterpolator(y91.a);
        this.f1354a.addUpdateListener(new a(hd1));
        this.f1354a.start();
    }

    public final void u() {
        setWillNotDraw(!q());
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1355a;
    }
}
