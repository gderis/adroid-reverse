package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;

public class MaterialComponentsViewInflater extends f0 {
    public y1 b(Context context, AttributeSet attributeSet) {
        return new be1(context, attributeSet);
    }

    public a2 c(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }

    public b2 d(Context context, AttributeSet attributeSet) {
        return new ta1(context, attributeSet);
    }

    public n2 j(Context context, AttributeSet attributeSet) {
        return new qc1(context, attributeSet);
    }

    public v2 n(Context context, AttributeSet attributeSet) {
        return new MaterialTextView(context, attributeSet);
    }
}
