package com.google.android.material.floatingactionbutton;

import android.animation.Animator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import defpackage.ac1;
import java.util.List;

public class FloatingActionButton extends oc1 implements xa, cc, yb1, od1, CoordinatorLayout.b {
    public static final int b = w91.Widget_Design_FloatingActionButton;
    public ac1 a;

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f1482a;

    /* renamed from: a  reason: collision with other field name */
    public PorterDuff.Mode f1483a;

    /* renamed from: a  reason: collision with other field name */
    public final Rect f1484a;

    /* renamed from: a  reason: collision with other field name */
    public final i2 f1485a;

    /* renamed from: b  reason: collision with other field name */
    public ColorStateList f1486b;

    /* renamed from: b  reason: collision with other field name */
    public PorterDuff.Mode f1487b;

    /* renamed from: b  reason: collision with other field name */
    public final Rect f1488b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1489b;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public ColorStateList f1490c;
    public int d;
    public int e;
    public int f;

    public static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.c<T> {
        public Rect a;

        /* renamed from: a  reason: collision with other field name */
        public b f1491a;

        /* renamed from: a  reason: collision with other field name */
        public boolean f1492a;

        public BaseBehavior() {
            this.f1492a = true;
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.FloatingActionButton_Behavior_Layout);
            this.f1492a = obtainStyledAttributes.getBoolean(x91.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
            obtainStyledAttributes.recycle();
        }

        public static boolean F(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.f) {
                return ((CoordinatorLayout.f) layoutParams).f() instanceof BottomSheetBehavior;
            }
            return false;
        }

        /* renamed from: E */
        public boolean b(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            Rect rect2 = floatingActionButton.f1484a;
            rect.set(floatingActionButton.getLeft() + rect2.left, floatingActionButton.getTop() + rect2.top, floatingActionButton.getRight() - rect2.right, floatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        public final void G(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton) {
            Rect rect = floatingActionButton.f1484a;
            if (rect != null && rect.centerX() > 0 && rect.centerY() > 0) {
                CoordinatorLayout.f fVar = (CoordinatorLayout.f) floatingActionButton.getLayoutParams();
                int i = 0;
                int i2 = floatingActionButton.getRight() >= coordinatorLayout.getWidth() - fVar.rightMargin ? rect.right : floatingActionButton.getLeft() <= fVar.leftMargin ? -rect.left : 0;
                if (floatingActionButton.getBottom() >= coordinatorLayout.getHeight() - fVar.bottomMargin) {
                    i = rect.bottom;
                } else if (floatingActionButton.getTop() <= fVar.topMargin) {
                    i = -rect.top;
                }
                if (i != 0) {
                    ya.Z(floatingActionButton, i);
                }
                if (i2 != 0) {
                    ya.Y(floatingActionButton, i2);
                }
            }
        }

        /* renamed from: H */
        public boolean h(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                K(coordinatorLayout, (AppBarLayout) view, floatingActionButton);
                return false;
            } else if (!F(view)) {
                return false;
            } else {
                L(view, floatingActionButton);
                return false;
            }
        }

        /* renamed from: I */
        public boolean l(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i) {
            List<View> r = coordinatorLayout.r(floatingActionButton);
            int size = r.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = r.get(i2);
                if (!(view instanceof AppBarLayout)) {
                    if (F(view) && L(view, floatingActionButton)) {
                        break;
                    }
                } else if (K(coordinatorLayout, (AppBarLayout) view, floatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.I(floatingActionButton, i);
            G(coordinatorLayout, floatingActionButton);
            return true;
        }

        public final boolean J(View view, FloatingActionButton floatingActionButton) {
            return this.f1492a && ((CoordinatorLayout.f) floatingActionButton.getLayoutParams()).e() == view.getId() && floatingActionButton.getUserSetVisibility() == 0;
        }

        public final boolean K(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!J(appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.a == null) {
                this.a = new Rect();
            }
            Rect rect = this.a;
            ec1.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.m(this.f1491a, false);
                return true;
            }
            floatingActionButton.t(this.f1491a, false);
            return true;
        }

        public final boolean L(View view, FloatingActionButton floatingActionButton) {
            if (!J(view, floatingActionButton)) {
                return false;
            }
            if (view.getTop() < (floatingActionButton.getHeight() / 2) + ((CoordinatorLayout.f) floatingActionButton.getLayoutParams()).topMargin) {
                floatingActionButton.m(this.f1491a, false);
                return true;
            }
            floatingActionButton.t(this.f1491a, false);
            return true;
        }

        public void g(CoordinatorLayout.f fVar) {
            if (fVar.f == 0) {
                fVar.f = 80;
            }
        }
    }

    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public /* bridge */ /* synthetic */ boolean E(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            return super.b(coordinatorLayout, floatingActionButton, rect);
        }

        public /* bridge */ /* synthetic */ boolean H(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            return super.h(coordinatorLayout, floatingActionButton, view);
        }

        public /* bridge */ /* synthetic */ boolean I(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i) {
            return super.l(coordinatorLayout, floatingActionButton, i);
        }

        public /* bridge */ /* synthetic */ void g(CoordinatorLayout.f fVar) {
            super.g(fVar);
        }
    }

    public class a implements ac1.j {
        public final /* synthetic */ b a;

        public a(b bVar) {
            this.a = bVar;
        }

        public void a() {
            this.a.b(FloatingActionButton.this);
        }

        public void b() {
            this.a.a(FloatingActionButton.this);
        }
    }

    public static abstract class b {
        public void a(FloatingActionButton floatingActionButton) {
        }

        public void b(FloatingActionButton floatingActionButton) {
        }
    }

    public class c implements ad1 {
        public c() {
        }

        public void a(Drawable drawable) {
            if (drawable != null) {
                FloatingActionButton.super.setBackgroundDrawable(drawable);
            }
        }

        public void b(int i, int i2, int i3, int i4) {
            FloatingActionButton.this.f1484a.set(i, i2, i3, i4);
            FloatingActionButton floatingActionButton = FloatingActionButton.this;
            floatingActionButton.setPadding(i + floatingActionButton.e, i2 + FloatingActionButton.this.e, i3 + FloatingActionButton.this.e, i4 + FloatingActionButton.this.e);
        }

        public boolean c() {
            return FloatingActionButton.this.f1489b;
        }
    }

    public class d<T extends FloatingActionButton> implements ac1.i {

        /* renamed from: a  reason: collision with other field name */
        public final ia1<T> f1494a;

        public d(ia1<T> ia1) {
            this.f1494a = ia1;
        }

        public void a() {
            this.f1494a.a(FloatingActionButton.this);
        }

        public void b() {
            this.f1494a.b(FloatingActionButton.this);
        }

        public boolean equals(Object obj) {
            return (obj instanceof d) && ((d) obj).f1494a.equals(this.f1494a);
        }

        public int hashCode() {
            return this.f1494a.hashCode();
        }
    }

    private ac1 getImpl() {
        if (this.a == null) {
            this.a = h();
        }
        return this.a;
    }

    public static int r(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == Integer.MIN_VALUE) {
            return Math.min(i, size);
        }
        if (mode == 0) {
            return i;
        }
        if (mode == 1073741824) {
            return size;
        }
        throw new IllegalArgumentException();
    }

    public boolean a() {
        throw null;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        getImpl().C(getDrawableState());
    }

    public void e(Animator.AnimatorListener animatorListener) {
        getImpl().d(animatorListener);
    }

    public void f(Animator.AnimatorListener animatorListener) {
        getImpl().e(animatorListener);
    }

    public void g(ia1<? extends FloatingActionButton> ia1) {
        getImpl().f(new d(ia1));
    }

    public ColorStateList getBackgroundTintList() {
        return this.f1482a;
    }

    public PorterDuff.Mode getBackgroundTintMode() {
        return this.f1483a;
    }

    public CoordinatorLayout.c<FloatingActionButton> getBehavior() {
        return new Behavior();
    }

    public float getCompatElevation() {
        return getImpl().m();
    }

    public float getCompatHoveredFocusedTranslationZ() {
        return getImpl().p();
    }

    public float getCompatPressedTranslationZ() {
        return getImpl().s();
    }

    public Drawable getContentBackground() {
        return getImpl().j();
    }

    public int getCustomSize() {
        return this.d;
    }

    public int getExpandedComponentIdHint() {
        throw null;
    }

    public fa1 getHideMotionSpec() {
        return getImpl().o();
    }

    @Deprecated
    public int getRippleColor() {
        ColorStateList colorStateList = this.f1490c;
        if (colorStateList != null) {
            return colorStateList.getDefaultColor();
        }
        return 0;
    }

    public ColorStateList getRippleColorStateList() {
        return this.f1490c;
    }

    public ld1 getShapeAppearanceModel() {
        return (ld1) ca.e(getImpl().t());
    }

    public fa1 getShowMotionSpec() {
        return getImpl().u();
    }

    public int getSize() {
        return this.c;
    }

    public int getSizeDimension() {
        return k(this.c);
    }

    public ColorStateList getSupportBackgroundTintList() {
        return getBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return getBackgroundTintMode();
    }

    public ColorStateList getSupportImageTintList() {
        return this.f1486b;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        return this.f1487b;
    }

    public boolean getUseCompatPadding() {
        return this.f1489b;
    }

    public final ac1 h() {
        return Build.VERSION.SDK_INT >= 21 ? new bc1(this, new c()) : new ac1(this, new c());
    }

    @Deprecated
    public boolean i(Rect rect) {
        if (!ya.T(this)) {
            return false;
        }
        rect.set(0, 0, getWidth(), getHeight());
        p(rect);
        return true;
    }

    public void j(Rect rect) {
        rect.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
        p(rect);
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        getImpl().y();
    }

    public final int k(int i) {
        int i2 = this.d;
        if (i2 != 0) {
            return i2;
        }
        Resources resources = getResources();
        if (i == -1) {
            return Math.max(resources.getConfiguration().screenWidthDp, resources.getConfiguration().screenHeightDp) < 470 ? k(1) : k(0);
        }
        return resources.getDimensionPixelSize(i != 1 ? q91.design_fab_size_normal : q91.design_fab_size_mini);
    }

    public void l(b bVar) {
        m(bVar, true);
    }

    public void m(b bVar, boolean z) {
        getImpl().v(u(bVar), z);
    }

    public boolean n() {
        return getImpl().w();
    }

    public boolean o() {
        return getImpl().x();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getImpl().z();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getImpl().B();
    }

    public void onMeasure(int i, int i2) {
        int sizeDimension = getSizeDimension();
        this.e = (sizeDimension - this.f) / 2;
        getImpl().b0();
        int min = Math.min(r(sizeDimension, i), r(sizeDimension, i2));
        Rect rect = this.f1484a;
        setMeasuredDimension(rect.left + min + rect.right, min + rect.top + rect.bottom);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof ud1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        ud1 ud1 = (ud1) parcelable;
        super.onRestoreInstanceState(ud1.a());
        Bundle bundle = (Bundle) ca.e(ud1.a.get("expandableWidgetHelper"));
        throw null;
    }

    public Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        if (onSaveInstanceState == null) {
            onSaveInstanceState = new Bundle();
        }
        new ud1(onSaveInstanceState);
        throw null;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0 || !i(this.f1488b) || this.f1488b.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    public final void p(Rect rect) {
        int i = rect.left;
        Rect rect2 = this.f1484a;
        rect.left = i + rect2.left;
        rect.top += rect2.top;
        rect.right -= rect2.right;
        rect.bottom -= rect2.bottom;
    }

    public final void q() {
        Drawable drawable = getDrawable();
        if (drawable != null) {
            ColorStateList colorStateList = this.f1486b;
            if (colorStateList == null) {
                m8.c(drawable);
                return;
            }
            int colorForState = colorStateList.getColorForState(getDrawableState(), 0);
            PorterDuff.Mode mode = this.f1487b;
            if (mode == null) {
                mode = PorterDuff.Mode.SRC_IN;
            }
            drawable.mutate().setColorFilter(e2.e(colorForState, mode));
        }
    }

    public void s(b bVar) {
        t(bVar, true);
    }

    public void setBackgroundColor(int i) {
    }

    public void setBackgroundDrawable(Drawable drawable) {
    }

    public void setBackgroundResource(int i) {
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f1482a != colorStateList) {
            this.f1482a = colorStateList;
            getImpl().J(colorStateList);
        }
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        if (this.f1483a != mode) {
            this.f1483a = mode;
            getImpl().K(mode);
        }
    }

    public void setCompatElevation(float f2) {
        getImpl().L(f2);
    }

    public void setCompatElevationResource(int i) {
        setCompatElevation(getResources().getDimension(i));
    }

    public void setCompatHoveredFocusedTranslationZ(float f2) {
        getImpl().O(f2);
    }

    public void setCompatHoveredFocusedTranslationZResource(int i) {
        setCompatHoveredFocusedTranslationZ(getResources().getDimension(i));
    }

    public void setCompatPressedTranslationZ(float f2) {
        getImpl().Q(f2);
    }

    public void setCompatPressedTranslationZResource(int i) {
        setCompatPressedTranslationZ(getResources().getDimension(i));
    }

    public void setCustomSize(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Custom size must be non-negative");
        } else if (i != this.d) {
            this.d = i;
            requestLayout();
        }
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        getImpl().c0(f2);
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        if (z != getImpl().n()) {
            getImpl().M(z);
            requestLayout();
        }
    }

    public void setExpandedComponentIdHint(int i) {
        throw null;
    }

    public void setHideMotionSpec(fa1 fa1) {
        getImpl().N(fa1);
    }

    public void setHideMotionSpecResource(int i) {
        setHideMotionSpec(fa1.c(getContext(), i));
    }

    public void setImageDrawable(Drawable drawable) {
        if (getDrawable() != drawable) {
            super.setImageDrawable(drawable);
            getImpl().a0();
            if (this.f1486b != null) {
                q();
            }
        }
    }

    public void setImageResource(int i) {
        this.f1485a.g(i);
        q();
    }

    public void setRippleColor(int i) {
        setRippleColor(ColorStateList.valueOf(i));
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (this.f1490c != colorStateList) {
            this.f1490c = colorStateList;
            getImpl().R(this.f1490c);
        }
    }

    public void setScaleX(float f2) {
        super.setScaleX(f2);
        getImpl().G();
    }

    public void setScaleY(float f2) {
        super.setScaleY(f2);
        getImpl().G();
    }

    public void setShadowPaddingEnabled(boolean z) {
        getImpl().S(z);
    }

    public void setShapeAppearanceModel(ld1 ld1) {
        getImpl().T(ld1);
    }

    public void setShowMotionSpec(fa1 fa1) {
        getImpl().U(fa1);
    }

    public void setShowMotionSpecResource(int i) {
        setShowMotionSpec(fa1.c(getContext(), i));
    }

    public void setSize(int i) {
        this.d = 0;
        if (i != this.c) {
            this.c = i;
            requestLayout();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        setBackgroundTintList(colorStateList);
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        setBackgroundTintMode(mode);
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f1486b != colorStateList) {
            this.f1486b = colorStateList;
            q();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        if (this.f1487b != mode) {
            this.f1487b = mode;
            q();
        }
    }

    public void setTranslationX(float f2) {
        super.setTranslationX(f2);
        getImpl().H();
    }

    public void setTranslationY(float f2) {
        super.setTranslationY(f2);
        getImpl().H();
    }

    public void setTranslationZ(float f2) {
        super.setTranslationZ(f2);
        getImpl().H();
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f1489b != z) {
            this.f1489b = z;
            getImpl().A();
        }
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
    }

    public void t(b bVar, boolean z) {
        getImpl().Y(u(bVar), z);
    }

    public final ac1.j u(b bVar) {
        if (bVar == null) {
            return null;
        }
        return new a(bVar);
    }
}
