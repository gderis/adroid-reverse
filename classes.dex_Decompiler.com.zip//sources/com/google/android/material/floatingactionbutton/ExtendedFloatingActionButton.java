package com.google.android.material.floatingactionbutton;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class ExtendedFloatingActionButton extends MaterialButton implements CoordinatorLayout.b {
    public static final Property<View, Float> a;
    public static final Property<View, Float> b;
    public static final Property<View, Float> c;
    public static final Property<View, Float> d;
    public static final int g = w91.Widget_MaterialComponents_ExtendedFloatingActionButton_Icon;

    /* renamed from: a  reason: collision with other field name */
    public final CoordinatorLayout.c<ExtendedFloatingActionButton> f1469a;

    /* renamed from: a  reason: collision with other field name */
    public final cc1 f1470a;

    /* renamed from: b  reason: collision with other field name */
    public ColorStateList f1471b;

    /* renamed from: b  reason: collision with other field name */
    public final cc1 f1472b;

    /* renamed from: c  reason: collision with other field name */
    public final cc1 f1473c;

    /* renamed from: d  reason: collision with other field name */
    public final cc1 f1474d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f1475d;
    public boolean e;
    public boolean f;
    public int h;
    public final int i;
    public int j;
    public int k;

    public static class ExtendedFloatingActionButtonBehavior<T extends ExtendedFloatingActionButton> extends CoordinatorLayout.c<T> {
        public Rect a;

        /* renamed from: a  reason: collision with other field name */
        public f f1476a;

        /* renamed from: a  reason: collision with other field name */
        public boolean f1477a;
        public f b;

        /* renamed from: b  reason: collision with other field name */
        public boolean f1478b;

        public ExtendedFloatingActionButtonBehavior() {
            this.f1477a = false;
            this.f1478b = true;
        }

        public ExtendedFloatingActionButtonBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.ExtendedFloatingActionButton_Behavior_Layout);
            this.f1477a = obtainStyledAttributes.getBoolean(x91.ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide, false);
            this.f1478b = obtainStyledAttributes.getBoolean(x91.ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink, true);
            obtainStyledAttributes.recycle();
        }

        public static boolean G(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.f) {
                return ((CoordinatorLayout.f) layoutParams).f() instanceof BottomSheetBehavior;
            }
            return false;
        }

        public void E(ExtendedFloatingActionButton extendedFloatingActionButton) {
            boolean z = this.f1478b;
            extendedFloatingActionButton.r(z ? extendedFloatingActionButton.f1472b : extendedFloatingActionButton.f1473c, z ? this.b : this.f1476a);
        }

        /* renamed from: F */
        public boolean b(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, Rect rect) {
            return super.b(coordinatorLayout, extendedFloatingActionButton, rect);
        }

        /* renamed from: H */
        public boolean h(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                L(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton);
                return false;
            } else if (!G(view)) {
                return false;
            } else {
                M(view, extendedFloatingActionButton);
                return false;
            }
        }

        /* renamed from: I */
        public boolean l(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, int i) {
            List<View> r = coordinatorLayout.r(extendedFloatingActionButton);
            int size = r.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = r.get(i2);
                if (!(view instanceof AppBarLayout)) {
                    if (G(view) && M(view, extendedFloatingActionButton)) {
                        break;
                    }
                } else if (L(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.I(extendedFloatingActionButton, i);
            return true;
        }

        public final boolean J(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            return (this.f1477a || this.f1478b) && ((CoordinatorLayout.f) extendedFloatingActionButton.getLayoutParams()).e() == view.getId();
        }

        public void K(ExtendedFloatingActionButton extendedFloatingActionButton) {
            boolean z = this.f1478b;
            extendedFloatingActionButton.r(z ? extendedFloatingActionButton.f1470a : extendedFloatingActionButton.f1474d, z ? this.b : this.f1476a);
        }

        public final boolean L(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!J(appBarLayout, extendedFloatingActionButton)) {
                return false;
            }
            if (this.a == null) {
                this.a = new Rect();
            }
            Rect rect = this.a;
            ec1.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                K(extendedFloatingActionButton);
                return true;
            }
            E(extendedFloatingActionButton);
            return true;
        }

        public final boolean M(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!J(view, extendedFloatingActionButton)) {
                return false;
            }
            if (view.getTop() < (extendedFloatingActionButton.getHeight() / 2) + ((CoordinatorLayout.f) extendedFloatingActionButton.getLayoutParams()).topMargin) {
                K(extendedFloatingActionButton);
                return true;
            }
            E(extendedFloatingActionButton);
            return true;
        }

        public void g(CoordinatorLayout.f fVar) {
            if (fVar.f == 0) {
                fVar.f = 80;
            }
        }
    }

    public class a extends AnimatorListenerAdapter {
        public final /* synthetic */ cc1 a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ f f1479a;

        /* renamed from: a  reason: collision with other field name */
        public boolean f1481a;

        public a(cc1 cc1, f fVar) {
            this.a = cc1;
        }

        public void onAnimationCancel(Animator animator) {
            this.f1481a = true;
            this.a.a();
        }

        public void onAnimationEnd(Animator animator) {
            this.a.i();
            if (!this.f1481a) {
                this.a.e(this.f1479a);
            }
        }

        public void onAnimationStart(Animator animator) {
            this.a.onAnimationStart(animator);
            this.f1481a = false;
        }
    }

    public static class b extends Property<View, Float> {
        public b(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) view.getLayoutParams().width);
        }

        /* renamed from: b */
        public void set(View view, Float f) {
            view.getLayoutParams().width = f.intValue();
            view.requestLayout();
        }
    }

    public static class c extends Property<View, Float> {
        public c(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) view.getLayoutParams().height);
        }

        /* renamed from: b */
        public void set(View view, Float f) {
            view.getLayoutParams().height = f.intValue();
            view.requestLayout();
        }
    }

    public static class d extends Property<View, Float> {
        public d(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) ya.I(view));
        }

        /* renamed from: b */
        public void set(View view, Float f) {
            ya.A0(view, f.intValue(), view.getPaddingTop(), ya.H(view), view.getPaddingBottom());
        }
    }

    public static class e extends Property<View, Float> {
        public e(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) ya.H(view));
        }

        /* renamed from: b */
        public void set(View view, Float f) {
            ya.A0(view, ya.I(view), view.getPaddingTop(), f.intValue(), view.getPaddingBottom());
        }
    }

    public static abstract class f {
    }

    static {
        Class<Float> cls = Float.class;
        a = new b(cls, "width");
        b = new c(cls, "height");
        c = new d(cls, "paddingStart");
        d = new e(cls, "paddingEnd");
    }

    public CoordinatorLayout.c<ExtendedFloatingActionButton> getBehavior() {
        return this.f1469a;
    }

    public int getCollapsedPadding() {
        return (getCollapsedSize() - getIconSize()) / 2;
    }

    public int getCollapsedSize() {
        int i2 = this.i;
        return i2 < 0 ? (Math.min(ya.I(this), ya.H(this)) * 2) + getIconSize() : i2;
    }

    public fa1 getExtendMotionSpec() {
        return this.f1472b.g();
    }

    public fa1 getHideMotionSpec() {
        return this.f1474d.g();
    }

    public fa1 getShowMotionSpec() {
        return this.f1473c.g();
    }

    public fa1 getShrinkMotionSpec() {
        return this.f1470a.g();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f1475d && TextUtils.isEmpty(getText()) && getIcon() != null) {
            this.f1475d = false;
            this.f1470a.c();
        }
    }

    public final boolean q() {
        return getVisibility() != 0 ? this.h == 2 : this.h != 1;
    }

    public final void r(cc1 cc1, f fVar) {
        if (!cc1.d()) {
            if (!t()) {
                cc1.c();
                cc1.e(fVar);
                return;
            }
            measure(0, 0);
            AnimatorSet h2 = cc1.h();
            h2.addListener(new a(cc1, fVar));
            for (Animator.AnimatorListener addListener : cc1.b()) {
                h2.addListener(addListener);
            }
            h2.start();
        }
    }

    public final void s() {
        this.f1471b = getTextColors();
    }

    public void setAnimateShowBeforeLayout(boolean z) {
        this.f = z;
    }

    public void setExtendMotionSpec(fa1 fa1) {
        this.f1472b.f(fa1);
    }

    public void setExtendMotionSpecResource(int i2) {
        setExtendMotionSpec(fa1.c(getContext(), i2));
    }

    public void setExtended(boolean z) {
        if (this.f1475d != z) {
            cc1 cc1 = z ? this.f1472b : this.f1470a;
            if (!cc1.d()) {
                cc1.c();
            }
        }
    }

    public void setHideMotionSpec(fa1 fa1) {
        this.f1474d.f(fa1);
    }

    public void setHideMotionSpecResource(int i2) {
        setHideMotionSpec(fa1.c(getContext(), i2));
    }

    public void setPadding(int i2, int i3, int i4, int i5) {
        super.setPadding(i2, i3, i4, i5);
        if (this.f1475d && !this.e) {
            this.j = ya.I(this);
            this.k = ya.H(this);
        }
    }

    public void setPaddingRelative(int i2, int i3, int i4, int i5) {
        super.setPaddingRelative(i2, i3, i4, i5);
        if (this.f1475d && !this.e) {
            this.j = i2;
            this.k = i4;
        }
    }

    public void setShowMotionSpec(fa1 fa1) {
        this.f1473c.f(fa1);
    }

    public void setShowMotionSpecResource(int i2) {
        setShowMotionSpec(fa1.c(getContext(), i2));
    }

    public void setShrinkMotionSpec(fa1 fa1) {
        this.f1470a.f(fa1);
    }

    public void setShrinkMotionSpecResource(int i2) {
        setShrinkMotionSpec(fa1.c(getContext(), i2));
    }

    public void setTextColor(int i2) {
        super.setTextColor(i2);
        s();
    }

    public void setTextColor(ColorStateList colorStateList) {
        super.setTextColor(colorStateList);
        s();
    }

    public final boolean t() {
        return (ya.T(this) || (!q() && this.f)) && !isInEditMode();
    }
}
