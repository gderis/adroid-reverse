package com.google.android.material.chip;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import defpackage.jb;
import defpackage.ua1;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

public class Chip extends b2 implements ua1.a, od1 {
    public static final int a = w91.Widget_MaterialComponents_Chip_Action;

    /* renamed from: a  reason: collision with other field name */
    public static final Rect f1450a = new Rect();

    /* renamed from: a  reason: collision with other field name */
    public static final int[] f1451a = {16842913};
    public static final int[] b = {16842911};

    /* renamed from: a  reason: collision with other field name */
    public final RectF f1452a;

    /* renamed from: a  reason: collision with other field name */
    public InsetDrawable f1453a;

    /* renamed from: a  reason: collision with other field name */
    public RippleDrawable f1454a;

    /* renamed from: a  reason: collision with other field name */
    public View.OnClickListener f1455a;

    /* renamed from: a  reason: collision with other field name */
    public CompoundButton.OnCheckedChangeListener f1456a;

    /* renamed from: a  reason: collision with other field name */
    public final c f1457a;

    /* renamed from: a  reason: collision with other field name */
    public ua1 f1458a;

    /* renamed from: a  reason: collision with other field name */
    public final wc1 f1459a;

    /* renamed from: b  reason: collision with other field name */
    public int f1460b;

    /* renamed from: b  reason: collision with other field name */
    public final Rect f1461b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1462b;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1463c;
    public boolean d;
    public boolean e;
    public boolean f;

    public class a extends wc1 {
        public a() {
        }

        public void a(int i) {
        }

        public void b(Typeface typeface, boolean z) {
            Chip chip = Chip.this;
            chip.setText(chip.f1458a.J2() ? Chip.this.f1458a.f1() : Chip.this.getText());
            Chip.this.requestLayout();
            Chip.this.invalidate();
        }
    }

    public class b extends ViewOutlineProvider {
        public b() {
        }

        @TargetApi(21)
        public void getOutline(View view, Outline outline) {
            if (Chip.this.f1458a != null) {
                Chip.this.f1458a.getOutline(outline);
            } else {
                outline.setAlpha(0.0f);
            }
        }
    }

    public class c extends hc {
        public c(Chip chip) {
            super(chip);
        }

        public int B(float f, float f2) {
            return (!Chip.this.n() || !Chip.this.getCloseIconTouchBounds().contains(f, f2)) ? 0 : 1;
        }

        public void C(List<Integer> list) {
            list.add(0);
            if (Chip.this.n() && Chip.this.s() && Chip.this.f1455a != null) {
                list.add(1);
            }
        }

        public boolean J(int i, int i2, Bundle bundle) {
            if (i2 != 16) {
                return false;
            }
            if (i == 0) {
                return Chip.this.performClick();
            }
            if (i == 1) {
                return Chip.this.t();
            }
            return false;
        }

        public void M(jb jbVar) {
            jbVar.U(Chip.this.r());
            jbVar.X(Chip.this.isClickable());
            jbVar.W((Chip.this.r() || Chip.this.isClickable()) ? Chip.this.r() ? "android.widget.CompoundButton" : "android.widget.Button" : "android.view.View");
            CharSequence text = Chip.this.getText();
            if (Build.VERSION.SDK_INT >= 23) {
                jbVar.r0(text);
            } else {
                jbVar.a0(text);
            }
        }

        public void N(int i, jb jbVar) {
            CharSequence charSequence = "";
            if (i == 1) {
                CharSequence closeIconContentDescription = Chip.this.getCloseIconContentDescription();
                if (closeIconContentDescription == null) {
                    CharSequence text = Chip.this.getText();
                    Context context = Chip.this.getContext();
                    int i2 = v91.mtrl_chip_close_icon_content_description;
                    Object[] objArr = new Object[1];
                    if (!TextUtils.isEmpty(text)) {
                        charSequence = text;
                    }
                    objArr[0] = charSequence;
                    closeIconContentDescription = context.getString(i2, objArr).trim();
                }
                jbVar.a0(closeIconContentDescription);
                jbVar.S(Chip.this.getCloseIconTouchBoundsInt());
                jbVar.b(jb.a.e);
                jbVar.b0(Chip.this.isEnabled());
                return;
            }
            jbVar.a0(charSequence);
            jbVar.S(Chip.f1450a);
        }

        public void O(int i, boolean z) {
            if (i == 1) {
                boolean unused = Chip.this.e = z;
                Chip.this.refreshDrawableState();
            }
        }
    }

    public Chip(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.chipStyle);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Chip(android.content.Context r8, android.util.AttributeSet r9, int r10) {
        /*
            r7 = this;
            int r4 = a
            android.content.Context r8 = defpackage.ee1.c(r8, r9, r10, r4)
            r7.<init>(r8, r9, r10)
            android.graphics.Rect r8 = new android.graphics.Rect
            r8.<init>()
            r7.f1461b = r8
            android.graphics.RectF r8 = new android.graphics.RectF
            r8.<init>()
            r7.f1452a = r8
            com.google.android.material.chip.Chip$a r8 = new com.google.android.material.chip.Chip$a
            r8.<init>()
            r7.f1459a = r8
            android.content.Context r8 = r7.getContext()
            r7.C(r9)
            ua1 r6 = defpackage.ua1.t0(r8, r9, r10, r4)
            r7.o(r8, r9, r10)
            r7.setChipDrawable(r6)
            float r0 = defpackage.ya.w(r7)
            r6.V(r0)
            int[] r2 = defpackage.x91.Chip
            r0 = 0
            int[] r5 = new int[r0]
            r0 = r8
            r1 = r9
            r3 = r10
            android.content.res.TypedArray r9 = defpackage.mc1.h(r0, r1, r2, r3, r4, r5)
            int r10 = android.os.Build.VERSION.SDK_INT
            r0 = 23
            if (r10 >= r0) goto L_0x0051
            int r10 = defpackage.x91.Chip_android_textColor
            android.content.res.ColorStateList r8 = defpackage.tc1.a(r8, r9, r10)
            r7.setTextColor(r8)
        L_0x0051:
            int r8 = defpackage.x91.Chip_shapeAppearance
            boolean r8 = r9.hasValue(r8)
            r9.recycle()
            com.google.android.material.chip.Chip$c r9 = new com.google.android.material.chip.Chip$c
            r9.<init>(r7)
            r7.f1457a = r9
            r7.x()
            if (r8 != 0) goto L_0x0069
            r7.p()
        L_0x0069:
            boolean r8 = r7.f1462b
            r7.setChecked(r8)
            java.lang.CharSequence r8 = r6.f1()
            r7.setText(r8)
            android.text.TextUtils$TruncateAt r8 = r6.Z0()
            r7.setEllipsize(r8)
            r7.B()
            ua1 r8 = r7.f1458a
            boolean r8 = r8.J2()
            if (r8 != 0) goto L_0x008e
            r8 = 1
            r7.setLines(r8)
            r7.setHorizontallyScrolling(r8)
        L_0x008e:
            r8 = 8388627(0x800013, float:1.175497E-38)
            r7.setGravity(r8)
            r7.A()
            boolean r8 = r7.v()
            if (r8 == 0) goto L_0x00a2
            int r8 = r7.c
            r7.setMinHeight(r8)
        L_0x00a2:
            int r8 = defpackage.ya.C(r7)
            r7.f1460b = r8
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: private */
    public RectF getCloseIconTouchBounds() {
        this.f1452a.setEmpty();
        if (n() && this.f1455a != null) {
            this.f1458a.W0(this.f1452a);
        }
        return this.f1452a;
    }

    /* access modifiers changed from: private */
    public Rect getCloseIconTouchBoundsInt() {
        RectF closeIconTouchBounds = getCloseIconTouchBounds();
        this.f1461b.set((int) closeIconTouchBounds.left, (int) closeIconTouchBounds.top, (int) closeIconTouchBounds.right, (int) closeIconTouchBounds.bottom);
        return this.f1461b;
    }

    private uc1 getTextAppearance() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.g1();
        }
        return null;
    }

    private void setCloseIconHovered(boolean z) {
        if (this.d != z) {
            this.d = z;
            refreshDrawableState();
        }
    }

    private void setCloseIconPressed(boolean z) {
        if (this.f1463c != z) {
            this.f1463c = z;
            refreshDrawableState();
        }
    }

    public final void A() {
        ua1 ua1;
        if (!TextUtils.isEmpty(getText()) && (ua1 = this.f1458a) != null) {
            int H0 = (int) (ua1.H0() + this.f1458a.h1() + this.f1458a.o0());
            int M0 = (int) (this.f1458a.M0() + this.f1458a.i1() + this.f1458a.k0());
            if (this.f1453a != null) {
                Rect rect = new Rect();
                this.f1453a.getPadding(rect);
                M0 += rect.left;
                H0 += rect.right;
            }
            ya.A0(this, M0, getPaddingTop(), H0, getPaddingBottom());
        }
    }

    public final void B() {
        TextPaint paint = getPaint();
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            paint.drawableState = ua1.getState();
        }
        uc1 textAppearance = getTextAppearance();
        if (textAppearance != null) {
            textAppearance.j(getContext(), paint, this.f1459a);
        }
    }

    public final void C(AttributeSet attributeSet) {
        if (attributeSet != null) {
            String attributeValue = attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "background");
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableLeft") != null) {
                throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
            } else if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableStart") != null) {
                throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
            } else if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableEnd") != null) {
                throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
            } else if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableRight") != null) {
                throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
            } else if (attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res/android", "singleLine", true) && attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "lines", 1) == 1 && attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "minLines", 1) == 1 && attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "maxLines", 1) == 1) {
                int attributeIntValue = attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "gravity", 8388627);
            } else {
                throw new UnsupportedOperationException("Chip does not support multi-line text");
            }
        }
    }

    public void a() {
        k(this.c);
        requestLayout();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public boolean dispatchHoverEvent(MotionEvent motionEvent) {
        return m(motionEvent) || this.f1457a.v(motionEvent) || super.dispatchHoverEvent(motionEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!this.f1457a.w(keyEvent) || this.f1457a.A() == Integer.MIN_VALUE) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        ua1 ua1 = this.f1458a;
        if ((ua1 == null || !ua1.n1()) ? false : this.f1458a.j2(j())) {
            invalidate();
        }
    }

    public Drawable getBackgroundDrawable() {
        InsetDrawable insetDrawable = this.f1453a;
        return insetDrawable == null ? this.f1458a : insetDrawable;
    }

    public Drawable getCheckedIcon() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.D0();
        }
        return null;
    }

    public ColorStateList getCheckedIconTint() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.E0();
        }
        return null;
    }

    public ColorStateList getChipBackgroundColor() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.F0();
        }
        return null;
    }

    public float getChipCornerRadius() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return Math.max(0.0f, ua1.G0());
        }
        return 0.0f;
    }

    public Drawable getChipDrawable() {
        return this.f1458a;
    }

    public float getChipEndPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.H0();
        }
        return 0.0f;
    }

    public Drawable getChipIcon() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.I0();
        }
        return null;
    }

    public float getChipIconSize() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.J0();
        }
        return 0.0f;
    }

    public ColorStateList getChipIconTint() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.K0();
        }
        return null;
    }

    public float getChipMinHeight() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.L0();
        }
        return 0.0f;
    }

    public float getChipStartPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.M0();
        }
        return 0.0f;
    }

    public ColorStateList getChipStrokeColor() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.N0();
        }
        return null;
    }

    public float getChipStrokeWidth() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.O0();
        }
        return 0.0f;
    }

    @Deprecated
    public CharSequence getChipText() {
        return getText();
    }

    public Drawable getCloseIcon() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.P0();
        }
        return null;
    }

    public CharSequence getCloseIconContentDescription() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.Q0();
        }
        return null;
    }

    public float getCloseIconEndPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.R0();
        }
        return 0.0f;
    }

    public float getCloseIconSize() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.S0();
        }
        return 0.0f;
    }

    public float getCloseIconStartPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.T0();
        }
        return 0.0f;
    }

    public ColorStateList getCloseIconTint() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.V0();
        }
        return null;
    }

    public TextUtils.TruncateAt getEllipsize() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.Z0();
        }
        return null;
    }

    public void getFocusedRect(Rect rect) {
        if (this.f1457a.A() == 1 || this.f1457a.x() == 1) {
            rect.set(getCloseIconTouchBoundsInt());
        } else {
            super.getFocusedRect(rect);
        }
    }

    public fa1 getHideMotionSpec() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.a1();
        }
        return null;
    }

    public float getIconEndPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.b1();
        }
        return 0.0f;
    }

    public float getIconStartPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.c1();
        }
        return 0.0f;
    }

    public ColorStateList getRippleColor() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.d1();
        }
        return null;
    }

    public ld1 getShapeAppearanceModel() {
        return this.f1458a.C();
    }

    public fa1 getShowMotionSpec() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.e1();
        }
        return null;
    }

    public float getTextEndPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.h1();
        }
        return 0.0f;
    }

    public float getTextStartPadding() {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            return ua1.i1();
        }
        return 0.0f;
    }

    public final void i(ua1 ua1) {
        ua1.n2(this);
    }

    public final int[] j() {
        int i = 0;
        int i2 = isEnabled() ? 1 : 0;
        if (this.e) {
            i2++;
        }
        if (this.d) {
            i2++;
        }
        if (this.f1463c) {
            i2++;
        }
        if (isChecked()) {
            i2++;
        }
        int[] iArr = new int[i2];
        if (isEnabled()) {
            iArr[0] = 16842910;
            i = 1;
        }
        if (this.e) {
            iArr[i] = 16842908;
            i++;
        }
        if (this.d) {
            iArr[i] = 16843623;
            i++;
        }
        if (this.f1463c) {
            iArr[i] = 16842919;
            i++;
        }
        if (isChecked()) {
            iArr[i] = 16842913;
        }
        return iArr;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:38:0x007d, code lost:
        if (getMinWidth() != r6) goto L_0x0083;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean k(int r6) {
        /*
            r5 = this;
            r5.c = r6
            boolean r0 = r5.v()
            r1 = 0
            if (r0 != 0) goto L_0x0015
            android.graphics.drawable.InsetDrawable r6 = r5.f1453a
            if (r6 == 0) goto L_0x0011
            r5.u()
            goto L_0x0014
        L_0x0011:
            r5.y()
        L_0x0014:
            return r1
        L_0x0015:
            ua1 r0 = r5.f1458a
            int r0 = r0.getIntrinsicHeight()
            int r0 = r6 - r0
            int r0 = java.lang.Math.max(r1, r0)
            ua1 r2 = r5.f1458a
            int r2 = r2.getIntrinsicWidth()
            int r2 = r6 - r2
            int r2 = java.lang.Math.max(r1, r2)
            if (r2 > 0) goto L_0x003d
            if (r0 > 0) goto L_0x003d
            android.graphics.drawable.InsetDrawable r6 = r5.f1453a
            if (r6 == 0) goto L_0x0039
            r5.u()
            goto L_0x003c
        L_0x0039:
            r5.y()
        L_0x003c:
            return r1
        L_0x003d:
            if (r2 <= 0) goto L_0x0042
            int r2 = r2 / 2
            goto L_0x0043
        L_0x0042:
            r2 = 0
        L_0x0043:
            if (r0 <= 0) goto L_0x0047
            int r1 = r0 / 2
        L_0x0047:
            android.graphics.drawable.InsetDrawable r0 = r5.f1453a
            r3 = 1
            if (r0 == 0) goto L_0x006a
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            android.graphics.drawable.InsetDrawable r4 = r5.f1453a
            r4.getPadding(r0)
            int r4 = r0.top
            if (r4 != r1) goto L_0x006a
            int r4 = r0.bottom
            if (r4 != r1) goto L_0x006a
            int r4 = r0.left
            if (r4 != r2) goto L_0x006a
            int r0 = r0.right
            if (r0 != r2) goto L_0x006a
            r5.y()
            return r3
        L_0x006a:
            int r0 = android.os.Build.VERSION.SDK_INT
            r4 = 16
            if (r0 < r4) goto L_0x0080
            int r0 = r5.getMinHeight()
            if (r0 == r6) goto L_0x0079
            r5.setMinHeight(r6)
        L_0x0079:
            int r0 = r5.getMinWidth()
            if (r0 == r6) goto L_0x0086
            goto L_0x0083
        L_0x0080:
            r5.setMinHeight(r6)
        L_0x0083:
            r5.setMinWidth(r6)
        L_0x0086:
            r5.q(r2, r1, r2, r1)
            r5.y()
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.k(int):boolean");
    }

    public final void l() {
        if (getBackgroundDrawable() == this.f1453a && this.f1458a.getCallback() == null) {
            this.f1458a.setCallback(this.f1453a);
        }
    }

    @SuppressLint({"PrivateApi"})
    public final boolean m(MotionEvent motionEvent) {
        Class<hc> cls = hc.class;
        if (motionEvent.getAction() == 10) {
            try {
                Field declaredField = cls.getDeclaredField("c");
                declaredField.setAccessible(true);
                if (((Integer) declaredField.get(this.f1457a)).intValue() != Integer.MIN_VALUE) {
                    Method declaredMethod = cls.getDeclaredMethod("V", new Class[]{Integer.TYPE});
                    declaredMethod.setAccessible(true);
                    declaredMethod.invoke(this.f1457a, new Object[]{Integer.MIN_VALUE});
                    return true;
                }
            } catch (IllegalAccessException | NoSuchFieldException | NoSuchMethodException | InvocationTargetException unused) {
            }
        }
        return false;
    }

    public final boolean n() {
        ua1 ua1 = this.f1458a;
        return (ua1 == null || ua1.P0() == null) ? false : true;
    }

    public final void o(Context context, AttributeSet attributeSet, int i) {
        TypedArray h = mc1.h(context, attributeSet, x91.Chip, i, a, new int[0]);
        this.f = h.getBoolean(x91.Chip_ensureMinTouchTargetSize, false);
        this.c = (int) Math.ceil((double) h.getDimension(x91.Chip_chipMinTouchTargetSize, (float) Math.ceil((double) nc1.b(getContext(), 48))));
        h.recycle();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        id1.f(this, this.f1458a);
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (isChecked()) {
            CheckBox.mergeDrawableStates(onCreateDrawableState, f1451a);
        }
        if (r()) {
            CheckBox.mergeDrawableStates(onCreateDrawableState, b);
        }
        return onCreateDrawableState;
    }

    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        this.f1457a.I(z, i, rect);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        boolean z;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 7) {
            if (actionMasked == 10) {
                z = false;
            }
            return super.onHoverEvent(motionEvent);
        }
        z = getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY());
        setCloseIconHovered(z);
        return super.onHoverEvent(motionEvent);
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName((r() || isClickable()) ? r() ? "android.widget.CompoundButton" : "android.widget.Button" : "android.view.View");
        accessibilityNodeInfo.setCheckable(r());
        accessibilityNodeInfo.setClickable(isClickable());
        if (getParent() instanceof ChipGroup) {
            ChipGroup chipGroup = (ChipGroup) getParent();
            jb.v0(accessibilityNodeInfo).Z(jb.c.a(chipGroup.b(this), 1, chipGroup.c() ? chipGroup.o(this) : -1, 1, false, isChecked()));
        }
    }

    @TargetApi(24)
    public PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i) {
        if (!getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()) || !isEnabled()) {
            return null;
        }
        return PointerIcon.getSystemIcon(getContext(), 1002);
    }

    @TargetApi(17)
    public void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        if (this.f1460b != i) {
            this.f1460b = i;
            A();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x001e, code lost:
        if (r0 != 3) goto L_0x0040;
     */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0049 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    @android.annotation.SuppressLint({"ClickableViewAccessibility"})
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            int r0 = r6.getActionMasked()
            android.graphics.RectF r1 = r5.getCloseIconTouchBounds()
            float r2 = r6.getX()
            float r3 = r6.getY()
            boolean r1 = r1.contains(r2, r3)
            r2 = 0
            r3 = 1
            if (r0 == 0) goto L_0x0039
            if (r0 == r3) goto L_0x002b
            r4 = 2
            if (r0 == r4) goto L_0x0021
            r1 = 3
            if (r0 == r1) goto L_0x0034
            goto L_0x0040
        L_0x0021:
            boolean r0 = r5.f1463c
            if (r0 == 0) goto L_0x0040
            if (r1 != 0) goto L_0x003e
            r5.setCloseIconPressed(r2)
            goto L_0x003e
        L_0x002b:
            boolean r0 = r5.f1463c
            if (r0 == 0) goto L_0x0034
            r5.t()
            r0 = 1
            goto L_0x0035
        L_0x0034:
            r0 = 0
        L_0x0035:
            r5.setCloseIconPressed(r2)
            goto L_0x0041
        L_0x0039:
            if (r1 == 0) goto L_0x0040
            r5.setCloseIconPressed(r3)
        L_0x003e:
            r0 = 1
            goto L_0x0041
        L_0x0040:
            r0 = 0
        L_0x0041:
            if (r0 != 0) goto L_0x0049
            boolean r6 = super.onTouchEvent(r6)
            if (r6 == 0) goto L_0x004a
        L_0x0049:
            r2 = 1
        L_0x004a:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void p() {
        if (Build.VERSION.SDK_INT >= 21) {
            setOutlineProvider(new b());
        }
    }

    public final void q(int i, int i2, int i3, int i4) {
        this.f1453a = new InsetDrawable(this.f1458a, i, i2, i3, i4);
    }

    public boolean r() {
        ua1 ua1 = this.f1458a;
        return ua1 != null && ua1.m1();
    }

    public boolean s() {
        ua1 ua1 = this.f1458a;
        return ua1 != null && ua1.o1();
    }

    public void setBackground(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f1454a) {
            super.setBackground(drawable);
        }
    }

    public void setBackgroundColor(int i) {
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f1454a) {
            super.setBackgroundDrawable(drawable);
        }
    }

    public void setBackgroundResource(int i) {
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
    }

    public void setCheckable(boolean z) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.v1(z);
        }
    }

    public void setCheckableResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.w1(i);
        }
    }

    public void setChecked(boolean z) {
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
        ua1 ua1 = this.f1458a;
        if (ua1 == null) {
            this.f1462b = z;
        } else if (ua1.m1()) {
            boolean isChecked = isChecked();
            super.setChecked(z);
            if (isChecked != z && (onCheckedChangeListener = this.f1456a) != null) {
                onCheckedChangeListener.onCheckedChanged(this, z);
            }
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.x1(drawable);
        }
    }

    @Deprecated
    public void setCheckedIconEnabled(boolean z) {
        setCheckedIconVisible(z);
    }

    @Deprecated
    public void setCheckedIconEnabledResource(int i) {
        setCheckedIconVisible(i);
    }

    public void setCheckedIconResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.y1(i);
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.z1(colorStateList);
        }
    }

    public void setCheckedIconTintResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.A1(i);
        }
    }

    public void setCheckedIconVisible(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.B1(i);
        }
    }

    public void setCheckedIconVisible(boolean z) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.C1(z);
        }
    }

    public void setChipBackgroundColor(ColorStateList colorStateList) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.D1(colorStateList);
        }
    }

    public void setChipBackgroundColorResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.E1(i);
        }
    }

    @Deprecated
    public void setChipCornerRadius(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.F1(f2);
        }
    }

    @Deprecated
    public void setChipCornerRadiusResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.G1(i);
        }
    }

    public void setChipDrawable(ua1 ua1) {
        ua1 ua12 = this.f1458a;
        if (ua12 != ua1) {
            w(ua12);
            this.f1458a = ua1;
            ua1.y2(false);
            i(this.f1458a);
            k(this.c);
        }
    }

    public void setChipEndPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.H1(f2);
        }
    }

    public void setChipEndPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.I1(i);
        }
    }

    public void setChipIcon(Drawable drawable) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.J1(drawable);
        }
    }

    @Deprecated
    public void setChipIconEnabled(boolean z) {
        setChipIconVisible(z);
    }

    @Deprecated
    public void setChipIconEnabledResource(int i) {
        setChipIconVisible(i);
    }

    public void setChipIconResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.K1(i);
        }
    }

    public void setChipIconSize(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.L1(f2);
        }
    }

    public void setChipIconSizeResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.M1(i);
        }
    }

    public void setChipIconTint(ColorStateList colorStateList) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.N1(colorStateList);
        }
    }

    public void setChipIconTintResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.O1(i);
        }
    }

    public void setChipIconVisible(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.P1(i);
        }
    }

    public void setChipIconVisible(boolean z) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.Q1(z);
        }
    }

    public void setChipMinHeight(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.R1(f2);
        }
    }

    public void setChipMinHeightResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.S1(i);
        }
    }

    public void setChipStartPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.T1(f2);
        }
    }

    public void setChipStartPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.U1(i);
        }
    }

    public void setChipStrokeColor(ColorStateList colorStateList) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.V1(colorStateList);
        }
    }

    public void setChipStrokeColorResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.W1(i);
        }
    }

    public void setChipStrokeWidth(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.X1(f2);
        }
    }

    public void setChipStrokeWidthResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.Y1(i);
        }
    }

    @Deprecated
    public void setChipText(CharSequence charSequence) {
        setText(charSequence);
    }

    @Deprecated
    public void setChipTextResource(int i) {
        setText(getResources().getString(i));
    }

    public void setCloseIcon(Drawable drawable) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.a2(drawable);
        }
        x();
    }

    public void setCloseIconContentDescription(CharSequence charSequence) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.b2(charSequence);
        }
    }

    @Deprecated
    public void setCloseIconEnabled(boolean z) {
        setCloseIconVisible(z);
    }

    @Deprecated
    public void setCloseIconEnabledResource(int i) {
        setCloseIconVisible(i);
    }

    public void setCloseIconEndPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.c2(f2);
        }
    }

    public void setCloseIconEndPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.d2(i);
        }
    }

    public void setCloseIconResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.e2(i);
        }
        x();
    }

    public void setCloseIconSize(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.f2(f2);
        }
    }

    public void setCloseIconSizeResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.g2(i);
        }
    }

    public void setCloseIconStartPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.h2(f2);
        }
    }

    public void setCloseIconStartPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.i2(i);
        }
    }

    public void setCloseIconTint(ColorStateList colorStateList) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.k2(colorStateList);
        }
    }

    public void setCloseIconTintResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.l2(i);
        }
    }

    public void setCloseIconVisible(int i) {
        setCloseIconVisible(getResources().getBoolean(i));
    }

    public void setCloseIconVisible(boolean z) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.m2(z);
        }
        x();
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        if (i != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (i3 == 0) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(i, i2, i3, i4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        if (i != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (i3 == 0) {
            super.setCompoundDrawablesWithIntrinsicBounds(i, i2, i3, i4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
        }
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.V(f2);
        }
    }

    public void setEllipsize(TextUtils.TruncateAt truncateAt) {
        if (this.f1458a != null) {
            if (truncateAt != TextUtils.TruncateAt.MARQUEE) {
                super.setEllipsize(truncateAt);
                ua1 ua1 = this.f1458a;
                if (ua1 != null) {
                    ua1.o2(truncateAt);
                    return;
                }
                return;
            }
            throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
        }
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        this.f = z;
        k(this.c);
    }

    public void setGravity(int i) {
        if (i == 8388627) {
            super.setGravity(i);
        }
    }

    public void setHideMotionSpec(fa1 fa1) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.p2(fa1);
        }
    }

    public void setHideMotionSpecResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.q2(i);
        }
    }

    public void setIconEndPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.r2(f2);
        }
    }

    public void setIconEndPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.s2(i);
        }
    }

    public void setIconStartPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.t2(f2);
        }
    }

    public void setIconStartPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.u2(i);
        }
    }

    public void setLayoutDirection(int i) {
        if (this.f1458a != null && Build.VERSION.SDK_INT >= 17) {
            super.setLayoutDirection(i);
        }
    }

    public void setLines(int i) {
        if (i <= 1) {
            super.setLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setMaxLines(int i) {
        if (i <= 1) {
            super.setMaxLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setMaxWidth(int i) {
        super.setMaxWidth(i);
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.v2(i);
        }
    }

    public void setMinLines(int i) {
        if (i <= 1) {
            super.setMinLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setOnCheckedChangeListenerInternal(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f1456a = onCheckedChangeListener;
    }

    public void setOnCloseIconClickListener(View.OnClickListener onClickListener) {
        this.f1455a = onClickListener;
        x();
    }

    public void setRippleColor(ColorStateList colorStateList) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.w2(colorStateList);
        }
        if (!this.f1458a.k1()) {
            z();
        }
    }

    public void setRippleColorResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.x2(i);
            if (!this.f1458a.k1()) {
                z();
            }
        }
    }

    public void setShapeAppearanceModel(ld1 ld1) {
        this.f1458a.setShapeAppearanceModel(ld1);
    }

    public void setShowMotionSpec(fa1 fa1) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.z2(fa1);
        }
    }

    public void setShowMotionSpecResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.A2(i);
        }
    }

    public void setSingleLine(boolean z) {
        if (z) {
            super.setSingleLine(z);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            if (charSequence == null) {
                charSequence = "";
            }
            super.setText(ua1.J2() ? null : charSequence, bufferType);
            ua1 ua12 = this.f1458a;
            if (ua12 != null) {
                ua12.B2(charSequence);
            }
        }
    }

    public void setTextAppearance(int i) {
        super.setTextAppearance(i);
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.D2(i);
        }
        B();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.D2(i);
        }
        B();
    }

    public void setTextAppearance(uc1 uc1) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.C2(uc1);
        }
        B();
    }

    public void setTextAppearanceResource(int i) {
        setTextAppearance(getContext(), i);
    }

    public void setTextEndPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.E2(f2);
        }
    }

    public void setTextEndPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.F2(i);
        }
    }

    public void setTextStartPadding(float f2) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.G2(f2);
        }
    }

    public void setTextStartPaddingResource(int i) {
        ua1 ua1 = this.f1458a;
        if (ua1 != null) {
            ua1.H2(i);
        }
    }

    public boolean t() {
        boolean z = false;
        playSoundEffect(0);
        View.OnClickListener onClickListener = this.f1455a;
        if (onClickListener != null) {
            onClickListener.onClick(this);
            z = true;
        }
        this.f1457a.U(1, 1);
        return z;
    }

    public final void u() {
        if (this.f1453a != null) {
            this.f1453a = null;
            setMinWidth(0);
            setMinHeight((int) getChipMinHeight());
            y();
        }
    }

    public boolean v() {
        return this.f;
    }

    public final void w(ua1 ua1) {
        if (ua1 != null) {
            ua1.n2((ua1.a) null);
        }
    }

    public final void x() {
        ya.o0(this, (!n() || !s() || this.f1455a == null) ? null : this.f1457a);
    }

    public final void y() {
        if (yc1.f5989a) {
            z();
            return;
        }
        this.f1458a.I2(true);
        ya.r0(this, getBackgroundDrawable());
        A();
        l();
    }

    public final void z() {
        this.f1454a = new RippleDrawable(yc1.a(this.f1458a.d1()), getBackgroundDrawable(), (Drawable) null);
        this.f1458a.I2(false);
        ya.r0(this, this.f1454a);
        A();
    }
}
