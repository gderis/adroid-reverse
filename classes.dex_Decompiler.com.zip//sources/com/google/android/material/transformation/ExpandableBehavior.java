package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.List;

@Deprecated
public abstract class ExpandableBehavior extends CoordinatorLayout.c<View> {
    public int a = 0;

    public class a implements ViewTreeObserver.OnPreDrawListener {
        public final /* synthetic */ int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ View f1597a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ yb1 f1599a;

        public a(View view, int i, yb1 yb1) {
            this.f1597a = view;
            this.a = i;
            this.f1599a = yb1;
        }

        public boolean onPreDraw() {
            this.f1597a.getViewTreeObserver().removeOnPreDrawListener(this);
            if (ExpandableBehavior.this.a == this.a) {
                ExpandableBehavior expandableBehavior = ExpandableBehavior.this;
                yb1 yb1 = this.f1599a;
                expandableBehavior.H((View) yb1, this.f1597a, yb1.a(), false);
            }
            return false;
        }
    }

    public ExpandableBehavior() {
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public final boolean F(boolean z) {
        if (!z) {
            return this.a == 1;
        }
        int i = this.a;
        return i == 0 || i == 2;
    }

    public yb1 G(CoordinatorLayout coordinatorLayout, View view) {
        List<View> r = coordinatorLayout.r(view);
        int size = r.size();
        for (int i = 0; i < size; i++) {
            View view2 = r.get(i);
            if (e(coordinatorLayout, view, view2)) {
                return (yb1) view2;
            }
        }
        return null;
    }

    public abstract boolean H(View view, View view2, boolean z, boolean z2);

    public boolean h(CoordinatorLayout coordinatorLayout, View view, View view2) {
        yb1 yb1 = (yb1) view2;
        if (!F(yb1.a())) {
            return false;
        }
        this.a = yb1.a() ? 1 : 2;
        return H((View) yb1, view, yb1.a(), true);
    }

    public boolean l(CoordinatorLayout coordinatorLayout, View view, int i) {
        yb1 G;
        if (ya.T(view) || (G = G(coordinatorLayout, view)) == null || !F(G.a())) {
            return false;
        }
        int i2 = G.a() ? 1 : 2;
        this.a = i2;
        view.getViewTreeObserver().addOnPreDrawListener(new a(view, i2, G));
        return false;
    }
}
