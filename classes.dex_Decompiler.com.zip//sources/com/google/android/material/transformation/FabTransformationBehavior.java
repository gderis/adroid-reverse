package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Pair;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import defpackage.ya1;
import java.util.ArrayList;
import java.util.List;

@Deprecated
public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {
    public float a;

    /* renamed from: a  reason: collision with other field name */
    public final Rect f1600a = new Rect();

    /* renamed from: a  reason: collision with other field name */
    public final RectF f1601a = new RectF();

    /* renamed from: a  reason: collision with other field name */
    public final int[] f1602a = new int[2];
    public float b;

    /* renamed from: b  reason: collision with other field name */
    public final RectF f1603b = new RectF();

    public class a extends AnimatorListenerAdapter {
        public final /* synthetic */ View a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ boolean f1605a;
        public final /* synthetic */ View b;

        public a(boolean z, View view, View view2) {
            this.f1605a = z;
            this.a = view;
            this.b = view2;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f1605a) {
                this.a.setVisibility(4);
                this.b.setAlpha(1.0f);
                this.b.setVisibility(0);
            }
        }

        public void onAnimationStart(Animator animator) {
            if (this.f1605a) {
                this.a.setVisibility(0);
                this.b.setAlpha(0.0f);
                this.b.setVisibility(4);
            }
        }
    }

    public class b implements ValueAnimator.AnimatorUpdateListener {
        public final /* synthetic */ View a;

        public b(View view) {
            this.a = view;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.a.invalidate();
        }
    }

    public class c extends AnimatorListenerAdapter {
        public final /* synthetic */ Drawable a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ ya1 f1608a;

        public c(ya1 ya1, Drawable drawable) {
            this.f1608a = ya1;
            this.a = drawable;
        }

        public void onAnimationEnd(Animator animator) {
            this.f1608a.setCircularRevealOverlayDrawable((Drawable) null);
        }

        public void onAnimationStart(Animator animator) {
            this.f1608a.setCircularRevealOverlayDrawable(this.a);
        }
    }

    public class d extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ ya1 f1609a;

        public d(ya1 ya1) {
            this.f1609a = ya1;
        }

        public void onAnimationEnd(Animator animator) {
            ya1.e revealInfo = this.f1609a.getRevealInfo();
            revealInfo.c = Float.MAX_VALUE;
            this.f1609a.setRevealInfo(revealInfo);
        }
    }

    public static class e {
        public fa1 a;

        /* renamed from: a  reason: collision with other field name */
        public ha1 f1610a;
    }

    public FabTransformationBehavior() {
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public AnimatorSet J(View view, View view2, boolean z, boolean z2) {
        boolean z3 = z;
        e e0 = e0(view2.getContext(), z3);
        if (z3) {
            this.a = view.getTranslationX();
            this.b = view.getTranslationY();
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (Build.VERSION.SDK_INT >= 21) {
            X(view, view2, z, z2, e0, arrayList, arrayList2);
        }
        RectF rectF = this.f1601a;
        View view3 = view;
        View view4 = view2;
        boolean z4 = z;
        ArrayList arrayList3 = arrayList;
        ArrayList arrayList4 = arrayList2;
        c0(view3, view4, z4, z2, e0, arrayList3, arrayList4, rectF);
        float width = rectF.width();
        float height = rectF.height();
        W(view3, view4, z4, e0, arrayList);
        boolean z5 = z2;
        e eVar = e0;
        Z(view3, view4, z4, z5, eVar, arrayList3, arrayList4);
        Y(view3, view4, z4, z5, eVar, width, height, arrayList, arrayList2);
        ArrayList arrayList5 = arrayList;
        ArrayList arrayList6 = arrayList2;
        V(view3, view4, z4, z5, eVar, arrayList5, arrayList6);
        U(view3, view4, z4, z5, eVar, arrayList5, arrayList6);
        AnimatorSet animatorSet = new AnimatorSet();
        z91.a(animatorSet, arrayList);
        animatorSet.addListener(new a(z3, view2, view));
        int size = arrayList2.size();
        for (int i = 0; i < size; i++) {
            animatorSet.addListener((Animator.AnimatorListener) arrayList2.get(i));
        }
        return animatorSet;
    }

    public final ViewGroup K(View view) {
        View findViewById = view.findViewById(s91.mtrl_child_content_container);
        return findViewById != null ? f0(findViewById) : ((view instanceof je1) || (view instanceof ie1)) ? f0(((ViewGroup) view).getChildAt(0)) : f0(view);
    }

    public final void L(View view, e eVar, ga1 ga1, ga1 ga12, float f, float f2, float f3, float f4, RectF rectF) {
        float S = S(eVar, ga1, f, f3);
        float S2 = S(eVar, ga12, f2, f4);
        Rect rect = this.f1600a;
        view.getWindowVisibleDisplayFrame(rect);
        RectF rectF2 = this.f1601a;
        rectF2.set(rect);
        RectF rectF3 = this.f1603b;
        T(view, rectF3);
        rectF3.offset(S, S2);
        rectF3.intersect(rectF2);
        rectF.set(rectF3);
    }

    public final void M(View view, RectF rectF) {
        T(view, rectF);
        rectF.offset(this.a, this.b);
    }

    public final Pair<ga1, ga1> N(float f, float f2, boolean z, e eVar) {
        String str;
        fa1 fa1;
        ga1 ga1;
        if (f == 0.0f || f2 == 0.0f) {
            ga1 = eVar.a.e("translationXLinear");
            fa1 = eVar.a;
            str = "translationYLinear";
        } else if ((!z || f2 >= 0.0f) && (z || f2 <= 0.0f)) {
            ga1 = eVar.a.e("translationXCurveDownwards");
            fa1 = eVar.a;
            str = "translationYCurveDownwards";
        } else {
            ga1 = eVar.a.e("translationXCurveUpwards");
            fa1 = eVar.a;
            str = "translationYCurveUpwards";
        }
        return new Pair<>(ga1, fa1.e(str));
    }

    public final float O(View view, View view2, ha1 ha1) {
        RectF rectF = this.f1601a;
        RectF rectF2 = this.f1603b;
        M(view, rectF);
        T(view2, rectF2);
        rectF2.offset(-Q(view, view2, ha1), 0.0f);
        return rectF.centerX() - rectF2.left;
    }

    public final float P(View view, View view2, ha1 ha1) {
        RectF rectF = this.f1601a;
        RectF rectF2 = this.f1603b;
        M(view, rectF);
        T(view2, rectF2);
        rectF2.offset(0.0f, -R(view, view2, ha1));
        return rectF.centerY() - rectF2.top;
    }

    public final float Q(View view, View view2, ha1 ha1) {
        float f;
        float f2;
        float f3;
        RectF rectF = this.f1601a;
        RectF rectF2 = this.f1603b;
        M(view, rectF);
        T(view2, rectF2);
        int i = ha1.f2779a & 7;
        if (i == 1) {
            f3 = rectF2.centerX();
            f2 = rectF.centerX();
        } else if (i == 3) {
            f3 = rectF2.left;
            f2 = rectF.left;
        } else if (i != 5) {
            f = 0.0f;
            return f + ha1.a;
        } else {
            f3 = rectF2.right;
            f2 = rectF.right;
        }
        f = f3 - f2;
        return f + ha1.a;
    }

    public final float R(View view, View view2, ha1 ha1) {
        float f;
        float f2;
        float f3;
        RectF rectF = this.f1601a;
        RectF rectF2 = this.f1603b;
        M(view, rectF);
        T(view2, rectF2);
        int i = ha1.f2779a & 112;
        if (i == 16) {
            f3 = rectF2.centerY();
            f2 = rectF.centerY();
        } else if (i == 48) {
            f3 = rectF2.top;
            f2 = rectF.top;
        } else if (i != 80) {
            f = 0.0f;
            return f + ha1.b;
        } else {
            f3 = rectF2.bottom;
            f2 = rectF.bottom;
        }
        f = f3 - f2;
        return f + ha1.b;
    }

    public final float S(e eVar, ga1 ga1, float f, float f2) {
        long c2 = ga1.c();
        long d2 = ga1.d();
        ga1 e2 = eVar.a.e("expansion");
        return y91.a(f, f2, ga1.e().getInterpolation(((float) (((e2.c() + e2.d()) + 17) - c2)) / ((float) d2)));
    }

    public final void T(View view, RectF rectF) {
        rectF.set(0.0f, 0.0f, (float) view.getWidth(), (float) view.getHeight());
        int[] iArr = this.f1602a;
        view.getLocationInWindow(iArr);
        rectF.offsetTo((float) iArr[0], (float) iArr[1]);
        rectF.offset((float) ((int) (-view.getTranslationX())), (float) ((int) (-view.getTranslationY())));
    }

    public final void U(View view, View view2, boolean z, boolean z2, e eVar, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ViewGroup K;
        ObjectAnimator objectAnimator;
        if (view2 instanceof ViewGroup) {
            if ((!(view2 instanceof ya1) || xa1.a != 0) && (K = K(view2)) != null) {
                if (z) {
                    if (!z2) {
                        ba1.a.set(K, Float.valueOf(0.0f));
                    }
                    objectAnimator = ObjectAnimator.ofFloat(K, ba1.a, new float[]{1.0f});
                } else {
                    objectAnimator = ObjectAnimator.ofFloat(K, ba1.a, new float[]{0.0f});
                }
                eVar.a.e("contentFade").a(objectAnimator);
                list.add(objectAnimator);
            }
        }
    }

    public final void V(View view, View view2, boolean z, boolean z2, e eVar, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ObjectAnimator objectAnimator;
        if (view2 instanceof ya1) {
            ya1 ya1 = (ya1) view2;
            int d0 = d0(view);
            int i = 16777215 & d0;
            if (z) {
                if (!z2) {
                    ya1.setCircularRevealScrimColor(d0);
                }
                objectAnimator = ObjectAnimator.ofInt(ya1, ya1.d.a, new int[]{i});
            } else {
                objectAnimator = ObjectAnimator.ofInt(ya1, ya1.d.a, new int[]{d0});
            }
            objectAnimator.setEvaluator(aa1.b());
            eVar.a.e("color").a(objectAnimator);
            list.add(objectAnimator);
        }
    }

    public final void W(View view, View view2, boolean z, e eVar, List<Animator> list) {
        float Q = Q(view, view2, eVar.f1610a);
        float R = R(view, view2, eVar.f1610a);
        Pair<ga1, ga1> N = N(Q, R, z, eVar);
        ga1 ga1 = (ga1) N.first;
        ga1 ga12 = (ga1) N.second;
        Property property = View.TRANSLATION_X;
        float[] fArr = new float[1];
        if (!z) {
            Q = this.a;
        }
        fArr[0] = Q;
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, property, fArr);
        Property property2 = View.TRANSLATION_Y;
        float[] fArr2 = new float[1];
        if (!z) {
            R = this.b;
        }
        fArr2[0] = R;
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(view, property2, fArr2);
        ga1.a(ofFloat);
        ga12.a(ofFloat2);
        list.add(ofFloat);
        list.add(ofFloat2);
    }

    @TargetApi(21)
    public final void X(View view, View view2, boolean z, boolean z2, e eVar, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ObjectAnimator objectAnimator;
        float w = ya.w(view2) - ya.w(view);
        if (z) {
            if (!z2) {
                view2.setTranslationZ(-w);
            }
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Z, new float[]{0.0f});
        } else {
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Z, new float[]{-w});
        }
        eVar.a.e("elevation").a(objectAnimator);
        list.add(objectAnimator);
    }

    public final void Y(View view, View view2, boolean z, boolean z2, e eVar, float f, float f2, List<Animator> list, List<Animator.AnimatorListener> list2) {
        Animator animator;
        View view3 = view;
        View view4 = view2;
        e eVar2 = eVar;
        if (view4 instanceof ya1) {
            ya1 ya1 = (ya1) view4;
            float O = O(view3, view4, eVar2.f1610a);
            float P = P(view3, view4, eVar2.f1610a);
            ((FloatingActionButton) view3).i(this.f1600a);
            float width = ((float) this.f1600a.width()) / 2.0f;
            ga1 e2 = eVar2.a.e("expansion");
            if (z) {
                if (!z2) {
                    ya1.setRevealInfo(new ya1.e(O, P, width));
                }
                if (z2) {
                    width = ya1.getRevealInfo().c;
                }
                animator = va1.a(ya1, O, P, pc1.b(O, P, 0.0f, 0.0f, f, f2));
                animator.addListener(new d(ya1));
                b0(view2, e2.c(), (int) O, (int) P, width, list);
            } else {
                float f3 = ya1.getRevealInfo().c;
                Animator a2 = va1.a(ya1, O, P, width);
                int i = (int) O;
                int i2 = (int) P;
                View view5 = view2;
                b0(view5, e2.c(), i, i2, f3, list);
                long c2 = e2.c();
                long d2 = e2.d();
                long f4 = eVar2.a.f();
                a0(view5, c2, d2, f4, i, i2, width, list);
                animator = a2;
            }
            e2.a(animator);
            list.add(animator);
            list2.add(va1.b(ya1));
        }
    }

    public final void Z(View view, View view2, boolean z, boolean z2, e eVar, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ObjectAnimator objectAnimator;
        if ((view2 instanceof ya1) && (view instanceof ImageView)) {
            ya1 ya1 = (ya1) view2;
            Drawable drawable = ((ImageView) view).getDrawable();
            if (drawable != null) {
                drawable.mutate();
                if (z) {
                    if (!z2) {
                        drawable.setAlpha(255);
                    }
                    objectAnimator = ObjectAnimator.ofInt(drawable, ca1.a, new int[]{0});
                } else {
                    objectAnimator = ObjectAnimator.ofInt(drawable, ca1.a, new int[]{255});
                }
                objectAnimator.addUpdateListener(new b(view2));
                eVar.a.e("iconFade").a(objectAnimator);
                list.add(objectAnimator);
                list2.add(new c(ya1, drawable));
            }
        }
    }

    public final void a0(View view, long j, long j2, long j3, int i, int i2, float f, List<Animator> list) {
        if (Build.VERSION.SDK_INT >= 21) {
            long j4 = j + j2;
            if (j4 < j3) {
                Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view, i, i2, f, f);
                createCircularReveal.setStartDelay(j4);
                createCircularReveal.setDuration(j3 - j4);
                list.add(createCircularReveal);
            }
        }
    }

    public final void b0(View view, long j, int i, int i2, float f, List<Animator> list) {
        if (Build.VERSION.SDK_INT >= 21 && j > 0) {
            Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view, i, i2, f, f);
            createCircularReveal.setStartDelay(0);
            createCircularReveal.setDuration(j);
            list.add(createCircularReveal);
        }
    }

    public final void c0(View view, View view2, boolean z, boolean z2, e eVar, List<Animator> list, List<Animator.AnimatorListener> list2, RectF rectF) {
        ObjectAnimator objectAnimator;
        ObjectAnimator objectAnimator2;
        View view3 = view;
        View view4 = view2;
        boolean z3 = z;
        e eVar2 = eVar;
        List<Animator> list3 = list;
        float Q = Q(view3, view4, eVar2.f1610a);
        float R = R(view3, view4, eVar2.f1610a);
        Pair<ga1, ga1> N = N(Q, R, z3, eVar2);
        ga1 ga1 = (ga1) N.first;
        ga1 ga12 = (ga1) N.second;
        if (z3) {
            if (!z2) {
                view4.setTranslationX(-Q);
                view4.setTranslationY(-R);
            }
            objectAnimator2 = ObjectAnimator.ofFloat(view4, View.TRANSLATION_X, new float[]{0.0f});
            objectAnimator = ObjectAnimator.ofFloat(view4, View.TRANSLATION_Y, new float[]{0.0f});
            L(view2, eVar, ga1, ga12, -Q, -R, 0.0f, 0.0f, rectF);
        } else {
            objectAnimator2 = ObjectAnimator.ofFloat(view4, View.TRANSLATION_X, new float[]{-Q});
            objectAnimator = ObjectAnimator.ofFloat(view4, View.TRANSLATION_Y, new float[]{-R});
        }
        ga1.a(objectAnimator2);
        ga12.a(objectAnimator);
        list3.add(objectAnimator2);
        list3.add(objectAnimator);
    }

    public final int d0(View view) {
        ColorStateList s = ya.s(view);
        if (s != null) {
            return s.getColorForState(view.getDrawableState(), s.getDefaultColor());
        }
        return 0;
    }

    public boolean e(CoordinatorLayout coordinatorLayout, View view, View view2) {
        if (view.getVisibility() == 8) {
            throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
        } else if (!(view2 instanceof FloatingActionButton)) {
            return false;
        } else {
            int expandedComponentIdHint = ((FloatingActionButton) view2).getExpandedComponentIdHint();
            return expandedComponentIdHint == 0 || expandedComponentIdHint == view.getId();
        }
    }

    public abstract e e0(Context context, boolean z);

    public final ViewGroup f0(View view) {
        if (view instanceof ViewGroup) {
            return (ViewGroup) view;
        }
        return null;
    }

    public void g(CoordinatorLayout.f fVar) {
        if (fVar.f == 0) {
            fVar.f = 80;
        }
    }
}
