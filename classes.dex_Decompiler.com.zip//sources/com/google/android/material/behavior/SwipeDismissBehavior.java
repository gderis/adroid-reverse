package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import defpackage.jb;
import defpackage.jc;
import defpackage.mb;

public class SwipeDismissBehavior<V extends View> extends CoordinatorLayout.c<V> {
    public float a = 0.0f;

    /* renamed from: a  reason: collision with other field name */
    public int f1380a = 2;

    /* renamed from: a  reason: collision with other field name */
    public c f1381a;

    /* renamed from: a  reason: collision with other field name */
    public final jc.c f1382a = new a();

    /* renamed from: a  reason: collision with other field name */
    public jc f1383a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f1384a;
    public float b = 0.5f;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1385b;
    public float c = 0.0f;
    public float d = 0.5f;

    public class a extends jc.c {
        public int a;
        public int b = -1;

        public a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
            if (r5 != false) goto L_0x001c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0010, code lost:
            if (r5 != false) goto L_0x0012;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:8:0x001c, code lost:
            r5 = r2.a;
            r3 = r3.getWidth() + r5;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int a(android.view.View r3, int r4, int r5) {
            /*
                r2 = this;
                int r5 = defpackage.ya.C(r3)
                r0 = 1
                if (r5 != r0) goto L_0x0009
                r5 = 1
                goto L_0x000a
            L_0x0009:
                r5 = 0
            L_0x000a:
                com.google.android.material.behavior.SwipeDismissBehavior r1 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r1 = r1.f1380a
                if (r1 != 0) goto L_0x0024
                if (r5 == 0) goto L_0x001c
            L_0x0012:
                int r5 = r2.a
                int r3 = r3.getWidth()
                int r5 = r5 - r3
                int r3 = r2.a
                goto L_0x0037
            L_0x001c:
                int r5 = r2.a
                int r3 = r3.getWidth()
                int r3 = r3 + r5
                goto L_0x0037
            L_0x0024:
                if (r1 != r0) goto L_0x0029
                if (r5 == 0) goto L_0x0012
                goto L_0x001c
            L_0x0029:
                int r5 = r2.a
                int r0 = r3.getWidth()
                int r5 = r5 - r0
                int r0 = r2.a
                int r3 = r3.getWidth()
                int r3 = r3 + r0
            L_0x0037:
                int r3 = com.google.android.material.behavior.SwipeDismissBehavior.G(r5, r4, r3)
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.a.a(android.view.View, int, int):int");
        }

        public int b(View view, int i, int i2) {
            return view.getTop();
        }

        public int d(View view) {
            return view.getWidth();
        }

        public void i(View view, int i) {
            this.b = i;
            this.a = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }

        public void j(int i) {
            c cVar = SwipeDismissBehavior.this.f1381a;
            if (cVar != null) {
                cVar.a(i);
            }
        }

        public void k(View view, int i, int i2, int i3, int i4) {
            float width = ((float) this.a) + (((float) view.getWidth()) * SwipeDismissBehavior.this.c);
            float width2 = ((float) this.a) + (((float) view.getWidth()) * SwipeDismissBehavior.this.d);
            float f = (float) i;
            if (f <= width) {
                view.setAlpha(1.0f);
            } else if (f >= width2) {
                view.setAlpha(0.0f);
            } else {
                view.setAlpha(SwipeDismissBehavior.F(0.0f, 1.0f - SwipeDismissBehavior.I(width, width2, f), 1.0f));
            }
        }

        public void l(View view, float f, float f2) {
            boolean z;
            int i;
            c cVar;
            this.b = -1;
            int width = view.getWidth();
            if (n(view, f)) {
                int left = view.getLeft();
                int i2 = this.a;
                i = left < i2 ? i2 - width : i2 + width;
                z = true;
            } else {
                i = this.a;
                z = false;
            }
            if (SwipeDismissBehavior.this.f1383a.F(i, view.getTop())) {
                ya.g0(view, new d(view, z));
            } else if (z && (cVar = SwipeDismissBehavior.this.f1381a) != null) {
                cVar.b(view);
            }
        }

        public boolean m(View view, int i) {
            int i2 = this.b;
            return (i2 == -1 || i2 == i) && SwipeDismissBehavior.this.E(view);
        }

        /* JADX WARNING: Removed duplicated region for block: B:15:0x0025 A[ORIG_RETURN, RETURN, SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:22:0x0034 A[ORIG_RETURN, RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final boolean n(android.view.View r6, float r7) {
            /*
                r5 = this;
                r0 = 0
                r1 = 0
                r2 = 1
                int r3 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
                if (r3 == 0) goto L_0x0036
                int r6 = defpackage.ya.C(r6)
                if (r6 != r2) goto L_0x000f
                r6 = 1
                goto L_0x0010
            L_0x000f:
                r6 = 0
            L_0x0010:
                com.google.android.material.behavior.SwipeDismissBehavior r3 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r3 = r3.f1380a
                r4 = 2
                if (r3 != r4) goto L_0x0018
                return r2
            L_0x0018:
                if (r3 != 0) goto L_0x0027
                if (r6 == 0) goto L_0x0021
                int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
                if (r6 >= 0) goto L_0x0026
                goto L_0x0025
            L_0x0021:
                int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
                if (r6 <= 0) goto L_0x0026
            L_0x0025:
                r1 = 1
            L_0x0026:
                return r1
            L_0x0027:
                if (r3 != r2) goto L_0x0035
                if (r6 == 0) goto L_0x0030
                int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
                if (r6 <= 0) goto L_0x0035
                goto L_0x0034
            L_0x0030:
                int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
                if (r6 >= 0) goto L_0x0035
            L_0x0034:
                r1 = 1
            L_0x0035:
                return r1
            L_0x0036:
                int r7 = r6.getLeft()
                int r0 = r5.a
                int r7 = r7 - r0
                int r6 = r6.getWidth()
                float r6 = (float) r6
                com.google.android.material.behavior.SwipeDismissBehavior r0 = com.google.android.material.behavior.SwipeDismissBehavior.this
                float r0 = r0.b
                float r6 = r6 * r0
                int r6 = java.lang.Math.round(r6)
                int r7 = java.lang.Math.abs(r7)
                if (r7 < r6) goto L_0x0053
                r1 = 1
            L_0x0053:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.a.n(android.view.View, float):boolean");
        }
    }

    public class b implements mb {
        public b() {
        }

        public boolean a(View view, mb.a aVar) {
            boolean z = false;
            if (!SwipeDismissBehavior.this.E(view)) {
                return false;
            }
            boolean z2 = ya.C(view) == 1;
            int i = SwipeDismissBehavior.this.f1380a;
            if ((i == 0 && z2) || (i == 1 && !z2)) {
                z = true;
            }
            int width = view.getWidth();
            if (z) {
                width = -width;
            }
            ya.Y(view, width);
            view.setAlpha(0.0f);
            c cVar = SwipeDismissBehavior.this.f1381a;
            if (cVar != null) {
                cVar.b(view);
            }
            return true;
        }
    }

    public interface c {
        void a(int i);

        void b(View view);
    }

    public class d implements Runnable {
        public final View a;
        public final boolean b;

        public d(View view, boolean z) {
            this.a = view;
            this.b = z;
        }

        public void run() {
            c cVar;
            jc jcVar = SwipeDismissBehavior.this.f1383a;
            if (jcVar != null && jcVar.k(true)) {
                ya.g0(this.a, this);
            } else if (this.b && (cVar = SwipeDismissBehavior.this.f1381a) != null) {
                cVar.b(this.a);
            }
        }
    }

    public static float F(float f, float f2, float f3) {
        return Math.min(Math.max(f, f2), f3);
    }

    public static int G(int i, int i2, int i3) {
        return Math.min(Math.max(i, i2), i3);
    }

    public static float I(float f, float f2, float f3) {
        return (f3 - f) / (f2 - f);
    }

    public boolean D(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        jc jcVar = this.f1383a;
        if (jcVar == null) {
            return false;
        }
        jcVar.z(motionEvent);
        return true;
    }

    public boolean E(View view) {
        return true;
    }

    public final void H(ViewGroup viewGroup) {
        if (this.f1383a == null) {
            this.f1383a = this.f1385b ? jc.l(viewGroup, this.a, this.f1382a) : jc.m(viewGroup, this.f1382a);
        }
    }

    public void J(float f) {
        this.d = F(0.0f, f, 1.0f);
    }

    public void K(float f) {
        this.c = F(0.0f, f, 1.0f);
    }

    public void L(int i) {
        this.f1380a = i;
    }

    public final void M(View view) {
        ya.i0(view, 1048576);
        if (E(view)) {
            ya.k0(view, jb.a.u, (CharSequence) null, new b());
        }
    }

    public boolean k(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        boolean z = this.f1384a;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            z = coordinatorLayout.B(v, (int) motionEvent.getX(), (int) motionEvent.getY());
            this.f1384a = z;
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f1384a = false;
        }
        if (!z) {
            return false;
        }
        H(coordinatorLayout);
        return this.f1383a.G(motionEvent);
    }

    public boolean l(CoordinatorLayout coordinatorLayout, V v, int i) {
        boolean l = super.l(coordinatorLayout, v, i);
        if (ya.A(v) == 0) {
            ya.x0(v, 1);
            M(v);
        }
        return l;
    }
}
