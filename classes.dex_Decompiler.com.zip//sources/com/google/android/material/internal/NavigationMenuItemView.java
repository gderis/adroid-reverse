package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import defpackage.e3;
import defpackage.p1;

public class NavigationMenuItemView extends gc1 implements p1.a {
    public static final int[] c = {16842912};
    public ColorStateList a;

    /* renamed from: a  reason: collision with other field name */
    public final CheckedTextView f1495a;

    /* renamed from: a  reason: collision with other field name */
    public FrameLayout f1496a;

    /* renamed from: a  reason: collision with other field name */
    public final da f1497a;

    /* renamed from: a  reason: collision with other field name */
    public k1 f1498a;

    /* renamed from: c  reason: collision with other field name */
    public Drawable f1499c;
    public boolean f;
    public boolean g;
    public boolean h;
    public int k;

    public class a extends da {
        public a() {
        }

        public void g(View view, jb jbVar) {
            super.g(view, jbVar);
            jbVar.U(NavigationMenuItemView.this.g);
        }
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a aVar = new a();
        this.f1497a = aVar;
        setOrientation(0);
        LayoutInflater.from(context).inflate(u91.design_navigation_menu_item, this, true);
        setIconSize(context.getResources().getDimensionPixelSize(q91.design_navigation_icon_size));
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(s91.design_menu_item_text);
        this.f1495a = checkedTextView;
        checkedTextView.setDuplicateParentStateEnabled(true);
        ya.o0(checkedTextView, aVar);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.f1496a == null) {
                this.f1496a = (FrameLayout) ((ViewStub) findViewById(s91.design_menu_item_action_area_stub)).inflate();
            }
            this.f1496a.removeAllViews();
            this.f1496a.addView(view);
        }
    }

    public final void B() {
        int i;
        e3.a aVar;
        if (D()) {
            this.f1495a.setVisibility(8);
            FrameLayout frameLayout = this.f1496a;
            if (frameLayout != null) {
                aVar = (e3.a) frameLayout.getLayoutParams();
                i = -1;
            } else {
                return;
            }
        } else {
            this.f1495a.setVisibility(0);
            FrameLayout frameLayout2 = this.f1496a;
            if (frameLayout2 != null) {
                aVar = (e3.a) frameLayout2.getLayoutParams();
                i = -2;
            } else {
                return;
            }
        }
        aVar.width = i;
        this.f1496a.setLayoutParams(aVar);
    }

    public final StateListDrawable C() {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(o.colorControlHighlight, typedValue, true)) {
            return null;
        }
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(c, new ColorDrawable(typedValue.data));
        stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
        return stateListDrawable;
    }

    public final boolean D() {
        return this.f1498a.getTitle() == null && this.f1498a.getIcon() == null && this.f1498a.getActionView() != null;
    }

    public boolean a() {
        return false;
    }

    public void f(k1 k1Var, int i) {
        this.f1498a = k1Var;
        if (k1Var.getItemId() > 0) {
            setId(k1Var.getItemId());
        }
        setVisibility(k1Var.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            ya.r0(this, C());
        }
        setCheckable(k1Var.isCheckable());
        setChecked(k1Var.isChecked());
        setEnabled(k1Var.isEnabled());
        setTitle(k1Var.getTitle());
        setIcon(k1Var.getIcon());
        setActionView(k1Var.getActionView());
        setContentDescription(k1Var.getContentDescription());
        u3.a(this, k1Var.getTooltipText());
        B();
    }

    public k1 getItemData() {
        return this.f1498a;
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        k1 k1Var = this.f1498a;
        if (k1Var != null && k1Var.isCheckable() && this.f1498a.isChecked()) {
            ViewGroup.mergeDrawableStates(onCreateDrawableState, c);
        }
        return onCreateDrawableState;
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.g != z) {
            this.g = z;
            this.f1497a.l(this.f1495a, 2048);
        }
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        this.f1495a.setChecked(z);
    }

    public void setHorizontalPadding(int i) {
        setPadding(i, 0, i, 0);
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.h) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = m8.r(drawable).mutate();
                m8.o(drawable, this.a);
            }
            int i = this.k;
            drawable.setBounds(0, 0, i, i);
        } else if (this.f) {
            if (this.f1499c == null) {
                Drawable a2 = z7.a(getResources(), r91.navigation_empty_icon, getContext().getTheme());
                this.f1499c = a2;
                if (a2 != null) {
                    int i2 = this.k;
                    a2.setBounds(0, 0, i2, i2);
                }
            }
            drawable = this.f1499c;
        }
        yb.i(this.f1495a, drawable, (Drawable) null, (Drawable) null, (Drawable) null);
    }

    public void setIconPadding(int i) {
        this.f1495a.setCompoundDrawablePadding(i);
    }

    public void setIconSize(int i) {
        this.k = i;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.a = colorStateList;
        this.h = colorStateList != null;
        k1 k1Var = this.f1498a;
        if (k1Var != null) {
            setIcon(k1Var.getIcon());
        }
    }

    public void setMaxLines(int i) {
        this.f1495a.setMaxLines(i);
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.f = z;
    }

    public void setTextAppearance(int i) {
        yb.n(this.f1495a, i);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f1495a.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.f1495a.setText(charSequence);
    }
}
