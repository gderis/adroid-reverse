package com.google.android.material.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class MaterialButton extends a2 implements Checkable, od1 {
    public static final int a = w91.Widget_MaterialComponents_Button;

    /* renamed from: a  reason: collision with other field name */
    public static final int[] f1432a = {16842911};
    public static final int[] b = {16842912};

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f1433a;

    /* renamed from: a  reason: collision with other field name */
    public PorterDuff.Mode f1434a;

    /* renamed from: a  reason: collision with other field name */
    public Drawable f1435a;

    /* renamed from: a  reason: collision with other field name */
    public b f1436a;

    /* renamed from: a  reason: collision with other field name */
    public final LinkedHashSet<a> f1437a;

    /* renamed from: a  reason: collision with other field name */
    public final pa1 f1438a;

    /* renamed from: b  reason: collision with other field name */
    public int f1439b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1440b;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1441c;
    public int d;
    public int e;
    public int f;

    public interface a {
        void a(MaterialButton materialButton, boolean z);
    }

    public interface b {
        void a(MaterialButton materialButton, boolean z);
    }

    public static class c extends gc {
        public static final Parcelable.Creator<c> CREATOR = new a();
        public boolean b;

        public static class a implements Parcelable.ClassLoaderCreator<c> {
            /* renamed from: a */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public c createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new c(parcel, classLoader);
            }

            /* renamed from: c */
            public c[] newArray(int i) {
                return new c[i];
            }
        }

        public c(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                c.class.getClassLoader();
            }
            b(parcel);
        }

        public c(Parcelable parcelable) {
            super(parcelable);
        }

        public final void b(Parcel parcel) {
            boolean z = true;
            if (parcel.readInt() != 1) {
                z = false;
            }
            this.b = z;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.b ? 1 : 0);
        }
    }

    public MaterialButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.materialButtonStyle);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MaterialButton(android.content.Context r9, android.util.AttributeSet r10, int r11) {
        /*
            r8 = this;
            int r6 = a
            android.content.Context r9 = defpackage.ee1.c(r9, r10, r11, r6)
            r8.<init>(r9, r10, r11)
            java.util.LinkedHashSet r9 = new java.util.LinkedHashSet
            r9.<init>()
            r8.f1437a = r9
            r9 = 0
            r8.f1440b = r9
            r8.f1441c = r9
            android.content.Context r7 = r8.getContext()
            int[] r2 = defpackage.x91.MaterialButton
            int[] r5 = new int[r9]
            r0 = r7
            r1 = r10
            r3 = r11
            r4 = r6
            android.content.res.TypedArray r0 = defpackage.mc1.h(r0, r1, r2, r3, r4, r5)
            int r1 = defpackage.x91.MaterialButton_iconPadding
            int r1 = r0.getDimensionPixelSize(r1, r9)
            r8.e = r1
            int r1 = defpackage.x91.MaterialButton_iconTintMode
            r2 = -1
            int r1 = r0.getInt(r1, r2)
            android.graphics.PorterDuff$Mode r2 = android.graphics.PorterDuff.Mode.SRC_IN
            android.graphics.PorterDuff$Mode r1 = defpackage.nc1.e(r1, r2)
            r8.f1434a = r1
            android.content.Context r1 = r8.getContext()
            int r2 = defpackage.x91.MaterialButton_iconTint
            android.content.res.ColorStateList r1 = defpackage.tc1.a(r1, r0, r2)
            r8.f1433a = r1
            android.content.Context r1 = r8.getContext()
            int r2 = defpackage.x91.MaterialButton_icon
            android.graphics.drawable.Drawable r1 = defpackage.tc1.d(r1, r0, r2)
            r8.f1435a = r1
            int r1 = defpackage.x91.MaterialButton_iconGravity
            r2 = 1
            int r1 = r0.getInteger(r1, r2)
            r8.f = r1
            int r1 = defpackage.x91.MaterialButton_iconSize
            int r1 = r0.getDimensionPixelSize(r1, r9)
            r8.f1439b = r1
            ld1$b r10 = defpackage.ld1.e(r7, r10, r11, r6)
            ld1 r10 = r10.m()
            pa1 r11 = new pa1
            r11.<init>(r8, r10)
            r8.f1438a = r11
            r11.q(r0)
            r0.recycle()
            int r10 = r8.e
            r8.setCompoundDrawablePadding(r10)
            android.graphics.drawable.Drawable r10 = r8.f1435a
            if (r10 == 0) goto L_0x0084
            r9 = 1
        L_0x0084:
            r8.j(r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.button.MaterialButton.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    private String getA11yClassName() {
        return (b() ? CompoundButton.class : Button.class).getName();
    }

    private int getTextHeight() {
        TextPaint paint = getPaint();
        String charSequence = getText().toString();
        if (getTransformationMethod() != null) {
            charSequence = getTransformationMethod().getTransformation(charSequence, this).toString();
        }
        Rect rect = new Rect();
        paint.getTextBounds(charSequence, 0, charSequence.length(), rect);
        return Math.min(rect.height(), getLayout().getHeight());
    }

    private int getTextWidth() {
        TextPaint paint = getPaint();
        String charSequence = getText().toString();
        if (getTransformationMethod() != null) {
            charSequence = getTransformationMethod().getTransformation(charSequence, this).toString();
        }
        return Math.min((int) paint.measureText(charSequence), getLayout().getEllipsizedWidth());
    }

    public void a(a aVar) {
        this.f1437a.add(aVar);
    }

    public boolean b() {
        pa1 pa1 = this.f1438a;
        return pa1 != null && pa1.p();
    }

    public final boolean c() {
        int i = this.f;
        return i == 3 || i == 4;
    }

    public final boolean d() {
        int i = this.f;
        return i == 1 || i == 2;
    }

    public final boolean e() {
        int i = this.f;
        return i == 16 || i == 32;
    }

    public final boolean f() {
        return ya.C(this) == 1;
    }

    public final boolean g() {
        pa1 pa1 = this.f1438a;
        return pa1 != null && !pa1.o();
    }

    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (g()) {
            return this.f1438a.b();
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.f1435a;
    }

    public int getIconGravity() {
        return this.f;
    }

    public int getIconPadding() {
        return this.e;
    }

    public int getIconSize() {
        return this.f1439b;
    }

    public ColorStateList getIconTint() {
        return this.f1433a;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f1434a;
    }

    public int getInsetBottom() {
        return this.f1438a.c();
    }

    public int getInsetTop() {
        return this.f1438a.d();
    }

    public ColorStateList getRippleColor() {
        if (g()) {
            return this.f1438a.h();
        }
        return null;
    }

    public ld1 getShapeAppearanceModel() {
        if (g()) {
            return this.f1438a.i();
        }
        throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
    }

    public ColorStateList getStrokeColor() {
        if (g()) {
            return this.f1438a.j();
        }
        return null;
    }

    public int getStrokeWidth() {
        if (g()) {
            return this.f1438a.k();
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        return g() ? this.f1438a.l() : super.getSupportBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return g() ? this.f1438a.m() : super.getSupportBackgroundTintMode();
    }

    public void h(a aVar) {
        this.f1437a.remove(aVar);
    }

    public final void i() {
        if (d()) {
            yb.i(this, this.f1435a, (Drawable) null, (Drawable) null, (Drawable) null);
        } else if (c()) {
            yb.i(this, (Drawable) null, (Drawable) null, this.f1435a, (Drawable) null);
        } else if (e()) {
            yb.i(this, (Drawable) null, this.f1435a, (Drawable) null, (Drawable) null);
        }
    }

    public boolean isChecked() {
        return this.f1440b;
    }

    public final void j(boolean z) {
        Drawable drawable = this.f1435a;
        if (drawable != null) {
            Drawable mutate = m8.r(drawable).mutate();
            this.f1435a = mutate;
            m8.o(mutate, this.f1433a);
            PorterDuff.Mode mode = this.f1434a;
            if (mode != null) {
                m8.p(this.f1435a, mode);
            }
            int i = this.f1439b;
            if (i == 0) {
                i = this.f1435a.getIntrinsicWidth();
            }
            int i2 = this.f1439b;
            if (i2 == 0) {
                i2 = this.f1435a.getIntrinsicHeight();
            }
            Drawable drawable2 = this.f1435a;
            int i3 = this.c;
            int i4 = this.d;
            drawable2.setBounds(i3, i4, i + i3, i2 + i4);
        }
        if (z) {
            i();
            return;
        }
        Drawable[] a2 = yb.a(this);
        boolean z2 = false;
        Drawable drawable3 = a2[0];
        Drawable drawable4 = a2[1];
        Drawable drawable5 = a2[2];
        if ((d() && drawable3 != this.f1435a) || ((c() && drawable5 != this.f1435a) || (e() && drawable4 != this.f1435a))) {
            z2 = true;
        }
        if (z2) {
            i();
        }
    }

    public final void k(int i, int i2) {
        if (this.f1435a != null && getLayout() != null) {
            if (d() || c()) {
                this.d = 0;
                int i3 = this.f;
                boolean z = true;
                if (i3 == 1 || i3 == 3) {
                    this.c = 0;
                } else {
                    int i4 = this.f1439b;
                    if (i4 == 0) {
                        i4 = this.f1435a.getIntrinsicWidth();
                    }
                    int textWidth = (((((i - getTextWidth()) - ya.H(this)) - i4) - this.e) - ya.I(this)) / 2;
                    boolean f2 = f();
                    if (this.f != 4) {
                        z = false;
                    }
                    if (f2 != z) {
                        textWidth = -textWidth;
                    }
                    if (this.c != textWidth) {
                        this.c = textWidth;
                        j(false);
                        return;
                    }
                    return;
                }
            } else if (e()) {
                this.c = 0;
                if (this.f == 16) {
                    this.d = 0;
                } else {
                    int i5 = this.f1439b;
                    if (i5 == 0) {
                        i5 = this.f1435a.getIntrinsicHeight();
                    }
                    int textHeight = (((((i2 - getTextHeight()) - getPaddingTop()) - i5) - this.e) - getPaddingBottom()) / 2;
                    if (this.d != textHeight) {
                        this.d = textHeight;
                        j(false);
                        return;
                    }
                    return;
                }
            } else {
                return;
            }
            j(false);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (g()) {
            id1.f(this, this.f1438a.f());
        }
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (b()) {
            Button.mergeDrawableStates(onCreateDrawableState, f1432a);
        }
        if (isChecked()) {
            Button.mergeDrawableStates(onCreateDrawableState, b);
        }
        return onCreateDrawableState;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(isChecked());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        accessibilityNodeInfo.setCheckable(b());
        accessibilityNodeInfo.setChecked(isChecked());
        accessibilityNodeInfo.setClickable(isClickable());
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        pa1 pa1;
        super.onLayout(z, i, i2, i3, i4);
        if (Build.VERSION.SDK_INT == 21 && (pa1 = this.f1438a) != null) {
            pa1.H(i4 - i2, i3 - i);
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.onRestoreInstanceState(cVar.a());
        setChecked(cVar.b);
    }

    public Parcelable onSaveInstanceState() {
        c cVar = new c(super.onSaveInstanceState());
        cVar.b = this.f1440b;
        return cVar;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        k(i, i2);
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        k(getMeasuredWidth(), getMeasuredHeight());
    }

    public boolean performClick() {
        toggle();
        return super.performClick();
    }

    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    public void setBackgroundColor(int i) {
        if (g()) {
            this.f1438a.r(i);
        } else {
            super.setBackgroundColor(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (g()) {
            if (drawable != getBackground()) {
                this.f1438a.s();
            } else {
                getBackground().setState(drawable.getState());
                return;
            }
        }
        super.setBackgroundDrawable(drawable);
    }

    public void setBackgroundResource(int i) {
        setBackgroundDrawable(i != 0 ? l0.d(getContext(), i) : null);
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z) {
        if (g()) {
            this.f1438a.t(z);
        }
    }

    public void setChecked(boolean z) {
        if (b() && isEnabled() && this.f1440b != z) {
            this.f1440b = z;
            refreshDrawableState();
            if (!this.f1441c) {
                this.f1441c = true;
                Iterator it = this.f1437a.iterator();
                while (it.hasNext()) {
                    ((a) it.next()).a(this, this.f1440b);
                }
                this.f1441c = false;
            }
        }
    }

    public void setCornerRadius(int i) {
        if (g()) {
            this.f1438a.u(i);
        }
    }

    public void setCornerRadiusResource(int i) {
        if (g()) {
            setCornerRadius(getResources().getDimensionPixelSize(i));
        }
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        if (g()) {
            this.f1438a.f().V(f2);
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.f1435a != drawable) {
            this.f1435a = drawable;
            j(true);
            k(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconGravity(int i) {
        if (this.f != i) {
            this.f = i;
            k(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconPadding(int i) {
        if (this.e != i) {
            this.e = i;
            setCompoundDrawablePadding(i);
        }
    }

    public void setIconResource(int i) {
        setIcon(i != 0 ? l0.d(getContext(), i) : null);
    }

    public void setIconSize(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("iconSize cannot be less than 0");
        } else if (this.f1439b != i) {
            this.f1439b = i;
            j(true);
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.f1433a != colorStateList) {
            this.f1433a = colorStateList;
            j(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.f1434a != mode) {
            this.f1434a = mode;
            j(false);
        }
    }

    public void setIconTintResource(int i) {
        setIconTint(l0.c(getContext(), i));
    }

    public void setInsetBottom(int i) {
        this.f1438a.v(i);
    }

    public void setInsetTop(int i) {
        this.f1438a.w(i);
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOnPressedChangeListenerInternal(b bVar) {
        this.f1436a = bVar;
    }

    public void setPressed(boolean z) {
        b bVar = this.f1436a;
        if (bVar != null) {
            bVar.a(this, z);
        }
        super.setPressed(z);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (g()) {
            this.f1438a.x(colorStateList);
        }
    }

    public void setRippleColorResource(int i) {
        if (g()) {
            setRippleColor(l0.c(getContext(), i));
        }
    }

    public void setShapeAppearanceModel(ld1 ld1) {
        if (g()) {
            this.f1438a.y(ld1);
            return;
        }
        throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
    }

    public void setShouldDrawSurfaceColorStroke(boolean z) {
        if (g()) {
            this.f1438a.z(z);
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (g()) {
            this.f1438a.A(colorStateList);
        }
    }

    public void setStrokeColorResource(int i) {
        if (g()) {
            setStrokeColor(l0.c(getContext(), i));
        }
    }

    public void setStrokeWidth(int i) {
        if (g()) {
            this.f1438a.B(i);
        }
    }

    public void setStrokeWidthResource(int i) {
        if (g()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i));
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (g()) {
            this.f1438a.C(colorStateList);
        } else {
            super.setSupportBackgroundTintList(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (g()) {
            this.f1438a.D(mode);
        } else {
            super.setSupportBackgroundTintMode(mode);
        }
    }

    public void toggle() {
        setChecked(!this.f1440b);
    }
}
