package com.google.android.material.button;

import android.content.Context;
import android.graphics.Canvas;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import com.google.android.material.button.MaterialButton;
import defpackage.jb;
import defpackage.ld1;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeMap;

public class MaterialButtonToggleGroup extends LinearLayout {
    public static final int a = w91.Widget_MaterialComponents_MaterialButtonToggleGroup;

    /* renamed from: a  reason: collision with other field name */
    public static final String f1442a = MaterialButtonToggleGroup.class.getSimpleName();

    /* renamed from: a  reason: collision with other field name */
    public final c f1443a;

    /* renamed from: a  reason: collision with other field name */
    public final f f1444a;

    /* renamed from: a  reason: collision with other field name */
    public final Comparator<MaterialButton> f1445a;

    /* renamed from: a  reason: collision with other field name */
    public final LinkedHashSet<e> f1446a;

    /* renamed from: a  reason: collision with other field name */
    public final List<d> f1447a;

    /* renamed from: a  reason: collision with other field name */
    public Integer[] f1448a;
    public int b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1449b;
    public boolean c;
    public boolean d;

    public class a implements Comparator<MaterialButton> {
        public a() {
        }

        /* renamed from: a */
        public int compare(MaterialButton materialButton, MaterialButton materialButton2) {
            int compareTo = Boolean.valueOf(materialButton.isChecked()).compareTo(Boolean.valueOf(materialButton2.isChecked()));
            if (compareTo != 0) {
                return compareTo;
            }
            int compareTo2 = Boolean.valueOf(materialButton.isPressed()).compareTo(Boolean.valueOf(materialButton2.isPressed()));
            return compareTo2 != 0 ? compareTo2 : Integer.valueOf(MaterialButtonToggleGroup.this.indexOfChild(materialButton)).compareTo(Integer.valueOf(MaterialButtonToggleGroup.this.indexOfChild(materialButton2)));
        }
    }

    public class b extends da {
        public b() {
        }

        public void g(View view, jb jbVar) {
            super.g(view, jbVar);
            jbVar.Z(jb.c.a(0, 1, MaterialButtonToggleGroup.this.n(view), 1, false, ((MaterialButton) view).isChecked()));
        }
    }

    public class c implements MaterialButton.a {
        public c() {
        }

        public /* synthetic */ c(MaterialButtonToggleGroup materialButtonToggleGroup, a aVar) {
            this();
        }

        public void a(MaterialButton materialButton, boolean z) {
            if (!MaterialButtonToggleGroup.this.f1449b) {
                if (MaterialButtonToggleGroup.this.c) {
                    int unused = MaterialButtonToggleGroup.this.b = z ? materialButton.getId() : -1;
                }
                if (MaterialButtonToggleGroup.this.u(materialButton.getId(), z)) {
                    MaterialButtonToggleGroup.this.l(materialButton.getId(), materialButton.isChecked());
                }
                MaterialButtonToggleGroup.this.invalidate();
            }
        }
    }

    public static class d {
        public static final dd1 a = new bd1(0.0f);
        public dd1 b;
        public dd1 c;
        public dd1 d;
        public dd1 e;

        public d(dd1 dd1, dd1 dd12, dd1 dd13, dd1 dd14) {
            this.b = dd1;
            this.c = dd13;
            this.d = dd14;
            this.e = dd12;
        }

        public static d a(d dVar) {
            dd1 dd1 = a;
            return new d(dd1, dVar.e, dd1, dVar.d);
        }

        public static d b(d dVar, View view) {
            return nc1.d(view) ? c(dVar) : d(dVar);
        }

        public static d c(d dVar) {
            dd1 dd1 = dVar.b;
            dd1 dd12 = dVar.e;
            dd1 dd13 = a;
            return new d(dd1, dd12, dd13, dd13);
        }

        public static d d(d dVar) {
            dd1 dd1 = a;
            return new d(dd1, dd1, dVar.c, dVar.d);
        }

        public static d e(d dVar, View view) {
            return nc1.d(view) ? d(dVar) : c(dVar);
        }

        public static d f(d dVar) {
            dd1 dd1 = dVar.b;
            dd1 dd12 = a;
            return new d(dd1, dd12, dVar.c, dd12);
        }
    }

    public interface e {
        void a(MaterialButtonToggleGroup materialButtonToggleGroup, int i, boolean z);
    }

    public class f implements MaterialButton.b {
        public f() {
        }

        public /* synthetic */ f(MaterialButtonToggleGroup materialButtonToggleGroup, a aVar) {
            this();
        }

        public void a(MaterialButton materialButton, boolean z) {
            MaterialButtonToggleGroup.this.invalidate();
        }
    }

    public MaterialButtonToggleGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.materialButtonToggleGroupStyle);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MaterialButtonToggleGroup(android.content.Context r7, android.util.AttributeSet r8, int r9) {
        /*
            r6 = this;
            int r4 = a
            android.content.Context r7 = defpackage.ee1.c(r7, r8, r9, r4)
            r6.<init>(r7, r8, r9)
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            r6.f1447a = r7
            com.google.android.material.button.MaterialButtonToggleGroup$c r7 = new com.google.android.material.button.MaterialButtonToggleGroup$c
            r0 = 0
            r7.<init>(r6, r0)
            r6.f1443a = r7
            com.google.android.material.button.MaterialButtonToggleGroup$f r7 = new com.google.android.material.button.MaterialButtonToggleGroup$f
            r7.<init>(r6, r0)
            r6.f1444a = r7
            java.util.LinkedHashSet r7 = new java.util.LinkedHashSet
            r7.<init>()
            r6.f1446a = r7
            com.google.android.material.button.MaterialButtonToggleGroup$a r7 = new com.google.android.material.button.MaterialButtonToggleGroup$a
            r7.<init>()
            r6.f1445a = r7
            r7 = 0
            r6.f1449b = r7
            android.content.Context r0 = r6.getContext()
            int[] r2 = defpackage.x91.MaterialButtonToggleGroup
            int[] r5 = new int[r7]
            r1 = r8
            r3 = r9
            android.content.res.TypedArray r8 = defpackage.mc1.h(r0, r1, r2, r3, r4, r5)
            int r9 = defpackage.x91.MaterialButtonToggleGroup_singleSelection
            boolean r9 = r8.getBoolean(r9, r7)
            r6.setSingleSelection((boolean) r9)
            int r9 = defpackage.x91.MaterialButtonToggleGroup_checkedButton
            r0 = -1
            int r9 = r8.getResourceId(r9, r0)
            r6.b = r9
            int r9 = defpackage.x91.MaterialButtonToggleGroup_selectionRequired
            boolean r7 = r8.getBoolean(r9, r7)
            r6.d = r7
            r7 = 1
            r6.setChildrenDrawingOrderEnabled(r7)
            r8.recycle()
            defpackage.ya.x0(r6, r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.button.MaterialButtonToggleGroup.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    private int getFirstVisibleChildIndex() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            if (p(i)) {
                return i;
            }
        }
        return -1;
    }

    private int getLastVisibleChildIndex() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            if (p(childCount)) {
                return childCount;
            }
        }
        return -1;
    }

    private int getVisibleButtonCount() {
        int i = 0;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            if ((getChildAt(i2) instanceof MaterialButton) && p(i2)) {
                i++;
            }
        }
        return i;
    }

    private void setCheckedId(int i) {
        this.b = i;
        l(i, true);
    }

    private void setGeneratedIdIfNeeded(MaterialButton materialButton) {
        if (materialButton.getId() == -1) {
            materialButton.setId(ya.k());
        }
    }

    private void setupButtonChild(MaterialButton materialButton) {
        materialButton.setMaxLines(1);
        materialButton.setEllipsize(TextUtils.TruncateAt.END);
        materialButton.setCheckable(true);
        materialButton.a(this.f1443a);
        materialButton.setOnPressedChangeListenerInternal(this.f1444a);
        materialButton.setShouldDrawSurfaceColorStroke(true);
    }

    public static void t(ld1.b bVar, d dVar) {
        if (dVar == null) {
            bVar.o(0.0f);
        } else {
            bVar.B(dVar.b).t(dVar.e).F(dVar.c).x(dVar.d);
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof MaterialButton) {
            super.addView(view, i, layoutParams);
            MaterialButton materialButton = (MaterialButton) view;
            setGeneratedIdIfNeeded(materialButton);
            setupButtonChild(materialButton);
            if (materialButton.isChecked()) {
                u(materialButton.getId(), true);
                setCheckedId(materialButton.getId());
            }
            ld1 shapeAppearanceModel = materialButton.getShapeAppearanceModel();
            this.f1447a.add(new d(shapeAppearanceModel.r(), shapeAppearanceModel.j(), shapeAppearanceModel.t(), shapeAppearanceModel.l()));
            ya.o0(materialButton, new b());
        }
    }

    public void dispatchDraw(Canvas canvas) {
        v();
        super.dispatchDraw(canvas);
    }

    public void g(e eVar) {
        this.f1446a.add(eVar);
    }

    public CharSequence getAccessibilityClassName() {
        return MaterialButtonToggleGroup.class.getName();
    }

    public int getCheckedButtonId() {
        if (this.c) {
            return this.b;
        }
        return -1;
    }

    public List<Integer> getCheckedButtonIds() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < getChildCount(); i++) {
            MaterialButton m = m(i);
            if (m.isChecked()) {
                arrayList.add(Integer.valueOf(m.getId()));
            }
        }
        return arrayList;
    }

    public int getChildDrawingOrder(int i, int i2) {
        Integer[] numArr = this.f1448a;
        return (numArr == null || i2 >= numArr.length) ? i2 : numArr[i2].intValue();
    }

    public final void h() {
        int firstVisibleChildIndex = getFirstVisibleChildIndex();
        if (firstVisibleChildIndex != -1) {
            for (int i = firstVisibleChildIndex + 1; i < getChildCount(); i++) {
                MaterialButton m = m(i);
                int min = Math.min(m.getStrokeWidth(), m(i - 1).getStrokeWidth());
                LinearLayout.LayoutParams i2 = i(m);
                if (getOrientation() == 0) {
                    ka.c(i2, 0);
                    ka.d(i2, -min);
                    i2.topMargin = 0;
                } else {
                    i2.bottomMargin = 0;
                    i2.topMargin = -min;
                    ka.d(i2, 0);
                }
                m.setLayoutParams(i2);
            }
            r(firstVisibleChildIndex);
        }
    }

    public final LinearLayout.LayoutParams i(View view) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        return layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : new LinearLayout.LayoutParams(layoutParams.width, layoutParams.height);
    }

    public final void j(int i) {
        s(i, true);
        u(i, true);
        setCheckedId(i);
    }

    public void k() {
        this.f1449b = true;
        for (int i = 0; i < getChildCount(); i++) {
            MaterialButton m = m(i);
            m.setChecked(false);
            l(m.getId(), false);
        }
        this.f1449b = false;
        setCheckedId(-1);
    }

    public final void l(int i, boolean z) {
        Iterator it = this.f1446a.iterator();
        while (it.hasNext()) {
            ((e) it.next()).a(this, i, z);
        }
    }

    public final MaterialButton m(int i) {
        return (MaterialButton) getChildAt(i);
    }

    public final int n(View view) {
        if (!(view instanceof MaterialButton)) {
            return -1;
        }
        int i = 0;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            if (getChildAt(i2) == view) {
                return i;
            }
            if ((getChildAt(i2) instanceof MaterialButton) && p(i2)) {
                i++;
            }
        }
        return -1;
    }

    public final d o(int i, int i2, int i3) {
        d dVar = this.f1447a.get(i);
        if (i2 == i3) {
            return dVar;
        }
        boolean z = getOrientation() == 0;
        if (i == i2) {
            return z ? d.e(dVar, this) : d.f(dVar);
        }
        if (i == i3) {
            return z ? d.b(dVar, this) : d.a(dVar);
        }
        return null;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        int i = this.b;
        if (i != -1) {
            j(i);
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        jb.v0(accessibilityNodeInfo).Y(jb.b.a(1, getVisibleButtonCount(), false, q() ? 1 : 2));
    }

    public void onMeasure(int i, int i2) {
        w();
        h();
        super.onMeasure(i, i2);
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        if (view instanceof MaterialButton) {
            MaterialButton materialButton = (MaterialButton) view;
            materialButton.h(this.f1443a);
            materialButton.setOnPressedChangeListenerInternal((MaterialButton.b) null);
        }
        int indexOfChild = indexOfChild(view);
        if (indexOfChild >= 0) {
            this.f1447a.remove(indexOfChild);
        }
        w();
        h();
    }

    public final boolean p(int i) {
        return getChildAt(i).getVisibility() != 8;
    }

    public boolean q() {
        return this.c;
    }

    public final void r(int i) {
        if (getChildCount() != 0 && i != -1) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) m(i).getLayoutParams();
            if (getOrientation() == 1) {
                layoutParams.topMargin = 0;
                layoutParams.bottomMargin = 0;
                return;
            }
            ka.c(layoutParams, 0);
            ka.d(layoutParams, 0);
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = 0;
        }
    }

    public final void s(int i, boolean z) {
        View findViewById = findViewById(i);
        if (findViewById instanceof MaterialButton) {
            this.f1449b = true;
            ((MaterialButton) findViewById).setChecked(z);
            this.f1449b = false;
        }
    }

    public void setSelectionRequired(boolean z) {
        this.d = z;
    }

    public void setSingleSelection(int i) {
        setSingleSelection(getResources().getBoolean(i));
    }

    public void setSingleSelection(boolean z) {
        if (this.c != z) {
            this.c = z;
            k();
        }
    }

    public final boolean u(int i, boolean z) {
        List<Integer> checkedButtonIds = getCheckedButtonIds();
        if (!this.d || !checkedButtonIds.isEmpty()) {
            if (z && this.c) {
                checkedButtonIds.remove(Integer.valueOf(i));
                for (Integer intValue : checkedButtonIds) {
                    int intValue2 = intValue.intValue();
                    s(intValue2, false);
                    l(intValue2, false);
                }
            }
            return true;
        }
        s(i, true);
        this.b = i;
        return false;
    }

    public final void v() {
        TreeMap treeMap = new TreeMap(this.f1445a);
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            treeMap.put(m(i), Integer.valueOf(i));
        }
        this.f1448a = (Integer[]) treeMap.values().toArray(new Integer[0]);
    }

    public void w() {
        int childCount = getChildCount();
        int firstVisibleChildIndex = getFirstVisibleChildIndex();
        int lastVisibleChildIndex = getLastVisibleChildIndex();
        for (int i = 0; i < childCount; i++) {
            MaterialButton m = m(i);
            if (m.getVisibility() != 8) {
                ld1.b v = m.getShapeAppearanceModel().v();
                t(v, o(i, firstVisibleChildIndex, lastVisibleChildIndex));
                m.setShapeAppearanceModel(v.m());
            }
        }
    }
}
