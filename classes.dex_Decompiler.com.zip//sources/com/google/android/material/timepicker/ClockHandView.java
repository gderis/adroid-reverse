package com.google.android.material.timepicker;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import java.util.ArrayList;
import java.util.List;

public class ClockHandView extends View {
    public double a;

    /* renamed from: a  reason: collision with other field name */
    public float f1576a;

    /* renamed from: a  reason: collision with other field name */
    public int f1577a;

    /* renamed from: a  reason: collision with other field name */
    public ValueAnimator f1578a;

    /* renamed from: a  reason: collision with other field name */
    public final Paint f1579a;

    /* renamed from: a  reason: collision with other field name */
    public final RectF f1580a;

    /* renamed from: a  reason: collision with other field name */
    public c f1581a;

    /* renamed from: a  reason: collision with other field name */
    public final List<d> f1582a;
    public float b;

    /* renamed from: b  reason: collision with other field name */
    public final int f1583b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1584b;
    public final float c;

    /* renamed from: c  reason: collision with other field name */
    public final int f1585c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1586c;
    public float d;

    /* renamed from: d  reason: collision with other field name */
    public int f1587d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f1588d;

    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ClockHandView.this.m(((Float) valueAnimator.getAnimatedValue()).floatValue(), true);
        }
    }

    public class b extends AnimatorListenerAdapter {
        public b() {
        }

        public void onAnimationCancel(Animator animator) {
            animator.end();
        }
    }

    public interface c {
        void a(float f, boolean z);
    }

    public interface d {
        void a(float f, boolean z);
    }

    public ClockHandView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.materialClockStyle);
    }

    public ClockHandView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1582a = new ArrayList();
        Paint paint = new Paint();
        this.f1579a = paint;
        this.f1580a = new RectF();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.ClockHandView, i, w91.Widget_MaterialComponents_TimePicker_Clock);
        this.f1587d = obtainStyledAttributes.getDimensionPixelSize(x91.ClockHandView_materialCircleRadius, 0);
        this.f1583b = obtainStyledAttributes.getDimensionPixelSize(x91.ClockHandView_selectorSize, 0);
        Resources resources = getResources();
        this.f1585c = resources.getDimensionPixelSize(q91.material_clock_hand_stroke_width);
        this.c = (float) resources.getDimensionPixelSize(q91.material_clock_hand_center_dot_radius);
        int color = obtainStyledAttributes.getColor(x91.ClockHandView_clockHandColor, 0);
        paint.setAntiAlias(true);
        paint.setColor(color);
        k(0.0f);
        this.f1577a = ViewConfiguration.get(context).getScaledTouchSlop();
        ya.x0(this, 2);
        obtainStyledAttributes.recycle();
    }

    public void b(d dVar) {
        this.f1582a.add(dVar);
    }

    public final void c(Canvas canvas) {
        int height = getHeight() / 2;
        int width = getWidth() / 2;
        float f = (float) width;
        float f2 = (float) height;
        this.f1579a.setStrokeWidth(0.0f);
        canvas.drawCircle((((float) this.f1587d) * ((float) Math.cos(this.a))) + f, (((float) this.f1587d) * ((float) Math.sin(this.a))) + f2, (float) this.f1583b, this.f1579a);
        double sin = Math.sin(this.a);
        double cos = Math.cos(this.a);
        double d2 = (double) ((float) (this.f1587d - this.f1583b));
        Double.isNaN(d2);
        float f3 = (float) (width + ((int) (cos * d2)));
        Double.isNaN(d2);
        float f4 = (float) (height + ((int) (d2 * sin)));
        this.f1579a.setStrokeWidth((float) this.f1585c);
        canvas.drawLine(f, f2, f3, f4, this.f1579a);
        canvas.drawCircle(f, f2, this.c, this.f1579a);
    }

    public RectF d() {
        return this.f1580a;
    }

    public final int e(float f, float f2) {
        int degrees = ((int) Math.toDegrees(Math.atan2((double) (f2 - ((float) (getHeight() / 2))), (double) (f - ((float) (getWidth() / 2)))))) + 90;
        return degrees < 0 ? degrees + 360 : degrees;
    }

    public float f() {
        return this.d;
    }

    public int g() {
        return this.f1583b;
    }

    public final Pair<Float, Float> h(float f) {
        float f2 = f();
        if (Math.abs(f2 - f) > 180.0f) {
            if (f2 > 180.0f && f < 180.0f) {
                f += 360.0f;
            }
            if (f2 < 180.0f && f > 180.0f) {
                f2 += 360.0f;
            }
        }
        return new Pair<>(Float.valueOf(f2), Float.valueOf(f));
    }

    public final boolean i(float f, float f2, boolean z, boolean z2, boolean z3) {
        float e = (float) e(f, f2);
        boolean z4 = false;
        boolean z5 = f() != e;
        if (z2 && z5) {
            return true;
        }
        if (!z5 && !z) {
            return false;
        }
        if (z3 && this.f1584b) {
            z4 = true;
        }
        l(e, z4);
        return true;
    }

    public void j(int i) {
        this.f1587d = i;
        invalidate();
    }

    public void k(float f) {
        l(f, false);
    }

    public void l(float f, boolean z) {
        ValueAnimator valueAnimator = this.f1578a;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        if (!z) {
            m(f, false);
            return;
        }
        Pair<Float, Float> h = h(f);
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{((Float) h.first).floatValue(), ((Float) h.second).floatValue()});
        this.f1578a = ofFloat;
        ofFloat.setDuration(200);
        this.f1578a.addUpdateListener(new a());
        this.f1578a.addListener(new b());
        this.f1578a.start();
    }

    public final void m(float f, boolean z) {
        float f2 = f % 360.0f;
        this.d = f2;
        this.a = Math.toRadians((double) (f2 - 90.0f));
        float width = ((float) (getWidth() / 2)) + (((float) this.f1587d) * ((float) Math.cos(this.a)));
        float height = ((float) (getHeight() / 2)) + (((float) this.f1587d) * ((float) Math.sin(this.a)));
        RectF rectF = this.f1580a;
        int i = this.f1583b;
        rectF.set(width - ((float) i), height - ((float) i), width + ((float) i), height + ((float) i));
        for (d a2 : this.f1582a) {
            a2.a(f2, z);
        }
        invalidate();
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        c(canvas);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        k(f());
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        boolean z2;
        boolean z3;
        c cVar;
        int actionMasked = motionEvent.getActionMasked();
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        if (actionMasked != 0) {
            if (actionMasked == 1 || actionMasked == 2) {
                int i = (int) (x - this.f1576a);
                int i2 = (int) (y - this.b);
                this.f1586c = (i * i) + (i2 * i2) > this.f1577a;
                boolean z4 = this.f1588d;
                z3 = actionMasked == 1;
                z2 = z4;
            } else {
                z3 = false;
                z2 = false;
            }
            z = false;
        } else {
            this.f1576a = x;
            this.b = y;
            this.f1586c = true;
            this.f1588d = false;
            z3 = false;
            z2 = false;
            z = true;
        }
        boolean i3 = i(x, y, z2, z, z3) | this.f1588d;
        this.f1588d = i3;
        if (i3 && z3 && (cVar = this.f1581a) != null) {
            cVar.a((float) e(x, y), this.f1586c);
        }
        return true;
    }
}
