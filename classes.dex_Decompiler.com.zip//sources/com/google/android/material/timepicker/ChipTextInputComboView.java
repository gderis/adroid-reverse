package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.TextInputLayout;

public class ChipTextInputComboView extends FrameLayout implements Checkable {
    public TextWatcher a;

    /* renamed from: a  reason: collision with other field name */
    public final EditText f1564a;

    /* renamed from: a  reason: collision with other field name */
    public TextView f1565a;

    /* renamed from: a  reason: collision with other field name */
    public final Chip f1566a;

    /* renamed from: a  reason: collision with other field name */
    public final TextInputLayout f1567a;

    public class b extends lc1 {
        public b() {
        }

        public void afterTextChanged(Editable editable) {
            if (TextUtils.isEmpty(editable)) {
                ChipTextInputComboView.this.f1566a.setText(ChipTextInputComboView.this.c("00"));
            } else {
                ChipTextInputComboView.this.f1566a.setText(ChipTextInputComboView.this.c(editable));
            }
        }
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        LayoutInflater from = LayoutInflater.from(context);
        Chip chip = (Chip) from.inflate(u91.material_time_chip, this, false);
        this.f1566a = chip;
        TextInputLayout textInputLayout = (TextInputLayout) from.inflate(u91.material_time_input, this, false);
        this.f1567a = textInputLayout;
        EditText editText = textInputLayout.getEditText();
        this.f1564a = editText;
        editText.setVisibility(4);
        b bVar = new b();
        this.a = bVar;
        editText.addTextChangedListener(bVar);
        d();
        addView(chip);
        addView(textInputLayout);
        this.f1565a = (TextView) findViewById(s91.material_label);
        editText.setSaveEnabled(false);
    }

    public final String c(CharSequence charSequence) {
        return he1.a(getResources(), charSequence);
    }

    public final void d() {
        if (Build.VERSION.SDK_INT >= 24) {
            this.f1564a.setImeHintLocales(getContext().getResources().getConfiguration().getLocales());
        }
    }

    public boolean isChecked() {
        return this.f1566a.isChecked();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        d();
    }

    public void setChecked(boolean z) {
        this.f1566a.setChecked(z);
        int i = 0;
        this.f1564a.setVisibility(z ? 0 : 4);
        Chip chip = this.f1566a;
        if (z) {
            i = 8;
        }
        chip.setVisibility(i);
        if (isChecked()) {
            this.f1564a.requestFocus();
            if (!TextUtils.isEmpty(this.f1564a.getText())) {
                EditText editText = this.f1564a;
                editText.setSelection(editText.getText().length());
            }
        }
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.f1566a.setOnClickListener(onClickListener);
    }

    public void setTag(int i, Object obj) {
        this.f1566a.setTag(i, obj);
    }

    public void toggle() {
        this.f1566a.toggle();
    }
}
