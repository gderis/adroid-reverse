package com.google.android.material.timepicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import com.google.android.material.timepicker.ClockHandView;
import defpackage.jb;
import java.util.Arrays;

public class ClockFaceView extends ge1 implements ClockHandView.d {
    public float a;

    /* renamed from: a  reason: collision with other field name */
    public final ColorStateList f1568a;

    /* renamed from: a  reason: collision with other field name */
    public final Rect f1569a;

    /* renamed from: a  reason: collision with other field name */
    public final RectF f1570a;

    /* renamed from: a  reason: collision with other field name */
    public final ClockHandView f1571a;

    /* renamed from: a  reason: collision with other field name */
    public final da f1572a;

    /* renamed from: a  reason: collision with other field name */
    public final float[] f1573a;

    /* renamed from: a  reason: collision with other field name */
    public final int[] f1574a;

    /* renamed from: a  reason: collision with other field name */
    public String[] f1575a;
    public final SparseArray<TextView> c;
    public final int p;

    public class a implements ViewTreeObserver.OnPreDrawListener {
        public a() {
        }

        public boolean onPreDraw() {
            if (!ClockFaceView.this.isShown()) {
                return true;
            }
            ClockFaceView.this.getViewTreeObserver().removeOnPreDrawListener(this);
            ClockFaceView.this.w(((ClockFaceView.this.getHeight() / 2) - ClockFaceView.this.f1571a.g()) - ClockFaceView.this.p);
            return true;
        }
    }

    public class b extends da {
        public b() {
        }

        public void g(View view, jb jbVar) {
            super.g(view, jbVar);
            int intValue = ((Integer) view.getTag(s91.material_value_index)).intValue();
            if (intValue > 0) {
                jbVar.s0((View) ClockFaceView.this.c.get(intValue - 1));
            }
            jbVar.Z(jb.c.a(0, 1, intValue, 1, false, view.isSelected()));
        }
    }

    public ClockFaceView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.materialClockStyle);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public ClockFaceView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1569a = new Rect();
        this.f1570a = new RectF();
        this.c = new SparseArray<>();
        this.f1573a = new float[]{0.0f, 0.9f, 1.0f};
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.ClockFaceView, i, w91.Widget_MaterialComponents_TimePicker_Clock);
        Resources resources = getResources();
        ColorStateList a2 = tc1.a(context, obtainStyledAttributes, x91.ClockFaceView_clockNumberTextColor);
        this.f1568a = a2;
        LayoutInflater.from(context).inflate(u91.material_clockface_view, this, true);
        ClockHandView clockHandView = (ClockHandView) findViewById(s91.material_clock_hand);
        this.f1571a = clockHandView;
        this.p = resources.getDimensionPixelSize(q91.material_clock_hand_padding);
        int colorForState = a2.getColorForState(new int[]{16842913}, a2.getDefaultColor());
        this.f1574a = new int[]{colorForState, colorForState, a2.getDefaultColor()};
        clockHandView.b(this);
        int defaultColor = l0.c(context, p91.material_timepicker_clockface).getDefaultColor();
        ColorStateList a3 = tc1.a(context, obtainStyledAttributes, x91.ClockFaceView_clockFaceBackgroundColor);
        setBackgroundColor(a3 != null ? a3.getDefaultColor() : defaultColor);
        getViewTreeObserver().addOnPreDrawListener(new a());
        setFocusable(true);
        obtainStyledAttributes.recycle();
        this.f1572a = new b();
        String[] strArr = new String[12];
        Arrays.fill(strArr, "");
        F(strArr, 0);
    }

    public final void D() {
        RectF d = this.f1571a.d();
        for (int i = 0; i < this.c.size(); i++) {
            TextView textView = this.c.get(i);
            if (textView != null) {
                textView.getDrawingRect(this.f1569a);
                this.f1569a.offset(textView.getPaddingLeft(), textView.getPaddingTop());
                offsetDescendantRectToMyCoords(textView, this.f1569a);
                this.f1570a.set(this.f1569a);
                textView.getPaint().setShader(E(d, this.f1570a));
                textView.invalidate();
            }
        }
    }

    public final RadialGradient E(RectF rectF, RectF rectF2) {
        if (!RectF.intersects(rectF, rectF2)) {
            return null;
        }
        return new RadialGradient(rectF.centerX() - this.f1570a.left, rectF.centerY() - this.f1570a.top, rectF.width() * 0.5f, this.f1574a, this.f1573a, Shader.TileMode.CLAMP);
    }

    public void F(String[] strArr, int i) {
        this.f1575a = strArr;
        G(i);
    }

    public final void G(int i) {
        LayoutInflater from = LayoutInflater.from(getContext());
        int size = this.c.size();
        for (int i2 = 0; i2 < Math.max(this.f1575a.length, size); i2++) {
            TextView textView = this.c.get(i2);
            if (i2 >= this.f1575a.length) {
                removeView(textView);
                this.c.remove(i2);
            } else {
                if (textView == null) {
                    textView = (TextView) from.inflate(u91.material_clockface_textview, this, false);
                    this.c.put(i2, textView);
                    addView(textView);
                }
                textView.setVisibility(0);
                textView.setText(this.f1575a[i2]);
                textView.setTag(s91.material_value_index, Integer.valueOf(i2));
                ya.o0(textView, this.f1572a);
                textView.setTextColor(this.f1568a);
                if (i != 0) {
                    textView.setContentDescription(getResources().getString(i, new Object[]{this.f1575a[i2]}));
                }
            }
        }
    }

    public void a(float f, boolean z) {
        if (Math.abs(this.a - f) > 0.001f) {
            this.a = f;
            D();
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        jb.v0(accessibilityNodeInfo).Y(jb.b.a(1, this.f1575a.length, false, 1));
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        D();
    }

    public void w(int i) {
        if (i != v()) {
            super.w(i);
            this.f1571a.j(v());
        }
    }
}
