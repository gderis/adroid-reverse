package com.google.android.material.timepicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Checkable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;

public class TimePickerView extends ConstraintLayout {
    public final View.OnClickListener a;

    /* renamed from: a  reason: collision with other field name */
    public final MaterialButtonToggleGroup f1589a;

    /* renamed from: a  reason: collision with other field name */
    public final Chip f1590a;

    /* renamed from: a  reason: collision with other field name */
    public final ClockFaceView f1591a;

    /* renamed from: a  reason: collision with other field name */
    public final ClockHandView f1592a;

    /* renamed from: a  reason: collision with other field name */
    public e f1593a;

    /* renamed from: a  reason: collision with other field name */
    public f f1594a;

    /* renamed from: a  reason: collision with other field name */
    public g f1595a;
    public final Chip b;

    public class a implements View.OnClickListener {
        public a() {
        }

        public void onClick(View view) {
            if (TimePickerView.this.f1595a != null) {
                TimePickerView.this.f1595a.a(((Integer) view.getTag(s91.selection_type)).intValue());
            }
        }
    }

    public class b implements MaterialButtonToggleGroup.e {
        public b() {
        }

        public void a(MaterialButtonToggleGroup materialButtonToggleGroup, int i, boolean z) {
            int i2 = i == s91.material_clock_period_pm_button ? 1 : 0;
            if (TimePickerView.this.f1594a != null && z) {
                TimePickerView.this.f1594a.a(i2);
            }
        }
    }

    public class c extends GestureDetector.SimpleOnGestureListener {
        public c() {
        }

        public boolean onDoubleTap(MotionEvent motionEvent) {
            boolean onDoubleTap = super.onDoubleTap(motionEvent);
            if (TimePickerView.this.f1593a != null) {
                TimePickerView.this.f1593a.a();
            }
            return onDoubleTap;
        }
    }

    public class d implements View.OnTouchListener {
        public final /* synthetic */ GestureDetector a;

        public d(GestureDetector gestureDetector) {
            this.a = gestureDetector;
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (((Checkable) view).isChecked()) {
                return this.a.onTouchEvent(motionEvent);
            }
            return false;
        }
    }

    public interface e {
        void a();
    }

    public interface f {
        void a(int i);
    }

    public interface g {
        void a(int i);
    }

    public TimePickerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TimePickerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = new a();
        LayoutInflater.from(context).inflate(u91.material_timepicker, this);
        this.f1591a = (ClockFaceView) findViewById(s91.material_clock_face);
        MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) findViewById(s91.material_clock_period_toggle);
        this.f1589a = materialButtonToggleGroup;
        materialButtonToggleGroup.g(new b());
        this.f1590a = (Chip) findViewById(s91.material_minute_tv);
        this.b = (Chip) findViewById(s91.material_hour_tv);
        this.f1592a = (ClockHandView) findViewById(s91.material_clock_hand);
        y();
        x();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        z();
    }

    public void onVisibilityChanged(View view, int i) {
        super.onVisibilityChanged(view, i);
        if (view == this && i == 0) {
            z();
        }
    }

    public final void x() {
        Chip chip = this.f1590a;
        int i = s91.selection_type;
        chip.setTag(i, 12);
        this.b.setTag(i, 10);
        this.f1590a.setOnClickListener(this.a);
        this.b.setOnClickListener(this.a);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public final void y() {
        d dVar = new d(new GestureDetector(getContext(), new c()));
        this.f1590a.setOnTouchListener(dVar);
        this.b.setOnTouchListener(dVar);
    }

    public final void z() {
        if (this.f1589a.getVisibility() == 0) {
            n6 n6Var = new n6();
            n6Var.g(this);
            int i = 1;
            if (ya.C(this) == 0) {
                i = 2;
            }
            n6Var.e(s91.material_clock_display, i);
            n6Var.c(this);
        }
    }
}
