package com.google.android.material.bottomsheet;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import defpackage.jb;
import defpackage.jc;
import defpackage.mb;
import defpackage.nc1;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.c<V> {
    public static final int a = w91.Widget_Design_BottomSheet_Modal;

    /* renamed from: a  reason: collision with other field name */
    public float f1400a;

    /* renamed from: a  reason: collision with other field name */
    public ValueAnimator f1401a;

    /* renamed from: a  reason: collision with other field name */
    public VelocityTracker f1402a;

    /* renamed from: a  reason: collision with other field name */
    public BottomSheetBehavior<V>.defpackage.h f1403a = null;

    /* renamed from: a  reason: collision with other field name */
    public hd1 f1404a;

    /* renamed from: a  reason: collision with other field name */
    public WeakReference<V> f1405a;

    /* renamed from: a  reason: collision with other field name */
    public final ArrayList<f> f1406a = new ArrayList<>();

    /* renamed from: a  reason: collision with other field name */
    public Map<View, Integer> f1407a;

    /* renamed from: a  reason: collision with other field name */
    public final jc.c f1408a = new d();

    /* renamed from: a  reason: collision with other field name */
    public jc f1409a;

    /* renamed from: a  reason: collision with other field name */
    public ld1 f1410a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f1411a = true;
    public float b = 0.5f;

    /* renamed from: b  reason: collision with other field name */
    public int f1412b = 0;

    /* renamed from: b  reason: collision with other field name */
    public WeakReference<View> f1413b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1414b = false;
    public float c = -1.0f;

    /* renamed from: c  reason: collision with other field name */
    public int f1415c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1416c;
    public int d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f1417d;
    public int e;

    /* renamed from: e  reason: collision with other field name */
    public boolean f1418e;
    public int f;

    /* renamed from: f  reason: collision with other field name */
    public boolean f1419f;
    public int g;

    /* renamed from: g  reason: collision with other field name */
    public boolean f1420g;
    public int h;

    /* renamed from: h  reason: collision with other field name */
    public boolean f1421h;
    public int i;

    /* renamed from: i  reason: collision with other field name */
    public boolean f1422i = true;
    public int j;

    /* renamed from: j  reason: collision with other field name */
    public boolean f1423j;
    public int k = 4;

    /* renamed from: k  reason: collision with other field name */
    public boolean f1424k;
    public int l;

    /* renamed from: l  reason: collision with other field name */
    public boolean f1425l;
    public int m;
    public int n;
    public int o;
    public int p;
    public int q;
    public int r = -1;

    public class a implements Runnable {
        public final /* synthetic */ int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ View f1426a;

        public a(View view, int i) {
            this.f1426a = view;
            this.a = i;
        }

        public void run() {
            BottomSheetBehavior.this.o0(this.f1426a, this.a);
        }
    }

    public class b implements ValueAnimator.AnimatorUpdateListener {
        public b() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            if (BottomSheetBehavior.this.f1404a != null) {
                BottomSheetBehavior.this.f1404a.X(floatValue);
            }
        }
    }

    public class c implements nc1.c {
        public c() {
        }

        public gb a(View view, gb gbVar, nc1.d dVar) {
            int unused = BottomSheetBehavior.this.f = gbVar.e().d;
            BottomSheetBehavior.this.v0(false);
            return gbVar;
        }
    }

    public class d extends jc.c {
        public d() {
        }

        public int a(View view, int i, int i2) {
            return view.getLeft();
        }

        public int b(View view, int i, int i2) {
            int V = BottomSheetBehavior.this.V();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return w8.b(i, V, bottomSheetBehavior.f1420g ? bottomSheetBehavior.o : bottomSheetBehavior.j);
        }

        public int e(View view) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return bottomSheetBehavior.f1420g ? bottomSheetBehavior.o : bottomSheetBehavior.j;
        }

        public void j(int i) {
            if (i == 1 && BottomSheetBehavior.this.f1422i) {
                BottomSheetBehavior.this.m0(1);
            }
        }

        public void k(View view, int i, int i2, int i3, int i4) {
            BottomSheetBehavior.this.T(i2);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:24:0x0075, code lost:
            if (java.lang.Math.abs(r7.getTop() - r6.a.g) < java.lang.Math.abs(r7.getTop() - r6.a.i)) goto L_0x0077;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:0x00b1, code lost:
            if (java.lang.Math.abs(r8 - r6.a.i) < java.lang.Math.abs(r8 - r6.a.j)) goto L_0x00b3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:40:0x00d8, code lost:
            if (java.lang.Math.abs(r8 - r6.a.h) < java.lang.Math.abs(r8 - r6.a.j)) goto L_0x0010;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:44:0x00ea, code lost:
            if (r8 < java.lang.Math.abs(r8 - r9.j)) goto L_0x0077;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:46:0x00fc, code lost:
            if (java.lang.Math.abs(r8 - r0) < java.lang.Math.abs(r8 - r6.a.j)) goto L_0x00b3;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void l(android.view.View r7, float r8, float r9) {
            /*
                r6 = this;
                r0 = 0
                r1 = 4
                r2 = 6
                r3 = 3
                int r4 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r4 >= 0) goto L_0x0027
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r8 = r8.f1411a
                if (r8 == 0) goto L_0x0017
            L_0x0010:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.h
            L_0x0014:
                r1 = 3
                goto L_0x00ff
            L_0x0017:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r9.i
                if (r8 <= r0) goto L_0x0024
                r8 = r0
                goto L_0x00b7
            L_0x0024:
                int r8 = r9.g
                goto L_0x0014
            L_0x0027:
                com.google.android.material.bottomsheet.BottomSheetBehavior r4 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r5 = r4.f1420g
                if (r5 == 0) goto L_0x007c
                boolean r4 = r4.q0(r7, r9)
                if (r4 == 0) goto L_0x007c
                float r8 = java.lang.Math.abs(r8)
                float r0 = java.lang.Math.abs(r9)
                int r8 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
                if (r8 >= 0) goto L_0x0045
                r8 = 1140457472(0x43fa0000, float:500.0)
                int r8 = (r9 > r8 ? 1 : (r9 == r8 ? 0 : -1))
                if (r8 > 0) goto L_0x004b
            L_0x0045:
                boolean r8 = r6.n(r7)
                if (r8 == 0) goto L_0x0052
            L_0x004b:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.o
                r1 = 5
                goto L_0x00ff
            L_0x0052:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r8 = r8.f1411a
                if (r8 == 0) goto L_0x005b
                goto L_0x0010
            L_0x005b:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r9 = r9.g
                int r8 = r8 - r9
                int r8 = java.lang.Math.abs(r8)
                int r9 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.i
                int r9 = r9 - r0
                int r9 = java.lang.Math.abs(r9)
                if (r8 >= r9) goto L_0x00b3
            L_0x0077:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.g
                goto L_0x0014
            L_0x007c:
                int r0 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r0 == 0) goto L_0x00b9
                float r8 = java.lang.Math.abs(r8)
                float r9 = java.lang.Math.abs(r9)
                int r8 = (r8 > r9 ? 1 : (r8 == r9 ? 0 : -1))
                if (r8 <= 0) goto L_0x008d
                goto L_0x00b9
            L_0x008d:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r8 = r8.f1411a
                if (r8 == 0) goto L_0x009a
            L_0x0095:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.j
                goto L_0x00ff
            L_0x009a:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r9 = r9.i
                int r9 = r8 - r9
                int r9 = java.lang.Math.abs(r9)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.j
                int r8 = r8 - r0
                int r8 = java.lang.Math.abs(r8)
                if (r9 >= r8) goto L_0x0095
            L_0x00b3:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.i
            L_0x00b7:
                r1 = 6
                goto L_0x00ff
            L_0x00b9:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.f1411a
                if (r9 == 0) goto L_0x00dc
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r9 = r9.h
                int r9 = r8 - r9
                int r9 = java.lang.Math.abs(r9)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.j
                int r8 = r8 - r0
                int r8 = java.lang.Math.abs(r8)
                if (r9 >= r8) goto L_0x0095
                goto L_0x0010
            L_0x00dc:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r9.i
                if (r8 >= r0) goto L_0x00ed
                int r9 = r9.j
                int r9 = r8 - r9
                int r9 = java.lang.Math.abs(r9)
                if (r8 >= r9) goto L_0x00b3
                goto L_0x0077
            L_0x00ed:
                int r9 = r8 - r0
                int r9 = java.lang.Math.abs(r9)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.j
                int r8 = r8 - r0
                int r8 = java.lang.Math.abs(r8)
                if (r9 >= r8) goto L_0x0095
                goto L_0x00b3
            L_0x00ff:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                r0 = 1
                r9.r0(r7, r1, r8, r0)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.d.l(android.view.View, float, float):void");
        }

        public boolean m(View view, int i) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            int i2 = bottomSheetBehavior.k;
            if (i2 == 1 || bottomSheetBehavior.f1425l) {
                return false;
            }
            if (i2 == 3 && bottomSheetBehavior.p == i) {
                WeakReference<View> weakReference = bottomSheetBehavior.f1413b;
                View view2 = weakReference != null ? (View) weakReference.get() : null;
                if (view2 != null && view2.canScrollVertically(-1)) {
                    return false;
                }
            }
            WeakReference<V> weakReference2 = BottomSheetBehavior.this.f1405a;
            return weakReference2 != null && weakReference2.get() == view;
        }

        public final boolean n(View view) {
            int top = view.getTop();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return top > (bottomSheetBehavior.o + bottomSheetBehavior.V()) / 2;
        }
    }

    public class e implements mb {
        public final /* synthetic */ int a;

        public e(int i) {
            this.a = i;
        }

        public boolean a(View view, mb.a aVar) {
            BottomSheetBehavior.this.l0(this.a);
            return true;
        }
    }

    public static abstract class f {
        public abstract void a(View view, float f);

        public abstract void b(View view, int i);
    }

    public static class g extends gc {
        public static final Parcelable.Creator<g> CREATOR = new a();
        public final int a;
        public int b;

        /* renamed from: b  reason: collision with other field name */
        public boolean f1429b;
        public boolean c;
        public boolean d;

        public static class a implements Parcelable.ClassLoaderCreator<g> {
            /* renamed from: a */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            /* renamed from: c */
            public g[] newArray(int i) {
                return new g[i];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.a = parcel.readInt();
            this.b = parcel.readInt();
            boolean z = false;
            this.f1429b = parcel.readInt() == 1;
            this.c = parcel.readInt() == 1;
            this.d = parcel.readInt() == 1 ? true : z;
        }

        public g(Parcelable parcelable, BottomSheetBehavior<?> bottomSheetBehavior) {
            super(parcelable);
            this.a = bottomSheetBehavior.k;
            this.b = bottomSheetBehavior.f1415c;
            this.f1429b = bottomSheetBehavior.f1411a;
            this.c = bottomSheetBehavior.f1420g;
            this.d = bottomSheetBehavior.f1421h;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.a);
            parcel.writeInt(this.b);
            parcel.writeInt(this.f1429b ? 1 : 0);
            parcel.writeInt(this.c ? 1 : 0);
            parcel.writeInt(this.d ? 1 : 0);
        }
    }

    public class h implements Runnable {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public final View f1430a;
        public boolean b;

        public h(View view, int i) {
            this.f1430a = view;
            this.a = i;
        }

        public void run() {
            jc jcVar = BottomSheetBehavior.this.f1409a;
            if (jcVar == null || !jcVar.k(true)) {
                BottomSheetBehavior.this.m0(this.a);
            } else {
                ya.g0(this.f1430a, this);
            }
            this.b = false;
        }
    }

    public BottomSheetBehavior() {
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int i2;
        this.e = context.getResources().getDimensionPixelSize(q91.mtrl_min_touch_target_size);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.BottomSheetBehavior_Layout);
        this.f1417d = obtainStyledAttributes.hasValue(x91.BottomSheetBehavior_Layout_shapeAppearance);
        int i3 = x91.BottomSheetBehavior_Layout_backgroundTint;
        boolean hasValue = obtainStyledAttributes.hasValue(i3);
        if (hasValue) {
            R(context, attributeSet, hasValue, tc1.a(context, obtainStyledAttributes, i3));
        } else {
            Q(context, attributeSet, hasValue);
        }
        S();
        if (Build.VERSION.SDK_INT >= 21) {
            this.c = obtainStyledAttributes.getDimension(x91.BottomSheetBehavior_Layout_android_elevation, -1.0f);
        }
        int i4 = x91.BottomSheetBehavior_Layout_behavior_peekHeight;
        TypedValue peekValue = obtainStyledAttributes.peekValue(i4);
        if (peekValue == null || (i2 = peekValue.data) != -1) {
            h0(obtainStyledAttributes.getDimensionPixelSize(i4, -1));
        } else {
            h0(i2);
        }
        g0(obtainStyledAttributes.getBoolean(x91.BottomSheetBehavior_Layout_behavior_hideable, false));
        e0(obtainStyledAttributes.getBoolean(x91.BottomSheetBehavior_Layout_gestureInsetBottomIgnored, false));
        d0(obtainStyledAttributes.getBoolean(x91.BottomSheetBehavior_Layout_behavior_fitToContents, true));
        k0(obtainStyledAttributes.getBoolean(x91.BottomSheetBehavior_Layout_behavior_skipCollapsed, false));
        b0(obtainStyledAttributes.getBoolean(x91.BottomSheetBehavior_Layout_behavior_draggable, true));
        j0(obtainStyledAttributes.getInt(x91.BottomSheetBehavior_Layout_behavior_saveFlags, 0));
        f0(obtainStyledAttributes.getFloat(x91.BottomSheetBehavior_Layout_behavior_halfExpandedRatio, 0.5f));
        int i5 = x91.BottomSheetBehavior_Layout_behavior_expandedOffset;
        TypedValue peekValue2 = obtainStyledAttributes.peekValue(i5);
        c0((peekValue2 == null || peekValue2.type != 16) ? obtainStyledAttributes.getDimensionPixelOffset(i5, 0) : peekValue2.data);
        obtainStyledAttributes.recycle();
        this.f1400a = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    public boolean A(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i2, int i3) {
        this.l = 0;
        this.f1424k = false;
        return (i2 & 2) != 0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0069, code lost:
        if (java.lang.Math.abs(r3 - r2.h) < java.lang.Math.abs(r3 - r2.j)) goto L_0x0029;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0078, code lost:
        if (r3 < java.lang.Math.abs(r3 - r2.j)) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0088, code lost:
        if (java.lang.Math.abs(r3 - r1) < java.lang.Math.abs(r3 - r2.j)) goto L_0x00a8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00a6, code lost:
        if (java.lang.Math.abs(r3 - r2.i) < java.lang.Math.abs(r3 - r2.j)) goto L_0x00a8;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void C(androidx.coordinatorlayout.widget.CoordinatorLayout r3, V r4, android.view.View r5, int r6) {
        /*
            r2 = this;
            int r3 = r4.getTop()
            int r6 = r2.V()
            r0 = 3
            if (r3 != r6) goto L_0x000f
            r2.m0(r0)
            return
        L_0x000f:
            java.lang.ref.WeakReference<android.view.View> r3 = r2.f1413b
            if (r3 == 0) goto L_0x00b1
            java.lang.Object r3 = r3.get()
            if (r5 != r3) goto L_0x00b1
            boolean r3 = r2.f1424k
            if (r3 != 0) goto L_0x001f
            goto L_0x00b1
        L_0x001f:
            int r3 = r2.l
            r5 = 4
            r6 = 6
            if (r3 <= 0) goto L_0x003c
            boolean r3 = r2.f1411a
            if (r3 == 0) goto L_0x002d
        L_0x0029:
            int r3 = r2.h
            goto L_0x00ab
        L_0x002d:
            int r3 = r4.getTop()
            int r5 = r2.i
            if (r3 <= r5) goto L_0x0038
            r3 = r5
            goto L_0x00aa
        L_0x0038:
            int r3 = r2.g
            goto L_0x00ab
        L_0x003c:
            boolean r3 = r2.f1420g
            if (r3 == 0) goto L_0x004e
            float r3 = r2.W()
            boolean r3 = r2.q0(r4, r3)
            if (r3 == 0) goto L_0x004e
            int r3 = r2.o
            r0 = 5
            goto L_0x00ab
        L_0x004e:
            int r3 = r2.l
            if (r3 != 0) goto L_0x008b
            int r3 = r4.getTop()
            boolean r1 = r2.f1411a
            if (r1 == 0) goto L_0x006c
            int r6 = r2.h
            int r6 = r3 - r6
            int r6 = java.lang.Math.abs(r6)
            int r1 = r2.j
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r6 >= r3) goto L_0x008f
            goto L_0x0029
        L_0x006c:
            int r1 = r2.i
            if (r3 >= r1) goto L_0x007b
            int r5 = r2.j
            int r5 = r3 - r5
            int r5 = java.lang.Math.abs(r5)
            if (r3 >= r5) goto L_0x00a8
            goto L_0x0038
        L_0x007b:
            int r0 = r3 - r1
            int r0 = java.lang.Math.abs(r0)
            int r1 = r2.j
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r0 >= r3) goto L_0x008f
            goto L_0x00a8
        L_0x008b:
            boolean r3 = r2.f1411a
            if (r3 == 0) goto L_0x0093
        L_0x008f:
            int r3 = r2.j
            r0 = 4
            goto L_0x00ab
        L_0x0093:
            int r3 = r4.getTop()
            int r0 = r2.i
            int r0 = r3 - r0
            int r0 = java.lang.Math.abs(r0)
            int r1 = r2.j
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r0 >= r3) goto L_0x008f
        L_0x00a8:
            int r3 = r2.i
        L_0x00aa:
            r0 = 6
        L_0x00ab:
            r5 = 0
            r2.r0(r4, r0, r3, r5)
            r2.f1424k = r5
        L_0x00b1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.C(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.View, int):void");
    }

    public boolean D(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.k == 1 && actionMasked == 0) {
            return true;
        }
        jc jcVar = this.f1409a;
        if (jcVar != null) {
            jcVar.z(motionEvent);
        }
        if (actionMasked == 0) {
            Z();
        }
        if (this.f1402a == null) {
            this.f1402a = VelocityTracker.obtain();
        }
        this.f1402a.addMovement(motionEvent);
        if (this.f1409a != null && actionMasked == 2 && !this.f1423j && Math.abs(((float) this.q) - motionEvent.getY()) > ((float) this.f1409a.u())) {
            this.f1409a.b(v, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        return !this.f1423j;
    }

    public final int L(V v, int i2, int i3) {
        return ya.b(v, v.getResources().getString(i2), P(i3));
    }

    public final void M() {
        int O = O();
        if (this.f1411a) {
            this.j = Math.max(this.o - O, this.h);
        } else {
            this.j = this.o - O;
        }
    }

    public final void N() {
        this.i = (int) (((float) this.o) * (1.0f - this.b));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x001e, code lost:
        r0 = r3.f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int O() {
        /*
            r3 = this;
            boolean r0 = r3.f1416c
            if (r0 == 0) goto L_0x001a
            int r0 = r3.d
            int r1 = r3.o
            int r2 = r3.n
            int r2 = r2 * 9
            int r2 = r2 / 16
            int r1 = r1 - r2
            int r0 = java.lang.Math.max(r0, r1)
            int r1 = r3.m
            int r0 = java.lang.Math.min(r0, r1)
            return r0
        L_0x001a:
            boolean r0 = r3.f1418e
            if (r0 != 0) goto L_0x002c
            int r0 = r3.f
            if (r0 <= 0) goto L_0x002c
            int r1 = r3.f1415c
            int r2 = r3.e
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r1, r0)
            return r0
        L_0x002c:
            int r0 = r3.f1415c
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.O():int");
    }

    public final mb P(int i2) {
        return new e(i2);
    }

    public final void Q(Context context, AttributeSet attributeSet, boolean z) {
        R(context, attributeSet, z, (ColorStateList) null);
    }

    public final void R(Context context, AttributeSet attributeSet, boolean z, ColorStateList colorStateList) {
        if (this.f1417d) {
            this.f1410a = ld1.e(context, attributeSet, o91.bottomSheetStyle, a).m();
            hd1 hd1 = new hd1(this.f1410a);
            this.f1404a = hd1;
            hd1.M(context);
            if (!z || colorStateList == null) {
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(16842801, typedValue, true);
                this.f1404a.setTint(typedValue.data);
                return;
            }
            this.f1404a.W(colorStateList);
        }
    }

    public final void S() {
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
        this.f1401a = ofFloat;
        ofFloat.setDuration(500);
        this.f1401a.addUpdateListener(new b());
    }

    public void T(int i2) {
        float f2;
        float f3;
        View view = (View) this.f1405a.get();
        if (view != null && !this.f1406a.isEmpty()) {
            int i3 = this.j;
            if (i2 > i3 || i3 == V()) {
                int i4 = this.j;
                f2 = (float) (i4 - i2);
                f3 = (float) (this.o - i4);
            } else {
                int i5 = this.j;
                f2 = (float) (i5 - i2);
                f3 = (float) (i5 - V());
            }
            float f4 = f2 / f3;
            for (int i6 = 0; i6 < this.f1406a.size(); i6++) {
                this.f1406a.get(i6).a(view, f4);
            }
        }
    }

    public View U(View view) {
        if (ya.U(view)) {
            return view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View U = U(viewGroup.getChildAt(i2));
            if (U != null) {
                return U;
            }
        }
        return null;
    }

    public int V() {
        return this.f1411a ? this.h : this.g;
    }

    public final float W() {
        VelocityTracker velocityTracker = this.f1402a;
        if (velocityTracker == null) {
            return 0.0f;
        }
        velocityTracker.computeCurrentVelocity(1000, this.f1400a);
        return this.f1402a.getYVelocity(this.p);
    }

    public boolean X() {
        return this.f1418e;
    }

    public final void Y(V v, jb.a aVar, int i2) {
        ya.k0(v, aVar, (CharSequence) null, P(i2));
    }

    public final void Z() {
        this.p = -1;
        VelocityTracker velocityTracker = this.f1402a;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f1402a = null;
        }
    }

    public final void a0(g gVar) {
        int i2 = this.f1412b;
        if (i2 != 0) {
            if (i2 == -1 || (i2 & 1) == 1) {
                this.f1415c = gVar.b;
            }
            if (i2 == -1 || (i2 & 2) == 2) {
                this.f1411a = gVar.f1429b;
            }
            if (i2 == -1 || (i2 & 4) == 4) {
                this.f1420g = gVar.c;
            }
            if (i2 == -1 || (i2 & 8) == 8) {
                this.f1421h = gVar.d;
            }
        }
    }

    public void b0(boolean z) {
        this.f1422i = z;
    }

    public void c0(int i2) {
        if (i2 >= 0) {
            this.g = i2;
            return;
        }
        throw new IllegalArgumentException("offset must be greater than or equal to 0");
    }

    public void d0(boolean z) {
        if (this.f1411a != z) {
            this.f1411a = z;
            if (this.f1405a != null) {
                M();
            }
            m0((!this.f1411a || this.k != 6) ? this.k : 3);
            s0();
        }
    }

    public void e0(boolean z) {
        this.f1418e = z;
    }

    public void f0(float f2) {
        if (f2 <= 0.0f || f2 >= 1.0f) {
            throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
        }
        this.b = f2;
        if (this.f1405a != null) {
            N();
        }
    }

    public void g(CoordinatorLayout.f fVar) {
        super.g(fVar);
        this.f1405a = null;
        this.f1409a = null;
    }

    public void g0(boolean z) {
        if (this.f1420g != z) {
            this.f1420g = z;
            if (!z && this.k == 5) {
                l0(4);
            }
            s0();
        }
    }

    public void h0(int i2) {
        i0(i2, false);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0021  */
    /* JADX WARNING: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void i0(int r4, boolean r5) {
        /*
            r3 = this;
            r0 = 1
            r1 = 0
            r2 = -1
            if (r4 != r2) goto L_0x000c
            boolean r4 = r3.f1416c
            if (r4 != 0) goto L_0x0015
            r3.f1416c = r0
            goto L_0x001f
        L_0x000c:
            boolean r2 = r3.f1416c
            if (r2 != 0) goto L_0x0017
            int r2 = r3.f1415c
            if (r2 == r4) goto L_0x0015
            goto L_0x0017
        L_0x0015:
            r0 = 0
            goto L_0x001f
        L_0x0017:
            r3.f1416c = r1
            int r4 = java.lang.Math.max(r1, r4)
            r3.f1415c = r4
        L_0x001f:
            if (r0 == 0) goto L_0x0024
            r3.v0(r5)
        L_0x0024:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.i0(int, boolean):void");
    }

    public void j() {
        super.j();
        this.f1405a = null;
        this.f1409a = null;
    }

    public void j0(int i2) {
        this.f1412b = i2;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v11, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean k(androidx.coordinatorlayout.widget.CoordinatorLayout r10, V r11, android.view.MotionEvent r12) {
        /*
            r9 = this;
            boolean r0 = r11.isShown()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x00d2
            boolean r0 = r9.f1422i
            if (r0 != 0) goto L_0x000e
            goto L_0x00d2
        L_0x000e:
            int r0 = r12.getActionMasked()
            if (r0 != 0) goto L_0x0017
            r9.Z()
        L_0x0017:
            android.view.VelocityTracker r3 = r9.f1402a
            if (r3 != 0) goto L_0x0021
            android.view.VelocityTracker r3 = android.view.VelocityTracker.obtain()
            r9.f1402a = r3
        L_0x0021:
            android.view.VelocityTracker r3 = r9.f1402a
            r3.addMovement(r12)
            r3 = 0
            r4 = -1
            r5 = 2
            if (r0 == 0) goto L_0x003c
            if (r0 == r2) goto L_0x0031
            r11 = 3
            if (r0 == r11) goto L_0x0031
            goto L_0x007f
        L_0x0031:
            r9.f1425l = r1
            r9.p = r4
            boolean r11 = r9.f1423j
            if (r11 == 0) goto L_0x007f
            r9.f1423j = r1
            return r1
        L_0x003c:
            float r6 = r12.getX()
            int r6 = (int) r6
            float r7 = r12.getY()
            int r7 = (int) r7
            r9.q = r7
            int r7 = r9.k
            if (r7 == r5) goto L_0x006e
            java.lang.ref.WeakReference<android.view.View> r7 = r9.f1413b
            if (r7 == 0) goto L_0x0057
            java.lang.Object r7 = r7.get()
            android.view.View r7 = (android.view.View) r7
            goto L_0x0058
        L_0x0057:
            r7 = r3
        L_0x0058:
            if (r7 == 0) goto L_0x006e
            int r8 = r9.q
            boolean r7 = r10.B(r7, r6, r8)
            if (r7 == 0) goto L_0x006e
            int r7 = r12.getActionIndex()
            int r7 = r12.getPointerId(r7)
            r9.p = r7
            r9.f1425l = r2
        L_0x006e:
            int r7 = r9.p
            if (r7 != r4) goto L_0x007c
            int r4 = r9.q
            boolean r11 = r10.B(r11, r6, r4)
            if (r11 != 0) goto L_0x007c
            r11 = 1
            goto L_0x007d
        L_0x007c:
            r11 = 0
        L_0x007d:
            r9.f1423j = r11
        L_0x007f:
            boolean r11 = r9.f1423j
            if (r11 != 0) goto L_0x008e
            jc r11 = r9.f1409a
            if (r11 == 0) goto L_0x008e
            boolean r11 = r11.G(r12)
            if (r11 == 0) goto L_0x008e
            return r2
        L_0x008e:
            java.lang.ref.WeakReference<android.view.View> r11 = r9.f1413b
            if (r11 == 0) goto L_0x0099
            java.lang.Object r11 = r11.get()
            r3 = r11
            android.view.View r3 = (android.view.View) r3
        L_0x0099:
            if (r0 != r5) goto L_0x00d1
            if (r3 == 0) goto L_0x00d1
            boolean r11 = r9.f1423j
            if (r11 != 0) goto L_0x00d1
            int r11 = r9.k
            if (r11 == r2) goto L_0x00d1
            float r11 = r12.getX()
            int r11 = (int) r11
            float r0 = r12.getY()
            int r0 = (int) r0
            boolean r10 = r10.B(r3, r11, r0)
            if (r10 != 0) goto L_0x00d1
            jc r10 = r9.f1409a
            if (r10 == 0) goto L_0x00d1
            int r10 = r9.q
            float r10 = (float) r10
            float r11 = r12.getY()
            float r10 = r10 - r11
            float r10 = java.lang.Math.abs(r10)
            jc r11 = r9.f1409a
            int r11 = r11.u()
            float r11 = (float) r11
            int r10 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r10 <= 0) goto L_0x00d1
            r1 = 1
        L_0x00d1:
            return r1
        L_0x00d2:
            r9.f1423j = r2
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.k(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    public void k0(boolean z) {
        this.f1421h = z;
    }

    public boolean l(CoordinatorLayout coordinatorLayout, V v, int i2) {
        int i3;
        hd1 hd1;
        if (ya.z(coordinatorLayout) && !ya.z(v)) {
            v.setFitsSystemWindows(true);
        }
        if (this.f1405a == null) {
            this.d = coordinatorLayout.getResources().getDimensionPixelSize(q91.design_bottom_sheet_peek_height_min);
            n0(v);
            this.f1405a = new WeakReference<>(v);
            if (this.f1417d && (hd1 = this.f1404a) != null) {
                ya.r0(v, hd1);
            }
            hd1 hd12 = this.f1404a;
            if (hd12 != null) {
                float f2 = this.c;
                if (f2 == -1.0f) {
                    f2 = ya.w(v);
                }
                hd12.V(f2);
                boolean z = this.k == 3;
                this.f1419f = z;
                this.f1404a.X(z ? 0.0f : 1.0f);
            }
            s0();
            if (ya.A(v) == 0) {
                ya.x0(v, 1);
            }
        }
        if (this.f1409a == null) {
            this.f1409a = jc.m(coordinatorLayout, this.f1408a);
        }
        int top = v.getTop();
        coordinatorLayout.I(v, i2);
        this.n = coordinatorLayout.getWidth();
        this.o = coordinatorLayout.getHeight();
        int height = v.getHeight();
        this.m = height;
        this.h = Math.max(0, this.o - height);
        N();
        M();
        int i4 = this.k;
        if (i4 == 3) {
            i3 = V();
        } else if (i4 == 6) {
            i3 = this.i;
        } else if (this.f1420g && i4 == 5) {
            i3 = this.o;
        } else if (i4 == 4) {
            i3 = this.j;
        } else {
            if (i4 == 1 || i4 == 2) {
                ya.Z(v, top - v.getTop());
            }
            this.f1413b = new WeakReference<>(U(v));
            return true;
        }
        ya.Z(v, i3);
        this.f1413b = new WeakReference<>(U(v));
        return true;
    }

    public void l0(int i2) {
        if (i2 != this.k) {
            if (this.f1405a != null) {
                p0(i2);
            } else if (i2 == 4 || i2 == 3 || i2 == 6 || (this.f1420g && i2 == 5)) {
                this.k = i2;
            }
        }
    }

    public void m0(int i2) {
        View view;
        if (this.k != i2) {
            this.k = i2;
            WeakReference<V> weakReference = this.f1405a;
            if (weakReference != null && (view = (View) weakReference.get()) != null) {
                if (i2 == 3) {
                    u0(true);
                } else if (i2 == 6 || i2 == 5 || i2 == 4) {
                    u0(false);
                }
                t0(i2);
                for (int i3 = 0; i3 < this.f1406a.size(); i3++) {
                    this.f1406a.get(i3).b(view, i2);
                }
                s0();
            }
        }
    }

    public final void n0(View view) {
        if (Build.VERSION.SDK_INT >= 29 && !X() && !this.f1416c) {
            nc1.a(view, new c());
        }
    }

    public boolean o(CoordinatorLayout coordinatorLayout, V v, View view, float f2, float f3) {
        WeakReference<View> weakReference = this.f1413b;
        if (weakReference == null || view != weakReference.get()) {
            return false;
        }
        return this.k != 3 || super.o(coordinatorLayout, v, view, f2, f3);
    }

    public void o0(View view, int i2) {
        int i3;
        int i4;
        if (i2 == 4) {
            i3 = this.j;
        } else if (i2 == 6) {
            int i5 = this.i;
            if (!this.f1411a || i5 > (i4 = this.h)) {
                i3 = i5;
            } else {
                i3 = i4;
                i2 = 3;
            }
        } else if (i2 == 3) {
            i3 = V();
        } else if (!this.f1420g || i2 != 5) {
            throw new IllegalArgumentException("Illegal state argument: " + i2);
        } else {
            i3 = this.o;
        }
        r0(view, i2, i3, false);
    }

    public final void p0(int i2) {
        View view = (View) this.f1405a.get();
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent == null || !parent.isLayoutRequested() || !ya.S(view)) {
                o0(view, i2);
            } else {
                view.post(new a(view, i2));
            }
        }
    }

    public void q(CoordinatorLayout coordinatorLayout, V v, View view, int i2, int i3, int[] iArr, int i4) {
        int i5;
        if (i4 != 1) {
            WeakReference<View> weakReference = this.f1413b;
            if (view == (weakReference != null ? (View) weakReference.get() : null)) {
                int top = v.getTop();
                int i6 = top - i3;
                if (i3 <= 0) {
                    if (i3 < 0 && !view.canScrollVertically(-1)) {
                        int i7 = this.j;
                        if (i6 > i7 && !this.f1420g) {
                            iArr[1] = top - i7;
                            ya.Z(v, -iArr[1]);
                            i5 = 4;
                        } else if (this.f1422i) {
                            iArr[1] = i3;
                            ya.Z(v, -i3);
                            m0(1);
                        } else {
                            return;
                        }
                    }
                    T(v.getTop());
                    this.l = i3;
                    this.f1424k = true;
                } else if (i6 < V()) {
                    iArr[1] = top - V();
                    ya.Z(v, -iArr[1]);
                    i5 = 3;
                } else if (this.f1422i) {
                    iArr[1] = i3;
                    ya.Z(v, -i3);
                    m0(1);
                    T(v.getTop());
                    this.l = i3;
                    this.f1424k = true;
                } else {
                    return;
                }
                m0(i5);
                T(v.getTop());
                this.l = i3;
                this.f1424k = true;
            }
        }
    }

    public boolean q0(View view, float f2) {
        if (this.f1421h) {
            return true;
        }
        if (view.getTop() < this.j) {
            return false;
        }
        return Math.abs((((float) view.getTop()) + (f2 * 0.1f)) - ((float) this.j)) / ((float) O()) > 0.5f;
    }

    public void r0(View view, int i2, int i3, boolean z) {
        jc jcVar = this.f1409a;
        if (jcVar != null && (!z ? jcVar.H(view, view.getLeft(), i3) : jcVar.F(view.getLeft(), i3))) {
            m0(2);
            t0(i2);
            if (this.f1403a == null) {
                this.f1403a = new h(view, i2);
            }
            if (!this.f1403a.b) {
                BottomSheetBehavior<V>.defpackage.h hVar = this.f1403a;
                hVar.a = i2;
                ya.g0(view, hVar);
                boolean unused = this.f1403a.b = true;
                return;
            }
            this.f1403a.a = i2;
            return;
        }
        m0(i2);
    }

    public final void s0() {
        View view;
        jb.a aVar;
        WeakReference<V> weakReference = this.f1405a;
        if (weakReference != null && (view = (View) weakReference.get()) != null) {
            ya.i0(view, 524288);
            ya.i0(view, 262144);
            ya.i0(view, 1048576);
            int i2 = this.r;
            if (i2 != -1) {
                ya.i0(view, i2);
            }
            int i3 = 6;
            if (this.k != 6) {
                this.r = L(view, v91.bottomsheet_action_expand_halfway, 6);
            }
            if (this.f1420g && this.k != 5) {
                Y(view, jb.a.u, 5);
            }
            int i4 = this.k;
            if (i4 == 3) {
                if (this.f1411a) {
                    i3 = 4;
                }
                aVar = jb.a.t;
            } else if (i4 == 4) {
                if (this.f1411a) {
                    i3 = 3;
                }
                aVar = jb.a.s;
            } else if (i4 == 6) {
                Y(view, jb.a.t, 4);
                Y(view, jb.a.s, 3);
                return;
            } else {
                return;
            }
            Y(view, aVar, i3);
        }
    }

    public void t(CoordinatorLayout coordinatorLayout, V v, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
    }

    public final void t0(int i2) {
        ValueAnimator valueAnimator;
        if (i2 != 2) {
            boolean z = i2 == 3;
            if (this.f1419f != z) {
                this.f1419f = z;
                if (this.f1404a != null && (valueAnimator = this.f1401a) != null) {
                    if (valueAnimator.isRunning()) {
                        this.f1401a.reverse();
                        return;
                    }
                    float f2 = z ? 0.0f : 1.0f;
                    this.f1401a.setFloatValues(new float[]{1.0f - f2, f2});
                    this.f1401a.start();
                }
            }
        }
    }

    public final void u0(boolean z) {
        Map<View, Integer> map;
        int intValue;
        WeakReference<V> weakReference = this.f1405a;
        if (weakReference != null) {
            ViewParent parent = ((View) weakReference.get()).getParent();
            if (parent instanceof CoordinatorLayout) {
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
                int childCount = coordinatorLayout.getChildCount();
                if (Build.VERSION.SDK_INT >= 16 && z) {
                    if (this.f1407a == null) {
                        this.f1407a = new HashMap(childCount);
                    } else {
                        return;
                    }
                }
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = coordinatorLayout.getChildAt(i2);
                    if (childAt != this.f1405a.get()) {
                        if (z) {
                            if (Build.VERSION.SDK_INT >= 16) {
                                this.f1407a.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                            }
                            if (this.f1414b) {
                                intValue = 4;
                            }
                        } else if (this.f1414b && (map = this.f1407a) != null && map.containsKey(childAt)) {
                            intValue = this.f1407a.get(childAt).intValue();
                        }
                        ya.x0(childAt, intValue);
                    }
                }
                if (!z) {
                    this.f1407a = null;
                } else if (this.f1414b) {
                    ((View) this.f1405a.get()).sendAccessibilityEvent(8);
                }
            }
        }
    }

    public final void v0(boolean z) {
        View view;
        if (this.f1405a != null) {
            M();
            if (this.k == 4 && (view = (View) this.f1405a.get()) != null) {
                if (z) {
                    p0(this.k);
                } else {
                    view.requestLayout();
                }
            }
        }
    }

    public void x(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        g gVar = (g) parcelable;
        super.x(coordinatorLayout, v, gVar.a());
        a0(gVar);
        int i2 = gVar.a;
        if (i2 == 1 || i2 == 2) {
            i2 = 4;
        }
        this.k = i2;
    }

    public Parcelable y(CoordinatorLayout coordinatorLayout, V v) {
        return new g(super.y(coordinatorLayout, v), (BottomSheetBehavior<?>) this);
    }
}
