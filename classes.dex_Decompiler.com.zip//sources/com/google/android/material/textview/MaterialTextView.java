package com.google.android.material.textview;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;

public class MaterialTextView extends v2 {
    public MaterialTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public MaterialTextView(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public MaterialTextView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(ee1.c(context, attributeSet, i, i2), attributeSet, i);
        int h;
        Context context2 = getContext();
        if (g(context2)) {
            Resources.Theme theme = context2.getTheme();
            if (!j(context2, theme, attributeSet, i, i2) && (h = h(theme, attributeSet, i, i2)) != -1) {
                e(theme, h);
            }
        }
    }

    public static boolean g(Context context) {
        return sc1.b(context, o91.textAppearanceLineHeightEnabled, true);
    }

    public static int h(Resources.Theme theme, AttributeSet attributeSet, int i, int i2) {
        TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, x91.MaterialTextView, i, i2);
        int resourceId = obtainStyledAttributes.getResourceId(x91.MaterialTextView_android_textAppearance, -1);
        obtainStyledAttributes.recycle();
        return resourceId;
    }

    public static int i(Context context, TypedArray typedArray, int... iArr) {
        int i = -1;
        for (int i2 = 0; i2 < iArr.length && i < 0; i2++) {
            i = tc1.c(context, typedArray, iArr[i2], -1);
        }
        return i;
    }

    public static boolean j(Context context, Resources.Theme theme, AttributeSet attributeSet, int i, int i2) {
        TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, x91.MaterialTextView, i, i2);
        int i3 = i(context, obtainStyledAttributes, x91.MaterialTextView_android_lineHeight, x91.MaterialTextView_lineHeight);
        obtainStyledAttributes.recycle();
        return i3 != -1;
    }

    public final void e(Resources.Theme theme, int i) {
        TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(i, x91.MaterialTextAppearance);
        int i2 = i(getContext(), obtainStyledAttributes, x91.MaterialTextAppearance_android_lineHeight, x91.MaterialTextAppearance_lineHeight);
        obtainStyledAttributes.recycle();
        if (i2 >= 0) {
            setLineHeight(i2);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        if (g(context)) {
            e(context.getTheme(), i);
        }
    }
}
