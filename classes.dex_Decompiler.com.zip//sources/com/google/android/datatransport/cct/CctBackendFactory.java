package com.google.android.datatransport.cct;

import androidx.annotation.Keep;

@Keep
public class CctBackendFactory implements xq {
    public gr create(br brVar) {
        return new ip(brVar.b(), brVar.e(), brVar.d());
    }
}
