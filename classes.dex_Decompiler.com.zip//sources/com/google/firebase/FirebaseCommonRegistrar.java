package com.google.firebase;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;

public class FirebaseCommonRegistrar implements wf1 {
    public static /* synthetic */ String a(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        return applicationInfo != null ? String.valueOf(applicationInfo.targetSdkVersion) : "";
    }

    public static /* synthetic */ String b(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        return (applicationInfo == null || Build.VERSION.SDK_INT < 24) ? "" : String.valueOf(applicationInfo.minSdkVersion);
    }

    public static /* synthetic */ String c(Context context) {
        int i = Build.VERSION.SDK_INT;
        return (i < 16 || !context.getPackageManager().hasSystemFeature("android.hardware.type.television")) ? (i < 20 || !context.getPackageManager().hasSystemFeature("android.hardware.type.watch")) ? (i < 23 || !context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) ? (i < 26 || !context.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) ? "" : "embedded" : "auto" : "watch" : "tv";
    }

    public static /* synthetic */ String d(Context context) {
        String installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
        return installerPackageName != null ? e(installerPackageName) : "";
    }

    public static String e(String str) {
        return str.replace(' ', '_').replace('/', '_');
    }

    public List<sf1<?>> getComponents() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(wp1.b());
        arrayList.add(em1.b());
        arrayList.add(aq1.a("fire-android", String.valueOf(Build.VERSION.SDK_INT)));
        arrayList.add(aq1.a("fire-core", "20.0.0"));
        arrayList.add(aq1.a("device-name", e(Build.PRODUCT)));
        arrayList.add(aq1.a("device-model", e(Build.DEVICE)));
        arrayList.add(aq1.a("device-brand", e(Build.BRAND)));
        arrayList.add(aq1.b("android-target-sdk", ne1.a));
        arrayList.add(aq1.b("android-min-sdk", oe1.a));
        arrayList.add(aq1.b("android-platform", pe1.a));
        arrayList.add(aq1.b("android-installer", me1.a));
        String a = yp1.a();
        if (a != null) {
            arrayList.add(aq1.a("kotlin", a));
        }
        return arrayList;
    }
}
