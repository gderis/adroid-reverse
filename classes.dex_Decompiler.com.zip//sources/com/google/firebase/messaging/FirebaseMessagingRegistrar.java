package com.google.firebase.messaging;

import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;

@Keep
public class FirebaseMessagingRegistrar implements wf1 {
    public static final /* synthetic */ FirebaseMessaging lambda$getComponents$0$FirebaseMessagingRegistrar(tf1 tf1) {
        return new FirebaseMessaging((re1) tf1.e(re1.class), (im1) tf1.e(im1.class), tf1.b(bq1.class), tf1.b(gm1.class), (sm1) tf1.e(sm1.class), (dp) tf1.e(dp.class), (am1) tf1.e(am1.class));
    }

    @Keep
    public List<sf1<?>> getComponents() {
        return Arrays.asList(new sf1[]{sf1.a(FirebaseMessaging.class).b(zf1.j(re1.class)).b(zf1.h(im1.class)).b(zf1.i(bq1.class)).b(zf1.i(gm1.class)).b(zf1.h(dp.class)).b(zf1.j(sm1.class)).b(zf1.j(am1.class)).f(lo1.a).c().d(), aq1.a("fire-fcm", "22.0.0")});
    }
}
