package com.google.firebase.messaging;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.Keep;
import defpackage.dp1;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.concurrent.GuardedBy;

public class FirebaseMessaging {
    public static final long a = TimeUnit.HOURS.toSeconds(8);
    @SuppressLint({"StaticFieldLeak"})

    /* renamed from: a  reason: collision with other field name */
    public static dp1 f1614a;
    @SuppressLint({"FirebaseUnknownNullness"})

    /* renamed from: a  reason: collision with other field name */
    public static dp f1615a;
    @GuardedBy("FirebaseMessaging.class")

    /* renamed from: a  reason: collision with other field name */
    public static ScheduledExecutorService f1616a;

    /* renamed from: a  reason: collision with other field name */
    public final Application.ActivityLifecycleCallbacks f1617a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f1618a;

    /* renamed from: a  reason: collision with other field name */
    public final a f1619a;

    /* renamed from: a  reason: collision with other field name */
    public final im1 f1620a;

    /* renamed from: a  reason: collision with other field name */
    public final Executor f1621a;

    /* renamed from: a  reason: collision with other field name */
    public final n81<ip1> f1622a;

    /* renamed from: a  reason: collision with other field name */
    public final oo1 f1623a;

    /* renamed from: a  reason: collision with other field name */
    public final re1 f1624a;

    /* renamed from: a  reason: collision with other field name */
    public final sm1 f1625a;

    /* renamed from: a  reason: collision with other field name */
    public final to1 f1626a;

    /* renamed from: a  reason: collision with other field name */
    public final yo1 f1627a;
    @GuardedBy("this")

    /* renamed from: a  reason: collision with other field name */
    public boolean f1628a;
    public final Executor b;

    public class a {
        public final am1 a;
        @GuardedBy("this")

        /* renamed from: a  reason: collision with other field name */
        public Boolean f1630a;
        @GuardedBy("this")

        /* renamed from: a  reason: collision with other field name */
        public yl1<qe1> f1631a;
        @GuardedBy("this")

        /* renamed from: a  reason: collision with other field name */
        public boolean f1632a;

        public a(am1 am1) {
            this.a = am1;
        }

        public synchronized void a() {
            if (!this.f1632a) {
                Boolean d = d();
                this.f1630a = d;
                if (d == null) {
                    ko1 ko1 = new ko1(this);
                    this.f1631a = ko1;
                    this.a.b(qe1.class, ko1);
                }
                this.f1632a = true;
            }
        }

        public synchronized boolean b() {
            Boolean bool;
            a();
            bool = this.f1630a;
            return bool != null ? bool.booleanValue() : FirebaseMessaging.this.f1624a.p();
        }

        public final /* synthetic */ void c(xl1 xl1) {
            if (b()) {
                FirebaseMessaging.this.r();
            }
        }

        public final Boolean d() {
            ApplicationInfo applicationInfo;
            Bundle bundle;
            Context g = FirebaseMessaging.this.f1624a.g();
            SharedPreferences sharedPreferences = g.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("auto_init")) {
                return Boolean.valueOf(sharedPreferences.getBoolean("auto_init", false));
            }
            try {
                PackageManager packageManager = g.getPackageManager();
                if (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(g.getPackageName(), 128)) == null || (bundle = applicationInfo.metaData) == null || !bundle.containsKey("firebase_messaging_auto_init_enabled")) {
                    return null;
                }
                return Boolean.valueOf(applicationInfo.metaData.getBoolean("firebase_messaging_auto_init_enabled"));
            } catch (PackageManager.NameNotFoundException unused) {
                return null;
            }
        }
    }

    public FirebaseMessaging(re1 re1, im1 im1, km1<bq1> km1, km1<gm1> km12, sm1 sm1, dp dpVar, am1 am1) {
        this(re1, im1, km1, km12, sm1, dpVar, am1, new to1(re1.g()));
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public FirebaseMessaging(defpackage.re1 r11, defpackage.im1 r12, defpackage.km1<defpackage.bq1> r13, defpackage.km1<defpackage.gm1> r14, defpackage.sm1 r15, defpackage.dp r16, defpackage.am1 r17, defpackage.to1 r18) {
        /*
            r10 = this;
            oo1 r7 = new oo1
            r0 = r7
            r1 = r11
            r2 = r18
            r3 = r13
            r4 = r14
            r5 = r15
            r0.<init>(r1, r2, r3, r4, r5)
            java.util.concurrent.ExecutorService r8 = defpackage.do1.e()
            java.util.concurrent.ScheduledExecutorService r9 = defpackage.do1.b()
            r0 = r10
            r2 = r12
            r3 = r15
            r4 = r16
            r5 = r17
            r6 = r18
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.messaging.FirebaseMessaging.<init>(re1, im1, km1, km1, sm1, dp, am1, to1):void");
    }

    public FirebaseMessaging(re1 re1, im1 im1, sm1 sm1, dp dpVar, am1 am1, to1 to1, oo1 oo1, Executor executor, Executor executor2) {
        this.f1628a = false;
        f1615a = dpVar;
        this.f1624a = re1;
        this.f1620a = im1;
        this.f1625a = sm1;
        this.f1619a = new a(am1);
        Context g = re1.g();
        this.f1618a = g;
        eo1 eo1 = new eo1();
        this.f1617a = eo1;
        this.f1626a = to1;
        this.b = executor;
        this.f1623a = oo1;
        this.f1627a = new yo1(executor);
        this.f1621a = executor2;
        Context g2 = re1.g();
        if (g2 instanceof Application) {
            ((Application) g2).registerActivityLifecycleCallbacks(eo1);
        } else {
            String valueOf = String.valueOf(g2);
            StringBuilder sb = new StringBuilder(valueOf.length() + 125);
            sb.append("Context ");
            sb.append(valueOf);
            sb.append(" was not an application, can't register for lifecycle callbacks. Some notification events may be dropped as a result.");
            sb.toString();
        }
        if (im1 != null) {
            im1.c(new fo1(this));
        }
        synchronized (FirebaseMessaging.class) {
            if (f1614a == null) {
                f1614a = new dp1(g);
            }
        }
        executor2.execute(new go1(this));
        n81<ip1> d = ip1.d(this, sm1, to1, oo1, g, do1.f());
        this.f1622a = d;
        d.e(do1.g(), new ho1(this));
    }

    @Keep
    public static synchronized FirebaseMessaging getInstance(re1 re1) {
        FirebaseMessaging firebaseMessaging;
        Class cls = FirebaseMessaging.class;
        synchronized (cls) {
            firebaseMessaging = (FirebaseMessaging) re1.f(cls);
            s10.k(firebaseMessaging, "Firebase Messaging component is not present");
        }
        return firebaseMessaging;
    }

    public static dp h() {
        return f1615a;
    }

    public String c() {
        im1 im1 = this.f1620a;
        if (im1 != null) {
            try {
                return (String) q81.a(im1.a());
            } catch (InterruptedException | ExecutionException e) {
                throw new IOException(e);
            }
        } else {
            dp1.a g = g();
            if (!t(g)) {
                return g.f2038a;
            }
            String c = to1.c(this.f1624a);
            try {
                String str = (String) q81.a(this.f1625a.b().h(do1.d(), new io1(this, c)));
                f1614a.f(f(), c, str, this.f1626a.a());
                if (g == null || !str.equals(g.f2038a)) {
                    i(str);
                }
                return str;
            } catch (InterruptedException | ExecutionException e2) {
                throw new IOException(e2);
            }
        }
    }

    public void d(Runnable runnable, long j) {
        synchronized (FirebaseMessaging.class) {
            if (f1616a == null) {
                f1616a = new ScheduledThreadPoolExecutor(1, new s40("TAG"));
            }
            f1616a.schedule(runnable, j, TimeUnit.SECONDS);
        }
    }

    public Context e() {
        return this.f1618a;
    }

    public final String f() {
        return "[DEFAULT]".equals(this.f1624a.i()) ? "" : this.f1624a.k();
    }

    public dp1.a g() {
        return f1614a.d(f(), to1.c(this.f1624a));
    }

    public final void i(String str) {
        if ("[DEFAULT]".equals(this.f1624a.i())) {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                String valueOf = String.valueOf(this.f1624a.i());
                if (valueOf.length() != 0) {
                    "Invoking onNewToken for app: ".concat(valueOf);
                } else {
                    new String("Invoking onNewToken for app: ");
                }
            }
            Intent intent = new Intent("com.google.firebase.messaging.NEW_TOKEN");
            intent.putExtra("token", str);
            new co1(this.f1618a).g(intent);
        }
    }

    public boolean j() {
        return this.f1619a.b();
    }

    public boolean k() {
        return this.f1626a.g();
    }

    public final /* synthetic */ n81 l(n81 n81) {
        return this.f1623a.d((String) n81.j());
    }

    public final /* synthetic */ n81 m(String str, n81 n81) {
        return this.f1627a.a(str, new jo1(this, n81));
    }

    public final /* synthetic */ void n() {
        if (j()) {
            r();
        }
    }

    public final /* synthetic */ void o(ip1 ip1) {
        if (j()) {
            ip1.n();
        }
    }

    public synchronized void p(boolean z) {
        this.f1628a = z;
    }

    public final synchronized void q() {
        if (!this.f1628a) {
            s(0);
        }
    }

    public final void r() {
        im1 im1 = this.f1620a;
        if (im1 != null) {
            im1.b();
        } else if (t(g())) {
            q();
        }
    }

    public synchronized void s(long j) {
        d(new ep1(this, Math.min(Math.max(30, j + j), a)), j);
        this.f1628a = true;
    }

    public boolean t(dp1.a aVar) {
        return aVar == null || aVar.b(this.f1626a.a());
    }
}
