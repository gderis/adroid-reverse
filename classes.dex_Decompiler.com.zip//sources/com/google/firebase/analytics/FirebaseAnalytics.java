package com.google.firebase.analytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Keep;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public final class FirebaseAnalytics {
    public static volatile FirebaseAnalytics a;

    /* renamed from: a  reason: collision with other field name */
    public final cf0 f1613a;

    public FirebaseAnalytics(cf0 cf0) {
        s10.j(cf0);
        this.f1613a = cf0;
    }

    @Keep
    public static FirebaseAnalytics getInstance(Context context) {
        if (a == null) {
            synchronized (FirebaseAnalytics.class) {
                if (a == null) {
                    a = new FirebaseAnalytics(cf0.r(context, (String) null, (String) null, (String) null, (Bundle) null));
                }
            }
        }
        return a;
    }

    @Keep
    public static a31 getScionFrontendApiImplementation(Context context, Bundle bundle) {
        cf0 r = cf0.r(context, (String) null, (String) null, (String) null, bundle);
        if (r == null) {
            return null;
        }
        return new ef1(r);
    }

    @Keep
    public String getFirebaseInstanceId() {
        try {
            return (String) q81.b(rm1.l().b(), 30000, TimeUnit.MILLISECONDS);
        } catch (ExecutionException e) {
            throw new IllegalStateException(e.getCause());
        } catch (TimeoutException unused) {
            throw new IllegalThreadStateException("Firebase Installations getId Task has timed out.");
        } catch (InterruptedException e2) {
            throw new IllegalStateException(e2);
        }
    }

    @Deprecated
    @Keep
    public void setCurrentScreen(Activity activity, String str, String str2) {
        this.f1613a.A(activity, str, str2);
    }
}
