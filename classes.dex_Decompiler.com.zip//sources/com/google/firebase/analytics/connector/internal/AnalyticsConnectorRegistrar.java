package com.google.firebase.analytics.connector.internal;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;

@Keep
public class AnalyticsConnectorRegistrar implements wf1 {
    @SuppressLint({"MissingPermission"})
    @Keep
    public List<sf1<?>> getComponents() {
        return Arrays.asList(new sf1[]{sf1.a(ue1.class).b(zf1.j(re1.class)).b(zf1.j(Context.class)).b(zf1.j(am1.class)).f(we1.a).e().d(), aq1.a("fire-analytics", "19.0.0")});
    }
}
