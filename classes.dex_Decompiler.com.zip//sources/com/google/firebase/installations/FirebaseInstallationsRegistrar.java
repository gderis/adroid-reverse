package com.google.firebase.installations;

import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;

@Keep
public class FirebaseInstallationsRegistrar implements wf1 {
    public static /* synthetic */ sm1 lambda$getComponents$0(tf1 tf1) {
        return new rm1((re1) tf1.e(re1.class), tf1.b(bq1.class), tf1.b(gm1.class));
    }

    public List<sf1<?>> getComponents() {
        return Arrays.asList(new sf1[]{sf1.a(sm1.class).b(zf1.j(re1.class)).b(zf1.i(gm1.class)).b(zf1.i(bq1.class)).f(om1.a).d(), aq1.a("fire-installations", "17.0.0")});
    }
}
