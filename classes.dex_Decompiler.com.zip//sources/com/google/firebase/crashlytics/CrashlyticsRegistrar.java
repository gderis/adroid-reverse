package com.google.firebase.crashlytics;

import java.util.Arrays;
import java.util.List;

public class CrashlyticsRegistrar implements wf1 {
    public final qg1 a(tf1 tf1) {
        return qg1.b((re1) tf1.e(re1.class), (sm1) tf1.e(sm1.class), tf1.b(rg1.class), tf1.d(ue1.class));
    }

    public List<sf1<?>> getComponents() {
        return Arrays.asList(new sf1[]{sf1.a(qg1.class).b(zf1.j(re1.class)).b(zf1.j(sm1.class)).b(zf1.i(rg1.class)).b(zf1.a(ue1.class)).f(new ng1(this)).e().d(), aq1.a("fire-cls", "18.0.0")});
    }
}
