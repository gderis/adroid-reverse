package com.google.firebase.datatransport;

import android.content.Context;
import androidx.annotation.Keep;
import java.util.Collections;
import java.util.List;

@Keep
public class TransportRegistrar implements wf1 {
    public List<sf1<?>> getComponents() {
        return Collections.singletonList(sf1.a(dp.class).b(zf1.j(Context.class)).f(gl1.a).d());
    }
}
