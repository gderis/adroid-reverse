package com.google.firebase.iid;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import java.util.concurrent.ExecutionException;

public final class FirebaseInstanceIdReceiver extends su {
    public final int b(Context context, ru ruVar) {
        try {
            return ((Integer) q81.a(new co1(context).g(ruVar.A0()))).intValue();
        } catch (InterruptedException | ExecutionException unused) {
            return 500;
        }
    }

    public final void c(Context context, Bundle bundle) {
        Intent putExtras = new Intent("com.google.firebase.messaging.NOTIFICATION_DISMISS").putExtras(bundle);
        if (so1.A(putExtras)) {
            so1.s(putExtras);
        }
    }
}
