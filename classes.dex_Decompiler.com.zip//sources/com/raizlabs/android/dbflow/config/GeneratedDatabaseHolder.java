package com.raizlabs.android.dbflow.config;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.UUID;

public final class GeneratedDatabaseHolder extends rq1 {
    public GeneratedDatabaseHolder() {
        this.typeConverters.put(Boolean.class, new yq1());
        this.typeConverters.put(Character.class, new ar1());
        this.typeConverters.put(BigDecimal.class, new wq1());
        this.typeConverters.put(BigInteger.class, new xq1());
        this.typeConverters.put(Date.class, new cr1());
        this.typeConverters.put(Time.class, new cr1());
        this.typeConverters.put(Timestamp.class, new cr1());
        this.typeConverters.put(Calendar.class, new zq1());
        this.typeConverters.put(GregorianCalendar.class, new zq1());
        this.typeConverters.put(java.util.Date.class, new br1());
        this.typeConverters.put(UUID.class, new er1());
        new oq1(this);
    }
}
