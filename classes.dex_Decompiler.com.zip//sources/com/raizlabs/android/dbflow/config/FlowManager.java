package com.raizlabs.android.dbflow.config;

import android.content.Context;
import defpackage.sq1;
import defpackage.tq1;
import java.util.HashSet;

public class FlowManager {
    public static GlobalDatabaseHolder a = new GlobalDatabaseHolder();

    /* renamed from: a  reason: collision with other field name */
    public static final String f1633a;

    /* renamed from: a  reason: collision with other field name */
    public static HashSet<Class<? extends rq1>> f1634a = new HashSet<>();

    /* renamed from: a  reason: collision with other field name */
    public static sq1 f1635a;
    public static final String b;

    public static class GlobalDatabaseHolder extends rq1 {
        private boolean initialized;

        private GlobalDatabaseHolder() {
            this.initialized = false;
        }

        public void add(rq1 rq1) {
            this.databaseDefinitionMap.putAll(rq1.databaseDefinitionMap);
            this.databaseNameMap.putAll(rq1.databaseNameMap);
            this.typeConverters.putAll(rq1.typeConverters);
            this.databaseClassLookupMap.putAll(rq1.databaseClassLookupMap);
            this.initialized = true;
        }

        public boolean isInitialized() {
            return this.initialized;
        }
    }

    public static class b extends RuntimeException {
        public b(String str, Throwable th) {
            super(str, th);
        }
    }

    static {
        String name = FlowManager.class.getPackage().getName();
        f1633a = name;
        b = name + "." + "GeneratedDatabaseHolder";
    }

    public static void a() {
        if (!a.isInitialized()) {
            throw new IllegalStateException("The global database holder is not initialized. Ensure you call FlowManager.init() before accessing the database.");
        }
    }

    public static sq1 b() {
        sq1 sq1 = f1635a;
        if (sq1 != null) {
            return sq1;
        }
        throw new IllegalStateException("Configuration is not initialized. Please call init(FlowConfig) in your application class.");
    }

    public static Context c() {
        sq1 sq1 = f1635a;
        if (sq1 != null) {
            return sq1.d();
        }
        throw new IllegalStateException("You must provide a valid FlowConfig instance. We recommend calling init() in your application class.");
    }

    public static qq1 d(Class<?> cls) {
        a();
        qq1 databaseForTable = a.getDatabaseForTable(cls);
        if (databaseForTable != null) {
            return databaseForTable;
        }
        throw new ws1("Model object: " + cls.getName() + " is not registered with a Database. Did you forget an annotation?");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [java.lang.Class<TModel>, java.lang.Class] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static <TModel> defpackage.us1<TModel> e(java.lang.Class<TModel> r2) {
        /*
            ys1 r0 = g(r2)
            if (r0 != 0) goto L_0x0010
            zs1 r0 = i(r2)
            if (r0 != 0) goto L_0x0010
            at1 r0 = j(r2)
        L_0x0010:
            if (r0 != 0) goto L_0x0017
            java.lang.String r1 = "InstanceAdapter"
            q(r1, r2)
        L_0x0017:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.raizlabs.android.dbflow.config.FlowManager.e(java.lang.Class):us1");
    }

    public static <TModel> ys1<TModel> f(Class<TModel> cls) {
        ys1<TModel> g = g(cls);
        if (g == null) {
            q("ModelAdapter", cls);
        }
        return g;
    }

    public static <T> ys1<T> g(Class<T> cls) {
        return d(cls).n(cls);
    }

    public static kr1 h(Class<?> cls) {
        return d(cls).p();
    }

    public static <T> zs1<T> i(Class<T> cls) {
        return d(cls).q(cls);
    }

    public static <T> at1<T> j(Class<T> cls) {
        return d(cls).s(cls);
    }

    public static String k(Class<?> cls) {
        ys1<?> g = g(cls);
        if (g != null) {
            return g.b();
        }
        zs1<?> i = i(cls);
        if (i != null) {
            return i.r();
        }
        q("ModelAdapter/ModelViewAdapter", cls);
        return null;
    }

    public static dr1 l(Class<?> cls) {
        a();
        return a.getTypeConverterForClass(cls);
    }

    public static kt1 m(Class<?> cls) {
        return d(cls).u();
    }

    public static void n(Context context) {
        o(new sq1.a(context).a());
    }

    public static void o(sq1 sq1) {
        f1635a = sq1;
        try {
            p(Class.forName(b));
        } catch (b e) {
            tq1.b(tq1.b.W, e.getMessage());
        } catch (ClassNotFoundException unused) {
            tq1.b(tq1.b.W, "Could not find the default GeneratedDatabaseHolder");
        }
        if (!sq1.b().isEmpty()) {
            for (Class<? extends rq1> p : sq1.b()) {
                p(p);
            }
        }
        if (sq1.e()) {
            for (qq1 u : a.getDatabaseDefinitions()) {
                u.u();
            }
        }
    }

    public static void p(Class<? extends rq1> cls) {
        if (!f1634a.contains(cls)) {
            try {
                rq1 rq1 = (rq1) cls.newInstance();
                if (rq1 != null) {
                    a.add(rq1);
                    f1634a.add(cls);
                }
            } catch (Throwable th) {
                th.printStackTrace();
                throw new b("Cannot load " + cls, th);
            }
        }
    }

    public static void q(String str, Class<?> cls) {
        throw new IllegalArgumentException("Cannot find " + str + " for " + cls + ". Ensure the class is annotated with proper annotation.");
    }
}
