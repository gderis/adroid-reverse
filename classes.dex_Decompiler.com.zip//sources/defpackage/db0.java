package defpackage;

import com.google.android.gms.common.api.Status;

/* renamed from: db0  reason: default package */
public abstract class db0 extends fu0<Status> {
    public db0(mw mwVar) {
        super(mwVar);
    }

    public final /* bridge */ /* synthetic */ rw g(Status status) {
        return status;
    }
}
