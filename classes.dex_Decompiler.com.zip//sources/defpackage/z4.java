package defpackage;

import defpackage.b5;
import defpackage.g5;
import java.util.ArrayList;

/* renamed from: z4  reason: default package */
public class z4 implements b5.a {
    public float a = 0.0f;

    /* renamed from: a  reason: collision with other field name */
    public g5 f6153a = null;

    /* renamed from: a  reason: collision with other field name */
    public ArrayList<g5> f6154a = new ArrayList<>();

    /* renamed from: a  reason: collision with other field name */
    public a f6155a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f6156a = false;
    public boolean b = false;

    /* renamed from: z4$a */
    public interface a {
        void a();

        g5 b(int i);

        void c(g5 g5Var, float f);

        void clear();

        void d(float f);

        void e(g5 g5Var, float f, boolean z);

        boolean f(g5 g5Var);

        float g(g5 g5Var, boolean z);

        float h(int i);

        int i();

        float j(z4 z4Var, boolean z);

        float k(g5 g5Var);
    }

    public z4() {
    }

    public z4(a5 a5Var) {
        this.f6155a = new y4(this, a5Var);
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00bb  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String A() {
        /*
            r9 = this;
            g5 r0 = r9.f6153a
            java.lang.String r1 = ""
            if (r0 != 0) goto L_0x0014
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r1)
            java.lang.String r1 = "0"
            r0.append(r1)
            goto L_0x0021
        L_0x0014:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r1)
            g5 r1 = r9.f6153a
            r0.append(r1)
        L_0x0021:
            java.lang.String r0 = r0.toString()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " = "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r1 = r9.a
            r2 = 0
            r3 = 1
            r4 = 0
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 == 0) goto L_0x0052
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            float r0 = r9.a
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            r1 = 1
            goto L_0x0053
        L_0x0052:
            r1 = 0
        L_0x0053:
            z4$a r5 = r9.f6155a
            int r5 = r5.i()
        L_0x0059:
            if (r2 >= r5) goto L_0x00d6
            z4$a r6 = r9.f6155a
            g5 r6 = r6.b(r2)
            if (r6 != 0) goto L_0x0064
            goto L_0x00d3
        L_0x0064:
            z4$a r7 = r9.f6155a
            float r7 = r7.h(r2)
            int r8 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r8 != 0) goto L_0x006f
            goto L_0x00d3
        L_0x006f:
            java.lang.String r6 = r6.toString()
            r8 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r1 != 0) goto L_0x0086
            int r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r1 >= 0) goto L_0x00af
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "- "
            goto L_0x00a6
        L_0x0086:
            int r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r1 <= 0) goto L_0x009c
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " + "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            goto L_0x00af
        L_0x009c:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " - "
        L_0x00a6:
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r7 = r7 * r8
        L_0x00af:
            r1 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1))
            if (r1 != 0) goto L_0x00bb
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            goto L_0x00c8
        L_0x00bb:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            r1.append(r7)
            java.lang.String r0 = " "
        L_0x00c8:
            r1.append(r0)
            r1.append(r6)
            java.lang.String r0 = r1.toString()
            r1 = 1
        L_0x00d3:
            int r2 = r2 + 1
            goto L_0x0059
        L_0x00d6:
            if (r1 != 0) goto L_0x00e9
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "0.0"
            r1.append(r0)
            java.lang.String r0 = r1.toString()
        L_0x00e9:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z4.A():java.lang.String");
    }

    public void B(b5 b5Var, g5 g5Var, boolean z) {
        if (g5Var.f2564b) {
            this.a += g5Var.f2556a * this.f6155a.k(g5Var);
            this.f6155a.g(g5Var, z);
            if (z) {
                g5Var.c(this);
            }
            if (b5.c && this.f6155a.i() == 0) {
                this.b = true;
                b5Var.f1046f = true;
            }
        }
    }

    public void C(b5 b5Var, z4 z4Var, boolean z) {
        this.a += z4Var.a * this.f6155a.j(z4Var, z);
        if (z) {
            z4Var.f6153a.c(this);
        }
        if (b5.c && this.f6153a != null && this.f6155a.i() == 0) {
            this.b = true;
            b5Var.f1046f = true;
        }
    }

    public void D(b5 b5Var, g5 g5Var, boolean z) {
        if (g5Var.f2566c) {
            float k = this.f6155a.k(g5Var);
            this.a += g5Var.b * k;
            this.f6155a.g(g5Var, z);
            if (z) {
                g5Var.c(this);
            }
            this.f6155a.e(b5Var.f1035a.f35a[g5Var.g], k, z);
            if (b5.c && this.f6155a.i() == 0) {
                this.b = true;
                b5Var.f1046f = true;
            }
        }
    }

    public void E(b5 b5Var) {
        if (b5Var.f1039a.length != 0) {
            boolean z = false;
            while (!z) {
                int i = this.f6155a.i();
                for (int i2 = 0; i2 < i; i2++) {
                    g5 b2 = this.f6155a.b(i2);
                    if (b2.c != -1 || b2.f2564b || b2.f2566c) {
                        this.f6154a.add(b2);
                    }
                }
                int size = this.f6154a.size();
                if (size > 0) {
                    for (int i3 = 0; i3 < size; i3++) {
                        g5 g5Var = this.f6154a.get(i3);
                        if (g5Var.f2564b) {
                            B(b5Var, g5Var, true);
                        } else if (g5Var.f2566c) {
                            D(b5Var, g5Var, true);
                        } else {
                            C(b5Var, b5Var.f1039a[g5Var.c], true);
                        }
                    }
                    this.f6154a.clear();
                } else {
                    z = true;
                }
            }
            if (b5.c && this.f6153a != null && this.f6155a.i() == 0) {
                this.b = true;
                b5Var.f1046f = true;
            }
        }
    }

    public g5 a(b5 b5Var, boolean[] zArr) {
        return x(zArr, (g5) null);
    }

    public void b(b5.a aVar) {
        if (aVar instanceof z4) {
            z4 z4Var = (z4) aVar;
            this.f6153a = null;
            this.f6155a.clear();
            for (int i = 0; i < z4Var.f6155a.i(); i++) {
                this.f6155a.e(z4Var.f6155a.b(i), z4Var.f6155a.h(i), true);
            }
        }
    }

    public g5 c() {
        return this.f6153a;
    }

    public void clear() {
        this.f6155a.clear();
        this.f6153a = null;
        this.a = 0.0f;
    }

    public void d(g5 g5Var) {
        int i = g5Var.d;
        float f = 1.0f;
        if (i != 1) {
            if (i == 2) {
                f = 1000.0f;
            } else if (i == 3) {
                f = 1000000.0f;
            } else if (i == 4) {
                f = 1.0E9f;
            } else if (i == 5) {
                f = 1.0E12f;
            }
        }
        this.f6155a.c(g5Var, f);
    }

    public z4 e(b5 b5Var, int i) {
        this.f6155a.c(b5Var.o(i, "ep"), 1.0f);
        this.f6155a.c(b5Var.o(i, "em"), -1.0f);
        return this;
    }

    public z4 f(g5 g5Var, int i) {
        this.f6155a.c(g5Var, (float) i);
        return this;
    }

    public boolean g(b5 b5Var) {
        boolean z;
        g5 h = h(b5Var);
        if (h == null) {
            z = true;
        } else {
            y(h);
            z = false;
        }
        if (this.f6155a.i() == 0) {
            this.b = true;
        }
        return z;
    }

    public g5 h(b5 b5Var) {
        int i = this.f6155a.i();
        g5 g5Var = null;
        g5 g5Var2 = null;
        boolean z = false;
        boolean z2 = false;
        float f = 0.0f;
        float f2 = 0.0f;
        for (int i2 = 0; i2 < i; i2++) {
            float h = this.f6155a.h(i2);
            g5 b2 = this.f6155a.b(i2);
            if (b2.f2557a == g5.a.UNRESTRICTED) {
                if (g5Var == null || f > h) {
                    z = v(b2, b5Var);
                    f = h;
                    g5Var = b2;
                } else if (!z && v(b2, b5Var)) {
                    f = h;
                    g5Var = b2;
                    z = true;
                }
            } else if (g5Var == null && h < 0.0f) {
                if (g5Var2 == null || f2 > h) {
                    z2 = v(b2, b5Var);
                    f2 = h;
                    g5Var2 = b2;
                } else if (!z2 && v(b2, b5Var)) {
                    f2 = h;
                    g5Var2 = b2;
                    z2 = true;
                }
            }
        }
        return g5Var != null ? g5Var : g5Var2;
    }

    public z4 i(g5 g5Var, g5 g5Var2, int i, float f, g5 g5Var3, g5 g5Var4, int i2) {
        float f2;
        int i3;
        if (g5Var2 == g5Var3) {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var4, 1.0f);
            this.f6155a.c(g5Var2, -2.0f);
            return this;
        }
        if (f == 0.5f) {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
            this.f6155a.c(g5Var3, -1.0f);
            this.f6155a.c(g5Var4, 1.0f);
            if (i > 0 || i2 > 0) {
                i3 = (-i) + i2;
            }
            return this;
        }
        if (f <= 0.0f) {
            this.f6155a.c(g5Var, -1.0f);
            this.f6155a.c(g5Var2, 1.0f);
            f2 = (float) i;
        } else if (f >= 1.0f) {
            this.f6155a.c(g5Var4, -1.0f);
            this.f6155a.c(g5Var3, 1.0f);
            i3 = -i2;
        } else {
            float f3 = 1.0f - f;
            this.f6155a.c(g5Var, f3 * 1.0f);
            this.f6155a.c(g5Var2, f3 * -1.0f);
            this.f6155a.c(g5Var3, -1.0f * f);
            this.f6155a.c(g5Var4, 1.0f * f);
            if (i > 0 || i2 > 0) {
                f2 = (((float) (-i)) * f3) + (((float) i2) * f);
            }
            return this;
        }
        this.a = f2;
        return this;
        f2 = (float) i3;
        this.a = f2;
        return this;
    }

    public boolean isEmpty() {
        return this.f6153a == null && this.a == 0.0f && this.f6155a.i() == 0;
    }

    public z4 j(g5 g5Var, int i) {
        this.f6153a = g5Var;
        float f = (float) i;
        g5Var.f2556a = f;
        this.a = f;
        this.b = true;
        return this;
    }

    public z4 k(g5 g5Var, g5 g5Var2, float f) {
        this.f6155a.c(g5Var, -1.0f);
        this.f6155a.c(g5Var2, f);
        return this;
    }

    public z4 l(g5 g5Var, g5 g5Var2, g5 g5Var3, g5 g5Var4, float f) {
        this.f6155a.c(g5Var, -1.0f);
        this.f6155a.c(g5Var2, 1.0f);
        this.f6155a.c(g5Var3, f);
        this.f6155a.c(g5Var4, -f);
        return this;
    }

    public z4 m(float f, float f2, float f3, g5 g5Var, g5 g5Var2, g5 g5Var3, g5 g5Var4) {
        this.a = 0.0f;
        if (f2 == 0.0f || f == f3) {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
            this.f6155a.c(g5Var4, 1.0f);
            this.f6155a.c(g5Var3, -1.0f);
        } else if (f == 0.0f) {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
        } else if (f3 == 0.0f) {
            this.f6155a.c(g5Var3, 1.0f);
            this.f6155a.c(g5Var4, -1.0f);
        } else {
            float f4 = (f / f2) / (f3 / f2);
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
            this.f6155a.c(g5Var4, f4);
            this.f6155a.c(g5Var3, -f4);
        }
        return this;
    }

    public z4 n(g5 g5Var, int i) {
        a aVar;
        float f;
        if (i < 0) {
            this.a = (float) (i * -1);
            aVar = this.f6155a;
            f = 1.0f;
        } else {
            this.a = (float) i;
            aVar = this.f6155a;
            f = -1.0f;
        }
        aVar.c(g5Var, f);
        return this;
    }

    public z4 o(g5 g5Var, g5 g5Var2, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.a = (float) i;
        }
        if (!z) {
            this.f6155a.c(g5Var, -1.0f);
            this.f6155a.c(g5Var2, 1.0f);
        } else {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
        }
        return this;
    }

    public z4 p(g5 g5Var, g5 g5Var2, g5 g5Var3, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.a = (float) i;
        }
        if (!z) {
            this.f6155a.c(g5Var, -1.0f);
            this.f6155a.c(g5Var2, 1.0f);
            this.f6155a.c(g5Var3, 1.0f);
        } else {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
            this.f6155a.c(g5Var3, -1.0f);
        }
        return this;
    }

    public z4 q(g5 g5Var, g5 g5Var2, g5 g5Var3, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.a = (float) i;
        }
        if (!z) {
            this.f6155a.c(g5Var, -1.0f);
            this.f6155a.c(g5Var2, 1.0f);
            this.f6155a.c(g5Var3, -1.0f);
        } else {
            this.f6155a.c(g5Var, 1.0f);
            this.f6155a.c(g5Var2, -1.0f);
            this.f6155a.c(g5Var3, 1.0f);
        }
        return this;
    }

    public z4 r(g5 g5Var, g5 g5Var2, g5 g5Var3, g5 g5Var4, float f) {
        this.f6155a.c(g5Var3, 0.5f);
        this.f6155a.c(g5Var4, 0.5f);
        this.f6155a.c(g5Var, -0.5f);
        this.f6155a.c(g5Var2, -0.5f);
        this.a = -f;
        return this;
    }

    public void s() {
        float f = this.a;
        if (f < 0.0f) {
            this.a = f * -1.0f;
            this.f6155a.a();
        }
    }

    public boolean t() {
        g5 g5Var = this.f6153a;
        return g5Var != null && (g5Var.f2557a == g5.a.UNRESTRICTED || this.a >= 0.0f);
    }

    public String toString() {
        return A();
    }

    public boolean u(g5 g5Var) {
        return this.f6155a.f(g5Var);
    }

    public final boolean v(g5 g5Var, b5 b5Var) {
        return g5Var.f <= 1;
    }

    public g5 w(g5 g5Var) {
        return x((boolean[]) null, g5Var);
    }

    public final g5 x(boolean[] zArr, g5 g5Var) {
        g5.a aVar;
        int i = this.f6155a.i();
        g5 g5Var2 = null;
        float f = 0.0f;
        for (int i2 = 0; i2 < i; i2++) {
            float h = this.f6155a.h(i2);
            if (h < 0.0f) {
                g5 b2 = this.f6155a.b(i2);
                if ((zArr == null || !zArr[b2.f2563b]) && b2 != g5Var && (((aVar = b2.f2557a) == g5.a.SLACK || aVar == g5.a.ERROR) && h < f)) {
                    f = h;
                    g5Var2 = b2;
                }
            }
        }
        return g5Var2;
    }

    public void y(g5 g5Var) {
        g5 g5Var2 = this.f6153a;
        if (g5Var2 != null) {
            this.f6155a.c(g5Var2, -1.0f);
            this.f6153a.c = -1;
            this.f6153a = null;
        }
        float g = this.f6155a.g(g5Var, true) * -1.0f;
        this.f6153a = g5Var;
        if (g != 1.0f) {
            this.a /= g;
            this.f6155a.d(g);
        }
    }

    public void z() {
        this.f6153a = null;
        this.f6155a.clear();
        this.a = 0.0f;
        this.b = false;
    }
}
