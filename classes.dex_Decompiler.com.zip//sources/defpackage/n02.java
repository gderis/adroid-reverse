package defpackage;

/* renamed from: n02  reason: default package */
public class n02 extends m02 {
}
