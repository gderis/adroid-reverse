package defpackage;

import java.nio.charset.Charset;

/* renamed from: gk1  reason: default package */
public final /* synthetic */ class gk1 implements bp {
    public static final /* synthetic */ gk1 a = new gk1();

    public final Object a(Object obj) {
        return ik1.f3073a.D((lj1) obj).getBytes(Charset.forName("UTF-8"));
    }
}
