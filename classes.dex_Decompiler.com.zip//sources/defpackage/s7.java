package defpackage;

/* renamed from: s7  reason: default package */
public final class s7 {
}
