package defpackage;

import android.net.Uri;

/* renamed from: x21  reason: default package */
public final class x21 implements Runnable {
    public final /* synthetic */ Uri a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ String f5781a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ y21 f5782a;
    public final /* synthetic */ String b;

    /* renamed from: b  reason: collision with other field name */
    public final /* synthetic */ boolean f5783b;

    public x21(y21 y21, boolean z, Uri uri, String str, String str2) {
        this.f5782a = y21;
        this.f5783b = z;
        this.a = uri;
        this.f5781a = str;
        this.b = str2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x004c, code lost:
        if (r2.a.a.z().w((java.lang.String) null, defpackage.bz0.c0) == false) goto L_0x005c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00ab A[SYNTHETIC, Splitter:B:31:0x00ab] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00fc A[Catch:{ RuntimeException -> 0x01d6 }] */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0110 A[SYNTHETIC, Splitter:B:47:0x0110] */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0143 A[Catch:{ RuntimeException -> 0x01d6 }] */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0145 A[Catch:{ RuntimeException -> 0x01d6 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r17 = this;
            r1 = r17
            y21 r2 = r1.f5782a
            boolean r0 = r1.f5783b
            android.net.Uri r3 = r1.a
            java.lang.String r4 = r1.f5781a
            java.lang.String r5 = r1.b
            z21 r6 = r2.a
            r6.h()
            z21 r6 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r6 = r6.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r6 = r6.z()     // Catch:{ RuntimeException -> 0x01d6 }
            zy0<java.lang.Boolean> r7 = defpackage.bz0.b0     // Catch:{ RuntimeException -> 0x01d6 }
            r8 = 0
            boolean r6 = r6.w(r8, r7)     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r9 = "Activity created with data 'referrer' without required params"
            java.lang.String r10 = "_cis"
            java.lang.String r11 = "utm_medium"
            java.lang.String r12 = "utm_source"
            java.lang.String r13 = "utm_campaign"
            java.lang.String r14 = "gclid"
            if (r6 != 0) goto L_0x004e
            z21 r6 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r6 = r6.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r6 = r6.z()     // Catch:{ RuntimeException -> 0x01d6 }
            zy0<java.lang.Boolean> r15 = defpackage.bz0.d0     // Catch:{ RuntimeException -> 0x01d6 }
            boolean r6 = r6.w(r8, r15)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r6 != 0) goto L_0x004e
            z21 r6 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r6 = r6.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r6 = r6.z()     // Catch:{ RuntimeException -> 0x01d6 }
            zy0<java.lang.Boolean> r15 = defpackage.bz0.c0     // Catch:{ RuntimeException -> 0x01d6 }
            boolean r6 = r6.w(r8, r15)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r6 == 0) goto L_0x005c
        L_0x004e:
            z21 r6 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r6 = r6.a     // Catch:{ RuntimeException -> 0x01d6 }
            z51 r6 = r6.G()     // Catch:{ RuntimeException -> 0x01d6 }
            boolean r15 = android.text.TextUtils.isEmpty(r5)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r15 == 0) goto L_0x005e
        L_0x005c:
            r6 = r8
            goto L_0x00a6
        L_0x005e:
            boolean r15 = r5.contains(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r15 != 0) goto L_0x0084
            boolean r15 = r5.contains(r13)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r15 != 0) goto L_0x0084
            boolean r15 = r5.contains(r12)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r15 != 0) goto L_0x0084
            boolean r15 = r5.contains(r11)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r15 != 0) goto L_0x0084
            w01 r6 = r6.a     // Catch:{ RuntimeException -> 0x01d6 }
            nz0 r6 = r6.c()     // Catch:{ RuntimeException -> 0x01d6 }
            lz0 r6 = r6.v()     // Catch:{ RuntimeException -> 0x01d6 }
            r6.a(r9)     // Catch:{ RuntimeException -> 0x01d6 }
            goto L_0x005c
        L_0x0084:
            java.lang.String r15 = "https://google.com/search?"
            int r16 = r5.length()     // Catch:{ RuntimeException -> 0x01d6 }
            if (r16 == 0) goto L_0x0091
            java.lang.String r15 = r15.concat(r5)     // Catch:{ RuntimeException -> 0x01d6 }
            goto L_0x0097
        L_0x0091:
            java.lang.String r8 = new java.lang.String     // Catch:{ RuntimeException -> 0x01d6 }
            r8.<init>(r15)     // Catch:{ RuntimeException -> 0x01d6 }
            r15 = r8
        L_0x0097:
            android.net.Uri r8 = android.net.Uri.parse(r15)     // Catch:{ RuntimeException -> 0x01d6 }
            android.os.Bundle r6 = r6.k0(r8)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r6 == 0) goto L_0x00a6
            java.lang.String r8 = "referrer"
            r6.putString(r10, r8)     // Catch:{ RuntimeException -> 0x01d6 }
        L_0x00a6:
            java.lang.String r8 = "_cmp"
            r15 = 1
            if (r0 == 0) goto L_0x00fc
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r0 = r0.a     // Catch:{ RuntimeException -> 0x01d6 }
            z51 r0 = r0.G()     // Catch:{ RuntimeException -> 0x01d6 }
            android.os.Bundle r0 = r0.k0(r3)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 == 0) goto L_0x00fd
            java.lang.String r3 = "intent"
            r0.putString(r10, r3)     // Catch:{ RuntimeException -> 0x01d6 }
            z21 r3 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r3 = r3.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r3 = r3.z()     // Catch:{ RuntimeException -> 0x01d6 }
            r10 = 0
            boolean r3 = r3.w(r10, r7)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r3 == 0) goto L_0x00ef
            boolean r3 = r0.containsKey(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r3 != 0) goto L_0x00ef
            if (r6 == 0) goto L_0x00ef
            boolean r3 = r6.containsKey(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r3 == 0) goto L_0x00ef
            java.lang.Object[] r3 = new java.lang.Object[r15]     // Catch:{ RuntimeException -> 0x01d6 }
            r7 = 0
            java.lang.String r10 = r6.getString(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            r3[r7] = r10     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r7 = "_cer"
            java.lang.String r10 = "gclid=%s"
            java.lang.String r3 = java.lang.String.format(r10, r3)     // Catch:{ RuntimeException -> 0x01d6 }
            r0.putString(r7, r3)     // Catch:{ RuntimeException -> 0x01d6 }
        L_0x00ef:
            z21 r3 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            r3.X(r4, r8, r0)     // Catch:{ RuntimeException -> 0x01d6 }
            z21 r3 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            i61 r3 = r3.f6141a     // Catch:{ RuntimeException -> 0x01d6 }
            r3.b(r4, r0)     // Catch:{ RuntimeException -> 0x01d6 }
            goto L_0x00fd
        L_0x00fc:
            r0 = 0
        L_0x00fd:
            z21 r3 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r3 = r3.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r3 = r3.z()     // Catch:{ RuntimeException -> 0x01d6 }
            zy0<java.lang.Boolean> r7 = defpackage.bz0.d0     // Catch:{ RuntimeException -> 0x01d6 }
            r10 = 0
            boolean r3 = r3.w(r10, r7)     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r7 = "auto"
            if (r3 == 0) goto L_0x013d
            z21 r3 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r3 = r3.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r3 = r3.z()     // Catch:{ RuntimeException -> 0x01d6 }
            zy0<java.lang.Boolean> r10 = defpackage.bz0.c0     // Catch:{ RuntimeException -> 0x01d6 }
            r15 = 0
            boolean r3 = r3.w(r15, r10)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r3 != 0) goto L_0x013d
            if (r6 == 0) goto L_0x013d
            boolean r3 = r6.containsKey(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r3 == 0) goto L_0x013d
            if (r0 == 0) goto L_0x0131
            boolean r0 = r0.containsKey(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 != 0) goto L_0x013d
        L_0x0131:
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r3 = "_lgclid"
            java.lang.String r10 = r6.getString(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            r15 = 1
            r0.c0(r7, r3, r10, r15)     // Catch:{ RuntimeException -> 0x01d6 }
        L_0x013d:
            boolean r0 = android.text.TextUtils.isEmpty(r5)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 == 0) goto L_0x0145
            goto L_0x01c5
        L_0x0145:
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r0 = r0.a     // Catch:{ RuntimeException -> 0x01d6 }
            nz0 r0 = r0.c()     // Catch:{ RuntimeException -> 0x01d6 }
            lz0 r0 = r0.v()     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r3 = "Activity created with referrer"
            r0.b(r3, r5)     // Catch:{ RuntimeException -> 0x01d6 }
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r0 = r0.a     // Catch:{ RuntimeException -> 0x01d6 }
            bv0 r0 = r0.z()     // Catch:{ RuntimeException -> 0x01d6 }
            zy0<java.lang.Boolean> r3 = defpackage.bz0.c0     // Catch:{ RuntimeException -> 0x01d6 }
            r10 = 0
            boolean r0 = r0.w(r10, r3)     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r3 = "_ldl"
            if (r0 == 0) goto L_0x0191
            if (r6 == 0) goto L_0x0178
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            r0.X(r4, r8, r6)     // Catch:{ RuntimeException -> 0x01d6 }
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            i61 r0 = r0.f6141a     // Catch:{ RuntimeException -> 0x01d6 }
            r0.b(r4, r6)     // Catch:{ RuntimeException -> 0x01d6 }
            goto L_0x0189
        L_0x0178:
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r0 = r0.a     // Catch:{ RuntimeException -> 0x01d6 }
            nz0 r0 = r0.c()     // Catch:{ RuntimeException -> 0x01d6 }
            lz0 r0 = r0.v()     // Catch:{ RuntimeException -> 0x01d6 }
            java.lang.String r4 = "Referrer does not contain valid parameters"
            r0.b(r4, r5)     // Catch:{ RuntimeException -> 0x01d6 }
        L_0x0189:
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            r4 = 1
            r5 = 0
            r0.c0(r7, r3, r5, r4)     // Catch:{ RuntimeException -> 0x01d6 }
            return
        L_0x0191:
            boolean r0 = r5.contains(r14)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 == 0) goto L_0x01c6
            boolean r0 = r5.contains(r13)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 != 0) goto L_0x01b9
            boolean r0 = r5.contains(r12)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 != 0) goto L_0x01b9
            boolean r0 = r5.contains(r11)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 != 0) goto L_0x01b9
            java.lang.String r0 = "utm_term"
            boolean r0 = r5.contains(r0)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 != 0) goto L_0x01b9
            java.lang.String r0 = "utm_content"
            boolean r0 = r5.contains(r0)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 == 0) goto L_0x01c6
        L_0x01b9:
            boolean r0 = android.text.TextUtils.isEmpty(r5)     // Catch:{ RuntimeException -> 0x01d6 }
            if (r0 != 0) goto L_0x01c5
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            r4 = 1
            r0.c0(r7, r3, r5, r4)     // Catch:{ RuntimeException -> 0x01d6 }
        L_0x01c5:
            return
        L_0x01c6:
            z21 r0 = r2.a     // Catch:{ RuntimeException -> 0x01d6 }
            w01 r0 = r0.a     // Catch:{ RuntimeException -> 0x01d6 }
            nz0 r0 = r0.c()     // Catch:{ RuntimeException -> 0x01d6 }
            lz0 r0 = r0.v()     // Catch:{ RuntimeException -> 0x01d6 }
            r0.a(r9)     // Catch:{ RuntimeException -> 0x01d6 }
            return
        L_0x01d6:
            r0 = move-exception
            z21 r2 = r2.a
            w01 r2 = r2.a
            nz0 r2 = r2.c()
            lz0 r2 = r2.o()
            java.lang.String r3 = "Throwable caught in handleReferrerForOnActivityCreated"
            r2.b(r3, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.x21.run():void");
    }
}
