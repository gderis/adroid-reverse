package defpackage;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: ea  reason: default package */
public abstract class ea {
    public final Context a;

    /* renamed from: a  reason: collision with other field name */
    public a f2248a;

    /* renamed from: a  reason: collision with other field name */
    public b f2249a;

    /* renamed from: ea$a */
    public interface a {
    }

    /* renamed from: ea$b */
    public interface b {
        void onActionProviderVisibilityChanged(boolean z);
    }

    public ea(Context context) {
        this.a = context;
    }

    public boolean a() {
        return false;
    }

    public boolean b() {
        return true;
    }

    public abstract View c();

    public View d(MenuItem menuItem) {
        return c();
    }

    public boolean e() {
        return false;
    }

    public void f(SubMenu subMenu) {
    }

    public boolean g() {
        return false;
    }

    public void h() {
        this.f2249a = null;
        this.f2248a = null;
    }

    public void i(a aVar) {
        this.f2248a = aVar;
    }

    public void j(b bVar) {
        if (!(this.f2249a == null || bVar == null)) {
            "setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this " + getClass().getSimpleName() + " instance while it is still in use somewhere else?";
        }
        this.f2249a = bVar;
    }
}
