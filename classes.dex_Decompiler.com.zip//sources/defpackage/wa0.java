package defpackage;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import defpackage.mw;

/* renamed from: wa0  reason: default package */
public class wa0 extends j10<i90> {
    public final da0<i90> a = new va0(this);
    public final String d;

    public wa0(Context context, Looper looper, mw.b bVar, mw.c cVar, String str, g10 g10) {
        super(context, looper, 23, g10, bVar, cVar);
        this.d = str;
    }

    public final yv[] B() {
        return uu0.f5452a;
    }

    public final Bundle D() {
        Bundle bundle = new Bundle();
        bundle.putString("client_name", this.d);
        return bundle;
    }

    public final String H() {
        return "com.google.android.gms.location.internal.IGoogleLocationManagerService";
    }

    public final String I() {
        return "com.google.android.location.internal.GoogleLocationManagerService.START";
    }

    public final int o() {
        return 11717000;
    }

    public final /* bridge */ /* synthetic */ IInterface y(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.location.internal.IGoogleLocationManagerService");
        return queryLocalInterface instanceof i90 ? (i90) queryLocalInterface : new h90(iBinder);
    }
}
