package defpackage;

/* renamed from: f11  reason: default package */
public final class f11 implements Runnable {
    public final /* synthetic */ g61 a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ p11 f2369a;

    public f11(p11 p11, g61 g61) {
        this.f2369a = p11;
        this.a = g61;
    }

    public final void run() {
        this.f2369a.f4365a.l();
        this.f2369a.f4365a.n(this.a);
    }
}
