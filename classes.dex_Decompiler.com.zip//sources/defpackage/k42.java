package defpackage;

import java.net.InetSocketAddress;
import java.net.Proxy;

/* renamed from: k42  reason: default package */
public final class k42 {
    public final e32 a;

    /* renamed from: a  reason: collision with other field name */
    public final InetSocketAddress f3415a;

    /* renamed from: a  reason: collision with other field name */
    public final Proxy f3416a;

    public k42(e32 e32, Proxy proxy, InetSocketAddress inetSocketAddress) {
        p12.d(e32, "address");
        p12.d(proxy, "proxy");
        p12.d(inetSocketAddress, "socketAddress");
        this.a = e32;
        this.f3416a = proxy;
        this.f3415a = inetSocketAddress;
    }

    public final e32 a() {
        return this.a;
    }

    public final Proxy b() {
        return this.f3416a;
    }

    public final boolean c() {
        return this.a.k() != null && this.f3416a.type() == Proxy.Type.HTTP;
    }

    public final InetSocketAddress d() {
        return this.f3415a;
    }

    public boolean equals(Object obj) {
        if (obj instanceof k42) {
            k42 k42 = (k42) obj;
            return p12.a(k42.a, this.a) && p12.a(k42.f3416a, this.f3416a) && p12.a(k42.f3415a, this.f3415a);
        }
    }

    public int hashCode() {
        return ((((527 + this.a.hashCode()) * 31) + this.f3416a.hashCode()) * 31) + this.f3415a.hashCode();
    }

    public String toString() {
        return "Route{" + this.f3415a + '}';
    }
}
