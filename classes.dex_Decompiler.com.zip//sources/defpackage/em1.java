package defpackage;

import android.content.Context;
import defpackage.gm1;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: em1  reason: default package */
public class em1 implements gm1 {
    public static final ThreadFactory a = bm1.a;

    /* renamed from: a  reason: collision with other field name */
    public final Set<fm1> f2300a;

    /* renamed from: a  reason: collision with other field name */
    public final Executor f2301a;

    /* renamed from: a  reason: collision with other field name */
    public km1<hm1> f2302a;

    public em1(Context context, Set<fm1> set) {
        this(new eg1(new cm1(context)), set, new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue(), a));
    }

    public em1(km1<hm1> km1, Set<fm1> set, Executor executor) {
        this.f2302a = km1;
        this.f2300a = set;
        this.f2301a = executor;
    }

    public static sf1<gm1> b() {
        return sf1.a(gm1.class).b(zf1.j(Context.class)).b(zf1.k(fm1.class)).f(dm1.a).d();
    }

    public static /* synthetic */ gm1 c(tf1 tf1) {
        return new em1((Context) tf1.e(Context.class), tf1.c(fm1.class));
    }

    public static /* synthetic */ Thread e(Runnable runnable) {
        return new Thread(runnable, "heartbeat-information-executor");
    }

    public gm1.a a(String str) {
        long currentTimeMillis = System.currentTimeMillis();
        boolean d = this.f2302a.get().d(str, currentTimeMillis);
        boolean c = this.f2302a.get().c(currentTimeMillis);
        return (!d || !c) ? c ? gm1.a.GLOBAL : d ? gm1.a.SDK : gm1.a.NONE : gm1.a.COMBINED;
    }
}
