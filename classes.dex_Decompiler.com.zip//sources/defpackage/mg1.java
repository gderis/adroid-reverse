package defpackage;

/* renamed from: mg1  reason: default package */
public final /* synthetic */ class mg1 implements ch1 {
    public final /* synthetic */ og1 a;

    public /* synthetic */ mg1(og1 og1) {
        this.a = og1;
    }

    public final void b(bh1 bh1) {
        this.a.g(bh1);
    }
}
