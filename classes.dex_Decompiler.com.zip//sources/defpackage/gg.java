package defpackage;

import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: gg  reason: default package */
public abstract class gg {
    public final ag a;

    /* renamed from: a  reason: collision with other field name */
    public final AtomicBoolean f2625a = new AtomicBoolean(false);

    /* renamed from: a  reason: collision with other field name */
    public volatile yg f2626a;

    public gg(ag agVar) {
        this.a = agVar;
    }

    public yg a() {
        b();
        return e(this.f2625a.compareAndSet(false, true));
    }

    public void b() {
        this.a.a();
    }

    public final yg c() {
        return this.a.d(d());
    }

    public abstract String d();

    public final yg e(boolean z) {
        if (!z) {
            return c();
        }
        if (this.f2626a == null) {
            this.f2626a = c();
        }
        return this.f2626a;
    }

    public void f(yg ygVar) {
        if (ygVar == this.f2626a) {
            this.f2625a.set(false);
        }
    }
}
