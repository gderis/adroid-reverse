package defpackage;

import com.google.auto.value.AutoValue;

@AutoValue
/* renamed from: vh1  reason: default package */
public abstract class vh1 {
    public static vh1 a(lj1 lj1, String str) {
        return new kh1(lj1, str);
    }

    public abstract lj1 b();

    public abstract String c();
}
