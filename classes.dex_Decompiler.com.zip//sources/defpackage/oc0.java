package defpackage;

/* renamed from: oc0  reason: default package */
public final class oc0 implements nc0 {
    public final String a;

    /* renamed from: a  reason: collision with other field name */
    public final zg0 f4271a;

    public oc0(zg0 zg0, String str) {
        this.f4271a = zg0;
        this.a = str;
    }

    public final zg0 a(wb0 wb0) {
        this.f4271a.f(this.a, wb0);
        return this.f4271a;
    }
}
