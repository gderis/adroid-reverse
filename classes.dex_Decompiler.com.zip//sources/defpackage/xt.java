package defpackage;

/* renamed from: xt  reason: default package */
public final class xt implements ir<wt> {
    public final nz1<cu> a;
    public final nz1<cu> b;
    public final nz1<qt> c;
    public final nz1<yt> d;

    public xt(nz1<cu> nz1, nz1<cu> nz12, nz1<qt> nz13, nz1<yt> nz14) {
        this.a = nz1;
        this.b = nz12;
        this.c = nz13;
        this.d = nz14;
    }

    public static xt a(nz1<cu> nz1, nz1<cu> nz12, nz1<qt> nz13, nz1<yt> nz14) {
        return new xt(nz1, nz12, nz13, nz14);
    }

    public static wt c(cu cuVar, cu cuVar2, Object obj, Object obj2) {
        return new wt(cuVar, cuVar2, (qt) obj, (yt) obj2);
    }

    /* renamed from: b */
    public wt get() {
        return c(this.a.get(), this.b.get(), this.c.get(), this.d.get());
    }
}
