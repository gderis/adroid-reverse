package defpackage;

import android.content.Context;
import android.util.DisplayMetrics;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: rb1  reason: default package */
public class rb1 extends LinearLayoutManager {

    /* renamed from: rb1$a */
    public class a extends Cif {
        public a(Context context) {
            super(context);
        }

        public float v(DisplayMetrics displayMetrics) {
            return 100.0f / ((float) displayMetrics.densityDpi);
        }
    }

    public rb1(Context context, int i, boolean z) {
        super(context, i, z);
    }

    public void I1(RecyclerView recyclerView, RecyclerView.a0 a0Var, int i) {
        a aVar = new a(recyclerView.getContext());
        aVar.p(i);
        J1(aVar);
    }
}
