package defpackage;

import defpackage.il0;

/* renamed from: jl0  reason: default package */
public interface jl0<T extends il0> {
}
