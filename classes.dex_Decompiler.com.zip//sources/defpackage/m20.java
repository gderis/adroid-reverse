package defpackage;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.text.TextUtils;
import java.util.Locale;
import javax.annotation.concurrent.GuardedBy;

/* renamed from: m20  reason: default package */
public final class m20 {
    @GuardedBy("sCache")
    public static Locale a;
    @GuardedBy("sCache")

    /* renamed from: a  reason: collision with other field name */
    public static final u4<String, String> f3767a = new u4<>();

    public static String a(Context context) {
        return context.getResources().getString(qu.common_google_play_services_notification_channel_name);
    }

    public static String b(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case 1:
                return resources.getString(qu.common_google_play_services_install_title);
            case 2:
                return resources.getString(qu.common_google_play_services_update_title);
            case 3:
                return resources.getString(qu.common_google_play_services_enable_title);
            case 4:
            case 6:
            case 18:
                return null;
            case 5:
                return c(context, "common_google_play_services_invalid_account_title");
            case 7:
                return c(context, "common_google_play_services_network_error_title");
            case 8:
            case 9:
            case 10:
            case 11:
            case 16:
                return null;
            case 17:
                return c(context, "common_google_play_services_sign_in_failed_title");
            case 20:
                return c(context, "common_google_play_services_restricted_profile_title");
            default:
                StringBuilder sb = new StringBuilder(33);
                sb.append("Unexpected error code ");
                sb.append(i);
                sb.toString();
                return null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0054, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0075, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String c(android.content.Context r4, java.lang.String r5) {
        /*
            u4<java.lang.String, java.lang.String> r0 = f3767a
            monitor-enter(r0)
            android.content.res.Resources r1 = r4.getResources()     // Catch:{ all -> 0x007b }
            android.content.res.Configuration r1 = r1.getConfiguration()     // Catch:{ all -> 0x007b }
            c9 r1 = defpackage.a9.a(r1)     // Catch:{ all -> 0x007b }
            r2 = 0
            java.util.Locale r1 = r1.c(r2)     // Catch:{ all -> 0x007b }
            java.util.Locale r2 = a     // Catch:{ all -> 0x007b }
            boolean r2 = r1.equals(r2)     // Catch:{ all -> 0x007b }
            if (r2 != 0) goto L_0x0021
            r0.clear()     // Catch:{ all -> 0x007b }
            a = r1     // Catch:{ all -> 0x007b }
        L_0x0021:
            java.lang.Object r1 = r0.get(r5)     // Catch:{ all -> 0x007b }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ all -> 0x007b }
            if (r1 == 0) goto L_0x002b
            monitor-exit(r0)     // Catch:{ all -> 0x007b }
            return r1
        L_0x002b:
            android.content.res.Resources r4 = defpackage.cw.e(r4)     // Catch:{ all -> 0x007b }
            r1 = 0
            if (r4 != 0) goto L_0x0034
            monitor-exit(r0)     // Catch:{ all -> 0x007b }
            return r1
        L_0x0034:
            java.lang.String r2 = "string"
            java.lang.String r3 = "com.google.android.gms"
            int r2 = r4.getIdentifier(r5, r2, r3)     // Catch:{ all -> 0x007b }
            if (r2 != 0) goto L_0x0055
            java.lang.String r4 = "Missing resource: "
            java.lang.String r5 = java.lang.String.valueOf(r5)     // Catch:{ all -> 0x007b }
            int r2 = r5.length()     // Catch:{ all -> 0x007b }
            if (r2 == 0) goto L_0x004e
            r4.concat(r5)     // Catch:{ all -> 0x007b }
            goto L_0x0053
        L_0x004e:
            java.lang.String r5 = new java.lang.String     // Catch:{ all -> 0x007b }
            r5.<init>(r4)     // Catch:{ all -> 0x007b }
        L_0x0053:
            monitor-exit(r0)     // Catch:{ all -> 0x007b }
            return r1
        L_0x0055:
            java.lang.String r4 = r4.getString(r2)     // Catch:{ all -> 0x007b }
            boolean r2 = android.text.TextUtils.isEmpty(r4)     // Catch:{ all -> 0x007b }
            if (r2 == 0) goto L_0x0076
            java.lang.String r4 = "Got empty resource: "
            java.lang.String r5 = java.lang.String.valueOf(r5)     // Catch:{ all -> 0x007b }
            int r2 = r5.length()     // Catch:{ all -> 0x007b }
            if (r2 == 0) goto L_0x006f
            r4.concat(r5)     // Catch:{ all -> 0x007b }
            goto L_0x0074
        L_0x006f:
            java.lang.String r5 = new java.lang.String     // Catch:{ all -> 0x007b }
            r5.<init>(r4)     // Catch:{ all -> 0x007b }
        L_0x0074:
            monitor-exit(r0)     // Catch:{ all -> 0x007b }
            return r1
        L_0x0076:
            r0.put(r5, r4)     // Catch:{ all -> 0x007b }
            monitor-exit(r0)     // Catch:{ all -> 0x007b }
            return r4
        L_0x007b:
            r4 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x007b }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.m20.c(android.content.Context, java.lang.String):java.lang.String");
    }

    public static String d(Context context, String str, String str2) {
        Resources resources = context.getResources();
        String c = c(context, str);
        if (c == null) {
            c = resources.getString(fw.common_google_play_services_unknown_issue);
        }
        return String.format(resources.getConfiguration().locale, c, new Object[]{str2});
    }

    public static String e(Context context) {
        String packageName = context.getPackageName();
        try {
            return z40.a(context).d(packageName).toString();
        } catch (PackageManager.NameNotFoundException | NullPointerException unused) {
            String str = context.getApplicationInfo().name;
            return TextUtils.isEmpty(str) ? packageName : str;
        }
    }

    public static String f(Context context, int i) {
        String c = i == 6 ? c(context, "common_google_play_services_resolution_required_title") : b(context, i);
        return c == null ? context.getResources().getString(qu.common_google_play_services_notification_ticker) : c;
    }

    public static String g(Context context, int i) {
        Resources resources = context.getResources();
        String e = e(context);
        if (i == 1) {
            return resources.getString(qu.common_google_play_services_install_text, new Object[]{e});
        } else if (i != 2) {
            if (i == 3) {
                return resources.getString(qu.common_google_play_services_enable_text, new Object[]{e});
            } else if (i == 5) {
                return d(context, "common_google_play_services_invalid_account_text", e);
            } else {
                if (i == 7) {
                    return d(context, "common_google_play_services_network_error_text", e);
                }
                if (i == 9) {
                    return resources.getString(qu.common_google_play_services_unsupported_text, new Object[]{e});
                } else if (i == 20) {
                    return d(context, "common_google_play_services_restricted_profile_text", e);
                } else {
                    switch (i) {
                        case 16:
                            return d(context, "common_google_play_services_api_unavailable_text", e);
                        case 17:
                            return d(context, "common_google_play_services_sign_in_failed_text", e);
                        case 18:
                            return resources.getString(qu.common_google_play_services_updating_text, new Object[]{e});
                        default:
                            return resources.getString(fw.common_google_play_services_unknown_issue, new Object[]{e});
                    }
                }
            }
        } else if (k40.f(context)) {
            return resources.getString(qu.common_google_play_services_wear_update_text);
        } else {
            return resources.getString(qu.common_google_play_services_update_text, new Object[]{e});
        }
    }

    public static String h(Context context, int i) {
        return (i == 6 || i == 19) ? d(context, "common_google_play_services_resolution_required_text", e(context)) : g(context, i);
    }

    public static String i(Context context, int i) {
        return context.getResources().getString(i != 1 ? i != 2 ? i != 3 ? 17039370 : qu.common_google_play_services_enable_button : qu.common_google_play_services_update_button : qu.common_google_play_services_install_button);
    }
}
