package defpackage;

/* renamed from: ix0  reason: default package */
public final /* synthetic */ class ix0 implements xy0 {
    public static final xy0 a = new ix0();

    public final Object a() {
        zy0<Long> zy0 = bz0.f1148a;
        return Boolean.valueOf(mp0.e());
    }
}
