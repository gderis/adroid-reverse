package defpackage;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* renamed from: n8  reason: default package */
public interface n8 {
    void setTint(int i);

    void setTintList(ColorStateList colorStateList);

    void setTintMode(PorterDuff.Mode mode);
}
