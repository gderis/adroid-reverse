package defpackage;

/* renamed from: ys0  reason: default package */
public final class ys0 {
}
