package defpackage;

import java.util.Locale;

/* renamed from: e9  reason: default package */
public interface e9 {
    Object a();

    Locale b(int i);
}
