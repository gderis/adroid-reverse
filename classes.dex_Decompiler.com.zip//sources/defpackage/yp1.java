package defpackage;

/* renamed from: yp1  reason: default package */
public final class yp1 {
    public static String a() {
        try {
            return pz1.f4547a.toString();
        } catch (NoClassDefFoundError unused) {
            return null;
        }
    }
}
