package defpackage;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.Iterator;

/* renamed from: c0  reason: default package */
public abstract class c0 {
    public static int a = -100;

    /* renamed from: a  reason: collision with other field name */
    public static final Object f1151a = new Object();

    /* renamed from: a  reason: collision with other field name */
    public static final p4<WeakReference<c0>> f1152a = new p4<>();

    public static void c(c0 c0Var) {
        synchronized (f1151a) {
            y(c0Var);
            f1152a.add(new WeakReference(c0Var));
        }
    }

    public static c0 g(Activity activity, b0 b0Var) {
        return new d0(activity, b0Var);
    }

    public static c0 h(Dialog dialog, b0 b0Var) {
        return new d0(dialog, b0Var);
    }

    public static int j() {
        return a;
    }

    public static void x(c0 c0Var) {
        synchronized (f1151a) {
            y(c0Var);
        }
    }

    public static void y(c0 c0Var) {
        synchronized (f1151a) {
            Iterator<WeakReference<c0>> it = f1152a.iterator();
            while (it.hasNext()) {
                c0 c0Var2 = (c0) it.next().get();
                if (c0Var2 == c0Var || c0Var2 == null) {
                    it.remove();
                }
            }
        }
    }

    public abstract void A(int i);

    public abstract void B(View view);

    public abstract void C(View view, ViewGroup.LayoutParams layoutParams);

    public void D(int i) {
    }

    public abstract void E(CharSequence charSequence);

    public abstract void d(View view, ViewGroup.LayoutParams layoutParams);

    @Deprecated
    public void e(Context context) {
    }

    public Context f(Context context) {
        e(context);
        return context;
    }

    public abstract <T extends View> T i(int i);

    public int k() {
        return -100;
    }

    public abstract MenuInflater l();

    public abstract y m();

    public abstract void n();

    public abstract void o();

    public abstract void p(Configuration configuration);

    public abstract void q(Bundle bundle);

    public abstract void r();

    public abstract void s(Bundle bundle);

    public abstract void t();

    public abstract void u(Bundle bundle);

    public abstract void v();

    public abstract void w();

    public abstract boolean z(int i);
}
