package defpackage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* renamed from: h02  reason: default package */
public class h02 extends g02 {
    public static final <T> Collection<T> c(T[] tArr) {
        p12.d(tArr, "$this$asCollection");
        return new a02(tArr, false);
    }

    public static final <T extends Comparable<? super T>> int d(List<? extends T> list, T t, int i, int i2) {
        p12.d(list, "$this$binarySearch");
        l(list.size(), i, i2);
        int i3 = i2 - 1;
        while (i <= i3) {
            int i4 = (i + i3) >>> 1;
            int a = a12.a((Comparable) list.get(i4), t);
            if (a < 0) {
                i = i4 + 1;
            } else if (a <= 0) {
                return i4;
            } else {
                i3 = i4 - 1;
            }
        }
        return -(i + 1);
    }

    public static /* synthetic */ int e(List list, Comparable comparable, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i = 0;
        }
        if ((i3 & 4) != 0) {
            i2 = list.size();
        }
        return d(list, comparable, i, i2);
    }

    public static final <T> List<T> f() {
        return r02.a;
    }

    public static final <T> int g(List<? extends T> list) {
        p12.d(list, "$this$lastIndex");
        return list.size() - 1;
    }

    public static final <T> List<T> h(T... tArr) {
        p12.d(tArr, "elements");
        return tArr.length > 0 ? d02.b(tArr) : f();
    }

    public static final <T> List<T> i(T... tArr) {
        p12.d(tArr, "elements");
        return e02.i(tArr);
    }

    public static final <T> List<T> j(T... tArr) {
        p12.d(tArr, "elements");
        return tArr.length == 0 ? new ArrayList() : new ArrayList(new a02(tArr, true));
    }

    public static final <T> List<T> k(List<? extends T> list) {
        p12.d(list, "$this$optimizeReadOnlyList");
        int size = list.size();
        return size != 0 ? size != 1 ? list : g02.b(list.get(0)) : f();
    }

    public static final void l(int i, int i2, int i3) {
        if (i2 > i3) {
            throw new IllegalArgumentException("fromIndex (" + i2 + ") is greater than toIndex (" + i3 + ").");
        } else if (i2 < 0) {
            throw new IndexOutOfBoundsException("fromIndex (" + i2 + ") is less than zero.");
        } else if (i3 > i) {
            throw new IndexOutOfBoundsException("toIndex (" + i3 + ") is greater than size (" + i + ").");
        }
    }

    public static final void m() {
        throw new ArithmeticException("Index overflow has happened.");
    }
}
