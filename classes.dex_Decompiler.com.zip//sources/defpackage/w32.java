package defpackage;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

/* renamed from: w32  reason: default package */
public interface w32 {
    public static final a a = new a((n12) null);

    /* renamed from: a  reason: collision with other field name */
    public static final w32 f5683a = new a.C0058a();

    /* renamed from: w32$a */
    public static final class a {

        /* renamed from: w32$a$a  reason: collision with other inner class name */
        public static final class C0058a implements w32 {
            public List<InetAddress> a(String str) {
                p12.d(str, "hostname");
                try {
                    InetAddress[] allByName = InetAddress.getAllByName(str);
                    p12.c(allByName, "InetAddress.getAllByName(hostname)");
                    return e02.p(allByName);
                } catch (NullPointerException e) {
                    UnknownHostException unknownHostException = new UnknownHostException("Broken system behaviour for dns lookup of " + str);
                    unknownHostException.initCause(e);
                    throw unknownHostException;
                }
            }
        }

        public a() {
        }

        public /* synthetic */ a(n12 n12) {
            this();
        }
    }

    List<InetAddress> a(String str);
}
