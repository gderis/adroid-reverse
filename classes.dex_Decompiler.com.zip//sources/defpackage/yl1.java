package defpackage;

/* renamed from: yl1  reason: default package */
public interface yl1<T> {
    void a(xl1<T> xl1);
}
