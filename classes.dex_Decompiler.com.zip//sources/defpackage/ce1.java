package defpackage;

import android.graphics.drawable.Drawable;
import android.view.View;
import com.google.android.material.textfield.TextInputLayout;

/* renamed from: ce1  reason: default package */
public class ce1 extends zd1 {
    public ce1(TextInputLayout textInputLayout) {
        super(textInputLayout);
    }

    public void a() {
        this.f6217a.setEndIconOnClickListener((View.OnClickListener) null);
        this.f6217a.setEndIconDrawable((Drawable) null);
        this.f6217a.setEndIconContentDescription((CharSequence) null);
    }
}
