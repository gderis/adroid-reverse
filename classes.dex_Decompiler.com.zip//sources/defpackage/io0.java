package defpackage;

/* renamed from: io0  reason: default package */
public interface io0 {
    boolean a();
}
