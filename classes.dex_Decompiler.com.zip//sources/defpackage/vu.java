package defpackage;

import android.os.Build;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import defpackage.tu;

/* renamed from: vu  reason: default package */
public class vu implements Parcelable {
    public static final Parcelable.Creator<vu> CREATOR = new xu();
    public Messenger a;

    /* renamed from: a  reason: collision with other field name */
    public tu f5615a;

    /* renamed from: vu$a */
    public static final class a extends ClassLoader {
        public final Class<?> loadClass(String str, boolean z) {
            return "com.google.android.gms.iid.MessengerCompat".equals(str) ? (Log.isLoggable("CloudMessengerCompat", 3) || Build.VERSION.SDK_INT != 23 || Log.isLoggable("CloudMessengerCompat", 3)) ? vu.class : vu.class : super.loadClass(str, z);
        }
    }

    public vu(IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.a = new Messenger(iBinder);
        } else {
            this.f5615a = new tu.a(iBinder);
        }
    }

    public final IBinder a() {
        Messenger messenger = this.a;
        return messenger != null ? messenger.getBinder() : this.f5615a.asBinder();
    }

    public final void b(Message message) {
        Messenger messenger = this.a;
        if (messenger != null) {
            messenger.send(message);
        } else {
            this.f5615a.n0(message);
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        try {
            return a().equals(((vu) obj).a());
        } catch (ClassCastException unused) {
            return false;
        }
    }

    public int hashCode() {
        return a().hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        Messenger messenger = this.a;
        parcel.writeStrongBinder(messenger != null ? messenger.getBinder() : this.f5615a.asBinder());
    }
}
