package defpackage;

import defpackage.ar;
import java.util.Objects;

/* renamed from: vq  reason: default package */
public final class vq extends ar {
    public final long a;

    /* renamed from: a  reason: collision with other field name */
    public final ar.a f5606a;

    public vq(ar.a aVar, long j) {
        Objects.requireNonNull(aVar, "Null status");
        this.f5606a = aVar;
        this.a = j;
    }

    public long b() {
        return this.a;
    }

    public ar.a c() {
        return this.f5606a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ar)) {
            return false;
        }
        ar arVar = (ar) obj;
        return this.f5606a.equals(arVar.c()) && this.a == arVar.b();
    }

    public int hashCode() {
        long j = this.a;
        return ((this.f5606a.hashCode() ^ 1000003) * 1000003) ^ ((int) (j ^ (j >>> 32)));
    }

    public String toString() {
        return "BackendResponse{status=" + this.f5606a + ", nextRequestWaitMillis=" + this.a + "}";
    }
}
