package defpackage;

import android.os.SystemClock;
import defpackage.ln;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.util.List;

/* renamed from: to  reason: default package */
public final class to {

    /* renamed from: to$b */
    public static class b {
        public final eo a;

        /* renamed from: a  reason: collision with other field name */
        public final String f5219a;

        public b(String str, eo eoVar) {
            this.f5219a = str;
            this.a = eoVar;
        }
    }

    public static void a(xn<?> xnVar, b bVar) {
        bo x = xnVar.x();
        int y = xnVar.y();
        try {
            x.b(bVar.a);
            xnVar.b(String.format("%s-retry [timeout=%s]", new Object[]{bVar.f5219a, Integer.valueOf(y)}));
        } catch (eo e) {
            xnVar.b(String.format("%s-timeout-giveup [timeout=%s]", new Object[]{bVar.f5219a, Integer.valueOf(y)}));
            throw e;
        }
    }

    public static un b(xn<?> xnVar, long j, List<qn> list) {
        ln.a m = xnVar.m();
        if (m == null) {
            return new un(304, (byte[]) null, true, j, list);
        }
        return new un(304, m.f3691a, true, j, no.a(list, m));
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0033 A[SYNTHETIC, Splitter:B:18:0x0033] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static byte[] c(java.io.InputStream r5, int r6, defpackage.ko r7) {
        /*
            java.lang.String r0 = "Error occurred when closing InputStream"
            uo r1 = new uo
            r1.<init>(r7, r6)
            r6 = 1024(0x400, float:1.435E-42)
            r2 = 0
            byte[] r6 = r7.a(r6)     // Catch:{ all -> 0x002f }
        L_0x000e:
            int r3 = r5.read(r6)     // Catch:{ all -> 0x002d }
            r4 = -1
            if (r3 == r4) goto L_0x0019
            r1.write(r6, r2, r3)     // Catch:{ all -> 0x002d }
            goto L_0x000e
        L_0x0019:
            byte[] r3 = r1.toByteArray()     // Catch:{ all -> 0x002d }
            r5.close()     // Catch:{ IOException -> 0x0021 }
            goto L_0x0026
        L_0x0021:
            java.lang.Object[] r5 = new java.lang.Object[r2]
            defpackage.fo.e(r0, r5)
        L_0x0026:
            r7.b(r6)
            r1.close()
            return r3
        L_0x002d:
            r3 = move-exception
            goto L_0x0031
        L_0x002f:
            r3 = move-exception
            r6 = 0
        L_0x0031:
            if (r5 == 0) goto L_0x003c
            r5.close()     // Catch:{ IOException -> 0x0037 }
            goto L_0x003c
        L_0x0037:
            java.lang.Object[] r5 = new java.lang.Object[r2]
            defpackage.fo.e(r0, r5)
        L_0x003c:
            r7.b(r6)
            r1.close()
            goto L_0x0044
        L_0x0043:
            throw r3
        L_0x0044:
            goto L_0x0043
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.to.c(java.io.InputStream, int, ko):byte[]");
    }

    public static void d(long j, xn<?> xnVar, byte[] bArr, int i) {
        if (fo.f2496a || j > 3000) {
            Object[] objArr = new Object[5];
            objArr[0] = xnVar;
            objArr[1] = Long.valueOf(j);
            objArr[2] = bArr != null ? Integer.valueOf(bArr.length) : "null";
            objArr[3] = Integer.valueOf(i);
            objArr[4] = Integer.valueOf(xnVar.x().c());
            fo.b("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", objArr);
        }
    }

    public static b e(xn<?> xnVar, IOException iOException, long j, oo ooVar, byte[] bArr) {
        if (iOException instanceof SocketTimeoutException) {
            return new b("socket", new Cdo());
        }
        if (iOException instanceof MalformedURLException) {
            throw new RuntimeException("Bad URL " + xnVar.A(), iOException);
        } else if (ooVar != null) {
            int d = ooVar.d();
            fo.c("Unexpected response code %d for %s", Integer.valueOf(d), xnVar.A());
            if (bArr == null) {
                return new b("network", new tn());
            }
            int i = d;
            byte[] bArr2 = bArr;
            un unVar = new un(i, bArr2, false, SystemClock.elapsedRealtime() - j, ooVar.c());
            if (d == 401 || d == 403) {
                return new b("auth", new kn(unVar));
            }
            if (d >= 400 && d <= 499) {
                throw new nn(unVar);
            } else if (d >= 500 && d <= 599 && xnVar.Q()) {
                return new b("server", new co(unVar));
            } else {
                throw new co(unVar);
            }
        } else if (xnVar.P()) {
            return new b("connection", new vn());
        } else {
            throw new vn(iOException);
        }
    }
}
