package defpackage;

import defpackage.in1;

/* renamed from: fn1  reason: default package */
public final class fn1 extends in1 {
    public final in1.b a;

    /* renamed from: a  reason: collision with other field name */
    public final String f2492a;

    /* renamed from: a  reason: collision with other field name */
    public final kn1 f2493a;
    public final String b;
    public final String c;

    /* renamed from: fn1$b */
    public static final class b extends in1.a {
        public in1.b a;

        /* renamed from: a  reason: collision with other field name */
        public String f2494a;

        /* renamed from: a  reason: collision with other field name */
        public kn1 f2495a;
        public String b;
        public String c;

        public in1 a() {
            return new fn1(this.f2494a, this.b, this.c, this.f2495a, this.a);
        }

        public in1.a b(kn1 kn1) {
            this.f2495a = kn1;
            return this;
        }

        public in1.a c(String str) {
            this.b = str;
            return this;
        }

        public in1.a d(String str) {
            this.c = str;
            return this;
        }

        public in1.a e(in1.b bVar) {
            this.a = bVar;
            return this;
        }

        public in1.a f(String str) {
            this.f2494a = str;
            return this;
        }
    }

    public fn1(String str, String str2, String str3, kn1 kn1, in1.b bVar) {
        this.f2492a = str;
        this.b = str2;
        this.c = str3;
        this.f2493a = kn1;
        this.a = bVar;
    }

    public kn1 b() {
        return this.f2493a;
    }

    public String c() {
        return this.b;
    }

    public String d() {
        return this.c;
    }

    public in1.b e() {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof in1)) {
            return false;
        }
        in1 in1 = (in1) obj;
        String str = this.f2492a;
        if (str != null ? str.equals(in1.f()) : in1.f() == null) {
            String str2 = this.b;
            if (str2 != null ? str2.equals(in1.c()) : in1.c() == null) {
                String str3 = this.c;
                if (str3 != null ? str3.equals(in1.d()) : in1.d() == null) {
                    kn1 kn1 = this.f2493a;
                    if (kn1 != null ? kn1.equals(in1.b()) : in1.b() == null) {
                        in1.b bVar = this.a;
                        in1.b e = in1.e();
                        if (bVar == null) {
                            if (e == null) {
                                return true;
                            }
                        } else if (bVar.equals(e)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public String f() {
        return this.f2492a;
    }

    public int hashCode() {
        String str = this.f2492a;
        int i = 0;
        int hashCode = ((str == null ? 0 : str.hashCode()) ^ 1000003) * 1000003;
        String str2 = this.b;
        int hashCode2 = (hashCode ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.c;
        int hashCode3 = (hashCode2 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        kn1 kn1 = this.f2493a;
        int hashCode4 = (hashCode3 ^ (kn1 == null ? 0 : kn1.hashCode())) * 1000003;
        in1.b bVar = this.a;
        if (bVar != null) {
            i = bVar.hashCode();
        }
        return hashCode4 ^ i;
    }

    public String toString() {
        return "InstallationResponse{uri=" + this.f2492a + ", fid=" + this.b + ", refreshToken=" + this.c + ", authToken=" + this.f2493a + ", responseCode=" + this.a + "}";
    }
}
