package defpackage;

/* renamed from: x31  reason: default package */
public final class x31 extends iv0 {
    public final /* synthetic */ o41 a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public x31(o41 o41, s11 s11) {
        super(s11);
        this.a = o41;
    }

    public final void a() {
        o41 o41 = this.a;
        o41.h();
        if (o41.H()) {
            o41.a.c().w().a("Inactivity, disconnecting from the service");
            o41.t();
        }
    }
}
