package defpackage;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

/* renamed from: zl0  reason: default package */
public final class zl0 extends rj0<Long> implements RandomAccess, ml0, sm0 {
    public static final zl0 a;

    /* renamed from: a  reason: collision with other field name */
    public int f6247a;

    /* renamed from: a  reason: collision with other field name */
    public long[] f6248a;

    static {
        zl0 zl0 = new zl0(new long[0], 0);
        a = zl0;
        zl0.n0();
    }

    public zl0() {
        this(new long[10], 0);
    }

    public zl0(long[] jArr, int i) {
        this.f6248a = jArr;
        this.f6247a = i;
    }

    public static zl0 c() {
        return a;
    }

    public final long E(int i) {
        e(i);
        return this.f6248a[i];
    }

    public final /* bridge */ /* synthetic */ void add(int i, Object obj) {
        int i2;
        long longValue = ((Long) obj).longValue();
        b();
        if (i < 0 || i > (i2 = this.f6247a)) {
            throw new IndexOutOfBoundsException(f(i));
        }
        long[] jArr = this.f6248a;
        if (i2 < jArr.length) {
            System.arraycopy(jArr, i, jArr, i + 1, i2 - i);
        } else {
            long[] jArr2 = new long[(((i2 * 3) / 2) + 1)];
            System.arraycopy(jArr, 0, jArr2, 0, i);
            System.arraycopy(this.f6248a, i, jArr2, i + 1, this.f6247a - i);
            this.f6248a = jArr2;
        }
        this.f6248a[i] = longValue;
        this.f6247a++;
        this.modCount++;
    }

    public final /* bridge */ /* synthetic */ boolean add(Object obj) {
        d(((Long) obj).longValue());
        return true;
    }

    public final boolean addAll(Collection<? extends Long> collection) {
        b();
        ol0.a(collection);
        if (!(collection instanceof zl0)) {
            return super.addAll(collection);
        }
        zl0 zl0 = (zl0) collection;
        int i = zl0.f6247a;
        if (i == 0) {
            return false;
        }
        int i2 = this.f6247a;
        if (Integer.MAX_VALUE - i2 >= i) {
            int i3 = i2 + i;
            long[] jArr = this.f6248a;
            if (i3 > jArr.length) {
                this.f6248a = Arrays.copyOf(jArr, i3);
            }
            System.arraycopy(zl0.f6248a, 0, this.f6248a, this.f6247a, zl0.f6247a);
            this.f6247a = i3;
            this.modCount++;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    public final void d(long j) {
        b();
        int i = this.f6247a;
        long[] jArr = this.f6248a;
        if (i == jArr.length) {
            long[] jArr2 = new long[(((i * 3) / 2) + 1)];
            System.arraycopy(jArr, 0, jArr2, 0, i);
            this.f6248a = jArr2;
        }
        long[] jArr3 = this.f6248a;
        int i2 = this.f6247a;
        this.f6247a = i2 + 1;
        jArr3[i2] = j;
    }

    public final void e(int i) {
        if (i < 0 || i >= this.f6247a) {
            throw new IndexOutOfBoundsException(f(i));
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zl0)) {
            return super.equals(obj);
        }
        zl0 zl0 = (zl0) obj;
        if (this.f6247a != zl0.f6247a) {
            return false;
        }
        long[] jArr = zl0.f6248a;
        for (int i = 0; i < this.f6247a; i++) {
            if (this.f6248a[i] != jArr[i]) {
                return false;
            }
        }
        return true;
    }

    public final String f(int i) {
        int i2 = this.f6247a;
        StringBuilder sb = new StringBuilder(35);
        sb.append("Index:");
        sb.append(i);
        sb.append(", Size:");
        sb.append(i2);
        return sb.toString();
    }

    public final /* bridge */ /* synthetic */ Object get(int i) {
        e(i);
        return Long.valueOf(this.f6248a[i]);
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.f6247a; i2++) {
            i = (i * 31) + ol0.e(this.f6248a[i2]);
        }
        return i;
    }

    public final int indexOf(Object obj) {
        if (!(obj instanceof Long)) {
            return -1;
        }
        long longValue = ((Long) obj).longValue();
        int i = this.f6247a;
        for (int i2 = 0; i2 < i; i2++) {
            if (this.f6248a[i2] == longValue) {
                return i2;
            }
        }
        return -1;
    }

    public final /* bridge */ /* synthetic */ Object remove(int i) {
        b();
        e(i);
        long[] jArr = this.f6248a;
        long j = jArr[i];
        int i2 = this.f6247a;
        if (i < i2 - 1) {
            System.arraycopy(jArr, i + 1, jArr, i, (i2 - i) - 1);
        }
        this.f6247a--;
        this.modCount++;
        return Long.valueOf(j);
    }

    public final void removeRange(int i, int i2) {
        b();
        if (i2 >= i) {
            long[] jArr = this.f6248a;
            System.arraycopy(jArr, i2, jArr, i, this.f6247a - i2);
            this.f6247a -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final /* bridge */ /* synthetic */ Object set(int i, Object obj) {
        long longValue = ((Long) obj).longValue();
        b();
        e(i);
        long[] jArr = this.f6248a;
        long j = jArr[i];
        jArr[i] = longValue;
        return Long.valueOf(j);
    }

    public final int size() {
        return this.f6247a;
    }

    /* renamed from: t */
    public final ml0 o(int i) {
        if (i >= this.f6247a) {
            return new zl0(Arrays.copyOf(this.f6248a, i), this.f6247a);
        }
        throw new IllegalArgumentException();
    }
}
