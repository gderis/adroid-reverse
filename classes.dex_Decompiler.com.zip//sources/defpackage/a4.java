package defpackage;

import java.util.concurrent.Executor;

/* renamed from: a4  reason: default package */
public class a4 extends c4 {
    public static volatile a4 a;

    /* renamed from: a  reason: collision with other field name */
    public static final Executor f21a = new a();
    public static final Executor b = new b();

    /* renamed from: a  reason: collision with other field name */
    public c4 f22a;

    /* renamed from: b  reason: collision with other field name */
    public c4 f23b;

    /* renamed from: a4$a */
    public static class a implements Executor {
        public void execute(Runnable runnable) {
            a4.e().c(runnable);
        }
    }

    /* renamed from: a4$b */
    public static class b implements Executor {
        public void execute(Runnable runnable) {
            a4.e().a(runnable);
        }
    }

    public a4() {
        b4 b4Var = new b4();
        this.f23b = b4Var;
        this.f22a = b4Var;
    }

    public static Executor d() {
        return b;
    }

    public static a4 e() {
        if (a != null) {
            return a;
        }
        synchronized (a4.class) {
            if (a == null) {
                a = new a4();
            }
        }
        return a;
    }

    public void a(Runnable runnable) {
        this.f22a.a(runnable);
    }

    public boolean b() {
        return this.f22a.b();
    }

    public void c(Runnable runnable) {
        this.f22a.c(runnable);
    }
}
