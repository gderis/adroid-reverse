package defpackage;

import defpackage.bu;

/* renamed from: qr  reason: default package */
public final /* synthetic */ class qr implements bu.a {
    public final /* synthetic */ iq a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ nq f4689a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ rr f4690a;

    public /* synthetic */ qr(rr rrVar, nq nqVar, iq iqVar) {
        this.f4690a = rrVar;
        this.f4689a = nqVar;
        this.a = iqVar;
    }

    public final Object a() {
        this.f4690a.c(this.f4689a, this.a);
        return null;
    }
}
