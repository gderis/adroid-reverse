package defpackage;

import java.util.List;

/* renamed from: rc0  reason: default package */
public final class rc0 extends dc0 {
    public final wb0 a(String str, zg0 zg0, List<wb0> list) {
        if (str == null || str.isEmpty() || !zg0.d(str)) {
            throw new IllegalArgumentException(String.format("Command not found: %s", new Object[]{str}));
        }
        wb0 h = zg0.h(str);
        if (h instanceof pb0) {
            return ((pb0) h).a(zg0, list);
        }
        throw new IllegalArgumentException(String.format("Function %s is not defined", new Object[]{str}));
    }
}
