package defpackage;

import java.util.concurrent.Callable;

/* renamed from: t50  reason: default package */
public final class t50 extends s50 {
    public final Callable<String> a;

    public t50(Callable<String> callable) {
        super(false, (String) null, (Throwable) null);
        this.a = callable;
    }

    public final String f() {
        try {
            return this.a.call();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
