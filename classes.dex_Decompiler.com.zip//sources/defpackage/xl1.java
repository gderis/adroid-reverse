package defpackage;

/* renamed from: xl1  reason: default package */
public class xl1<T> {
    public final Class<T> a;

    /* renamed from: a  reason: collision with other field name */
    public final T f5868a;

    public T a() {
        return this.f5868a;
    }

    public Class<T> b() {
        return this.a;
    }

    public String toString() {
        return String.format("Event{type: %s, payload: %s}", new Object[]{this.a, this.f5868a});
    }
}
