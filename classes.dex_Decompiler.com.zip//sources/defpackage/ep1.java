package defpackage;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

/* renamed from: ep1  reason: default package */
public class ep1 implements Runnable {
    public final long a;

    /* renamed from: a  reason: collision with other field name */
    public final PowerManager.WakeLock f2318a;

    /* renamed from: a  reason: collision with other field name */
    public final FirebaseMessaging f2319a;

    /* renamed from: a  reason: collision with other field name */
    public ExecutorService f2320a = new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue(), new s40("firebase-iid-executor"));

    /* renamed from: ep1$a */
    public static class a extends BroadcastReceiver {
        @Nullable
        public ep1 a;

        public a(ep1 ep1) {
            this.a = ep1;
        }

        public void a() {
            boolean c = ep1.c();
            this.a.b().registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }

        public void onReceive(Context context, Intent intent) {
            ep1 ep1 = this.a;
            if (ep1 != null && ep1.d()) {
                boolean c = ep1.c();
                this.a.f2319a.d(this.a, 0);
                this.a.b().unregisterReceiver(this);
                this.a = null;
            }
        }
    }

    @SuppressLint({"InvalidWakeLockTag"})
    public ep1(FirebaseMessaging firebaseMessaging, long j) {
        this.f2319a = firebaseMessaging;
        this.a = j;
        PowerManager.WakeLock newWakeLock = ((PowerManager) b().getSystemService("power")).newWakeLock(1, "fiid-sync");
        this.f2318a = newWakeLock;
        newWakeLock.setReferenceCounted(false);
    }

    public static boolean c() {
        return Log.isLoggable("FirebaseMessaging", 3) || (Build.VERSION.SDK_INT == 23 && Log.isLoggable("FirebaseMessaging", 3));
    }

    public Context b() {
        return this.f2319a.e();
    }

    public boolean d() {
        ConnectivityManager connectivityManager = (ConnectivityManager) b().getSystemService("connectivity");
        NetworkInfo activeNetworkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public boolean e() {
        try {
            if (this.f2319a.c() == null) {
                return false;
            }
            boolean isLoggable = Log.isLoggable("FirebaseMessaging", 3);
            return true;
        } catch (IOException e) {
            if (oo1.f(e.getMessage())) {
                String message = e.getMessage();
                StringBuilder sb = new StringBuilder(String.valueOf(message).length() + 52);
                sb.append("Token retrieval failed: ");
                sb.append(message);
                sb.append(". Will retry token retrieval");
                sb.toString();
                return false;
            } else if (e.getMessage() == null) {
                return false;
            } else {
                throw e;
            }
        } catch (SecurityException unused) {
            return false;
        }
    }

    @SuppressLint({"WakelockTimeout"})
    public void run() {
        if (ap1.b().e(b())) {
            this.f2318a.acquire();
        }
        try {
            this.f2319a.p(true);
            if (!this.f2319a.k()) {
                this.f2319a.p(false);
                if (!ap1.b().e(b())) {
                    return;
                }
            } else if (!ap1.b().d(b()) || d()) {
                if (e()) {
                    this.f2319a.p(false);
                } else {
                    this.f2319a.s(this.a);
                }
                if (!ap1.b().e(b())) {
                    return;
                }
            } else {
                new a(this).a();
                if (!ap1.b().e(b())) {
                    return;
                }
            }
        } catch (IOException e) {
            String message = e.getMessage();
            StringBuilder sb = new StringBuilder(String.valueOf(message).length() + 93);
            sb.append("Topic sync or token retrieval failed on hard failure exceptions: ");
            sb.append(message);
            sb.append(". Won't retry the operation.");
            sb.toString();
            this.f2319a.p(false);
            if (!ap1.b().e(b())) {
                return;
            }
        } catch (Throwable th) {
            if (ap1.b().e(b())) {
                this.f2318a.release();
            }
            throw th;
        }
        this.f2318a.release();
    }
}
