package defpackage;

import android.view.View;

/* renamed from: x4  reason: default package */
public class x4 {
    public static String a(View view) {
        try {
            return view.getContext().getResources().getResourceEntryName(view.getId());
        } catch (Exception unused) {
            return "UNKNOWN";
        }
    }
}
