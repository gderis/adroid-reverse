package defpackage;

/* renamed from: to0  reason: default package */
public final class to0 implements dj0<uo0> {
    public static final to0 a = new to0();

    /* renamed from: a  reason: collision with other field name */
    public final dj0<uo0> f5220a = hj0.a(hj0.b(new vo0()));

    public static long A() {
        return a.a().k();
    }

    public static long B() {
        return a.a().r();
    }

    public static long C() {
        return a.a().z();
    }

    public static long D() {
        return a.a().F();
    }

    public static long E() {
        return a.a().g();
    }

    public static long F() {
        return a.a().q();
    }

    public static long G() {
        return a.a().y();
    }

    public static long H() {
        return a.a().D();
    }

    public static long I() {
        return a.a().e();
    }

    public static long J() {
        return a.a().o();
    }

    public static long K() {
        return a.a().v();
    }

    public static long b() {
        return a.a().A();
    }

    public static long c() {
        return a.a().p();
    }

    public static long d() {
        return a.a().x();
    }

    public static long e() {
        return a.a().G();
    }

    public static long f() {
        return a.a().j();
    }

    public static long g() {
        return a.a().m();
    }

    public static long h() {
        return a.a().u();
    }

    public static long i() {
        return a.a().C();
    }

    public static String j() {
        return a.a().t();
    }

    public static long k() {
        return a.a().n();
    }

    public static long m() {
        return a.a().d();
    }

    public static long n() {
        return a.a().i();
    }

    public static long o() {
        return a.a().b();
    }

    public static String p() {
        return a.a().h();
    }

    public static String q() {
        return a.a().c();
    }

    public static long r() {
        return a.a().f();
    }

    public static long s() {
        return a.a().l();
    }

    public static long t() {
        return a.a().w();
    }

    public static long u() {
        return a.a().E();
    }

    public static long v() {
        return a.a().I();
    }

    public static long w() {
        return a.a().a();
    }

    public static long x() {
        return a.a().s();
    }

    public static long y() {
        return a.a().B();
    }

    public static long z() {
        return a.a().H();
    }

    /* renamed from: l */
    public final uo0 a() {
        return this.f5220a.a();
    }
}
