package defpackage;

/* renamed from: fx0  reason: default package */
public final /* synthetic */ class fx0 implements xy0 {
    public static final xy0 a = new fx0();

    public final Object a() {
        zy0<Long> zy0 = bz0.f1148a;
        return Boolean.valueOf(do0.b());
    }
}
