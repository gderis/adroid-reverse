package defpackage;

/* renamed from: uo0  reason: default package */
public interface uo0 {
    long A();

    long B();

    long C();

    long D();

    long E();

    long F();

    long G();

    long H();

    long I();

    long a();

    long b();

    String c();

    long d();

    long e();

    long f();

    long g();

    String h();

    long i();

    long j();

    long k();

    long l();

    long m();

    long n();

    long o();

    long p();

    long q();

    long r();

    long s();

    String t();

    long u();

    long v();

    long w();

    long x();

    long y();

    long z();
}
