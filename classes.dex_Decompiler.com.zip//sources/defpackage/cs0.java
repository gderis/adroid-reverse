package defpackage;

import java.util.List;

/* renamed from: cs0  reason: default package */
public interface cs0 {
    void a(int i, String str, List<String> list, boolean z, boolean z2);
}
