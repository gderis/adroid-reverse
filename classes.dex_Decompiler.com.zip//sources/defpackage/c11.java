package defpackage;

import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

/* renamed from: c11  reason: default package */
public final class c11 {
    public long a;

    /* renamed from: a  reason: collision with other field name */
    public Boolean f1170a;

    /* renamed from: a  reason: collision with other field name */
    public final String f1171a;

    /* renamed from: a  reason: collision with other field name */
    public List<String> f1172a;

    /* renamed from: a  reason: collision with other field name */
    public final w01 f1173a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f1174a;
    public long b;

    /* renamed from: b  reason: collision with other field name */
    public String f1175b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f1176b;
    public long c;

    /* renamed from: c  reason: collision with other field name */
    public String f1177c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f1178c;
    public long d;

    /* renamed from: d  reason: collision with other field name */
    public String f1179d;
    public long e;

    /* renamed from: e  reason: collision with other field name */
    public String f1180e;
    public long f;

    /* renamed from: f  reason: collision with other field name */
    public String f1181f;
    public long g;

    /* renamed from: g  reason: collision with other field name */
    public String f1182g;
    public long h;

    /* renamed from: h  reason: collision with other field name */
    public String f1183h;
    public long i;

    /* renamed from: i  reason: collision with other field name */
    public String f1184i;
    public long j;

    /* renamed from: j  reason: collision with other field name */
    public String f1185j;
    public long k;
    public long l;
    public long m;
    public long n;
    public long o;
    public long p;

    public c11(w01 w01, String str) {
        s10.j(w01);
        s10.f(str);
        this.f1173a = w01;
        this.f1171a = str;
        w01.f().h();
    }

    public final boolean A() {
        this.f1173a.f().h();
        return this.f1178c;
    }

    public final String B() {
        this.f1173a.f().h();
        return this.f1185j;
    }

    public final String C() {
        this.f1173a.f().h();
        String str = this.f1185j;
        D((String) null);
        return str;
    }

    public final void D(String str) {
        this.f1173a.f().h();
        this.f1178c |= !z51.G(this.f1185j, str);
        this.f1185j = str;
    }

    public final long E() {
        this.f1173a.f().h();
        return this.g;
    }

    public final void F(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.g != j2;
        this.g = j2;
    }

    public final boolean G() {
        this.f1173a.f().h();
        return this.f1176b;
    }

    public final void H(boolean z) {
        this.f1173a.f().h();
        this.f1178c |= this.f1176b != z;
        this.f1176b = z;
    }

    public final Boolean I() {
        this.f1173a.f().h();
        return this.f1170a;
    }

    public final void J(Boolean bool) {
        this.f1173a.f().h();
        boolean z = this.f1178c;
        Boolean bool2 = this.f1170a;
        int i2 = z51.a;
        this.f1178c = z | (!((bool2 == null && bool == null) ? true : bool2 == null ? false : bool2.equals(bool)));
        this.f1170a = bool;
    }

    public final List<String> K() {
        this.f1173a.f().h();
        return this.f1172a;
    }

    public final void L(List<String> list) {
        this.f1173a.f().h();
        List<String> list2 = this.f1172a;
        int i2 = z51.a;
        if (list2 != null || list != null) {
            if (list2 == null || !list2.equals(list)) {
                this.f1178c = true;
                this.f1172a = list != null ? new ArrayList(list) : null;
            }
        }
    }

    public final void M() {
        this.f1173a.f().h();
        this.f1178c = false;
    }

    public final String N() {
        this.f1173a.f().h();
        return this.f1171a;
    }

    public final String O() {
        this.f1173a.f().h();
        return this.f1175b;
    }

    public final void P(String str) {
        this.f1173a.f().h();
        this.f1178c |= !z51.G(this.f1175b, str);
        this.f1175b = str;
    }

    public final String Q() {
        this.f1173a.f().h();
        return this.f1177c;
    }

    public final void R(String str) {
        this.f1173a.f().h();
        if (true == TextUtils.isEmpty(str)) {
            str = null;
        }
        this.f1178c |= true ^ z51.G(this.f1177c, str);
        this.f1177c = str;
    }

    public final String S() {
        this.f1173a.f().h();
        return this.f1183h;
    }

    public final void T(String str) {
        this.f1173a.f().h();
        if (true == TextUtils.isEmpty(str)) {
            str = null;
        }
        this.f1178c |= true ^ z51.G(this.f1183h, str);
        this.f1183h = str;
    }

    public final String U() {
        this.f1173a.f().h();
        return this.f1184i;
    }

    public final void V(String str) {
        this.f1173a.f().h();
        if (true == TextUtils.isEmpty(str)) {
            str = null;
        }
        this.f1178c |= true ^ z51.G(this.f1184i, str);
        this.f1184i = str;
    }

    public final String W() {
        this.f1173a.f().h();
        return this.f1179d;
    }

    public final void X(String str) {
        this.f1173a.f().h();
        this.f1178c |= !z51.G(this.f1179d, str);
        this.f1179d = str;
    }

    public final String Y() {
        this.f1173a.f().h();
        return this.f1180e;
    }

    public final void Z(String str) {
        this.f1173a.f().h();
        this.f1178c |= !z51.G(this.f1180e, str);
        this.f1180e = str;
    }

    public final void a(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.e != j2;
        this.e = j2;
    }

    public final long a0() {
        this.f1173a.f().h();
        return this.b;
    }

    public final long b() {
        this.f1173a.f().h();
        return this.f;
    }

    public final void b0(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.b != j2;
        this.b = j2;
    }

    public final void c(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.f != j2;
        this.f = j2;
    }

    public final long c0() {
        this.f1173a.f().h();
        return this.c;
    }

    public final long d() {
        this.f1173a.f().h();
        return this.h;
    }

    public final void d0(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.c != j2;
        this.c = j2;
    }

    public final void e(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.h != j2;
        this.h = j2;
    }

    public final String e0() {
        this.f1173a.f().h();
        return this.f1181f;
    }

    public final boolean f() {
        this.f1173a.f().h();
        return this.f1174a;
    }

    public final void f0(String str) {
        this.f1173a.f().h();
        this.f1178c |= !z51.G(this.f1181f, str);
        this.f1181f = str;
    }

    public final void g(boolean z) {
        this.f1173a.f().h();
        this.f1178c |= this.f1174a != z;
        this.f1174a = z;
    }

    public final long g0() {
        this.f1173a.f().h();
        return this.d;
    }

    public final void h(long j2) {
        boolean z = true;
        s10.a(j2 >= 0);
        this.f1173a.f().h();
        boolean z2 = this.f1178c;
        if (this.a == j2) {
            z = false;
        }
        this.f1178c = z | z2;
        this.a = j2;
    }

    public final void h0(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.d != j2;
        this.d = j2;
    }

    public final long i() {
        this.f1173a.f().h();
        return this.a;
    }

    public final String i0() {
        this.f1173a.f().h();
        return this.f1182g;
    }

    public final long j() {
        this.f1173a.f().h();
        return this.o;
    }

    public final void j0(String str) {
        this.f1173a.f().h();
        this.f1178c |= !z51.G(this.f1182g, str);
        this.f1182g = str;
    }

    public final void k(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.o != j2;
        this.o = j2;
    }

    public final long k0() {
        this.f1173a.f().h();
        return this.e;
    }

    public final long l() {
        this.f1173a.f().h();
        return this.p;
    }

    public final void m(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.p != j2;
        this.p = j2;
    }

    public final void n() {
        this.f1173a.f().h();
        long j2 = this.a + 1;
        if (j2 > 2147483647L) {
            this.f1173a.c().r().b("Bundle index overflow. appId", nz0.x(this.f1171a));
            j2 = 0;
        }
        this.f1178c = true;
        this.a = j2;
    }

    public final long o() {
        this.f1173a.f().h();
        return this.i;
    }

    public final void p(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.i != j2;
        this.i = j2;
    }

    public final long q() {
        this.f1173a.f().h();
        return this.j;
    }

    public final void r(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.j != j2;
        this.j = j2;
    }

    public final long s() {
        this.f1173a.f().h();
        return this.k;
    }

    public final void t(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.k != j2;
        this.k = j2;
    }

    public final long u() {
        this.f1173a.f().h();
        return this.l;
    }

    public final void v(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.l != j2;
        this.l = j2;
    }

    public final long w() {
        this.f1173a.f().h();
        return this.n;
    }

    public final void x(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.n != j2;
        this.n = j2;
    }

    public final long y() {
        this.f1173a.f().h();
        return this.m;
    }

    public final void z(long j2) {
        this.f1173a.f().h();
        this.f1178c |= this.m != j2;
        this.m = j2;
    }
}
