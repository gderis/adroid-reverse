package defpackage;

/* renamed from: r32  reason: default package */
public /* synthetic */ class r32 {
    public static /* synthetic */ int a(long j) {
        return (int) (j ^ (j >>> 32));
    }
}
