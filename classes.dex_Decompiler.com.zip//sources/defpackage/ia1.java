package defpackage;

import android.view.View;

/* renamed from: ia1  reason: default package */
public interface ia1<T extends View> {
    void a(T t);

    void b(T t);
}
