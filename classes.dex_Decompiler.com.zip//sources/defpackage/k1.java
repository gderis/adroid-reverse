package defpackage;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewDebug;
import android.widget.LinearLayout;
import defpackage.ea;
import defpackage.p1;

/* renamed from: k1  reason: default package */
public final class k1 implements t8 {
    public char a;

    /* renamed from: a  reason: collision with other field name */
    public final int f3366a;

    /* renamed from: a  reason: collision with other field name */
    public Intent f3367a;

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f3368a = null;

    /* renamed from: a  reason: collision with other field name */
    public PorterDuff.Mode f3369a = null;

    /* renamed from: a  reason: collision with other field name */
    public Drawable f3370a;

    /* renamed from: a  reason: collision with other field name */
    public ContextMenu.ContextMenuInfo f3371a;

    /* renamed from: a  reason: collision with other field name */
    public MenuItem.OnActionExpandListener f3372a;

    /* renamed from: a  reason: collision with other field name */
    public MenuItem.OnMenuItemClickListener f3373a;

    /* renamed from: a  reason: collision with other field name */
    public View f3374a;

    /* renamed from: a  reason: collision with other field name */
    public ea f3375a;

    /* renamed from: a  reason: collision with other field name */
    public i1 f3376a;

    /* renamed from: a  reason: collision with other field name */
    public CharSequence f3377a;

    /* renamed from: a  reason: collision with other field name */
    public Runnable f3378a;

    /* renamed from: a  reason: collision with other field name */
    public t1 f3379a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f3380a = false;
    public char b;

    /* renamed from: b  reason: collision with other field name */
    public final int f3381b;

    /* renamed from: b  reason: collision with other field name */
    public CharSequence f3382b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f3383b = false;
    public final int c;

    /* renamed from: c  reason: collision with other field name */
    public CharSequence f3384c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f3385c = false;
    public final int d;

    /* renamed from: d  reason: collision with other field name */
    public CharSequence f3386d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f3387d = false;
    public int e = 4096;
    public int f = 4096;
    public int g = 0;
    public int h = 16;
    public int i = 0;

    /* renamed from: k1$a */
    public class a implements ea.b {
        public a() {
        }

        public void onActionProviderVisibilityChanged(boolean z) {
            k1 k1Var = k1.this;
            k1Var.f3376a.J(k1Var);
        }
    }

    public k1(i1 i1Var, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f3376a = i1Var;
        this.f3366a = i3;
        this.f3381b = i2;
        this.c = i4;
        this.d = i5;
        this.f3377a = charSequence;
        this.i = i6;
    }

    public static void f(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    public boolean A(boolean z) {
        int i2 = this.h;
        int i3 = (z ? 0 : 8) | (i2 & -9);
        this.h = i3;
        return i2 != i3;
    }

    public boolean B() {
        return this.f3376a.A();
    }

    public boolean C() {
        return this.f3376a.H() && i() != 0;
    }

    public boolean D() {
        return (this.i & 4) == 4;
    }

    /* renamed from: a */
    public t8 setTooltipText(CharSequence charSequence) {
        this.f3386d = charSequence;
        this.f3376a.K(false);
        return this;
    }

    /* renamed from: b */
    public t8 setContentDescription(CharSequence charSequence) {
        this.f3384c = charSequence;
        this.f3376a.K(false);
        return this;
    }

    public ea c() {
        return this.f3375a;
    }

    public boolean collapseActionView() {
        if ((this.i & 8) == 0) {
            return false;
        }
        if (this.f3374a == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f3372a;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f3376a.f(this);
        }
        return false;
    }

    public t8 d(ea eaVar) {
        ea eaVar2 = this.f3375a;
        if (eaVar2 != null) {
            eaVar2.h();
        }
        this.f3374a = null;
        this.f3375a = eaVar;
        this.f3376a.K(true);
        ea eaVar3 = this.f3375a;
        if (eaVar3 != null) {
            eaVar3.j(new a());
        }
        return this;
    }

    public void e() {
        this.f3376a.I(this);
    }

    public boolean expandActionView() {
        if (!l()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f3372a;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f3376a.k(this);
        }
        return false;
    }

    public final Drawable g(Drawable drawable) {
        if (drawable != null && this.f3385c && (this.f3380a || this.f3383b)) {
            drawable = m8.r(drawable).mutate();
            if (this.f3380a) {
                m8.o(drawable, this.f3368a);
            }
            if (this.f3383b) {
                m8.p(drawable, this.f3369a);
            }
            this.f3385c = false;
        }
        return drawable;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    public View getActionView() {
        View view = this.f3374a;
        if (view != null) {
            return view;
        }
        ea eaVar = this.f3375a;
        if (eaVar == null) {
            return null;
        }
        View d2 = eaVar.d(this);
        this.f3374a = d2;
        return d2;
    }

    public int getAlphabeticModifiers() {
        return this.f;
    }

    public char getAlphabeticShortcut() {
        return this.b;
    }

    public CharSequence getContentDescription() {
        return this.f3384c;
    }

    public int getGroupId() {
        return this.f3381b;
    }

    public Drawable getIcon() {
        Drawable drawable = this.f3370a;
        if (drawable != null) {
            return g(drawable);
        }
        if (this.g == 0) {
            return null;
        }
        Drawable d2 = l0.d(this.f3376a.u(), this.g);
        this.g = 0;
        this.f3370a = d2;
        return g(d2);
    }

    public ColorStateList getIconTintList() {
        return this.f3368a;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f3369a;
    }

    public Intent getIntent() {
        return this.f3367a;
    }

    @ViewDebug.CapturedViewProperty
    public int getItemId() {
        return this.f3366a;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f3371a;
    }

    public int getNumericModifiers() {
        return this.e;
    }

    public char getNumericShortcut() {
        return this.a;
    }

    public int getOrder() {
        return this.c;
    }

    public SubMenu getSubMenu() {
        return this.f3379a;
    }

    @ViewDebug.CapturedViewProperty
    public CharSequence getTitle() {
        return this.f3377a;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f3382b;
        if (charSequence == null) {
            charSequence = this.f3377a;
        }
        return (Build.VERSION.SDK_INT >= 18 || charSequence == null || (charSequence instanceof String)) ? charSequence : charSequence.toString();
    }

    public CharSequence getTooltipText() {
        return this.f3386d;
    }

    public int h() {
        return this.d;
    }

    public boolean hasSubMenu() {
        return this.f3379a != null;
    }

    public char i() {
        return this.f3376a.G() ? this.b : this.a;
    }

    public boolean isActionViewExpanded() {
        return this.f3387d;
    }

    public boolean isCheckable() {
        return (this.h & 1) == 1;
    }

    public boolean isChecked() {
        return (this.h & 2) == 2;
    }

    public boolean isEnabled() {
        return (this.h & 16) != 0;
    }

    public boolean isVisible() {
        ea eaVar = this.f3375a;
        return (eaVar == null || !eaVar.g()) ? (this.h & 8) == 0 : (this.h & 8) == 0 && this.f3375a.b();
    }

    public String j() {
        int i2;
        char i3 = i();
        if (i3 == 0) {
            return "";
        }
        Resources resources = this.f3376a.u().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f3376a.u()).hasPermanentMenuKey()) {
            sb.append(resources.getString(v.abc_prepend_shortcut_label));
        }
        int i4 = this.f3376a.G() ? this.f : this.e;
        f(sb, i4, 65536, resources.getString(v.abc_menu_meta_shortcut_label));
        f(sb, i4, 4096, resources.getString(v.abc_menu_ctrl_shortcut_label));
        f(sb, i4, 2, resources.getString(v.abc_menu_alt_shortcut_label));
        f(sb, i4, 1, resources.getString(v.abc_menu_shift_shortcut_label));
        f(sb, i4, 4, resources.getString(v.abc_menu_sym_shortcut_label));
        f(sb, i4, 8, resources.getString(v.abc_menu_function_shortcut_label));
        if (i3 == 8) {
            i2 = v.abc_menu_delete_shortcut_label;
        } else if (i3 == 10) {
            i2 = v.abc_menu_enter_shortcut_label;
        } else if (i3 != ' ') {
            sb.append(i3);
            return sb.toString();
        } else {
            i2 = v.abc_menu_space_shortcut_label;
        }
        sb.append(resources.getString(i2));
        return sb.toString();
    }

    public CharSequence k(p1.a aVar) {
        return (aVar == null || !aVar.a()) ? getTitle() : getTitleCondensed();
    }

    public boolean l() {
        ea eaVar;
        if ((this.i & 8) == 0) {
            return false;
        }
        if (this.f3374a == null && (eaVar = this.f3375a) != null) {
            this.f3374a = eaVar.d(this);
        }
        return this.f3374a != null;
    }

    public boolean m() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.f3373a;
        if (onMenuItemClickListener != null && onMenuItemClickListener.onMenuItemClick(this)) {
            return true;
        }
        i1 i1Var = this.f3376a;
        if (i1Var.h(i1Var, this)) {
            return true;
        }
        Runnable runnable = this.f3378a;
        if (runnable != null) {
            runnable.run();
            return true;
        }
        if (this.f3367a != null) {
            try {
                this.f3376a.u().startActivity(this.f3367a);
                return true;
            } catch (ActivityNotFoundException unused) {
            }
        }
        ea eaVar = this.f3375a;
        return eaVar != null && eaVar.e();
    }

    public boolean n() {
        return (this.h & 32) == 32;
    }

    public boolean o() {
        return (this.h & 4) != 0;
    }

    public boolean p() {
        return (this.i & 1) == 1;
    }

    public boolean q() {
        return (this.i & 2) == 2;
    }

    /* renamed from: r */
    public t8 setActionView(int i2) {
        Context u = this.f3376a.u();
        setActionView(LayoutInflater.from(u).inflate(i2, new LinearLayout(u), false));
        return this;
    }

    /* renamed from: s */
    public t8 setActionView(View view) {
        int i2;
        this.f3374a = view;
        this.f3375a = null;
        if (view != null && view.getId() == -1 && (i2 = this.f3366a) > 0) {
            view.setId(i2);
        }
        this.f3376a.I(this);
        return this;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    public MenuItem setAlphabeticShortcut(char c2) {
        if (this.b == c2) {
            return this;
        }
        this.b = Character.toLowerCase(c2);
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.b == c2 && this.f == i2) {
            return this;
        }
        this.b = Character.toLowerCase(c2);
        this.f = KeyEvent.normalizeMetaState(i2);
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        int i2 = this.h;
        boolean z2 = z | (i2 & true);
        this.h = z2 ? 1 : 0;
        if (i2 != z2) {
            this.f3376a.K(false);
        }
        return this;
    }

    public MenuItem setChecked(boolean z) {
        if ((this.h & 4) != 0) {
            this.f3376a.T(this);
        } else {
            u(z);
        }
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.h = z ? this.h | 16 : this.h & -17;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setIcon(int i2) {
        this.f3370a = null;
        this.g = i2;
        this.f3385c = true;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.g = 0;
        this.f3370a = drawable;
        this.f3385c = true;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f3368a = colorStateList;
        this.f3380a = true;
        this.f3385c = true;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f3369a = mode;
        this.f3383b = true;
        this.f3385c = true;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f3367a = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c2) {
        if (this.a == c2) {
            return this;
        }
        this.a = c2;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setNumericShortcut(char c2, int i2) {
        if (this.a == c2 && this.e == i2) {
            return this;
        }
        this.a = c2;
        this.e = KeyEvent.normalizeMetaState(i2);
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f3372a = onActionExpandListener;
        return this;
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f3373a = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c2, char c3) {
        this.a = c2;
        this.b = Character.toLowerCase(c3);
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.a = c2;
        this.e = KeyEvent.normalizeMetaState(i2);
        this.b = Character.toLowerCase(c3);
        this.f = KeyEvent.normalizeMetaState(i3);
        this.f3376a.K(false);
        return this;
    }

    public void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 == 0 || i3 == 1 || i3 == 2) {
            this.i = i2;
            this.f3376a.I(this);
            return;
        }
        throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
    }

    public MenuItem setTitle(int i2) {
        return setTitle((CharSequence) this.f3376a.u().getString(i2));
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f3377a = charSequence;
        this.f3376a.K(false);
        t1 t1Var = this.f3379a;
        if (t1Var != null) {
            t1Var.setHeaderTitle(charSequence);
        }
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f3382b = charSequence;
        this.f3376a.K(false);
        return this;
    }

    public MenuItem setVisible(boolean z) {
        if (A(z)) {
            this.f3376a.J(this);
        }
        return this;
    }

    public void t(boolean z) {
        this.f3387d = z;
        this.f3376a.K(false);
    }

    public String toString() {
        CharSequence charSequence = this.f3377a;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public void u(boolean z) {
        int i2 = this.h;
        int i3 = (z ? 2 : 0) | (i2 & -3);
        this.h = i3;
        if (i2 != i3) {
            this.f3376a.K(false);
        }
    }

    public void v(boolean z) {
        this.h = (z ? 4 : 0) | (this.h & -5);
    }

    public void w(boolean z) {
        this.h = z ? this.h | 32 : this.h & -33;
    }

    public void x(ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.f3371a = contextMenuInfo;
    }

    /* renamed from: y */
    public t8 setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    public void z(t1 t1Var) {
        this.f3379a = t1Var;
        t1Var.setHeaderTitle(getTitle());
    }
}
