package defpackage;

import android.os.Bundle;
import android.os.IInterface;

/* renamed from: od0  reason: default package */
public interface od0 extends IInterface {
    void F0(Bundle bundle);
}
