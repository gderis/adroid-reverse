package defpackage;

/* renamed from: xp0  reason: default package */
public final class xp0 implements wp0 {
    public static final ui0<Boolean> a;
    public static final ui0<Boolean> b;
    public static final ui0<Long> c;

    static {
        si0 si0 = new si0(li0.a("com.google.android.gms.measurement"));
        a = si0.b("measurement.collection.efficient_engagement_reporting_enabled_2", true);
        b = si0.b("measurement.collection.redundant_engagement_removal_enabled", false);
        c = si0.a("measurement.id.collection.redundant_engagement_removal_enabled", 0);
    }

    public final boolean a() {
        return b.e().booleanValue();
    }
}
