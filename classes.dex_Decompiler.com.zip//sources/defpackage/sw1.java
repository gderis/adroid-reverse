package defpackage;

import android.app.Application;
import android.content.Context;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: sw1  reason: default package */
public class sw1 extends Application {
    public static final HashMap<String, String> a = new HashMap<>();

    public static ix1 a(Context context, xt1 xt1, boolean z) {
        Class<fv1> cls = fv1.class;
        JSONArray jSONArray = new JSONArray();
        long j = 0;
        try {
            j = xt1.l(wx1.a(-481408813011527372L));
            int p = xt1.p(wx1.a(-481408834486363852L), 50);
            if (!xt1.a(wx1.a(-481408855961200332L), z)) {
                return new ix1(jSONArray, j);
            }
            xr1<TModel> a2 = fs1.c(new js1[0]).a(cls);
            ks1<Long> ks1 = gv1.f;
            List<TModel> p2 = a2.q(ks1.e(Long.valueOf(j))).s(ks1, true).r(p).p();
            o82.d(wx1.a(-481408877436036812L), ox1.c(j));
            if (p2.size() > 0) {
                for (int i = 0; i < p2.size(); i++) {
                    try {
                        String g = ((fv1) p2.get(i)).g();
                        JSONObject jSONObject = new JSONObject();
                        JSONObject jSONObject2 = new JSONObject();
                        jSONObject2.put(wx1.a(-481408950450480844L), g);
                        HashMap<String, String> hashMap = a;
                        if (hashMap.containsKey(g)) {
                            g = hashMap.get(g);
                        } else if (!g.startsWith(wx1.a(-481408971925317324L)) && !hashMap.containsKey(g)) {
                            String f = ox1.f(context, g);
                            if (f.length() <= 0) {
                                f = g;
                            }
                            hashMap.put(g, f);
                            g = f;
                        }
                        jSONObject2.put(wx1.a(-481408980515251916L), g);
                        jSONObject.put(wx1.a(-481409036349826764L), jSONObject2);
                        jSONObject.put(wx1.a(-481409070709565132L), ((fv1) p2.get(i)).e());
                        jSONObject.put(wx1.a(-481409105069303500L), ((fv1) p2.get(i)).h());
                        jSONObject.put(wx1.a(-481409126544139980L), ((fv1) p2.get(i)).i());
                        jSONObject.put(wx1.a(-481409148018976460L), ((fv1) p2.get(i)).c());
                        jSONObject.put(wx1.a(-481409169493812940L), ox1.c(((fv1) p2.get(i)).d()));
                        jSONObject.put(wx1.a(-481409208148518604L), ((fv1) p2.get(i)).f());
                        jSONArray.put(jSONObject);
                        if (((fv1) p2.get(i)).d() > j) {
                            j = ((fv1) p2.get(i)).d();
                        }
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                }
                try {
                    Calendar instance = Calendar.getInstance();
                    instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481409268278060748L)));
                    instance.add(10, -72);
                    fs1.b(cls).q(gv1.f.f(Long.valueOf(instance.getTimeInMillis()))).m().h();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return new ix1(jSONArray, j);
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }
}
