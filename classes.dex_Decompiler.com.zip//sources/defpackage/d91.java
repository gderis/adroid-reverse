package defpackage;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

/* renamed from: d91  reason: default package */
public final class d91 implements Runnable {
    public final /* synthetic */ e91 a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ n81 f1957a;

    public d91(e91 e91, n81 n81) {
        this.a = e91;
        this.f1957a = n81;
    }

    public final void run() {
        try {
            n81 a2 = this.a.f2247a.a(this.f1957a.j());
            if (a2 == null) {
                this.a.a(new NullPointerException("Continuation returned null"));
                return;
            }
            Executor executor = p81.b;
            a2.e(executor, this.a);
            a2.d(executor, this.a);
            a2.a(executor, this.a);
        } catch (l81 e) {
            if (e.getCause() instanceof Exception) {
                this.a.a((Exception) e.getCause());
            } else {
                this.a.a(e);
            }
        } catch (CancellationException unused) {
            this.a.b();
        } catch (Exception e2) {
            this.a.a(e2);
        }
    }
}
