package defpackage;

import java.net.Proxy;

/* renamed from: o42  reason: default package */
public final /* synthetic */ class o42 {
    public static final /* synthetic */ int[] a;

    static {
        int[] iArr = new int[Proxy.Type.values().length];
        a = iArr;
        iArr[Proxy.Type.DIRECT.ordinal()] = 1;
    }
}
