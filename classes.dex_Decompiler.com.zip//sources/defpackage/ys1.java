package defpackage;

import com.raizlabs.android.dbflow.config.FlowManager;

/* renamed from: ys1  reason: default package */
public abstract class ys1<TModel> extends us1<TModel> implements vs1<TModel> {
    public it1 a;

    /* renamed from: a  reason: collision with other field name */
    public ss1<TModel> f6074a;
    public it1 b;

    public ys1(qq1 qq1) {
        super(qq1);
        if (l() != null && l().b() != null) {
            ss1<TModel> b2 = l().b();
            this.f6074a = b2;
            b2.e(this);
        }
    }

    public it1 A(kt1 kt1) {
        return kt1.e(B());
    }

    public abstract String B();

    public boolean C(TModel tmodel) {
        return y().c(tmodel);
    }

    public void D(TModel tmodel, kt1 kt1) {
    }

    public void E(ss1<TModel> ss1) {
        this.f6074a = ss1;
        ss1.e(this);
    }

    public void F(TModel tmodel, Number number) {
    }

    public void q(it1 it1, TModel tmodel) {
        c(it1, tmodel, 0);
    }

    public ss1<TModel> r() {
        return new ss1<>();
    }

    public boolean s() {
        return true;
    }

    public abstract String t();

    public abstract String u();

    public it1 v() {
        if (this.a == null) {
            this.a = w(FlowManager.m(h()));
        }
        return this.a;
    }

    public it1 w(kt1 kt1) {
        return kt1.e(x());
    }

    public String x() {
        return t();
    }

    public ss1<TModel> y() {
        if (this.f6074a == null) {
            ss1<TModel> r = r();
            this.f6074a = r;
            r.e(this);
        }
        return this.f6074a;
    }

    public it1 z() {
        if (this.b == null) {
            this.b = A(FlowManager.m(h()));
        }
        return this.b;
    }
}
