package defpackage;

/* renamed from: wl  reason: default package */
public class wl {
    public Long a;

    /* renamed from: a  reason: collision with other field name */
    public String f5726a;

    public wl(String str, long j) {
        this.f5726a = str;
        this.a = Long.valueOf(j);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public wl(String str, boolean z) {
        this(str, z ? 1 : 0);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof wl)) {
            return false;
        }
        wl wlVar = (wl) obj;
        if (!this.f5726a.equals(wlVar.f5726a)) {
            return false;
        }
        Long l = this.a;
        Long l2 = wlVar.a;
        return l != null ? l.equals(l2) : l2 == null;
    }

    public int hashCode() {
        int hashCode = this.f5726a.hashCode() * 31;
        Long l = this.a;
        return hashCode + (l != null ? l.hashCode() : 0);
    }
}
