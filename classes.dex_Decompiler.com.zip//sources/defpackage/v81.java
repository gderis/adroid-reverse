package defpackage;

/* renamed from: v81  reason: default package */
public final class v81 implements Runnable {
    public final /* synthetic */ w81 a;

    public v81(w81 w81) {
        this.a = w81;
    }

    public final void run() {
        synchronized (this.a.f5709a) {
            if (this.a.a != null) {
                this.a.a.b();
            }
        }
    }
}
