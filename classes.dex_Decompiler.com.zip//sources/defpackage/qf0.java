package defpackage;

/* renamed from: qf0  reason: default package */
public final class qf0 extends gl0<qf0, pf0> implements mm0 {
    /* access modifiers changed from: private */
    public static final qf0 zzk;
    private int zza;
    private int zze;
    private String zzf = "";
    private jf0 zzg;
    private boolean zzh;
    private boolean zzi;
    private boolean zzj;

    static {
        qf0 qf0 = new qf0();
        zzk = qf0;
        gl0.x(qf0.class, qf0);
    }

    public static pf0 I() {
        return (pf0) zzk.r();
    }

    public static /* synthetic */ void K(qf0 qf0, String str) {
        qf0.zza |= 2;
        qf0.zzf = str;
    }

    public final boolean A() {
        return (this.zza & 1) != 0;
    }

    public final int B() {
        return this.zze;
    }

    public final String C() {
        return this.zzf;
    }

    public final jf0 D() {
        jf0 jf0 = this.zzg;
        return jf0 == null ? jf0.I() : jf0;
    }

    public final boolean E() {
        return this.zzh;
    }

    public final boolean F() {
        return this.zzi;
    }

    public final boolean G() {
        return (this.zza & 32) != 0;
    }

    public final boolean H() {
        return this.zzj;
    }

    public final Object z(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return gl0.y(zzk, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001င\u0000\u0002ဈ\u0001\u0003ဉ\u0002\u0004ဇ\u0003\u0005ဇ\u0004\u0006ဇ\u0005", new Object[]{"zza", "zze", "zzf", "zzg", "zzh", "zzi", "zzj"});
        } else if (i2 == 3) {
            return new qf0();
        } else {
            if (i2 == 4) {
                return new pf0((df0) null);
            }
            if (i2 != 5) {
                return null;
            }
            return zzk;
        }
    }
}
