package defpackage;

import defpackage.yp;

/* renamed from: sp  reason: default package */
public final class sp extends yp {
    public final yp.b a;

    /* renamed from: a  reason: collision with other field name */
    public final yp.c f5087a;

    /* renamed from: sp$b */
    public static final class b extends yp.a {
        public yp.b a;

        /* renamed from: a  reason: collision with other field name */
        public yp.c f5088a;

        public yp a() {
            return new sp(this.f5088a, this.a);
        }

        public yp.a b(yp.b bVar) {
            this.a = bVar;
            return this;
        }

        public yp.a c(yp.c cVar) {
            this.f5088a = cVar;
            return this;
        }
    }

    public sp(yp.c cVar, yp.b bVar) {
        this.f5087a = cVar;
        this.a = bVar;
    }

    public yp.b b() {
        return this.a;
    }

    public yp.c c() {
        return this.f5087a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof yp)) {
            return false;
        }
        yp ypVar = (yp) obj;
        yp.c cVar = this.f5087a;
        if (cVar != null ? cVar.equals(ypVar.c()) : ypVar.c() == null) {
            yp.b bVar = this.a;
            yp.b b2 = ypVar.b();
            if (bVar == null) {
                if (b2 == null) {
                    return true;
                }
            } else if (bVar.equals(b2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        yp.c cVar = this.f5087a;
        int i = 0;
        int hashCode = ((cVar == null ? 0 : cVar.hashCode()) ^ 1000003) * 1000003;
        yp.b bVar = this.a;
        if (bVar != null) {
            i = bVar.hashCode();
        }
        return hashCode ^ i;
    }

    public String toString() {
        return "NetworkConnectionInfo{networkType=" + this.f5087a + ", mobileSubtype=" + this.a + "}";
    }
}
