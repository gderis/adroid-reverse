package defpackage;

import android.animation.TimeInterpolator;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;
import defpackage.sh;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: wh  reason: default package */
public class wh extends sh {
    public int b;
    public int c = 0;
    public boolean e = true;
    public boolean f = false;
    public ArrayList<sh> q = new ArrayList<>();

    /* renamed from: wh$a */
    public class a extends th {
        public final /* synthetic */ sh a;

        public a(sh shVar) {
            this.a = shVar;
        }

        public void c(sh shVar) {
            this.a.Z();
            shVar.V(this);
        }
    }

    /* renamed from: wh$b */
    public static class b extends th {
        public wh a;

        public b(wh whVar) {
            this.a = whVar;
        }

        public void c(sh shVar) {
            wh whVar = this.a;
            int i = whVar.b - 1;
            whVar.b = i;
            if (i == 0) {
                whVar.f = false;
                whVar.q();
            }
            shVar.V(this);
        }

        public void d(sh shVar) {
            wh whVar = this.a;
            if (!whVar.f) {
                whVar.g0();
                this.a.f = true;
            }
        }
    }

    public void T(View view) {
        super.T(view);
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            this.q.get(i).T(view);
        }
    }

    public void X(View view) {
        super.X(view);
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            this.q.get(i).X(view);
        }
    }

    public void Z() {
        if (this.q.isEmpty()) {
            g0();
            q();
            return;
        }
        u0();
        if (!this.e) {
            for (int i = 1; i < this.q.size(); i++) {
                this.q.get(i - 1).a(new a(this.q.get(i)));
            }
            sh shVar = this.q.get(0);
            if (shVar != null) {
                shVar.Z();
                return;
            }
            return;
        }
        Iterator<sh> it = this.q.iterator();
        while (it.hasNext()) {
            it.next().Z();
        }
    }

    public void b0(sh.e eVar) {
        super.b0(eVar);
        this.c |= 8;
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            this.q.get(i).b0(eVar);
        }
    }

    public void d0(mh mhVar) {
        super.d0(mhVar);
        this.c |= 4;
        if (this.q != null) {
            for (int i = 0; i < this.q.size(); i++) {
                this.q.get(i).d0(mhVar);
            }
        }
    }

    public void e0(vh vhVar) {
        super.e0(vhVar);
        this.c |= 2;
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            this.q.get(i).e0(vhVar);
        }
    }

    public void g(yh yhVar) {
        if (M(yhVar.a)) {
            Iterator<sh> it = this.q.iterator();
            while (it.hasNext()) {
                sh next = it.next();
                if (next.M(yhVar.a)) {
                    next.g(yhVar);
                    yhVar.f6023a.add(next);
                }
            }
        }
    }

    public String h0(String str) {
        String h0 = super.h0(str);
        for (int i = 0; i < this.q.size(); i++) {
            StringBuilder sb = new StringBuilder();
            sb.append(h0);
            sb.append("\n");
            sb.append(this.q.get(i).h0(str + "  "));
            h0 = sb.toString();
        }
        return h0;
    }

    public void i(yh yhVar) {
        super.i(yhVar);
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            this.q.get(i).i(yhVar);
        }
    }

    /* renamed from: i0 */
    public wh a(sh.f fVar) {
        return (wh) super.a(fVar);
    }

    public void j(yh yhVar) {
        if (M(yhVar.a)) {
            Iterator<sh> it = this.q.iterator();
            while (it.hasNext()) {
                sh next = it.next();
                if (next.M(yhVar.a)) {
                    next.j(yhVar);
                    yhVar.f6023a.add(next);
                }
            }
        }
    }

    /* renamed from: j0 */
    public wh b(View view) {
        for (int i = 0; i < this.q.size(); i++) {
            this.q.get(i).b(view);
        }
        return (wh) super.b(view);
    }

    public wh k0(sh shVar) {
        l0(shVar);
        long j = this.b;
        if (j >= 0) {
            shVar.a0(j);
        }
        if ((this.c & 1) != 0) {
            shVar.c0(u());
        }
        if ((this.c & 2) != 0) {
            shVar.e0(A());
        }
        if ((this.c & 4) != 0) {
            shVar.d0(z());
        }
        if ((this.c & 8) != 0) {
            shVar.b0(s());
        }
        return this;
    }

    public final void l0(sh shVar) {
        this.q.add(shVar);
        shVar.f5029a = this;
    }

    /* renamed from: m */
    public sh clone() {
        wh whVar = (wh) super.clone();
        whVar.q = new ArrayList<>();
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            whVar.l0(this.q.get(i).clone());
        }
        return whVar;
    }

    public sh m0(int i) {
        if (i < 0 || i >= this.q.size()) {
            return null;
        }
        return this.q.get(i);
    }

    public int n0() {
        return this.q.size();
    }

    /* renamed from: o0 */
    public wh V(sh.f fVar) {
        return (wh) super.V(fVar);
    }

    public void p(ViewGroup viewGroup, zh zhVar, zh zhVar2, ArrayList<yh> arrayList, ArrayList<yh> arrayList2) {
        long C = C();
        int size = this.q.size();
        for (int i = 0; i < size; i++) {
            sh shVar = this.q.get(i);
            if (C > 0 && (this.e || i == 0)) {
                long C2 = shVar.C();
                if (C2 > 0) {
                    shVar.f0(C2 + C);
                } else {
                    shVar.f0(C);
                }
            }
            shVar.p(viewGroup, zhVar, zhVar2, arrayList, arrayList2);
        }
    }

    /* renamed from: p0 */
    public wh W(View view) {
        for (int i = 0; i < this.q.size(); i++) {
            this.q.get(i).W(view);
        }
        return (wh) super.W(view);
    }

    /* renamed from: q0 */
    public wh a0(long j) {
        ArrayList<sh> arrayList;
        super.a0(j);
        if (this.b >= 0 && (arrayList = this.q) != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.q.get(i).a0(j);
            }
        }
        return this;
    }

    /* renamed from: r0 */
    public wh c0(TimeInterpolator timeInterpolator) {
        this.c |= 1;
        ArrayList<sh> arrayList = this.q;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.q.get(i).c0(timeInterpolator);
            }
        }
        return (wh) super.c0(timeInterpolator);
    }

    public wh s0(int i) {
        if (i == 0) {
            this.e = true;
        } else if (i == 1) {
            this.e = false;
        } else {
            throw new AndroidRuntimeException("Invalid parameter for TransitionSet ordering: " + i);
        }
        return this;
    }

    /* renamed from: t0 */
    public wh f0(long j) {
        return (wh) super.f0(j);
    }

    public final void u0() {
        b bVar = new b(this);
        Iterator<sh> it = this.q.iterator();
        while (it.hasNext()) {
            it.next().a(bVar);
        }
        this.b = this.q.size();
    }
}
