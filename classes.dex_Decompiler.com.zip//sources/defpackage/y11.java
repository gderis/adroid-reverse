package defpackage;

import android.os.Bundle;

/* renamed from: y11  reason: default package */
public interface y11 {
    void a(String str, String str2, Bundle bundle, long j);
}
