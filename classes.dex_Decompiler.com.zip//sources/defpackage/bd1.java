package defpackage;

import android.graphics.RectF;
import java.util.Arrays;

/* renamed from: bd1  reason: default package */
public final class bd1 implements dd1 {
    public final float a;

    public bd1(float f) {
        this.a = f;
    }

    public float a(RectF rectF) {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof bd1) && this.a == ((bd1) obj).a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.a)});
    }
}
