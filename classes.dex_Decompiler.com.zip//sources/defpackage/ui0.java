package defpackage;

import android.content.Context;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nullable;

/* renamed from: ui0  reason: default package */
public abstract class ui0<T> {
    public static final /* synthetic */ int a = 0;

    /* renamed from: a  reason: collision with other field name */
    public static final Object f5391a = new Object();

    /* renamed from: a  reason: collision with other field name */
    public static final AtomicInteger f5392a = new AtomicInteger();

    /* renamed from: a  reason: collision with other field name */
    public static final AtomicReference<Collection<ui0<?>>> f5393a = new AtomicReference<>();
    @Nullable

    /* renamed from: a  reason: collision with other field name */
    public static volatile ti0 f5394a;

    /* renamed from: a  reason: collision with other field name */
    public static final wi0 f5395a = new wi0(ni0.a);

    /* renamed from: a  reason: collision with other field name */
    public final String f5396a;

    /* renamed from: a  reason: collision with other field name */
    public final si0 f5397a;

    /* renamed from: a  reason: collision with other field name */
    public final boolean f5398a;
    public volatile int b = -1;

    /* renamed from: b  reason: collision with other field name */
    public final T f5399b;
    public volatile T c;

    public /* synthetic */ ui0(si0 si0, String str, Object obj, boolean z, oi0 oi0) {
        if (si0.a != null) {
            this.f5397a = si0;
            this.f5396a = str;
            this.f5399b = obj;
            this.f5398a = true;
            return;
        }
        throw new IllegalArgumentException("Must pass a valid SharedPreferences file name or ContentProvider URI");
    }

    @Deprecated
    public static void b(Context context) {
        synchronized (f5391a) {
            ti0 ti0 = f5394a;
            Context applicationContext = context.getApplicationContext();
            if (applicationContext != null) {
                context = applicationContext;
            }
            if (ti0 == null || ti0.a() != context) {
                bi0.e();
                vi0.c();
                ii0.d();
                f5394a = new xh0(context, hj0.a(new mi0(context)));
                f5392a.incrementAndGet();
            }
        }
    }

    public static void c() {
        f5392a.incrementAndGet();
    }

    public abstract T a(Object obj);

    public final String d() {
        String str = this.f5397a.c;
        return this.f5396a;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x00ae  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00e1  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final T e() {
        /*
            r6 = this;
            boolean r0 = r6.f5398a
            if (r0 != 0) goto L_0x000b
            java.lang.String r0 = r6.f5396a
            java.lang.String r1 = "flagName must not be null"
            java.util.Objects.requireNonNull(r0, r1)
        L_0x000b:
            java.util.concurrent.atomic.AtomicInteger r0 = f5392a
            int r0 = r0.get()
            int r1 = r6.b
            if (r1 >= r0) goto L_0x010c
            monitor-enter(r6)
            int r1 = r6.b     // Catch:{ all -> 0x0109 }
            if (r1 >= r0) goto L_0x0107
            ti0 r1 = f5394a     // Catch:{ all -> 0x0109 }
            java.lang.String r2 = "Must call PhenotypeFlag.init() first"
            if (r1 == 0) goto L_0x0101
            si0 r2 = r6.f5397a     // Catch:{ all -> 0x0109 }
            boolean r2 = r2.f5063b     // Catch:{ all -> 0x0109 }
            android.content.Context r2 = r1.a()     // Catch:{ all -> 0x0109 }
            ii0 r2 = defpackage.ii0.b(r2)     // Catch:{ all -> 0x0109 }
            java.lang.String r3 = "gms:phenotype:phenotype_flag:debug_bypass_phenotype"
            java.lang.String r2 = r2.a(r3)     // Catch:{ all -> 0x0109 }
            r3 = 0
            if (r2 == 0) goto L_0x0065
            java.util.regex.Pattern r4 = defpackage.vh0.f5558a     // Catch:{ all -> 0x0109 }
            java.util.regex.Matcher r2 = r4.matcher(r2)     // Catch:{ all -> 0x0109 }
            boolean r2 = r2.matches()     // Catch:{ all -> 0x0109 }
            if (r2 == 0) goto L_0x0065
            java.lang.String r2 = "PhenotypeFlag"
            r4 = 3
            boolean r2 = android.util.Log.isLoggable(r2, r4)     // Catch:{ all -> 0x0109 }
            if (r2 == 0) goto L_0x0063
            java.lang.String r2 = "Bypass reading Phenotype values for flag: "
            java.lang.String r4 = r6.d()     // Catch:{ all -> 0x0109 }
            java.lang.String r4 = java.lang.String.valueOf(r4)     // Catch:{ all -> 0x0109 }
            int r5 = r4.length()     // Catch:{ all -> 0x0109 }
            if (r5 == 0) goto L_0x005e
            r2.concat(r4)     // Catch:{ all -> 0x0109 }
            goto L_0x0063
        L_0x005e:
            java.lang.String r4 = new java.lang.String     // Catch:{ all -> 0x0109 }
            r4.<init>(r2)     // Catch:{ all -> 0x0109 }
        L_0x0063:
            r2 = r3
            goto L_0x00ac
        L_0x0065:
            si0 r2 = r6.f5397a     // Catch:{ all -> 0x0109 }
            android.net.Uri r2 = r2.a     // Catch:{ all -> 0x0109 }
            if (r2 == 0) goto L_0x0090
            android.content.Context r2 = r1.a()     // Catch:{ all -> 0x0109 }
            si0 r4 = r6.f5397a     // Catch:{ all -> 0x0109 }
            android.net.Uri r4 = r4.a     // Catch:{ all -> 0x0109 }
            boolean r2 = defpackage.ki0.a(r2, r4)     // Catch:{ all -> 0x0109 }
            if (r2 == 0) goto L_0x008e
            si0 r2 = r6.f5397a     // Catch:{ all -> 0x0109 }
            boolean r2 = r2.d     // Catch:{ all -> 0x0109 }
            android.content.Context r2 = r1.a()     // Catch:{ all -> 0x0109 }
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ all -> 0x0109 }
            si0 r4 = r6.f5397a     // Catch:{ all -> 0x0109 }
            android.net.Uri r4 = r4.a     // Catch:{ all -> 0x0109 }
            bi0 r2 = defpackage.bi0.b(r2, r4)     // Catch:{ all -> 0x0109 }
            goto L_0x009c
        L_0x008e:
            r2 = r3
            goto L_0x009c
        L_0x0090:
            android.content.Context r2 = r1.a()     // Catch:{ all -> 0x0109 }
            si0 r4 = r6.f5397a     // Catch:{ all -> 0x0109 }
            java.lang.String r4 = r4.f5060a     // Catch:{ all -> 0x0109 }
            vi0 r2 = defpackage.vi0.b(r2, r3)     // Catch:{ all -> 0x0109 }
        L_0x009c:
            if (r2 == 0) goto L_0x0063
            java.lang.String r4 = r6.d()     // Catch:{ all -> 0x0109 }
            java.lang.Object r2 = r2.a(r4)     // Catch:{ all -> 0x0109 }
            if (r2 == 0) goto L_0x0063
            java.lang.Object r2 = r6.a(r2)     // Catch:{ all -> 0x0109 }
        L_0x00ac:
            if (r2 == 0) goto L_0x00af
            goto L_0x00d1
        L_0x00af:
            si0 r2 = r6.f5397a     // Catch:{ all -> 0x0109 }
            boolean r2 = r2.f5062a     // Catch:{ all -> 0x0109 }
            android.content.Context r2 = r1.a()     // Catch:{ all -> 0x0109 }
            ii0 r2 = defpackage.ii0.b(r2)     // Catch:{ all -> 0x0109 }
            si0 r4 = r6.f5397a     // Catch:{ all -> 0x0109 }
            boolean r4 = r4.f5062a     // Catch:{ all -> 0x0109 }
            java.lang.String r4 = r6.f5396a     // Catch:{ all -> 0x0109 }
            java.lang.String r2 = r2.a(r4)     // Catch:{ all -> 0x0109 }
            if (r2 == 0) goto L_0x00cc
            java.lang.Object r2 = r6.a(r2)     // Catch:{ all -> 0x0109 }
            goto L_0x00cd
        L_0x00cc:
            r2 = r3
        L_0x00cd:
            if (r2 != 0) goto L_0x00d1
            T r2 = r6.f5399b     // Catch:{ all -> 0x0109 }
        L_0x00d1:
            dj0 r1 = r1.b()     // Catch:{ all -> 0x0109 }
            java.lang.Object r1 = r1.a()     // Catch:{ all -> 0x0109 }
            aj0 r1 = (defpackage.aj0) r1     // Catch:{ all -> 0x0109 }
            boolean r4 = r1.a()     // Catch:{ all -> 0x0109 }
            if (r4 == 0) goto L_0x00fc
            java.lang.Object r1 = r1.b()     // Catch:{ all -> 0x0109 }
            ji0 r1 = (defpackage.ji0) r1     // Catch:{ all -> 0x0109 }
            si0 r2 = r6.f5397a     // Catch:{ all -> 0x0109 }
            android.net.Uri r4 = r2.a     // Catch:{ all -> 0x0109 }
            java.lang.String r2 = r2.c     // Catch:{ all -> 0x0109 }
            java.lang.String r5 = r6.f5396a     // Catch:{ all -> 0x0109 }
            java.lang.String r1 = r1.a(r4, r3, r2, r5)     // Catch:{ all -> 0x0109 }
            if (r1 != 0) goto L_0x00f8
            T r2 = r6.f5399b     // Catch:{ all -> 0x0109 }
            goto L_0x00fc
        L_0x00f8:
            java.lang.Object r2 = r6.a(r1)     // Catch:{ all -> 0x0109 }
        L_0x00fc:
            r6.c = r2     // Catch:{ all -> 0x0109 }
            r6.b = r0     // Catch:{ all -> 0x0109 }
            goto L_0x0107
        L_0x0101:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x0109 }
            r0.<init>(r2)     // Catch:{ all -> 0x0109 }
            throw r0     // Catch:{ all -> 0x0109 }
        L_0x0107:
            monitor-exit(r6)     // Catch:{ all -> 0x0109 }
            goto L_0x010c
        L_0x0109:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x0109 }
            throw r0
        L_0x010c:
            T r0 = r6.c
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ui0.e():java.lang.Object");
    }
}
