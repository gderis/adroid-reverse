package defpackage;

import com.google.android.gms.common.api.Status;

/* renamed from: a90  reason: default package */
public abstract class a90 extends fu0<Status> {
    public a90(mw mwVar) {
        super(mwVar);
    }

    public final /* bridge */ /* synthetic */ rw g(Status status) {
        return status;
    }
}
