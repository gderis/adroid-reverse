package defpackage;

/* renamed from: t21  reason: default package */
public final class t21 implements Runnable {
    public final /* synthetic */ Boolean a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ z21 f5140a;

    public t21(z21 z21, Boolean bool) {
        this.f5140a = z21;
        this.a = bool;
    }

    public final void run() {
        this.f5140a.L(this.a, true);
    }
}
