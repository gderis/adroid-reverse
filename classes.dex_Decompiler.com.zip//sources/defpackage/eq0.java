package defpackage;

/* renamed from: eq0  reason: default package */
public final class eq0 implements dj0<fq0> {
    public static final eq0 a = new eq0();

    /* renamed from: a  reason: collision with other field name */
    public final dj0<fq0> f2321a = hj0.a(hj0.b(new hq0()));

    public static boolean b() {
        return a.a().a();
    }

    public static boolean c() {
        return a.a().b();
    }

    public static boolean d() {
        return a.a().c();
    }

    public static boolean e() {
        return a.a().d();
    }

    /* renamed from: f */
    public final fq0 a() {
        return this.f2321a.a();
    }
}
