package defpackage;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* renamed from: r60  reason: default package */
public class r60 implements IInterface {
    public final IBinder a;

    /* renamed from: a  reason: collision with other field name */
    public final String f4728a;

    public r60(IBinder iBinder, String str) {
        this.a = iBinder;
        this.f4728a = str;
    }

    public IBinder asBinder() {
        return this.a;
    }

    public final Parcel b() {
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.f4728a);
        return obtain;
    }

    public final void c(int i, Parcel parcel) {
        Parcel obtain = Parcel.obtain();
        try {
            this.a.transact(i, parcel, obtain, 0);
            obtain.readException();
        } finally {
            parcel.recycle();
            obtain.recycle();
        }
    }

    public final void d(int i, Parcel parcel) {
        try {
            this.a.transact(1, parcel, (Parcel) null, 1);
        } finally {
            parcel.recycle();
        }
    }
}
