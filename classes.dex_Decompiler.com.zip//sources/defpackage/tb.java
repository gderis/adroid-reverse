package defpackage;

import android.os.Build;
import android.widget.EdgeEffect;

/* renamed from: tb  reason: default package */
public final class tb {
    public static void a(EdgeEffect edgeEffect, float f, float f2) {
        if (Build.VERSION.SDK_INT >= 21) {
            edgeEffect.onPull(f, f2);
        } else {
            edgeEffect.onPull(f);
        }
    }
}
