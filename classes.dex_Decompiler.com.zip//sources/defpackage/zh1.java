package defpackage;

/* renamed from: zh1  reason: default package */
public enum zh1 {
    DEVELOPER(1),
    USER_SIDELOAD(2),
    TEST_DISTRIBUTION(3),
    APP_STORE(4);
    

    /* renamed from: a  reason: collision with other field name */
    public final int f6232a;

    /* access modifiers changed from: public */
    zh1(int i) {
        this.f6232a = i;
    }

    public static zh1 a(String str) {
        return str != null ? APP_STORE : DEVELOPER;
    }

    public int b() {
        return this.f6232a;
    }

    public String toString() {
        return Integer.toString(this.f6232a);
    }
}
