package defpackage;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;

/* renamed from: r9  reason: default package */
public class r9 implements Spannable {
    public static final Object a = new Object();

    /* renamed from: a  reason: collision with other field name */
    public final PrecomputedText f4744a;

    /* renamed from: a  reason: collision with other field name */
    public final Spannable f4745a;

    /* renamed from: a  reason: collision with other field name */
    public final a f4746a;

    /* renamed from: r9$a */
    public static final class a {
        public final int a;

        /* renamed from: a  reason: collision with other field name */
        public final PrecomputedText.Params f4747a;

        /* renamed from: a  reason: collision with other field name */
        public final TextDirectionHeuristic f4748a;

        /* renamed from: a  reason: collision with other field name */
        public final TextPaint f4749a;
        public final int b;

        /* renamed from: r9$a$a  reason: collision with other inner class name */
        public static class C0049a {
            public int a;

            /* renamed from: a  reason: collision with other field name */
            public TextDirectionHeuristic f4750a;

            /* renamed from: a  reason: collision with other field name */
            public final TextPaint f4751a;
            public int b;

            public C0049a(TextPaint textPaint) {
                this.f4751a = textPaint;
                int i = Build.VERSION.SDK_INT;
                if (i >= 23) {
                    this.a = 1;
                    this.b = 1;
                } else {
                    this.b = 0;
                    this.a = 0;
                }
                this.f4750a = i >= 18 ? TextDirectionHeuristics.FIRSTSTRONG_LTR : null;
            }

            public a a() {
                return new a(this.f4751a, this.f4750a, this.a, this.b);
            }

            public C0049a b(int i) {
                this.a = i;
                return this;
            }

            public C0049a c(int i) {
                this.b = i;
                return this;
            }

            public C0049a d(TextDirectionHeuristic textDirectionHeuristic) {
                this.f4750a = textDirectionHeuristic;
                return this;
            }
        }

        public a(PrecomputedText.Params params) {
            this.f4749a = params.getTextPaint();
            this.f4748a = params.getTextDirection();
            this.a = params.getBreakStrategy();
            this.b = params.getHyphenationFrequency();
            this.f4747a = Build.VERSION.SDK_INT < 29 ? null : params;
        }

        @SuppressLint({"NewApi"})
        public a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i, int i2) {
            this.f4747a = Build.VERSION.SDK_INT >= 29 ? new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i).setHyphenationFrequency(i2).setTextDirection(textDirectionHeuristic).build() : null;
            this.f4749a = textPaint;
            this.f4748a = textDirectionHeuristic;
            this.a = i;
            this.b = i2;
        }

        public boolean a(a aVar) {
            int i = Build.VERSION.SDK_INT;
            if ((i >= 23 && (this.a != aVar.b() || this.b != aVar.c())) || this.f4749a.getTextSize() != aVar.e().getTextSize() || this.f4749a.getTextScaleX() != aVar.e().getTextScaleX() || this.f4749a.getTextSkewX() != aVar.e().getTextSkewX()) {
                return false;
            }
            if ((i >= 21 && (this.f4749a.getLetterSpacing() != aVar.e().getLetterSpacing() || !TextUtils.equals(this.f4749a.getFontFeatureSettings(), aVar.e().getFontFeatureSettings()))) || this.f4749a.getFlags() != aVar.e().getFlags()) {
                return false;
            }
            if (i >= 24) {
                if (!this.f4749a.getTextLocales().equals(aVar.e().getTextLocales())) {
                    return false;
                }
            } else if (i >= 17 && !this.f4749a.getTextLocale().equals(aVar.e().getTextLocale())) {
                return false;
            }
            return this.f4749a.getTypeface() == null ? aVar.e().getTypeface() == null : this.f4749a.getTypeface().equals(aVar.e().getTypeface());
        }

        public int b() {
            return this.a;
        }

        public int c() {
            return this.b;
        }

        public TextDirectionHeuristic d() {
            return this.f4748a;
        }

        public TextPaint e() {
            return this.f4749a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            if (!a(aVar)) {
                return false;
            }
            return Build.VERSION.SDK_INT < 18 || this.f4748a == aVar.d();
        }

        public int hashCode() {
            int i = Build.VERSION.SDK_INT;
            if (i >= 24) {
                return x9.b(Float.valueOf(this.f4749a.getTextSize()), Float.valueOf(this.f4749a.getTextScaleX()), Float.valueOf(this.f4749a.getTextSkewX()), Float.valueOf(this.f4749a.getLetterSpacing()), Integer.valueOf(this.f4749a.getFlags()), this.f4749a.getTextLocales(), this.f4749a.getTypeface(), Boolean.valueOf(this.f4749a.isElegantTextHeight()), this.f4748a, Integer.valueOf(this.a), Integer.valueOf(this.b));
            } else if (i >= 21) {
                return x9.b(Float.valueOf(this.f4749a.getTextSize()), Float.valueOf(this.f4749a.getTextScaleX()), Float.valueOf(this.f4749a.getTextSkewX()), Float.valueOf(this.f4749a.getLetterSpacing()), Integer.valueOf(this.f4749a.getFlags()), this.f4749a.getTextLocale(), this.f4749a.getTypeface(), Boolean.valueOf(this.f4749a.isElegantTextHeight()), this.f4748a, Integer.valueOf(this.a), Integer.valueOf(this.b));
            } else if (i >= 18) {
                return x9.b(Float.valueOf(this.f4749a.getTextSize()), Float.valueOf(this.f4749a.getTextScaleX()), Float.valueOf(this.f4749a.getTextSkewX()), Integer.valueOf(this.f4749a.getFlags()), this.f4749a.getTextLocale(), this.f4749a.getTypeface(), this.f4748a, Integer.valueOf(this.a), Integer.valueOf(this.b));
            } else if (i >= 17) {
                return x9.b(Float.valueOf(this.f4749a.getTextSize()), Float.valueOf(this.f4749a.getTextScaleX()), Float.valueOf(this.f4749a.getTextSkewX()), Integer.valueOf(this.f4749a.getFlags()), this.f4749a.getTextLocale(), this.f4749a.getTypeface(), this.f4748a, Integer.valueOf(this.a), Integer.valueOf(this.b));
            } else {
                return x9.b(Float.valueOf(this.f4749a.getTextSize()), Float.valueOf(this.f4749a.getTextScaleX()), Float.valueOf(this.f4749a.getTextSkewX()), Integer.valueOf(this.f4749a.getFlags()), this.f4749a.getTypeface(), this.f4748a, Integer.valueOf(this.a), Integer.valueOf(this.b));
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:12:0x00df  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.String toString() {
            /*
                r4 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "{"
                r0.<init>(r1)
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "textSize="
                r1.append(r2)
                android.text.TextPaint r2 = r4.f4749a
                float r2 = r2.getTextSize()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = ", textScaleX="
                r1.append(r2)
                android.text.TextPaint r2 = r4.f4749a
                float r2 = r2.getTextScaleX()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = ", textSkewX="
                r1.append(r2)
                android.text.TextPaint r2 = r4.f4749a
                float r2 = r2.getTextSkewX()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
                int r1 = android.os.Build.VERSION.SDK_INT
                r2 = 21
                if (r1 < r2) goto L_0x008f
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = ", letterSpacing="
                r2.append(r3)
                android.text.TextPaint r3 = r4.f4749a
                float r3 = r3.getLetterSpacing()
                r2.append(r3)
                java.lang.String r2 = r2.toString()
                r0.append(r2)
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = ", elegantTextHeight="
                r2.append(r3)
                android.text.TextPaint r3 = r4.f4749a
                boolean r3 = r3.isElegantTextHeight()
                r2.append(r3)
                java.lang.String r2 = r2.toString()
                r0.append(r2)
            L_0x008f:
                r2 = 24
                java.lang.String r3 = ", textLocale="
                if (r1 < r2) goto L_0x00ae
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                r2.append(r3)
                android.text.TextPaint r3 = r4.f4749a
                android.os.LocaleList r3 = r3.getTextLocales()
            L_0x00a3:
                r2.append(r3)
                java.lang.String r2 = r2.toString()
                r0.append(r2)
                goto L_0x00c1
            L_0x00ae:
                r2 = 17
                if (r1 < r2) goto L_0x00c1
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                r2.append(r3)
                android.text.TextPaint r3 = r4.f4749a
                java.util.Locale r3 = r3.getTextLocale()
                goto L_0x00a3
            L_0x00c1:
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = ", typeface="
                r2.append(r3)
                android.text.TextPaint r3 = r4.f4749a
                android.graphics.Typeface r3 = r3.getTypeface()
                r2.append(r3)
                java.lang.String r2 = r2.toString()
                r0.append(r2)
                r2 = 26
                if (r1 < r2) goto L_0x00f9
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = ", variationSettings="
                r1.append(r2)
                android.text.TextPaint r2 = r4.f4749a
                java.lang.String r2 = r2.getFontVariationSettings()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
            L_0x00f9:
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = ", textDir="
                r1.append(r2)
                android.text.TextDirectionHeuristic r2 = r4.f4748a
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = ", breakStrategy="
                r1.append(r2)
                int r2 = r4.a
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = ", hyphenationFrequency="
                r1.append(r2)
                int r2 = r4.b
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.append(r1)
                java.lang.String r1 = "}"
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: defpackage.r9.a.toString():java.lang.String");
        }
    }

    public a a() {
        return this.f4746a;
    }

    public PrecomputedText b() {
        Spannable spannable = this.f4745a;
        if (spannable instanceof PrecomputedText) {
            return (PrecomputedText) spannable;
        }
        return null;
    }

    public char charAt(int i) {
        return this.f4745a.charAt(i);
    }

    public int getSpanEnd(Object obj) {
        return this.f4745a.getSpanEnd(obj);
    }

    public int getSpanFlags(Object obj) {
        return this.f4745a.getSpanFlags(obj);
    }

    public int getSpanStart(Object obj) {
        return this.f4745a.getSpanStart(obj);
    }

    @SuppressLint({"NewApi"})
    public <T> T[] getSpans(int i, int i2, Class<T> cls) {
        return Build.VERSION.SDK_INT >= 29 ? this.f4744a.getSpans(i, i2, cls) : this.f4745a.getSpans(i, i2, cls);
    }

    public int length() {
        return this.f4745a.length();
    }

    public int nextSpanTransition(int i, int i2, Class cls) {
        return this.f4745a.nextSpanTransition(i, i2, cls);
    }

    @SuppressLint({"NewApi"})
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        } else if (Build.VERSION.SDK_INT >= 29) {
            this.f4744a.removeSpan(obj);
        } else {
            this.f4745a.removeSpan(obj);
        }
    }

    @SuppressLint({"NewApi"})
    public void setSpan(Object obj, int i, int i2, int i3) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        } else if (Build.VERSION.SDK_INT >= 29) {
            this.f4744a.setSpan(obj, i, i2, i3);
        } else {
            this.f4745a.setSpan(obj, i, i2, i3);
        }
    }

    public CharSequence subSequence(int i, int i2) {
        return this.f4745a.subSequence(i, i2);
    }

    public String toString() {
        return this.f4745a.toString();
    }
}
