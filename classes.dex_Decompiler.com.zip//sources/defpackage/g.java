package defpackage;

import android.annotation.SuppressLint;

/* renamed from: g  reason: default package */
public interface g<O> {
    void a(@SuppressLint({"UnknownNullness"}) O o);
}
