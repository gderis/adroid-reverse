package defpackage;

import android.content.Context;
import android.os.Looper;
import defpackage.hw;
import defpackage.mw;

/* renamed from: x71  reason: default package */
public final class x71 extends hw.a<j71, i71> {
    public final /* synthetic */ hw.f c(Context context, Looper looper, g10 g10, Object obj, mw.b bVar, mw.c cVar) {
        i71 i71 = (i71) obj;
        if (i71 == null) {
            i71 = i71.a;
        }
        return new j71(context, looper, true, g10, i71, bVar, cVar);
    }
}
