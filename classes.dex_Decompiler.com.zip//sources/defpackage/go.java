package defpackage;

import defpackage.ln;
import defpackage.xn;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

/* renamed from: go  reason: default package */
public class go implements xn.b {
    public final ao a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<String, List<xn<?>>> f2664a = new HashMap();

    /* renamed from: a  reason: collision with other field name */
    public final BlockingQueue<xn<?>> f2665a;

    /* renamed from: a  reason: collision with other field name */
    public final mn f2666a;

    /* renamed from: a  reason: collision with other field name */
    public final yn f2667a = null;

    public go(mn mnVar, BlockingQueue<xn<?>> blockingQueue, ao aoVar) {
        this.a = aoVar;
        this.f2666a = mnVar;
        this.f2665a = blockingQueue;
    }

    public void a(xn<?> xnVar, zn<?> znVar) {
        List<xn> remove;
        ln.a aVar = znVar.f6253a;
        if (aVar == null || aVar.a()) {
            b(xnVar);
            return;
        }
        String n = xnVar.n();
        synchronized (this) {
            remove = this.f2664a.remove(n);
        }
        if (remove != null) {
            if (fo.f2496a) {
                fo.e("Releasing %d waiting requests for cacheKey=%s.", Integer.valueOf(remove.size()), n);
            }
            for (xn b : remove) {
                this.a.b(b, znVar);
            }
        }
    }

    public synchronized void b(xn<?> xnVar) {
        BlockingQueue<xn<?>> blockingQueue;
        String n = xnVar.n();
        List remove = this.f2664a.remove(n);
        if (remove != null && !remove.isEmpty()) {
            if (fo.f2496a) {
                fo.e("%d waiting requests for cacheKey=%s; resend to network", Integer.valueOf(remove.size()), n);
            }
            xn xnVar2 = (xn) remove.remove(0);
            this.f2664a.put(n, remove);
            xnVar2.K(this);
            yn ynVar = this.f2667a;
            if (ynVar != null) {
                ynVar.f(xnVar2);
            } else if (!(this.f2666a == null || (blockingQueue = this.f2665a) == null)) {
                try {
                    blockingQueue.put(xnVar2);
                } catch (InterruptedException e) {
                    fo.c("Couldn't add request to queue. %s", e.toString());
                    Thread.currentThread().interrupt();
                    this.f2666a.d();
                }
            }
        }
        return;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0039, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0051, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized boolean c(defpackage.xn<?> r6) {
        /*
            r5 = this;
            monitor-enter(r5)
            java.lang.String r0 = r6.n()     // Catch:{ all -> 0x0052 }
            java.util.Map<java.lang.String, java.util.List<xn<?>>> r1 = r5.f2664a     // Catch:{ all -> 0x0052 }
            boolean r1 = r1.containsKey(r0)     // Catch:{ all -> 0x0052 }
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L_0x003a
            java.util.Map<java.lang.String, java.util.List<xn<?>>> r1 = r5.f2664a     // Catch:{ all -> 0x0052 }
            java.lang.Object r1 = r1.get(r0)     // Catch:{ all -> 0x0052 }
            java.util.List r1 = (java.util.List) r1     // Catch:{ all -> 0x0052 }
            if (r1 != 0) goto L_0x001e
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ all -> 0x0052 }
            r1.<init>()     // Catch:{ all -> 0x0052 }
        L_0x001e:
            java.lang.String r4 = "waiting-for-response"
            r6.b(r4)     // Catch:{ all -> 0x0052 }
            r1.add(r6)     // Catch:{ all -> 0x0052 }
            java.util.Map<java.lang.String, java.util.List<xn<?>>> r6 = r5.f2664a     // Catch:{ all -> 0x0052 }
            r6.put(r0, r1)     // Catch:{ all -> 0x0052 }
            boolean r6 = defpackage.fo.f2496a     // Catch:{ all -> 0x0052 }
            if (r6 == 0) goto L_0x0038
            java.lang.String r6 = "Request for cacheKey=%s is in flight, putting on hold."
            java.lang.Object[] r1 = new java.lang.Object[r2]     // Catch:{ all -> 0x0052 }
            r1[r3] = r0     // Catch:{ all -> 0x0052 }
            defpackage.fo.b(r6, r1)     // Catch:{ all -> 0x0052 }
        L_0x0038:
            monitor-exit(r5)
            return r2
        L_0x003a:
            java.util.Map<java.lang.String, java.util.List<xn<?>>> r1 = r5.f2664a     // Catch:{ all -> 0x0052 }
            r4 = 0
            r1.put(r0, r4)     // Catch:{ all -> 0x0052 }
            r6.K(r5)     // Catch:{ all -> 0x0052 }
            boolean r6 = defpackage.fo.f2496a     // Catch:{ all -> 0x0052 }
            if (r6 == 0) goto L_0x0050
            java.lang.String r6 = "new request, sending to network %s"
            java.lang.Object[] r1 = new java.lang.Object[r2]     // Catch:{ all -> 0x0052 }
            r1[r3] = r0     // Catch:{ all -> 0x0052 }
            defpackage.fo.b(r6, r1)     // Catch:{ all -> 0x0052 }
        L_0x0050:
            monitor-exit(r5)
            return r3
        L_0x0052:
            r6 = move-exception
            monitor-exit(r5)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.go.c(xn):boolean");
    }
}
