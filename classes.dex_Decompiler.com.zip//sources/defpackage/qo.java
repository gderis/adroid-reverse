package defpackage;

import java.io.DataOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

/* renamed from: qo  reason: default package */
public class qo extends io {
    public final SSLSocketFactory a;

    /* renamed from: a  reason: collision with other field name */
    public final b f4663a;

    /* renamed from: qo$a */
    public static class a extends FilterInputStream {
        public final HttpURLConnection a;

        public a(HttpURLConnection httpURLConnection) {
            super(qo.k(httpURLConnection));
            this.a = httpURLConnection;
        }

        public void close() {
            super.close();
            this.a.disconnect();
        }
    }

    /* renamed from: qo$b */
    public interface b extends vo {
    }

    public qo() {
        this((b) null);
    }

    public qo(b bVar) {
        this(bVar, (SSLSocketFactory) null);
    }

    public qo(b bVar, SSLSocketFactory sSLSocketFactory) {
        this.f4663a = bVar;
        this.a = sSLSocketFactory;
    }

    public static List<qn> f(Map<String, List<String>> map) {
        ArrayList arrayList = new ArrayList(map.size());
        for (Map.Entry next : map.entrySet()) {
            if (next.getKey() != null) {
                for (String qnVar : (List) next.getValue()) {
                    arrayList.add(new qn((String) next.getKey(), qnVar));
                }
            }
        }
        return arrayList;
    }

    public static boolean j(int i, int i2) {
        return (i == 4 || (100 <= i2 && i2 < 200) || i2 == 204 || i2 == 304) ? false : true;
    }

    public static InputStream k(HttpURLConnection httpURLConnection) {
        try {
            return httpURLConnection.getInputStream();
        } catch (IOException unused) {
            return httpURLConnection.getErrorStream();
        }
    }

    public oo b(xn<?> xnVar, Map<String, String> map) {
        String A = xnVar.A();
        HashMap hashMap = new HashMap();
        hashMap.putAll(map);
        hashMap.putAll(xnVar.o());
        b bVar = this.f4663a;
        if (bVar != null) {
            String a2 = bVar.a(A);
            if (a2 != null) {
                A = a2;
            } else {
                throw new IOException("URL blocked by rewriter: " + A);
            }
        }
        HttpURLConnection l = l(new URL(A), xnVar);
        boolean z = false;
        try {
            for (String str : hashMap.keySet()) {
                l.setRequestProperty(str, (String) hashMap.get(str));
            }
            m(l, xnVar);
            int responseCode = l.getResponseCode();
            if (responseCode == -1) {
                throw new IOException("Could not retrieve response code from HttpUrlConnection.");
            } else if (!j(xnVar.p(), responseCode)) {
                oo ooVar = new oo(responseCode, f(l.getHeaderFields()));
                l.disconnect();
                return ooVar;
            } else {
                z = true;
                return new oo(responseCode, f(l.getHeaderFields()), l.getContentLength(), h(xnVar, l));
            }
        } catch (Throwable th) {
            if (!z) {
                l.disconnect();
            }
            throw th;
        }
    }

    public final void d(HttpURLConnection httpURLConnection, xn<?> xnVar, byte[] bArr) {
        httpURLConnection.setDoOutput(true);
        if (!httpURLConnection.getRequestProperties().containsKey("Content-Type")) {
            httpURLConnection.setRequestProperty("Content-Type", xnVar.l());
        }
        DataOutputStream dataOutputStream = new DataOutputStream(i(xnVar, httpURLConnection, bArr.length));
        dataOutputStream.write(bArr);
        dataOutputStream.close();
    }

    public final void e(HttpURLConnection httpURLConnection, xn<?> xnVar) {
        byte[] k = xnVar.k();
        if (k != null) {
            d(httpURLConnection, xnVar, k);
        }
    }

    public HttpURLConnection g(URL url) {
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setInstanceFollowRedirects(HttpURLConnection.getFollowRedirects());
        return httpURLConnection;
    }

    public InputStream h(xn<?> xnVar, HttpURLConnection httpURLConnection) {
        return new a(httpURLConnection);
    }

    public OutputStream i(xn<?> xnVar, HttpURLConnection httpURLConnection, int i) {
        return httpURLConnection.getOutputStream();
    }

    public final HttpURLConnection l(URL url, xn<?> xnVar) {
        SSLSocketFactory sSLSocketFactory;
        HttpURLConnection g = g(url);
        int y = xnVar.y();
        g.setConnectTimeout(y);
        g.setReadTimeout(y);
        g.setUseCaches(false);
        g.setDoInput(true);
        if ("https".equals(url.getProtocol()) && (sSLSocketFactory = this.a) != null) {
            ((HttpsURLConnection) g).setSSLSocketFactory(sSLSocketFactory);
        }
        return g;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0022, code lost:
        r3.setRequestMethod(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0029, code lost:
        e(r3, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002f, code lost:
        r3.setRequestMethod(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m(java.net.HttpURLConnection r3, defpackage.xn<?> r4) {
        /*
            r2 = this;
            int r0 = r4.p()
            java.lang.String r1 = "POST"
            switch(r0) {
                case -1: goto L_0x0033;
                case 0: goto L_0x002d;
                case 1: goto L_0x0026;
                case 2: goto L_0x0020;
                case 3: goto L_0x001d;
                case 4: goto L_0x001a;
                case 5: goto L_0x0017;
                case 6: goto L_0x0014;
                case 7: goto L_0x0011;
                default: goto L_0x0009;
            }
        L_0x0009:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            java.lang.String r4 = "Unknown method type."
            r3.<init>(r4)
            throw r3
        L_0x0011:
            java.lang.String r0 = "PATCH"
            goto L_0x0022
        L_0x0014:
            java.lang.String r4 = "TRACE"
            goto L_0x002f
        L_0x0017:
            java.lang.String r4 = "OPTIONS"
            goto L_0x002f
        L_0x001a:
            java.lang.String r4 = "HEAD"
            goto L_0x002f
        L_0x001d:
            java.lang.String r4 = "DELETE"
            goto L_0x002f
        L_0x0020:
            java.lang.String r0 = "PUT"
        L_0x0022:
            r3.setRequestMethod(r0)
            goto L_0x0029
        L_0x0026:
            r3.setRequestMethod(r1)
        L_0x0029:
            r2.e(r3, r4)
            goto L_0x003f
        L_0x002d:
            java.lang.String r4 = "GET"
        L_0x002f:
            r3.setRequestMethod(r4)
            goto L_0x003f
        L_0x0033:
            byte[] r0 = r4.s()
            if (r0 == 0) goto L_0x003f
            r3.setRequestMethod(r1)
            r2.d(r3, r4, r0)
        L_0x003f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.qo.m(java.net.HttpURLConnection, xn):void");
    }
}
