package defpackage;

import defpackage.lj1;

/* renamed from: qi1  reason: default package */
public final class qi1 implements ql1 {
    public static final ql1 a = new qi1();

    /* renamed from: qi1$a */
    public static final class a implements ml1<lj1.b> {
        public static final ll1 a = ll1.d("key");

        /* renamed from: a  reason: collision with other field name */
        public static final a f4633a = new a();
        public static final ll1 b = ll1.d("value");

        /* renamed from: b */
        public void a(lj1.b bVar, nl1 nl1) {
            nl1.d(a, bVar.b());
            nl1.d(b, bVar.c());
        }
    }

    /* renamed from: qi1$b */
    public static final class b implements ml1<lj1> {
        public static final ll1 a = ll1.d("sdkVersion");

        /* renamed from: a  reason: collision with other field name */
        public static final b f4634a = new b();
        public static final ll1 b = ll1.d("gmpAppId");
        public static final ll1 c = ll1.d("platform");
        public static final ll1 d = ll1.d("installationUuid");
        public static final ll1 e = ll1.d("buildVersion");
        public static final ll1 f = ll1.d("displayVersion");
        public static final ll1 g = ll1.d("session");
        public static final ll1 h = ll1.d("ndkPayload");

        /* renamed from: b */
        public void a(lj1 lj1, nl1 nl1) {
            nl1.d(a, lj1.i());
            nl1.d(b, lj1.e());
            nl1.a(c, lj1.h());
            nl1.d(d, lj1.f());
            nl1.d(e, lj1.c());
            nl1.d(f, lj1.d());
            nl1.d(g, lj1.j());
            nl1.d(h, lj1.g());
        }
    }

    /* renamed from: qi1$c */
    public static final class c implements ml1<lj1.c> {
        public static final ll1 a = ll1.d("files");

        /* renamed from: a  reason: collision with other field name */
        public static final c f4635a = new c();
        public static final ll1 b = ll1.d("orgId");

        /* renamed from: b */
        public void a(lj1.c cVar, nl1 nl1) {
            nl1.d(a, cVar.b());
            nl1.d(b, cVar.c());
        }
    }

    /* renamed from: qi1$d */
    public static final class d implements ml1<lj1.c.b> {
        public static final ll1 a = ll1.d("filename");

        /* renamed from: a  reason: collision with other field name */
        public static final d f4636a = new d();
        public static final ll1 b = ll1.d("contents");

        /* renamed from: b */
        public void a(lj1.c.b bVar, nl1 nl1) {
            nl1.d(a, bVar.c());
            nl1.d(b, bVar.b());
        }
    }

    /* renamed from: qi1$e */
    public static final class e implements ml1<lj1.d.a> {
        public static final ll1 a = ll1.d("identifier");

        /* renamed from: a  reason: collision with other field name */
        public static final e f4637a = new e();
        public static final ll1 b = ll1.d("version");
        public static final ll1 c = ll1.d("displayVersion");
        public static final ll1 d = ll1.d("organization");
        public static final ll1 e = ll1.d("installationUuid");
        public static final ll1 f = ll1.d("developmentPlatform");
        public static final ll1 g = ll1.d("developmentPlatformVersion");

        /* renamed from: b */
        public void a(lj1.d.a aVar, nl1 nl1) {
            nl1.d(a, aVar.e());
            nl1.d(b, aVar.h());
            nl1.d(c, aVar.d());
            nl1.d(d, aVar.g());
            nl1.d(e, aVar.f());
            nl1.d(f, aVar.b());
            nl1.d(g, aVar.c());
        }
    }

    /* renamed from: qi1$f */
    public static final class f implements ml1<lj1.d.a.b> {
        public static final ll1 a = ll1.d("clsId");

        /* renamed from: a  reason: collision with other field name */
        public static final f f4638a = new f();

        /* renamed from: b */
        public void a(lj1.d.a.b bVar, nl1 nl1) {
            nl1.d(a, bVar.a());
        }
    }

    /* renamed from: qi1$g */
    public static final class g implements ml1<lj1.d.c> {
        public static final ll1 a = ll1.d("arch");

        /* renamed from: a  reason: collision with other field name */
        public static final g f4639a = new g();
        public static final ll1 b = ll1.d("model");
        public static final ll1 c = ll1.d("cores");
        public static final ll1 d = ll1.d("ram");
        public static final ll1 e = ll1.d("diskSpace");
        public static final ll1 f = ll1.d("simulator");
        public static final ll1 g = ll1.d("state");
        public static final ll1 h = ll1.d("manufacturer");
        public static final ll1 i = ll1.d("modelClass");

        /* renamed from: b */
        public void a(lj1.d.c cVar, nl1 nl1) {
            nl1.a(a, cVar.b());
            nl1.d(b, cVar.f());
            nl1.a(c, cVar.c());
            nl1.c(d, cVar.h());
            nl1.c(e, cVar.d());
            nl1.b(f, cVar.j());
            nl1.a(g, cVar.i());
            nl1.d(h, cVar.e());
            nl1.d(i, cVar.g());
        }
    }

    /* renamed from: qi1$h */
    public static final class h implements ml1<lj1.d> {
        public static final ll1 a = ll1.d("generator");

        /* renamed from: a  reason: collision with other field name */
        public static final h f4640a = new h();
        public static final ll1 b = ll1.d("identifier");
        public static final ll1 c = ll1.d("startedAt");
        public static final ll1 d = ll1.d("endedAt");
        public static final ll1 e = ll1.d("crashed");
        public static final ll1 f = ll1.d("app");
        public static final ll1 g = ll1.d("user");
        public static final ll1 h = ll1.d("os");
        public static final ll1 i = ll1.d("device");
        public static final ll1 j = ll1.d("events");
        public static final ll1 k = ll1.d("generatorType");

        /* renamed from: b */
        public void a(lj1.d dVar, nl1 nl1) {
            nl1.d(a, dVar.f());
            nl1.d(b, dVar.i());
            nl1.c(c, dVar.k());
            nl1.d(d, dVar.d());
            nl1.b(e, dVar.m());
            nl1.d(f, dVar.b());
            nl1.d(g, dVar.l());
            nl1.d(h, dVar.j());
            nl1.d(i, dVar.c());
            nl1.d(j, dVar.e());
            nl1.a(k, dVar.g());
        }
    }

    /* renamed from: qi1$i */
    public static final class i implements ml1<lj1.d.C0035d.a> {
        public static final ll1 a = ll1.d("execution");

        /* renamed from: a  reason: collision with other field name */
        public static final i f4641a = new i();
        public static final ll1 b = ll1.d("customAttributes");
        public static final ll1 c = ll1.d("background");
        public static final ll1 d = ll1.d("uiOrientation");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a aVar, nl1 nl1) {
            nl1.d(a, aVar.d());
            nl1.d(b, aVar.c());
            nl1.d(c, aVar.b());
            nl1.a(d, aVar.e());
        }
    }

    /* renamed from: qi1$j */
    public static final class j implements ml1<lj1.d.C0035d.a.b.C0037a> {
        public static final ll1 a = ll1.d("baseAddress");

        /* renamed from: a  reason: collision with other field name */
        public static final j f4642a = new j();
        public static final ll1 b = ll1.d("size");
        public static final ll1 c = ll1.d("name");
        public static final ll1 d = ll1.d("uuid");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a.b.C0037a aVar, nl1 nl1) {
            nl1.c(a, aVar.b());
            nl1.c(b, aVar.d());
            nl1.d(c, aVar.c());
            nl1.d(d, aVar.f());
        }
    }

    /* renamed from: qi1$k */
    public static final class k implements ml1<lj1.d.C0035d.a.b> {
        public static final ll1 a = ll1.d("threads");

        /* renamed from: a  reason: collision with other field name */
        public static final k f4643a = new k();
        public static final ll1 b = ll1.d("exception");
        public static final ll1 c = ll1.d("signal");
        public static final ll1 d = ll1.d("binaries");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a.b bVar, nl1 nl1) {
            nl1.d(a, bVar.e());
            nl1.d(b, bVar.c());
            nl1.d(c, bVar.d());
            nl1.d(d, bVar.b());
        }
    }

    /* renamed from: qi1$l */
    public static final class l implements ml1<lj1.d.C0035d.a.b.c> {
        public static final ll1 a = ll1.d("type");

        /* renamed from: a  reason: collision with other field name */
        public static final l f4644a = new l();
        public static final ll1 b = ll1.d("reason");
        public static final ll1 c = ll1.d("frames");
        public static final ll1 d = ll1.d("causedBy");
        public static final ll1 e = ll1.d("overflowCount");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a.b.c cVar, nl1 nl1) {
            nl1.d(a, cVar.f());
            nl1.d(b, cVar.e());
            nl1.d(c, cVar.c());
            nl1.d(d, cVar.b());
            nl1.a(e, cVar.d());
        }
    }

    /* renamed from: qi1$m */
    public static final class m implements ml1<lj1.d.C0035d.a.b.C0041d> {
        public static final ll1 a = ll1.d("name");

        /* renamed from: a  reason: collision with other field name */
        public static final m f4645a = new m();
        public static final ll1 b = ll1.d("code");
        public static final ll1 c = ll1.d("address");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a.b.C0041d dVar, nl1 nl1) {
            nl1.d(a, dVar.d());
            nl1.d(b, dVar.c());
            nl1.c(c, dVar.b());
        }
    }

    /* renamed from: qi1$n */
    public static final class n implements ml1<lj1.d.C0035d.a.b.e> {
        public static final ll1 a = ll1.d("name");

        /* renamed from: a  reason: collision with other field name */
        public static final n f4646a = new n();
        public static final ll1 b = ll1.d("importance");
        public static final ll1 c = ll1.d("frames");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a.b.e eVar, nl1 nl1) {
            nl1.d(a, eVar.d());
            nl1.a(b, eVar.c());
            nl1.d(c, eVar.b());
        }
    }

    /* renamed from: qi1$o */
    public static final class o implements ml1<lj1.d.C0035d.a.b.e.C0044b> {
        public static final ll1 a = ll1.d("pc");

        /* renamed from: a  reason: collision with other field name */
        public static final o f4647a = new o();
        public static final ll1 b = ll1.d("symbol");
        public static final ll1 c = ll1.d("file");
        public static final ll1 d = ll1.d("offset");
        public static final ll1 e = ll1.d("importance");

        /* renamed from: b */
        public void a(lj1.d.C0035d.a.b.e.C0044b bVar, nl1 nl1) {
            nl1.c(a, bVar.e());
            nl1.d(b, bVar.f());
            nl1.d(c, bVar.b());
            nl1.c(d, bVar.d());
            nl1.a(e, bVar.c());
        }
    }

    /* renamed from: qi1$p */
    public static final class p implements ml1<lj1.d.C0035d.c> {
        public static final ll1 a = ll1.d("batteryLevel");

        /* renamed from: a  reason: collision with other field name */
        public static final p f4648a = new p();
        public static final ll1 b = ll1.d("batteryVelocity");
        public static final ll1 c = ll1.d("proximityOn");
        public static final ll1 d = ll1.d("orientation");
        public static final ll1 e = ll1.d("ramUsed");
        public static final ll1 f = ll1.d("diskUsed");

        /* renamed from: b */
        public void a(lj1.d.C0035d.c cVar, nl1 nl1) {
            nl1.d(a, cVar.b());
            nl1.a(b, cVar.c());
            nl1.b(c, cVar.g());
            nl1.a(d, cVar.e());
            nl1.c(e, cVar.f());
            nl1.c(f, cVar.d());
        }
    }

    /* renamed from: qi1$q */
    public static final class q implements ml1<lj1.d.C0035d> {
        public static final ll1 a = ll1.d("timestamp");

        /* renamed from: a  reason: collision with other field name */
        public static final q f4649a = new q();
        public static final ll1 b = ll1.d("type");
        public static final ll1 c = ll1.d("app");
        public static final ll1 d = ll1.d("device");
        public static final ll1 e = ll1.d("log");

        /* renamed from: b */
        public void a(lj1.d.C0035d dVar, nl1 nl1) {
            nl1.c(a, dVar.e());
            nl1.d(b, dVar.f());
            nl1.d(c, dVar.b());
            nl1.d(d, dVar.c());
            nl1.d(e, dVar.d());
        }
    }

    /* renamed from: qi1$r */
    public static final class r implements ml1<lj1.d.C0035d.C0046d> {
        public static final ll1 a = ll1.d("content");

        /* renamed from: a  reason: collision with other field name */
        public static final r f4650a = new r();

        /* renamed from: b */
        public void a(lj1.d.C0035d.C0046d dVar, nl1 nl1) {
            nl1.d(a, dVar.b());
        }
    }

    /* renamed from: qi1$s */
    public static final class s implements ml1<lj1.d.e> {
        public static final ll1 a = ll1.d("platform");

        /* renamed from: a  reason: collision with other field name */
        public static final s f4651a = new s();
        public static final ll1 b = ll1.d("version");
        public static final ll1 c = ll1.d("buildVersion");
        public static final ll1 d = ll1.d("jailbroken");

        /* renamed from: b */
        public void a(lj1.d.e eVar, nl1 nl1) {
            nl1.a(a, eVar.c());
            nl1.d(b, eVar.d());
            nl1.d(c, eVar.b());
            nl1.b(d, eVar.e());
        }
    }

    /* renamed from: qi1$t */
    public static final class t implements ml1<lj1.d.f> {
        public static final ll1 a = ll1.d("identifier");

        /* renamed from: a  reason: collision with other field name */
        public static final t f4652a = new t();

        /* renamed from: b */
        public void a(lj1.d.f fVar, nl1 nl1) {
            nl1.d(a, fVar.b());
        }
    }

    public void a(rl1<?> rl1) {
        b bVar = b.f4634a;
        rl1.a(lj1.class, bVar);
        rl1.a(ri1.class, bVar);
        h hVar = h.f4640a;
        rl1.a(lj1.d.class, hVar);
        rl1.a(vi1.class, hVar);
        e eVar = e.f4637a;
        rl1.a(lj1.d.a.class, eVar);
        rl1.a(wi1.class, eVar);
        f fVar = f.f4638a;
        rl1.a(lj1.d.a.b.class, fVar);
        rl1.a(xi1.class, fVar);
        t tVar = t.f4652a;
        rl1.a(lj1.d.f.class, tVar);
        rl1.a(kj1.class, tVar);
        s sVar = s.f4651a;
        rl1.a(lj1.d.e.class, sVar);
        rl1.a(jj1.class, sVar);
        g gVar = g.f4639a;
        rl1.a(lj1.d.c.class, gVar);
        rl1.a(yi1.class, gVar);
        q qVar = q.f4649a;
        rl1.a(lj1.d.C0035d.class, qVar);
        rl1.a(zi1.class, qVar);
        i iVar = i.f4641a;
        rl1.a(lj1.d.C0035d.a.class, iVar);
        rl1.a(aj1.class, iVar);
        k kVar = k.f4643a;
        rl1.a(lj1.d.C0035d.a.b.class, kVar);
        rl1.a(bj1.class, kVar);
        n nVar = n.f4646a;
        rl1.a(lj1.d.C0035d.a.b.e.class, nVar);
        rl1.a(fj1.class, nVar);
        o oVar = o.f4647a;
        rl1.a(lj1.d.C0035d.a.b.e.C0044b.class, oVar);
        rl1.a(gj1.class, oVar);
        l lVar = l.f4644a;
        rl1.a(lj1.d.C0035d.a.b.c.class, lVar);
        rl1.a(dj1.class, lVar);
        m mVar = m.f4645a;
        rl1.a(lj1.d.C0035d.a.b.C0041d.class, mVar);
        rl1.a(ej1.class, mVar);
        j jVar = j.f4642a;
        rl1.a(lj1.d.C0035d.a.b.C0037a.class, jVar);
        rl1.a(cj1.class, jVar);
        a aVar = a.f4633a;
        rl1.a(lj1.b.class, aVar);
        rl1.a(si1.class, aVar);
        p pVar = p.f4648a;
        rl1.a(lj1.d.C0035d.c.class, pVar);
        rl1.a(hj1.class, pVar);
        r rVar = r.f4650a;
        rl1.a(lj1.d.C0035d.C0046d.class, rVar);
        rl1.a(ij1.class, rVar);
        c cVar = c.f4635a;
        rl1.a(lj1.c.class, cVar);
        rl1.a(ti1.class, cVar);
        d dVar = d.f4636a;
        rl1.a(lj1.c.b.class, dVar);
        rl1.a(ui1.class, dVar);
    }
}
