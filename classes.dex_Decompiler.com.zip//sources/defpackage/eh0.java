package defpackage;

/* renamed from: eh0  reason: default package */
public final class eh0 extends cl0<fh0, eh0> implements mm0 {
    public eh0() {
        super(fh0.zzg);
    }

    public /* synthetic */ eh0(eg0 eg0) {
        super(fh0.zzg);
    }

    public final eh0 r(int i) {
        if (this.f1285b) {
            n();
            this.f1285b = false;
        }
        fh0.H((fh0) this.b, i);
        return this;
    }

    public final eh0 s(Iterable<? extends Long> iterable) {
        if (this.f1285b) {
            n();
            this.f1285b = false;
        }
        fh0.I((fh0) this.b, iterable);
        return this;
    }
}
