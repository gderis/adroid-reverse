package defpackage;

import defpackage.dn1;
import defpackage.en1;
import java.util.Objects;

/* renamed from: bn1  reason: default package */
public final class bn1 extends en1 {
    public final long a;

    /* renamed from: a  reason: collision with other field name */
    public final dn1.a f1115a;

    /* renamed from: a  reason: collision with other field name */
    public final String f1116a;
    public final long b;

    /* renamed from: b  reason: collision with other field name */
    public final String f1117b;
    public final String c;
    public final String d;

    /* renamed from: bn1$b */
    public static final class b extends en1.a {
        public dn1.a a;

        /* renamed from: a  reason: collision with other field name */
        public Long f1118a;

        /* renamed from: a  reason: collision with other field name */
        public String f1119a;
        public Long b;

        /* renamed from: b  reason: collision with other field name */
        public String f1120b;
        public String c;
        public String d;

        public b() {
        }

        public b(en1 en1) {
            this.f1119a = en1.d();
            this.a = en1.g();
            this.f1120b = en1.b();
            this.c = en1.f();
            this.f1118a = Long.valueOf(en1.c());
            this.b = Long.valueOf(en1.h());
            this.d = en1.e();
        }

        public en1 a() {
            String str = "";
            if (this.a == null) {
                str = str + " registrationStatus";
            }
            if (this.f1118a == null) {
                str = str + " expiresInSecs";
            }
            if (this.b == null) {
                str = str + " tokenCreationEpochInSecs";
            }
            if (str.isEmpty()) {
                return new bn1(this.f1119a, this.a, this.f1120b, this.c, this.f1118a.longValue(), this.b.longValue(), this.d);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        public en1.a b(String str) {
            this.f1120b = str;
            return this;
        }

        public en1.a c(long j) {
            this.f1118a = Long.valueOf(j);
            return this;
        }

        public en1.a d(String str) {
            this.f1119a = str;
            return this;
        }

        public en1.a e(String str) {
            this.d = str;
            return this;
        }

        public en1.a f(String str) {
            this.c = str;
            return this;
        }

        public en1.a g(dn1.a aVar) {
            Objects.requireNonNull(aVar, "Null registrationStatus");
            this.a = aVar;
            return this;
        }

        public en1.a h(long j) {
            this.b = Long.valueOf(j);
            return this;
        }
    }

    public bn1(String str, dn1.a aVar, String str2, String str3, long j, long j2, String str4) {
        this.f1116a = str;
        this.f1115a = aVar;
        this.f1117b = str2;
        this.c = str3;
        this.a = j;
        this.b = j2;
        this.d = str4;
    }

    public String b() {
        return this.f1117b;
    }

    public long c() {
        return this.a;
    }

    public String d() {
        return this.f1116a;
    }

    public String e() {
        return this.d;
    }

    public boolean equals(Object obj) {
        String str;
        String str2;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof en1)) {
            return false;
        }
        en1 en1 = (en1) obj;
        String str3 = this.f1116a;
        if (str3 != null ? str3.equals(en1.d()) : en1.d() == null) {
            if (this.f1115a.equals(en1.g()) && ((str = this.f1117b) != null ? str.equals(en1.b()) : en1.b() == null) && ((str2 = this.c) != null ? str2.equals(en1.f()) : en1.f() == null) && this.a == en1.c() && this.b == en1.h()) {
                String str4 = this.d;
                String e = en1.e();
                if (str4 == null) {
                    if (e == null) {
                        return true;
                    }
                } else if (str4.equals(e)) {
                    return true;
                }
            }
        }
        return false;
    }

    public String f() {
        return this.c;
    }

    public dn1.a g() {
        return this.f1115a;
    }

    public long h() {
        return this.b;
    }

    public int hashCode() {
        String str = this.f1116a;
        int i = 0;
        int hashCode = ((((str == null ? 0 : str.hashCode()) ^ 1000003) * 1000003) ^ this.f1115a.hashCode()) * 1000003;
        String str2 = this.f1117b;
        int hashCode2 = (hashCode ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.c;
        int hashCode3 = str3 == null ? 0 : str3.hashCode();
        long j = this.a;
        long j2 = this.b;
        int i2 = (((((hashCode2 ^ hashCode3) * 1000003) ^ ((int) (j ^ (j >>> 32)))) * 1000003) ^ ((int) (j2 ^ (j2 >>> 32)))) * 1000003;
        String str4 = this.d;
        if (str4 != null) {
            i = str4.hashCode();
        }
        return i2 ^ i;
    }

    public en1.a n() {
        return new b(this);
    }

    public String toString() {
        return "PersistedInstallationEntry{firebaseInstallationId=" + this.f1116a + ", registrationStatus=" + this.f1115a + ", authToken=" + this.f1117b + ", refreshToken=" + this.c + ", expiresInSecs=" + this.a + ", tokenCreationEpochInSecs=" + this.b + ", fisError=" + this.d + "}";
    }
}
