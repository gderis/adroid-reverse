package defpackage;

import android.content.Context;
import android.content.SharedPreferences;
import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;

/* renamed from: gp1  reason: default package */
public final class gp1 {
    public static WeakReference<gp1> a;

    /* renamed from: a  reason: collision with other field name */
    public final SharedPreferences f2669a;

    /* renamed from: a  reason: collision with other field name */
    public cp1 f2670a;

    /* renamed from: a  reason: collision with other field name */
    public final Executor f2671a;

    public gp1(SharedPreferences sharedPreferences, Executor executor) {
        this.f2671a = executor;
        this.f2669a = sharedPreferences;
    }

    public static synchronized gp1 a(Context context, Executor executor) {
        synchronized (gp1.class) {
            WeakReference<gp1> weakReference = a;
            gp1 gp1 = weakReference != null ? (gp1) weakReference.get() : null;
            if (gp1 != null) {
                return gp1;
            }
            gp1 gp12 = new gp1(context.getSharedPreferences("com.google.android.gms.appid", 0), executor);
            gp12.c();
            a = new WeakReference<>(gp12);
            return gp12;
        }
    }

    public synchronized fp1 b() {
        return fp1.a(this.f2670a.e());
    }

    public final synchronized void c() {
        this.f2670a = cp1.c(this.f2669a, "topic_operation_queue", ",", this.f2671a);
    }

    public synchronized boolean d(fp1 fp1) {
        return this.f2670a.f(fp1.e());
    }
}
