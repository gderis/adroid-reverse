package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;

/* renamed from: yz1  reason: default package */
public abstract class yz1<E> implements Collection<E>, x12 {

    /* renamed from: yz1$a */
    public static final class a extends q12 implements i12<E, CharSequence> {
        public final /* synthetic */ yz1 a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(yz1 yz1) {
            super(1);
            this.a = yz1;
        }

        /* renamed from: c */
        public final CharSequence b(E e) {
            return e == this.a ? "(this Collection)" : String.valueOf(e);
        }
    }

    public boolean add(E e) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(Collection<? extends E> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public abstract int b();

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean contains(Object obj) {
        if (isEmpty()) {
            return false;
        }
        for (Object a2 : this) {
            if (p12.a(a2, obj)) {
                return true;
            }
        }
        return false;
    }

    public boolean containsAll(Collection<? extends Object> collection) {
        p12.d(collection, "elements");
        if (collection.isEmpty()) {
            return true;
        }
        Iterator<T> it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean removeAll(Collection<? extends Object> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean retainAll(Collection<? extends Object> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ int size() {
        return b();
    }

    public Object[] toArray() {
        return m12.a(this);
    }

    public <T> T[] toArray(T[] tArr) {
        p12.d(tArr, "array");
        T[] b = m12.b(this, tArr);
        Objects.requireNonNull(b, "null cannot be cast to non-null type kotlin.Array<T>");
        return b;
    }

    public String toString() {
        return p02.y(this, ", ", "[", "]", 0, (CharSequence) null, new a(this), 24, (Object) null);
    }
}
