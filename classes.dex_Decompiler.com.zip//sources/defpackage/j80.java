package defpackage;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

/* renamed from: j80  reason: default package */
public final class j80 extends WeakReference<Throwable> {
    public final int a;

    public j80(Throwable th, ReferenceQueue<Throwable> referenceQueue) {
        super(th, referenceQueue);
        this.a = System.identityHashCode(th);
    }

    public final boolean equals(Object obj) {
        if (obj != null && obj.getClass() == j80.class) {
            if (this == obj) {
                return true;
            }
            j80 j80 = (j80) obj;
            return this.a == j80.a && get() == j80.get();
        }
    }

    public final int hashCode() {
        return this.a;
    }
}
