package defpackage;

import java.util.concurrent.Executor;

/* renamed from: am1  reason: default package */
public interface am1 {
    <T> void a(Class<T> cls, Executor executor, yl1<? super T> yl1);

    <T> void b(Class<T> cls, yl1<? super T> yl1);
}
