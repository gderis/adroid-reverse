package defpackage;

import android.util.AndroidRuntimeException;

/* renamed from: rd  reason: default package */
public final class rd extends AndroidRuntimeException {
    public rd(String str) {
        super(str);
    }
}
