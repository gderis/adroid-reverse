package defpackage;

import com.google.auto.value.AutoValue;
import defpackage.pp;

@AutoValue
/* renamed from: vp  reason: default package */
public abstract class vp {

    @AutoValue.Builder
    /* renamed from: vp$a */
    public static abstract class a {
        public abstract vp a();

        public abstract a b(Integer num);

        public abstract a c(long j);

        public abstract a d(long j);

        public abstract a e(yp ypVar);

        public abstract a f(byte[] bArr);

        public abstract a g(String str);

        public abstract a h(long j);
    }

    public static a a() {
        return new pp.b();
    }

    public static a i(String str) {
        return a().g(str);
    }

    public static a j(byte[] bArr) {
        return a().f(bArr);
    }

    public abstract Integer b();

    public abstract long c();

    public abstract long d();

    public abstract yp e();

    public abstract byte[] f();

    public abstract String g();

    public abstract long h();
}
