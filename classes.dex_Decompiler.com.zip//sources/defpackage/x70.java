package defpackage;

/* renamed from: x70  reason: default package */
public final class x70 implements ml1<z70> {
    public static final ll1 a = ll1.d("messagingClientEventExtension");

    /* renamed from: a  reason: collision with other field name */
    public static final x70 f5797a = new x70();

    public final /* bridge */ /* synthetic */ void a(Object obj, Object obj2) {
        ((nl1) obj2).d(a, ((z70) obj).b());
    }
}
