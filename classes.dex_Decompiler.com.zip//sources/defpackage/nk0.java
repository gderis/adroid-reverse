package defpackage;

import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: nk0  reason: default package */
public abstract class nk0 extends wj0 {
    public static final Logger a = Logger.getLogger(nk0.class.getName());

    /* renamed from: a  reason: collision with other field name */
    public static final boolean f4179a = vn0.f();

    /* renamed from: a  reason: collision with other field name */
    public ok0 f4180a;

    public nk0() {
    }

    public /* synthetic */ nk0(kk0 kk0) {
    }

    public static int A(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        return (i & -268435456) == 0 ? 4 : 5;
    }

    public static int B(long j) {
        int i;
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        if ((-34359738368L & j) != 0) {
            j >>>= 28;
            i = 6;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        return (j & -16384) != 0 ? i + 1 : i;
    }

    public static int C(String str) {
        int i;
        try {
            i = ao0.c(str);
        } catch (zn0 unused) {
            i = str.getBytes(ol0.f4312a).length;
        }
        return A(i) + i;
    }

    public static int D(sl0 sl0) {
        int a2 = sl0.a();
        return A(a2) + a2;
    }

    public static int a(gk0 gk0) {
        int d = gk0.d();
        return A(d) + d;
    }

    public static int b(lm0 lm0, wm0 wm0) {
        qj0 qj0 = (qj0) lm0;
        int h = qj0.h();
        if (h == -1) {
            h = wm0.g(qj0);
            qj0.i(h);
        }
        return A(h) + h;
    }

    @Deprecated
    public static int e(int i, lm0 lm0, wm0 wm0) {
        int A = A(i << 3);
        int i2 = A + A;
        qj0 qj0 = (qj0) lm0;
        int h = qj0.h();
        if (h == -1) {
            h = wm0.g(qj0);
            qj0.i(h);
        }
        return i2 + h;
    }

    public static nk0 x(byte[] bArr) {
        return new lk0(bArr, 0, bArr.length);
    }

    public static int y(int i) {
        return A(i << 3);
    }

    public static int z(int i) {
        if (i >= 0) {
            return A(i);
        }
        return 10;
    }

    public final void c() {
        if (w() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public final void d(String str, zn0 zn0) {
        a.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", zn0);
        byte[] bytes = str.getBytes(ol0.f4312a);
        try {
            int length = bytes.length;
            r(length);
            v(bytes, 0, length);
        } catch (IndexOutOfBoundsException e) {
            throw new mk0(e);
        } catch (mk0 e2) {
            throw e2;
        }
    }

    public abstract void g(int i, int i2);

    public abstract void h(int i, int i2);

    public abstract void i(int i, int i2);

    public abstract void j(int i, int i2);

    public abstract void k(int i, long j);

    public abstract void l(int i, long j);

    public abstract void m(int i, boolean z);

    public abstract void n(int i, String str);

    public abstract void o(int i, gk0 gk0);

    public abstract void p(byte b);

    public abstract void q(int i);

    public abstract void r(int i);

    public abstract void s(int i);

    public abstract void t(long j);

    public abstract void u(long j);

    public abstract void v(byte[] bArr, int i, int i2);

    public abstract int w();
}
