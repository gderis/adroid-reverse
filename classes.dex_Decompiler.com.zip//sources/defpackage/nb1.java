package defpackage;

import android.content.Context;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.google.android.material.datepicker.MaterialCalendarGridView;
import java.util.Collection;

/* renamed from: nb1  reason: default package */
public class nb1 extends BaseAdapter {
    public static final int a = tb1.k().getMaximum(4);

    /* renamed from: a  reason: collision with other field name */
    public final bb1 f4122a;

    /* renamed from: a  reason: collision with other field name */
    public db1 f4123a;

    /* renamed from: a  reason: collision with other field name */
    public final eb1<?> f4124a;

    /* renamed from: a  reason: collision with other field name */
    public Collection<Long> f4125a;

    /* renamed from: a  reason: collision with other field name */
    public final mb1 f4126a;

    public nb1(mb1 mb1, eb1<?> eb1, bb1 bb1) {
        this.f4126a = mb1;
        this.f4124a = eb1;
        this.f4122a = bb1;
        this.f4125a = eb1.c0();
    }

    public int a(int i) {
        return b() + (i - 1);
    }

    public int b() {
        return this.f4126a.g();
    }

    /* renamed from: c */
    public Long getItem(int i) {
        if (i < this.f4126a.g() || i > i()) {
            return null;
        }
        return Long.valueOf(this.f4126a.h(j(i)));
    }

    /* JADX WARNING: type inference failed for: r7v11, types: [android.view.View] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0080 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0081  */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.widget.TextView getView(int r6, android.view.View r7, android.view.ViewGroup r8) {
        /*
            r5 = this;
            android.content.Context r0 = r8.getContext()
            r5.e(r0)
            r0 = r7
            android.widget.TextView r0 = (android.widget.TextView) r0
            r1 = 0
            if (r7 != 0) goto L_0x001e
            android.content.Context r7 = r8.getContext()
            android.view.LayoutInflater r7 = android.view.LayoutInflater.from(r7)
            int r0 = defpackage.u91.mtrl_calendar_day
            android.view.View r7 = r7.inflate(r0, r8, r1)
            r0 = r7
            android.widget.TextView r0 = (android.widget.TextView) r0
        L_0x001e:
            int r7 = r5.b()
            int r7 = r6 - r7
            if (r7 < 0) goto L_0x0072
            mb1 r8 = r5.f4126a
            int r2 = r8.d
            if (r7 < r2) goto L_0x002d
            goto L_0x0072
        L_0x002d:
            r2 = 1
            int r7 = r7 + r2
            r0.setTag(r8)
            android.content.res.Resources r8 = r0.getResources()
            android.content.res.Configuration r8 = r8.getConfiguration()
            java.util.Locale r8 = r8.locale
            java.lang.Object[] r3 = new java.lang.Object[r2]
            java.lang.Integer r4 = java.lang.Integer.valueOf(r7)
            r3[r1] = r4
            java.lang.String r4 = "%d"
            java.lang.String r8 = java.lang.String.format(r8, r4, r3)
            r0.setText(r8)
            mb1 r8 = r5.f4126a
            long r7 = r8.h(r7)
            mb1 r3 = r5.f4126a
            int r3 = r3.b
            mb1 r4 = defpackage.mb1.f()
            int r4 = r4.b
            if (r3 != r4) goto L_0x0064
            java.lang.String r7 = defpackage.fb1.a(r7)
            goto L_0x0068
        L_0x0064:
            java.lang.String r7 = defpackage.fb1.d(r7)
        L_0x0068:
            r0.setContentDescription(r7)
            r0.setVisibility(r1)
            r0.setEnabled(r2)
            goto L_0x007a
        L_0x0072:
            r7 = 8
            r0.setVisibility(r7)
            r0.setEnabled(r1)
        L_0x007a:
            java.lang.Long r6 = r5.getItem(r6)
            if (r6 != 0) goto L_0x0081
            return r0
        L_0x0081:
            long r6 = r6.longValue()
            r5.k(r0, r6)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.nb1.getView(int, android.view.View, android.view.ViewGroup):android.widget.TextView");
    }

    public final void e(Context context) {
        if (this.f4123a == null) {
            this.f4123a = new db1(context);
        }
    }

    public boolean f(int i) {
        return i % this.f4126a.c == 0;
    }

    public boolean g(int i) {
        return (i + 1) % this.f4126a.c == 0;
    }

    public int getCount() {
        return this.f4126a.d + b();
    }

    public long getItemId(int i) {
        return (long) (i / this.f4126a.c);
    }

    public final boolean h(long j) {
        for (Long longValue : this.f4124a.c0()) {
            if (tb1.a(j) == tb1.a(longValue.longValue())) {
                return true;
            }
        }
        return false;
    }

    public boolean hasStableIds() {
        return true;
    }

    public int i() {
        return (this.f4126a.g() + this.f4126a.d) - 1;
    }

    public int j(int i) {
        return (i - this.f4126a.g()) + 1;
    }

    public final void k(TextView textView, long j) {
        cb1 cb1;
        if (textView != null) {
            if (this.f4122a.f().b0(j)) {
                textView.setEnabled(true);
                if (h(j)) {
                    cb1 = this.f4123a.b;
                } else {
                    int i = (tb1.i().getTimeInMillis() > j ? 1 : (tb1.i().getTimeInMillis() == j ? 0 : -1));
                    db1 db1 = this.f4123a;
                    cb1 = i == 0 ? db1.c : db1.f1958a;
                }
            } else {
                textView.setEnabled(false);
                cb1 = this.f4123a.g;
            }
            cb1.d(textView);
        }
    }

    public final void l(MaterialCalendarGridView materialCalendarGridView, long j) {
        if (mb1.e(j).equals(this.f4126a)) {
            k((TextView) materialCalendarGridView.getChildAt(materialCalendarGridView.getAdapter().a(this.f4126a.i(j)) - materialCalendarGridView.getFirstVisiblePosition()), j);
        }
    }

    public void m(MaterialCalendarGridView materialCalendarGridView) {
        for (Long longValue : this.f4125a) {
            l(materialCalendarGridView, longValue.longValue());
        }
        eb1<?> eb1 = this.f4124a;
        if (eb1 != null) {
            for (Long longValue2 : eb1.c0()) {
                l(materialCalendarGridView, longValue2.longValue());
            }
            this.f4125a = this.f4124a.c0();
        }
    }

    public boolean n(int i) {
        return i >= b() && i <= i();
    }
}
