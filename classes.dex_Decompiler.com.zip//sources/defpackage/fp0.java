package defpackage;

/* renamed from: fp0  reason: default package */
public interface fp0 {
    String a(String str);
}
