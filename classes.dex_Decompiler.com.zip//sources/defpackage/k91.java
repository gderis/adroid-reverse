package defpackage;

import java.util.concurrent.Executor;

/* renamed from: k91  reason: default package */
public interface k91 {
    Executor a(Executor executor);
}
