package defpackage;

/* renamed from: ep0  reason: default package */
public final class ep0 implements dp0 {
    public static final ui0<Boolean> a = new si0(li0.a("com.google.android.gms.measurement")).b("measurement.upload.file_truncate_fix", false);

    public final boolean a() {
        return a.e().booleanValue();
    }
}
