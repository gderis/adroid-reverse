package defpackage;

/* renamed from: ro1  reason: default package */
public final /* synthetic */ class ro1 implements bp {
    public static final bp a = new ro1();

    public Object a(Object obj) {
        return ((sp1) obj).c();
    }
}
