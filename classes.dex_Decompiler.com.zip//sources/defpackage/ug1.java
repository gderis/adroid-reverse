package defpackage;

import java.io.File;

/* renamed from: ug1  reason: default package */
public final class ug1 implements rg1 {
    public static final tg1 a = new b();

    /* renamed from: a  reason: collision with other field name */
    public final km1<rg1> f5372a;

    /* renamed from: ug1$b */
    public static final class b implements tg1 {
        public b() {
        }

        public File a() {
            return null;
        }

        public File b() {
            return null;
        }

        public File c() {
            return null;
        }

        public File d() {
            return null;
        }

        public File e() {
            return null;
        }

        public File f() {
            return null;
        }
    }

    public ug1(km1<rg1> km1) {
        this.f5372a = km1;
    }

    public void a(String str, String str2, String str3, String str4, String str5, int i, String str6) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            rg1.a(str, str2, str3, str4, str5, i, str6);
        }
    }

    public tg1 b(String str) {
        rg1 rg1 = this.f5372a.get();
        return rg1 != null ? rg1.b(str) : a;
    }

    public boolean c(String str) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            return rg1.c(str);
        }
        return false;
    }

    public void d(String str, String str2, String str3, boolean z) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            rg1.d(str, str2, str3, z);
        }
    }

    public void e(String str, String str2, long j) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            rg1.e(str, str2, j);
        }
    }

    public void f(String str, int i, String str2, int i2, long j, long j2, boolean z, int i3, String str3, String str4) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            rg1.f(str, i, str2, i2, j, j2, z, i3, str3, str4);
        }
    }

    public boolean g(String str) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            return rg1.g(str);
        }
        return true;
    }

    public boolean h(String str) {
        rg1 rg1 = this.f5372a.get();
        if (rg1 != null) {
            return rg1.h(str);
        }
        return true;
    }
}
