package defpackage;

/* renamed from: lw0  reason: default package */
public final /* synthetic */ class lw0 implements xy0 {
    public static final xy0 a = new lw0();

    public final Object a() {
        zy0<Long> zy0 = bz0.f1148a;
        return Integer.valueOf((int) to0.h());
    }
}
