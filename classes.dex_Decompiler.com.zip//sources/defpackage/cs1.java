package defpackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: cs1  reason: default package */
public class cs1 extends sr1 implements nr1, Iterable<es1> {
    public final List<es1> a;

    /* renamed from: a  reason: collision with other field name */
    public or1 f1801a;
    public boolean c;
    public boolean d;
    public boolean e;

    public cs1() {
        this((as1) null);
    }

    public cs1(as1 as1) {
        super(as1);
        this.a = new ArrayList();
        this.e = true;
        this.c = "AND";
    }

    public static cs1 v() {
        return new cs1();
    }

    public static cs1 y() {
        return new cs1().B(false);
    }

    public final void A(String str) {
        if (this.a.size() > 0) {
            List<es1> list = this.a;
            list.get(list.size() - 1).d(str);
        }
    }

    public cs1 B(boolean z) {
        this.e = z;
        this.c = true;
        return this;
    }

    public void h(or1 or1) {
        int size = this.a.size();
        if (this.e && size > 0) {
            or1.a("(");
        }
        for (int i = 0; i < size; i++) {
            es1 es1 = this.a.get(i);
            es1.h(or1);
            if (!this.d && es1.e() && i < size - 1) {
                or1.h(es1.k());
            } else if (i < size - 1) {
                or1.a(", ");
            }
        }
        if (this.e && size > 0) {
            or1.a(")");
        }
    }

    public String i() {
        if (this.c) {
            this.f1801a = x();
        }
        or1 or1 = this.f1801a;
        return or1 == null ? "" : or1.toString();
    }

    public Iterator<es1> iterator() {
        return this.a.iterator();
    }

    public cs1 s(es1 es1) {
        return z("AND", es1);
    }

    public String toString() {
        return x().toString();
    }

    public cs1 u(es1... es1Arr) {
        for (es1 s : es1Arr) {
            s(s);
        }
        return this;
    }

    public List<es1> w() {
        return this.a;
    }

    public final or1 x() {
        or1 or1 = new or1();
        h(or1);
        return or1;
    }

    public final cs1 z(String str, es1 es1) {
        if (es1 != null) {
            A(str);
            this.a.add(es1);
            this.c = true;
        }
        return this;
    }
}
