package defpackage;

/* renamed from: xl  reason: default package */
public interface xl {
    void a(wl wlVar);

    Long b(String str);
}
