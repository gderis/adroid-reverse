package defpackage;

import com.google.android.gms.common.api.internal.LifecycleCallback;

/* renamed from: s00  reason: default package */
public final class s00 implements Runnable {
    public final /* synthetic */ LifecycleCallback a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ String f4893a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ t00 f4894a;

    public s00(t00 t00, LifecycleCallback lifecycleCallback, String str) {
        this.f4894a = t00;
        this.a = lifecycleCallback;
        this.f4893a = str;
    }

    public final void run() {
        if (this.f4894a.f5126a > 0) {
            this.a.f(this.f4894a.f5127a != null ? this.f4894a.f5127a.getBundle(this.f4893a) : null);
        }
        if (this.f4894a.f5126a >= 2) {
            this.a.j();
        }
        if (this.f4894a.f5126a >= 3) {
            this.a.h();
        }
        if (this.f4894a.f5126a >= 4) {
            this.a.k();
        }
        if (this.f4894a.f5126a >= 5) {
            this.a.g();
        }
    }
}
