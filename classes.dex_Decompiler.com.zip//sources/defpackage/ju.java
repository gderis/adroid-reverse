package defpackage;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.SystemClock;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.GuardedBy;

@ParametersAreNonnullByDefault
/* renamed from: ju  reason: default package */
public class ju {
    public final long a;
    @GuardedBy("this")

    /* renamed from: a  reason: collision with other field name */
    public final Context f3308a;

    /* renamed from: a  reason: collision with other field name */
    public final Object f3309a = new Object();
    @GuardedBy("mAutoDisconnectTaskLock")

    /* renamed from: a  reason: collision with other field name */
    public b f3310a;
    @GuardedBy("this")

    /* renamed from: a  reason: collision with other field name */
    public n60 f3311a;
    @GuardedBy("this")

    /* renamed from: a  reason: collision with other field name */
    public vv f3312a;
    @GuardedBy("this")

    /* renamed from: a  reason: collision with other field name */
    public boolean f3313a;
    public final boolean b;

    /* renamed from: ju$a */
    public static final class a {
        public final String a;

        /* renamed from: a  reason: collision with other field name */
        public final boolean f3314a;

        public a(String str, boolean z) {
            this.a = str;
            this.f3314a = z;
        }

        public final String a() {
            return this.a;
        }

        public final boolean b() {
            return this.f3314a;
        }

        public final String toString() {
            String str = this.a;
            boolean z = this.f3314a;
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 7);
            sb.append("{");
            sb.append(str);
            sb.append("}");
            sb.append(z);
            return sb.toString();
        }
    }

    /* renamed from: ju$b */
    public static class b extends Thread {
        public long a;

        /* renamed from: a  reason: collision with other field name */
        public WeakReference<ju> f3315a;

        /* renamed from: a  reason: collision with other field name */
        public CountDownLatch f3316a = new CountDownLatch(1);
        public boolean b = false;

        public b(ju juVar, long j) {
            this.f3315a = new WeakReference<>(juVar);
            this.a = j;
            start();
        }

        public final void a() {
            ju juVar = (ju) this.f3315a.get();
            if (juVar != null) {
                juVar.a();
                this.b = true;
            }
        }

        public final void run() {
            try {
                if (!this.f3316a.await(this.a, TimeUnit.MILLISECONDS)) {
                    a();
                }
            } catch (InterruptedException unused) {
                a();
            }
        }
    }

    public ju(Context context, long j, boolean z, boolean z2) {
        Context applicationContext;
        s10.j(context);
        if (z && (applicationContext = context.getApplicationContext()) != null) {
            context = applicationContext;
        }
        this.f3308a = context;
        this.f3313a = false;
        this.a = j;
        this.b = z2;
    }

    public static a b(Context context) {
        lu luVar = new lu(context);
        boolean a2 = luVar.a("gads:ad_id_app_context:enabled", false);
        float b2 = luVar.b("gads:ad_id_app_context:ping_ratio", 0.0f);
        String c = luVar.c("gads:ad_id_use_shared_preference:experiment_id", "");
        ju juVar = new ju(context, -1, a2, luVar.a("gads:ad_id_use_persistent_service:enabled", false));
        try {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            juVar.h(false);
            a c2 = juVar.c();
            juVar.i(c2, a2, b2, SystemClock.elapsedRealtime() - elapsedRealtime, c, (Throwable) null);
            juVar.a();
            return c2;
        } catch (Throwable th) {
            juVar.a();
            throw th;
        }
    }

    public static void d(boolean z) {
    }

    public static vv e(Context context, boolean z) {
        try {
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            int j = aw.h().j(context, dw.a);
            if (j == 0 || j == 2) {
                String str = z ? "com.google.android.gms.ads.identifier.service.PERSISTENT_START" : "com.google.android.gms.ads.identifier.service.START";
                vv vvVar = new vv();
                Intent intent = new Intent(str);
                intent.setPackage("com.google.android.gms");
                try {
                    if (z30.b().a(context, intent, vvVar, 1)) {
                        return vvVar;
                    }
                    throw new IOException("Connection failure");
                } catch (Throwable th) {
                    throw new IOException(th);
                }
            } else {
                throw new IOException("Google Play services not available");
            }
        } catch (PackageManager.NameNotFoundException unused) {
            throw new bw(9);
        }
    }

    public static n60 f(Context context, vv vvVar) {
        try {
            return o60.b(vvVar.a(10000, TimeUnit.MILLISECONDS));
        } catch (InterruptedException unused) {
            throw new IOException("Interrupted exception");
        } catch (Throwable th) {
            throw new IOException(th);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0029, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a() {
        /*
            r3 = this;
            java.lang.String r0 = "Calling this from your main thread can lead to deadlock"
            defpackage.s10.i(r0)
            monitor-enter(r3)
            android.content.Context r0 = r3.f3308a     // Catch:{ all -> 0x002a }
            if (r0 == 0) goto L_0x0028
            vv r0 = r3.f3312a     // Catch:{ all -> 0x002a }
            if (r0 != 0) goto L_0x000f
            goto L_0x0028
        L_0x000f:
            boolean r0 = r3.f3313a     // Catch:{ all -> 0x001e }
            if (r0 == 0) goto L_0x001e
            z30 r0 = defpackage.z30.b()     // Catch:{ all -> 0x001e }
            android.content.Context r1 = r3.f3308a     // Catch:{ all -> 0x001e }
            vv r2 = r3.f3312a     // Catch:{ all -> 0x001e }
            r0.c(r1, r2)     // Catch:{ all -> 0x001e }
        L_0x001e:
            r0 = 0
            r3.f3313a = r0     // Catch:{ all -> 0x002a }
            r0 = 0
            r3.f3311a = r0     // Catch:{ all -> 0x002a }
            r3.f3312a = r0     // Catch:{ all -> 0x002a }
            monitor-exit(r3)     // Catch:{ all -> 0x002a }
            return
        L_0x0028:
            monitor-exit(r3)     // Catch:{ all -> 0x002a }
            return
        L_0x002a:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x002a }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ju.a():void");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:39|40|41) */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0063, code lost:
        throw new java.io.IOException("Remote exception");
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:39:0x005c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public defpackage.ju.a c() {
        /*
            r4 = this;
            java.lang.String r0 = "Calling this from your main thread can lead to deadlock"
            defpackage.s10.i(r0)
            monitor-enter(r4)
            boolean r0 = r4.f3313a     // Catch:{ all -> 0x0064 }
            if (r0 != 0) goto L_0x003b
            java.lang.Object r0 = r4.f3309a     // Catch:{ all -> 0x0064 }
            monitor-enter(r0)     // Catch:{ all -> 0x0064 }
            ju$b r1 = r4.f3310a     // Catch:{ all -> 0x0038 }
            if (r1 == 0) goto L_0x0030
            boolean r1 = r1.b     // Catch:{ all -> 0x0038 }
            if (r1 == 0) goto L_0x0030
            monitor-exit(r0)     // Catch:{ all -> 0x0038 }
            r0 = 0
            r4.h(r0)     // Catch:{ Exception -> 0x0027 }
            boolean r0 = r4.f3313a     // Catch:{ all -> 0x0064 }
            if (r0 == 0) goto L_0x001f
            goto L_0x003b
        L_0x001f:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ all -> 0x0064 }
            java.lang.String r1 = "AdvertisingIdClient cannot reconnect."
            r0.<init>(r1)     // Catch:{ all -> 0x0064 }
            throw r0     // Catch:{ all -> 0x0064 }
        L_0x0027:
            r0 = move-exception
            java.io.IOException r1 = new java.io.IOException     // Catch:{ all -> 0x0064 }
            java.lang.String r2 = "AdvertisingIdClient cannot reconnect."
            r1.<init>(r2, r0)     // Catch:{ all -> 0x0064 }
            throw r1     // Catch:{ all -> 0x0064 }
        L_0x0030:
            java.io.IOException r1 = new java.io.IOException     // Catch:{ all -> 0x0038 }
            java.lang.String r2 = "AdvertisingIdClient is not connected."
            r1.<init>(r2)     // Catch:{ all -> 0x0038 }
            throw r1     // Catch:{ all -> 0x0038 }
        L_0x0038:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0038 }
            throw r1     // Catch:{ all -> 0x0064 }
        L_0x003b:
            vv r0 = r4.f3312a     // Catch:{ all -> 0x0064 }
            defpackage.s10.j(r0)     // Catch:{ all -> 0x0064 }
            n60 r0 = r4.f3311a     // Catch:{ all -> 0x0064 }
            defpackage.s10.j(r0)     // Catch:{ all -> 0x0064 }
            ju$a r0 = new ju$a     // Catch:{ RemoteException -> 0x005c }
            n60 r1 = r4.f3311a     // Catch:{ RemoteException -> 0x005c }
            java.lang.String r1 = r1.g0()     // Catch:{ RemoteException -> 0x005c }
            n60 r2 = r4.f3311a     // Catch:{ RemoteException -> 0x005c }
            r3 = 1
            boolean r2 = r2.A0(r3)     // Catch:{ RemoteException -> 0x005c }
            r0.<init>(r1, r2)     // Catch:{ RemoteException -> 0x005c }
            monitor-exit(r4)     // Catch:{ all -> 0x0064 }
            r4.g()
            return r0
        L_0x005c:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ all -> 0x0064 }
            java.lang.String r1 = "Remote exception"
            r0.<init>(r1)     // Catch:{ all -> 0x0064 }
            throw r0     // Catch:{ all -> 0x0064 }
        L_0x0064:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0064 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ju.c():ju$a");
    }

    public void finalize() {
        a();
        super.finalize();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(7:2|3|(3:5|6|7)|8|9|(1:11)|12) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0011 */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0019  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void g() {
        /*
            r6 = this;
            java.lang.Object r0 = r6.f3309a
            monitor-enter(r0)
            ju$b r1 = r6.f3310a     // Catch:{ all -> 0x0024 }
            if (r1 == 0) goto L_0x0011
            java.util.concurrent.CountDownLatch r1 = r1.f3316a     // Catch:{ all -> 0x0024 }
            r1.countDown()     // Catch:{ all -> 0x0024 }
            ju$b r1 = r6.f3310a     // Catch:{ InterruptedException -> 0x0011 }
            r1.join()     // Catch:{ InterruptedException -> 0x0011 }
        L_0x0011:
            long r1 = r6.a     // Catch:{ all -> 0x0024 }
            r3 = 0
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 <= 0) goto L_0x0022
            ju$b r1 = new ju$b     // Catch:{ all -> 0x0024 }
            long r2 = r6.a     // Catch:{ all -> 0x0024 }
            r1.<init>(r6, r2)     // Catch:{ all -> 0x0024 }
            r6.f3310a = r1     // Catch:{ all -> 0x0024 }
        L_0x0022:
            monitor-exit(r0)     // Catch:{ all -> 0x0024 }
            return
        L_0x0024:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0024 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ju.g():void");
    }

    public final void h(boolean z) {
        s10.i("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.f3313a) {
                a();
            }
            vv e = e(this.f3308a, this.b);
            this.f3312a = e;
            this.f3311a = f(this.f3308a, e);
            this.f3313a = true;
            if (z) {
                g();
            }
        }
    }

    public final boolean i(a aVar, boolean z, float f, long j, String str, Throwable th) {
        if (Math.random() > ((double) f)) {
            return false;
        }
        HashMap hashMap = new HashMap();
        String str2 = "1";
        hashMap.put("app_context", z ? str2 : "0");
        if (aVar != null) {
            if (!aVar.b()) {
                str2 = "0";
            }
            hashMap.put("limit_ad_tracking", str2);
        }
        if (!(aVar == null || aVar.a() == null)) {
            hashMap.put("ad_id_size", Integer.toString(aVar.a().length()));
        }
        if (th != null) {
            hashMap.put("error", th.getClass().getName());
        }
        if (str != null && !str.isEmpty()) {
            hashMap.put("experiment_id", str);
        }
        hashMap.put("tag", "AdvertisingIdClient");
        hashMap.put("time_spent", Long.toString(j));
        new ku(this, hashMap).start();
        return true;
    }
}
