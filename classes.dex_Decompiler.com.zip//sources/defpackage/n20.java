package defpackage;

import android.app.Activity;
import android.content.Intent;

/* renamed from: n20  reason: default package */
public final class n20 extends l20 {
    public final /* synthetic */ int a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ Activity f4027a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ Intent f4028a;

    public n20(Intent intent, Activity activity, int i) {
        this.f4028a = intent;
        this.f4027a = activity;
        this.a = i;
    }

    public final void c() {
        Intent intent = this.f4028a;
        if (intent != null) {
            this.f4027a.startActivityForResult(intent, this.a);
        }
    }
}
