package defpackage;

import java.util.concurrent.Callable;

/* renamed from: j01  reason: default package */
public final /* synthetic */ class j01 implements Callable {
    public final String a;

    /* renamed from: a  reason: collision with other field name */
    public final o01 f3175a;

    public j01(o01 o01, String str) {
        this.f3175a = o01;
        this.a = str;
    }

    public final Object call() {
        return new eo0("internal.remoteConfig", new n01(this.f3175a, this.a));
    }
}
