package defpackage;

import android.os.Bundle;

/* renamed from: m00  reason: default package */
public final class m00 implements az {
    public final /* synthetic */ k00 a;

    public m00(k00 k00) {
        this.a = k00;
    }

    public /* synthetic */ m00(k00 k00, j00 j00) {
        this(k00);
    }

    public final void a(wv wvVar) {
        this.a.f3361a.lock();
        try {
            wv unused = this.a.f3363a = wvVar;
            this.a.y();
        } finally {
            this.a.f3361a.unlock();
        }
    }

    public final void b(int i, boolean z) {
        this.a.f3361a.lock();
        try {
            if (!this.a.f3364a && this.a.f3365b != null) {
                if (this.a.f3365b.E0()) {
                    boolean unused = this.a.f3364a = true;
                    this.a.b.b(i);
                }
            }
            boolean unused2 = this.a.f3364a = false;
            this.a.k(i, z);
        } finally {
            this.a.f3361a.unlock();
        }
    }

    public final void j(Bundle bundle) {
        this.a.f3361a.lock();
        try {
            this.a.l(bundle);
            wv unused = this.a.f3363a = wv.a;
            this.a.y();
        } finally {
            this.a.f3361a.unlock();
        }
    }
}
