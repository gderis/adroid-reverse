package defpackage;

import android.content.Context;

/* renamed from: cl  reason: default package */
public class cl extends el<Boolean> {
    public cl(Context context, hn hnVar) {
        super(ql.c(context, hnVar).a());
    }

    public boolean b(im imVar) {
        return imVar.f3080a.g();
    }

    /* renamed from: i */
    public boolean c(Boolean bool) {
        return !bool.booleanValue();
    }
}
