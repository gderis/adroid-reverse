package defpackage;

import java.util.ArrayList;
import java.util.List;

/* renamed from: vb0  reason: default package */
public final class vb0 extends pb0 implements sb0 {
    public final List<String> a;

    /* renamed from: a  reason: collision with other field name */
    public zg0 f5536a;
    public final List<wb0> b;

    public vb0(String str, List<wb0> list, List<wb0> list2, zg0 zg0) {
        super(str);
        this.a = new ArrayList();
        this.f5536a = zg0;
        if (!list.isEmpty()) {
            for (wb0 b2 : list) {
                this.a.add(b2.b());
            }
        }
        this.b = new ArrayList(list2);
    }

    public vb0(vb0 vb0) {
        super(vb0.a);
        ArrayList arrayList = new ArrayList(vb0.a.size());
        this.a = arrayList;
        arrayList.addAll(vb0.a);
        ArrayList arrayList2 = new ArrayList(vb0.b.size());
        this.b = arrayList2;
        arrayList2.addAll(vb0.b);
        this.f5536a = vb0.f5536a;
    }

    public final wb0 a(zg0 zg0, List<wb0> list) {
        wb0 wb0;
        String str;
        zg0 c = this.f5536a.c();
        for (int i = 0; i < this.a.size(); i++) {
            if (i < list.size()) {
                str = this.a.get(i);
                wb0 = zg0.a(list.get(i));
            } else {
                str = this.a.get(i);
                wb0 = wb0.a;
            }
            c.f(str, wb0);
        }
        for (wb0 next : this.b) {
            wb0 a2 = c.a(next);
            if (a2 instanceof xb0) {
                a2 = c.a(next);
            }
            if (a2 instanceof nb0) {
                return ((nb0) a2).a();
            }
        }
        return wb0.a;
    }

    public final wb0 c() {
        return new vb0(this);
    }
}
