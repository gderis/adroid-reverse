package defpackage;

import java.util.concurrent.Executor;

/* renamed from: zm  reason: default package */
public class zm implements Executor {
    public void execute(Runnable runnable) {
        runnable.run();
    }
}
