package defpackage;

/* renamed from: aa  reason: default package */
public class aa<T> implements z9<T> {
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public final Object[] f114a;

    public aa(int i) {
        if (i > 0) {
            this.f114a = new Object[i];
            return;
        }
        throw new IllegalArgumentException("The max pool size must be > 0");
    }

    public boolean a(T t) {
        if (!c(t)) {
            int i = this.a;
            Object[] objArr = this.f114a;
            if (i >= objArr.length) {
                return false;
            }
            objArr[i] = t;
            this.a = i + 1;
            return true;
        }
        throw new IllegalStateException("Already in the pool!");
    }

    public T b() {
        int i = this.a;
        if (i <= 0) {
            return null;
        }
        int i2 = i - 1;
        T[] tArr = this.f114a;
        T t = tArr[i2];
        tArr[i2] = null;
        this.a = i - 1;
        return t;
    }

    public final boolean c(T t) {
        for (int i = 0; i < this.a; i++) {
            if (this.f114a[i] == t) {
                return true;
            }
        }
        return false;
    }
}
