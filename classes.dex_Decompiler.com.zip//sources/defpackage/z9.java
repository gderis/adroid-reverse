package defpackage;

/* renamed from: z9  reason: default package */
public interface z9<T> {
    boolean a(T t);

    T b();
}
