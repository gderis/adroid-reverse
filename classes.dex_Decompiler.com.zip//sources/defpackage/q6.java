package defpackage;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import defpackage.m5;

/* renamed from: q6  reason: default package */
public class q6 extends View {
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public View f4584a;
    public int b;

    public void a(ConstraintLayout constraintLayout) {
        if (this.f4584a != null) {
            ConstraintLayout.b bVar = (ConstraintLayout.b) getLayoutParams();
            ConstraintLayout.b bVar2 = (ConstraintLayout.b) this.f4584a.getLayoutParams();
            bVar2.f592a.T0(0);
            m5.b y = bVar.f592a.y();
            m5.b bVar3 = m5.b.FIXED;
            if (y != bVar3) {
                bVar.f592a.U0(bVar2.f592a.R());
            }
            if (bVar.f592a.O() != bVar3) {
                bVar.f592a.v0(bVar2.f592a.v());
            }
            bVar2.f592a.T0(8);
        }
    }

    public void b(ConstraintLayout constraintLayout) {
        if (this.a == -1 && !isInEditMode()) {
            setVisibility(this.b);
        }
        View findViewById = constraintLayout.findViewById(this.a);
        this.f4584a = findViewById;
        if (findViewById != null) {
            ((ConstraintLayout.b) findViewById.getLayoutParams()).f608h = true;
            this.f4584a.setVisibility(0);
            setVisibility(0);
        }
    }

    public View getContent() {
        return this.f4584a;
    }

    public int getEmptyVisibility() {
        return this.b;
    }

    public void onDraw(Canvas canvas) {
        if (isInEditMode()) {
            canvas.drawRGB(223, 223, 223);
            Paint paint = new Paint();
            paint.setARGB(255, 210, 210, 210);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
            Rect rect = new Rect();
            canvas.getClipBounds(rect);
            paint.setTextSize((float) rect.height());
            int height = rect.height();
            int width = rect.width();
            paint.setTextAlign(Paint.Align.LEFT);
            paint.getTextBounds("?", 0, 1, rect);
            canvas.drawText("?", ((((float) width) / 2.0f) - (((float) rect.width()) / 2.0f)) - ((float) rect.left), ((((float) height) / 2.0f) + (((float) rect.height()) / 2.0f)) - ((float) rect.bottom), paint);
        }
    }

    public void setContentId(int i) {
        View findViewById;
        if (this.a != i) {
            View view = this.f4584a;
            if (view != null) {
                view.setVisibility(0);
                ((ConstraintLayout.b) this.f4584a.getLayoutParams()).f608h = false;
                this.f4584a = null;
            }
            this.a = i;
            if (i != -1 && (findViewById = ((View) getParent()).findViewById(i)) != null) {
                findViewById.setVisibility(8);
            }
        }
    }

    public void setEmptyVisibility(int i) {
        this.b = i;
    }
}
