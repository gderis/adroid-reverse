package defpackage;

import android.view.SubMenu;

/* renamed from: u8  reason: default package */
public interface u8 extends s8, SubMenu {
}
