package defpackage;

/* renamed from: ve  reason: default package */
public final class ve {
    public static final int view_tree_view_model_store_owner = 2131231222;
}
