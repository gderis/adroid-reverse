package defpackage;

import com.google.auto.value.AutoValue;
import defpackage.qp;
import java.util.List;

@AutoValue
/* renamed from: wp  reason: default package */
public abstract class wp {

    @AutoValue.Builder
    /* renamed from: wp$a */
    public static abstract class a {
        public abstract wp a();

        public abstract a b(up upVar);

        public abstract a c(List<vp> list);

        public abstract a d(Integer num);

        public abstract a e(String str);

        public abstract a f(zp zpVar);

        public abstract a g(long j);

        public abstract a h(long j);

        public a i(int i) {
            return d(Integer.valueOf(i));
        }

        public a j(String str) {
            return e(str);
        }
    }

    public static a a() {
        return new qp.b();
    }

    public abstract up b();

    public abstract List<vp> c();

    public abstract Integer d();

    public abstract String e();

    public abstract zp f();

    public abstract long g();

    public abstract long h();
}
