package defpackage;

import android.text.SpannableStringBuilder;
import java.util.Locale;

/* renamed from: p9  reason: default package */
public final class p9 {
    public static final String a = Character.toString(8206);

    /* renamed from: a  reason: collision with other field name */
    public static final p9 f4408a;

    /* renamed from: a  reason: collision with other field name */
    public static final s9 f4409a;
    public static final String b = Character.toString(8207);

    /* renamed from: b  reason: collision with other field name */
    public static final p9 f4410b;

    /* renamed from: a  reason: collision with other field name */
    public final int f4411a;

    /* renamed from: a  reason: collision with other field name */
    public final boolean f4412a;

    /* renamed from: b  reason: collision with other field name */
    public final s9 f4413b;

    /* renamed from: p9$a */
    public static final class a {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public s9 f4414a;

        /* renamed from: a  reason: collision with other field name */
        public boolean f4415a;

        public a() {
            c(p9.e(Locale.getDefault()));
        }

        public static p9 b(boolean z) {
            return z ? p9.f4410b : p9.f4408a;
        }

        public p9 a() {
            return (this.a == 2 && this.f4414a == p9.f4409a) ? b(this.f4415a) : new p9(this.f4415a, this.a, this.f4414a);
        }

        public final void c(boolean z) {
            this.f4415a = z;
            this.f4414a = p9.f4409a;
            this.a = 2;
        }
    }

    /* renamed from: p9$b */
    public static class b {
        public static final byte[] a = new byte[1792];

        /* renamed from: a  reason: collision with other field name */
        public char f4416a;

        /* renamed from: a  reason: collision with other field name */
        public final int f4417a;

        /* renamed from: a  reason: collision with other field name */
        public final CharSequence f4418a;

        /* renamed from: a  reason: collision with other field name */
        public final boolean f4419a;
        public int b;

        static {
            for (int i = 0; i < 1792; i++) {
                a[i] = Character.getDirectionality(i);
            }
        }

        public b(CharSequence charSequence, boolean z) {
            this.f4418a = charSequence;
            this.f4419a = z;
            this.f4417a = charSequence.length();
        }

        public static byte c(char c) {
            return c < 1792 ? a[c] : Character.getDirectionality(c);
        }

        public byte a() {
            char charAt = this.f4418a.charAt(this.b - 1);
            this.f4416a = charAt;
            if (Character.isLowSurrogate(charAt)) {
                int codePointBefore = Character.codePointBefore(this.f4418a, this.b);
                this.b -= Character.charCount(codePointBefore);
                return Character.getDirectionality(codePointBefore);
            }
            this.b--;
            byte c = c(this.f4416a);
            if (!this.f4419a) {
                return c;
            }
            char c2 = this.f4416a;
            return c2 == '>' ? h() : c2 == ';' ? f() : c;
        }

        public byte b() {
            char charAt = this.f4418a.charAt(this.b);
            this.f4416a = charAt;
            if (Character.isHighSurrogate(charAt)) {
                int codePointAt = Character.codePointAt(this.f4418a, this.b);
                this.b += Character.charCount(codePointAt);
                return Character.getDirectionality(codePointAt);
            }
            this.b++;
            byte c = c(this.f4416a);
            if (!this.f4419a) {
                return c;
            }
            char c2 = this.f4416a;
            return c2 == '<' ? i() : c2 == '&' ? g() : c;
        }

        public int d() {
            this.b = 0;
            int i = 0;
            int i2 = 0;
            int i3 = 0;
            while (this.b < this.f4417a && i == 0) {
                byte b2 = b();
                if (b2 != 0) {
                    if (b2 == 1 || b2 == 2) {
                        if (i3 == 0) {
                            return 1;
                        }
                    } else if (b2 != 9) {
                        switch (b2) {
                            case 14:
                            case 15:
                                i3++;
                                i2 = -1;
                                continue;
                            case 16:
                            case 17:
                                i3++;
                                i2 = 1;
                                continue;
                            case 18:
                                i3--;
                                i2 = 0;
                                continue;
                        }
                    }
                } else if (i3 == 0) {
                    return -1;
                }
                i = i3;
            }
            if (i == 0) {
                return 0;
            }
            if (i2 != 0) {
                return i2;
            }
            while (this.b > 0) {
                switch (a()) {
                    case 14:
                    case 15:
                        if (i == i3) {
                            return -1;
                        }
                        break;
                    case 16:
                    case 17:
                        if (i == i3) {
                            return 1;
                        }
                        break;
                    case 18:
                        i3++;
                        continue;
                }
                i3--;
            }
            return 0;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:18:0x002b, code lost:
            r1 = r1 - 1;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int e() {
            /*
                r7 = this;
                int r0 = r7.f4417a
                r7.b = r0
                r0 = 0
                r1 = 0
                r2 = 0
            L_0x0007:
                int r3 = r7.b
                if (r3 <= 0) goto L_0x003b
                byte r3 = r7.a()
                r4 = -1
                if (r3 == 0) goto L_0x0034
                r5 = 1
                if (r3 == r5) goto L_0x002e
                r6 = 2
                if (r3 == r6) goto L_0x002e
                r6 = 9
                if (r3 == r6) goto L_0x0007
                switch(r3) {
                    case 14: goto L_0x0028;
                    case 15: goto L_0x0028;
                    case 16: goto L_0x0025;
                    case 17: goto L_0x0025;
                    case 18: goto L_0x0022;
                    default: goto L_0x001f;
                }
            L_0x001f:
                if (r2 != 0) goto L_0x0007
                goto L_0x0039
            L_0x0022:
                int r1 = r1 + 1
                goto L_0x0007
            L_0x0025:
                if (r2 != r1) goto L_0x002b
                return r5
            L_0x0028:
                if (r2 != r1) goto L_0x002b
                return r4
            L_0x002b:
                int r1 = r1 + -1
                goto L_0x0007
            L_0x002e:
                if (r1 != 0) goto L_0x0031
                return r5
            L_0x0031:
                if (r2 != 0) goto L_0x0007
                goto L_0x0039
            L_0x0034:
                if (r1 != 0) goto L_0x0037
                return r4
            L_0x0037:
                if (r2 != 0) goto L_0x0007
            L_0x0039:
                r2 = r1
                goto L_0x0007
            L_0x003b:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: defpackage.p9.b.e():int");
        }

        public final byte f() {
            char charAt;
            int i = this.b;
            do {
                int i2 = this.b;
                if (i2 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f4418a;
                int i3 = i2 - 1;
                this.b = i3;
                charAt = charSequence.charAt(i3);
                this.f4416a = charAt;
                if (charAt == '&') {
                    return 12;
                }
            } while (charAt != ';');
            this.b = i;
            this.f4416a = ';';
            return 13;
        }

        public final byte g() {
            char charAt;
            do {
                int i = this.b;
                if (i >= this.f4417a) {
                    return 12;
                }
                CharSequence charSequence = this.f4418a;
                this.b = i + 1;
                charAt = charSequence.charAt(i);
                this.f4416a = charAt;
            } while (charAt != ';');
            return 12;
        }

        public final byte h() {
            char charAt;
            int i = this.b;
            while (true) {
                int i2 = this.b;
                if (i2 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f4418a;
                int i3 = i2 - 1;
                this.b = i3;
                char charAt2 = charSequence.charAt(i3);
                this.f4416a = charAt2;
                if (charAt2 == '<') {
                    return 12;
                }
                if (charAt2 == '>') {
                    break;
                } else if (charAt2 == '\"' || charAt2 == '\'') {
                    do {
                        int i4 = this.b;
                        if (i4 <= 0) {
                            break;
                        }
                        CharSequence charSequence2 = this.f4418a;
                        int i5 = i4 - 1;
                        this.b = i5;
                        charAt = charSequence2.charAt(i5);
                        this.f4416a = charAt;
                    } while (charAt != charAt2);
                }
            }
            this.b = i;
            this.f4416a = '>';
            return 13;
        }

        public final byte i() {
            char charAt;
            int i = this.b;
            while (true) {
                int i2 = this.b;
                if (i2 < this.f4417a) {
                    CharSequence charSequence = this.f4418a;
                    this.b = i2 + 1;
                    char charAt2 = charSequence.charAt(i2);
                    this.f4416a = charAt2;
                    if (charAt2 == '>') {
                        return 12;
                    }
                    if (charAt2 == '\"' || charAt2 == '\'') {
                        do {
                            int i3 = this.b;
                            if (i3 >= this.f4417a) {
                                break;
                            }
                            CharSequence charSequence2 = this.f4418a;
                            this.b = i3 + 1;
                            charAt = charSequence2.charAt(i3);
                            this.f4416a = charAt;
                        } while (charAt != charAt2);
                    }
                } else {
                    this.b = i;
                    this.f4416a = '<';
                    return 13;
                }
            }
        }
    }

    static {
        s9 s9Var = t9.c;
        f4409a = s9Var;
        f4408a = new p9(false, 2, s9Var);
        f4410b = new p9(true, 2, s9Var);
    }

    public p9(boolean z, int i, s9 s9Var) {
        this.f4412a = z;
        this.f4411a = i;
        this.f4413b = s9Var;
    }

    public static int a(CharSequence charSequence) {
        return new b(charSequence, false).d();
    }

    public static int b(CharSequence charSequence) {
        return new b(charSequence, false).e();
    }

    public static p9 c() {
        return new a().a();
    }

    public static boolean e(Locale locale) {
        return u9.b(locale) == 1;
    }

    public boolean d() {
        return (this.f4411a & 2) != 0;
    }

    public final String f(CharSequence charSequence, s9 s9Var) {
        boolean a2 = s9Var.a(charSequence, 0, charSequence.length());
        return (this.f4412a || (!a2 && b(charSequence) != 1)) ? this.f4412a ? (!a2 || b(charSequence) == -1) ? b : "" : "" : a;
    }

    public final String g(CharSequence charSequence, s9 s9Var) {
        boolean a2 = s9Var.a(charSequence, 0, charSequence.length());
        return (this.f4412a || (!a2 && a(charSequence) != 1)) ? this.f4412a ? (!a2 || a(charSequence) == -1) ? b : "" : "" : a;
    }

    public CharSequence h(CharSequence charSequence) {
        return i(charSequence, this.f4413b, true);
    }

    public CharSequence i(CharSequence charSequence, s9 s9Var, boolean z) {
        if (charSequence == null) {
            return null;
        }
        boolean a2 = s9Var.a(charSequence, 0, charSequence.length());
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        if (d() && z) {
            spannableStringBuilder.append(g(charSequence, a2 ? t9.b : t9.a));
        }
        if (a2 != this.f4412a) {
            spannableStringBuilder.append(a2 ? (char) 8235 : 8234);
            spannableStringBuilder.append(charSequence);
            spannableStringBuilder.append(8236);
        } else {
            spannableStringBuilder.append(charSequence);
        }
        if (z) {
            spannableStringBuilder.append(f(charSequence, a2 ? t9.b : t9.a));
        }
        return spannableStringBuilder;
    }

    public String j(String str) {
        return k(str, this.f4413b, true);
    }

    public String k(String str, s9 s9Var, boolean z) {
        if (str == null) {
            return null;
        }
        return i(str, s9Var, z).toString();
    }
}
