package defpackage;

import android.os.Bundle;
import android.view.View;

/* renamed from: mb  reason: default package */
public interface mb {

    /* renamed from: mb$a */
    public static abstract class a {
        public Bundle a;

        public void a(Bundle bundle) {
            this.a = bundle;
        }
    }

    /* renamed from: mb$b */
    public static final class b extends a {
    }

    /* renamed from: mb$c */
    public static final class c extends a {
    }

    /* renamed from: mb$d */
    public static final class d extends a {
    }

    /* renamed from: mb$e */
    public static final class e extends a {
    }

    /* renamed from: mb$f */
    public static final class f extends a {
    }

    /* renamed from: mb$g */
    public static final class g extends a {
    }

    /* renamed from: mb$h */
    public static final class h extends a {
    }

    boolean a(View view, a aVar);
}
