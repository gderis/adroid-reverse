package defpackage;

/* renamed from: z72  reason: default package */
public final /* synthetic */ class z72 {
    public static final o72 a(h82 h82) {
        p12.d(h82, "$this$buffer");
        return new c82(h82);
    }

    public static final p72 b(j82 j82) {
        p12.d(j82, "$this$buffer");
        return new d82(j82);
    }
}
