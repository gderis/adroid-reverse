package defpackage;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.List;

/* renamed from: nd1  reason: default package */
public class nd1 {
    @Deprecated
    public float a;

    /* renamed from: a  reason: collision with other field name */
    public final List<f> f4131a = new ArrayList();

    /* renamed from: a  reason: collision with other field name */
    public boolean f4132a;
    @Deprecated
    public float b;

    /* renamed from: b  reason: collision with other field name */
    public final List<g> f4133b = new ArrayList();
    @Deprecated
    public float c;
    @Deprecated
    public float d;
    @Deprecated
    public float e;
    @Deprecated
    public float f;

    /* renamed from: nd1$a */
    public class a extends g {
        public final /* synthetic */ List a;
        public final /* synthetic */ Matrix b;

        public a(List list, Matrix matrix) {
            this.a = list;
            this.b = matrix;
        }

        public void a(Matrix matrix, zc1 zc1, int i, Canvas canvas) {
            for (g a2 : this.a) {
                a2.a(this.b, zc1, i, canvas);
            }
        }
    }

    /* renamed from: nd1$b */
    public static class b extends g {
        public final d a;

        public b(d dVar) {
            this.a = dVar;
        }

        public void a(Matrix matrix, zc1 zc1, int i, Canvas canvas) {
            float h = this.a.m();
            float i2 = this.a.n();
            zc1.a(canvas, matrix, new RectF(this.a.k(), this.a.o(), this.a.l(), this.a.j()), i, h, i2);
        }
    }

    /* renamed from: nd1$c */
    public static class c extends g {
        public final float a;

        /* renamed from: a  reason: collision with other field name */
        public final e f4135a;
        public final float b;

        public c(e eVar, float f, float f2) {
            this.f4135a = eVar;
            this.a = f;
            this.b = f2;
        }

        public void a(Matrix matrix, zc1 zc1, int i, Canvas canvas) {
            RectF rectF = new RectF(0.0f, 0.0f, (float) Math.hypot((double) (this.f4135a.b - this.b), (double) (this.f4135a.a - this.a)), 0.0f);
            Matrix matrix2 = new Matrix(matrix);
            matrix2.preTranslate(this.a, this.b);
            matrix2.preRotate(c());
            zc1.b(canvas, matrix2, rectF, i);
        }

        public float c() {
            return (float) Math.toDegrees(Math.atan((double) ((this.f4135a.b - this.b) / (this.f4135a.a - this.a))));
        }
    }

    /* renamed from: nd1$d */
    public static class d extends f {
        public static final RectF a = new RectF();
        @Deprecated

        /* renamed from: a  reason: collision with other field name */
        public float f4136a;
        @Deprecated
        public float b;
        @Deprecated
        public float c;
        @Deprecated
        public float d;
        @Deprecated
        public float e;
        @Deprecated
        public float f;

        public d(float f2, float f3, float f4, float f5) {
            q(f2);
            u(f3);
            r(f4);
            p(f5);
        }

        public void a(Matrix matrix, Path path) {
            Matrix matrix2 = this.a;
            matrix.invert(matrix2);
            path.transform(matrix2);
            RectF rectF = a;
            rectF.set(k(), o(), l(), j());
            path.arcTo(rectF, m(), n(), false);
            path.transform(matrix);
        }

        public final float j() {
            return this.d;
        }

        public final float k() {
            return this.f4136a;
        }

        public final float l() {
            return this.c;
        }

        public final float m() {
            return this.e;
        }

        public final float n() {
            return this.f;
        }

        public final float o() {
            return this.b;
        }

        public final void p(float f2) {
            this.d = f2;
        }

        public final void q(float f2) {
            this.f4136a = f2;
        }

        public final void r(float f2) {
            this.c = f2;
        }

        public final void s(float f2) {
            this.e = f2;
        }

        public final void t(float f2) {
            this.f = f2;
        }

        public final void u(float f2) {
            this.b = f2;
        }
    }

    /* renamed from: nd1$e */
    public static class e extends f {
        public float a;
        public float b;

        public void a(Matrix matrix, Path path) {
            Matrix matrix2 = this.a;
            matrix.invert(matrix2);
            path.transform(matrix2);
            path.lineTo(this.a, this.b);
            path.transform(matrix);
        }
    }

    /* renamed from: nd1$f */
    public static abstract class f {
        public final Matrix a = new Matrix();

        public abstract void a(Matrix matrix, Path path);
    }

    /* renamed from: nd1$g */
    public static abstract class g {
        public static final Matrix a = new Matrix();

        public abstract void a(Matrix matrix, zc1 zc1, int i, Canvas canvas);

        public final void b(zc1 zc1, int i, Canvas canvas) {
            a(a, zc1, i, canvas);
        }
    }

    public nd1() {
        n(0.0f, 0.0f);
    }

    public void a(float f2, float f3, float f4, float f5, float f6, float f7) {
        d dVar = new d(f2, f3, f4, f5);
        dVar.s(f6);
        dVar.t(f7);
        this.f4131a.add(dVar);
        b bVar = new b(dVar);
        float f8 = f6 + f7;
        boolean z = f7 < 0.0f;
        if (z) {
            f6 = (f6 + 180.0f) % 360.0f;
        }
        c(bVar, f6, z ? (180.0f + f8) % 360.0f : f8);
        double d2 = (double) f8;
        r(((f2 + f4) * 0.5f) + (((f4 - f2) / 2.0f) * ((float) Math.cos(Math.toRadians(d2)))));
        s(((f3 + f5) * 0.5f) + (((f5 - f3) / 2.0f) * ((float) Math.sin(Math.toRadians(d2)))));
    }

    public final void b(float f2) {
        if (g() != f2) {
            float g2 = ((f2 - g()) + 360.0f) % 360.0f;
            if (g2 <= 180.0f) {
                d dVar = new d(i(), j(), i(), j());
                dVar.s(g());
                dVar.t(g2);
                this.f4133b.add(new b(dVar));
                p(f2);
            }
        }
    }

    public final void c(g gVar, float f2, float f3) {
        b(f2);
        this.f4133b.add(gVar);
        p(f3);
    }

    public void d(Matrix matrix, Path path) {
        int size = this.f4131a.size();
        for (int i = 0; i < size; i++) {
            this.f4131a.get(i).a(matrix, path);
        }
    }

    public boolean e() {
        return this.f4132a;
    }

    public g f(Matrix matrix) {
        b(h());
        return new a(new ArrayList(this.f4133b), new Matrix(matrix));
    }

    public final float g() {
        return this.e;
    }

    public final float h() {
        return this.f;
    }

    public float i() {
        return this.c;
    }

    public float j() {
        return this.d;
    }

    public float k() {
        return this.a;
    }

    public float l() {
        return this.b;
    }

    public void m(float f2, float f3) {
        e eVar = new e();
        float unused = eVar.a = f2;
        float unused2 = eVar.b = f3;
        this.f4131a.add(eVar);
        c cVar = new c(eVar, i(), j());
        c(cVar, cVar.c() + 270.0f, cVar.c() + 270.0f);
        r(f2);
        s(f3);
    }

    public void n(float f2, float f3) {
        o(f2, f3, 270.0f, 0.0f);
    }

    public void o(float f2, float f3, float f4, float f5) {
        t(f2);
        u(f3);
        r(f2);
        s(f3);
        p(f4);
        q((f4 + f5) % 360.0f);
        this.f4131a.clear();
        this.f4133b.clear();
        this.f4132a = false;
    }

    public final void p(float f2) {
        this.e = f2;
    }

    public final void q(float f2) {
        this.f = f2;
    }

    public final void r(float f2) {
        this.c = f2;
    }

    public final void s(float f2) {
        this.d = f2;
    }

    public final void t(float f2) {
        this.a = f2;
    }

    public final void u(float f2) {
        this.b = f2;
    }
}
