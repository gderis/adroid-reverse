package defpackage;

/* renamed from: a80  reason: default package */
public interface a80 {
}
