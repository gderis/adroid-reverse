package defpackage;

/* renamed from: c00  reason: default package */
public final class c00 {
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final wv f1153a;

    public c00(wv wvVar, int i) {
        s10.j(wvVar);
        this.f1153a = wvVar;
        this.a = i;
    }

    public final int a() {
        return this.a;
    }

    public final wv b() {
        return this.f1153a;
    }
}
