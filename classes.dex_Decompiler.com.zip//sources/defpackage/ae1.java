package defpackage;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;
import java.util.ArrayList;
import java.util.List;

/* renamed from: ae1  reason: default package */
public final class ae1 {
    public final float a;

    /* renamed from: a  reason: collision with other field name */
    public int f201a;

    /* renamed from: a  reason: collision with other field name */
    public Animator f202a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f203a;

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f204a;

    /* renamed from: a  reason: collision with other field name */
    public Typeface f205a;

    /* renamed from: a  reason: collision with other field name */
    public FrameLayout f206a;

    /* renamed from: a  reason: collision with other field name */
    public LinearLayout f207a;

    /* renamed from: a  reason: collision with other field name */
    public TextView f208a;

    /* renamed from: a  reason: collision with other field name */
    public final TextInputLayout f209a;

    /* renamed from: a  reason: collision with other field name */
    public CharSequence f210a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f211a;
    public int b;

    /* renamed from: b  reason: collision with other field name */
    public ColorStateList f212b;

    /* renamed from: b  reason: collision with other field name */
    public TextView f213b;

    /* renamed from: b  reason: collision with other field name */
    public CharSequence f214b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f215b;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public CharSequence f216c;
    public int d;
    public int e;

    /* renamed from: ae1$a */
    public class a extends AnimatorListenerAdapter {
        public final /* synthetic */ int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ TextView f218a;
        public final /* synthetic */ int b;

        /* renamed from: b  reason: collision with other field name */
        public final /* synthetic */ TextView f219b;

        public a(int i, TextView textView, int i2, TextView textView2) {
            this.a = i;
            this.f218a = textView;
            this.b = i2;
            this.f219b = textView2;
        }

        public void onAnimationEnd(Animator animator) {
            int unused = ae1.this.b = this.a;
            Animator unused2 = ae1.this.f202a = null;
            TextView textView = this.f218a;
            if (textView != null) {
                textView.setVisibility(4);
                if (this.b == 1 && ae1.this.f208a != null) {
                    ae1.this.f208a.setText((CharSequence) null);
                }
            }
            TextView textView2 = this.f219b;
            if (textView2 != null) {
                textView2.setTranslationY(0.0f);
                this.f219b.setAlpha(1.0f);
            }
        }

        public void onAnimationStart(Animator animator) {
            TextView textView = this.f219b;
            if (textView != null) {
                textView.setVisibility(0);
            }
        }
    }

    public ae1(TextInputLayout textInputLayout) {
        Context context = textInputLayout.getContext();
        this.f203a = context;
        this.f209a = textInputLayout;
        this.a = (float) context.getResources().getDimensionPixelSize(q91.design_textinput_caption_translate_y);
    }

    public final void A(int i, int i2) {
        TextView l;
        TextView l2;
        if (i != i2) {
            if (!(i2 == 0 || (l2 = l(i2)) == null)) {
                l2.setVisibility(0);
                l2.setAlpha(1.0f);
            }
            if (!(i == 0 || (l = l(i)) == null)) {
                l.setVisibility(4);
                if (i == 1) {
                    l.setText((CharSequence) null);
                }
            }
            this.b = i2;
        }
    }

    public void B(CharSequence charSequence) {
        this.f214b = charSequence;
        TextView textView = this.f208a;
        if (textView != null) {
            textView.setContentDescription(charSequence);
        }
    }

    public void C(boolean z) {
        if (this.f211a != z) {
            g();
            if (z) {
                v2 v2Var = new v2(this.f203a);
                this.f208a = v2Var;
                v2Var.setId(s91.textinput_error);
                if (Build.VERSION.SDK_INT >= 17) {
                    this.f208a.setTextAlignment(5);
                }
                Typeface typeface = this.f205a;
                if (typeface != null) {
                    this.f208a.setTypeface(typeface);
                }
                D(this.d);
                E(this.f204a);
                B(this.f214b);
                this.f208a.setVisibility(4);
                ya.q0(this.f208a, 1);
                d(this.f208a, 0);
            } else {
                t();
                z(this.f208a, 0);
                this.f208a = null;
                this.f209a.r0();
                this.f209a.E0();
            }
            this.f211a = z;
        }
    }

    public void D(int i) {
        this.d = i;
        TextView textView = this.f208a;
        if (textView != null) {
            this.f209a.e0(textView, i);
        }
    }

    public void E(ColorStateList colorStateList) {
        this.f204a = colorStateList;
        TextView textView = this.f208a;
        if (textView != null && colorStateList != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void F(int i) {
        this.e = i;
        TextView textView = this.f213b;
        if (textView != null) {
            yb.n(textView, i);
        }
    }

    public void G(boolean z) {
        if (this.f215b != z) {
            g();
            if (z) {
                v2 v2Var = new v2(this.f203a);
                this.f213b = v2Var;
                v2Var.setId(s91.textinput_helper_text);
                if (Build.VERSION.SDK_INT >= 17) {
                    this.f213b.setTextAlignment(5);
                }
                Typeface typeface = this.f205a;
                if (typeface != null) {
                    this.f213b.setTypeface(typeface);
                }
                this.f213b.setVisibility(4);
                ya.q0(this.f213b, 1);
                F(this.e);
                H(this.f212b);
                d(this.f213b, 1);
            } else {
                u();
                z(this.f213b, 1);
                this.f213b = null;
                this.f209a.r0();
                this.f209a.E0();
            }
            this.f215b = z;
        }
    }

    public void H(ColorStateList colorStateList) {
        this.f212b = colorStateList;
        TextView textView = this.f213b;
        if (textView != null && colorStateList != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public final void I(TextView textView, Typeface typeface) {
        if (textView != null) {
            textView.setTypeface(typeface);
        }
    }

    public void J(Typeface typeface) {
        if (typeface != this.f205a) {
            this.f205a = typeface;
            I(this.f208a, typeface);
            I(this.f213b, typeface);
        }
    }

    public final void K(ViewGroup viewGroup, int i) {
        if (i == 0) {
            viewGroup.setVisibility(8);
        }
    }

    public final boolean L(TextView textView, CharSequence charSequence) {
        return ya.T(this.f209a) && this.f209a.isEnabled() && (this.c != this.b || textView == null || !TextUtils.equals(textView.getText(), charSequence));
    }

    public void M(CharSequence charSequence) {
        g();
        this.f210a = charSequence;
        this.f208a.setText(charSequence);
        int i = this.b;
        if (i != 1) {
            this.c = 1;
        }
        O(i, this.c, L(this.f208a, charSequence));
    }

    public void N(CharSequence charSequence) {
        g();
        this.f216c = charSequence;
        this.f213b.setText(charSequence);
        int i = this.b;
        if (i != 2) {
            this.c = 2;
        }
        O(i, this.c, L(this.f213b, charSequence));
    }

    public final void O(int i, int i2, boolean z) {
        boolean z2 = z;
        if (i != i2) {
            if (z2) {
                AnimatorSet animatorSet = new AnimatorSet();
                this.f202a = animatorSet;
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = arrayList;
                int i3 = i;
                int i4 = i2;
                h(arrayList2, this.f215b, this.f213b, 2, i3, i4);
                h(arrayList2, this.f211a, this.f208a, 1, i3, i4);
                z91.a(animatorSet, arrayList);
                animatorSet.addListener(new a(i2, l(i), i, l(i2)));
                animatorSet.start();
            } else {
                A(i, i2);
            }
            this.f209a.r0();
            this.f209a.u0(z2);
            this.f209a.E0();
        }
    }

    public void d(TextView textView, int i) {
        if (this.f207a == null && this.f206a == null) {
            LinearLayout linearLayout = new LinearLayout(this.f203a);
            this.f207a = linearLayout;
            linearLayout.setOrientation(0);
            this.f209a.addView(this.f207a, -1, -2);
            this.f206a = new FrameLayout(this.f203a);
            this.f207a.addView(this.f206a, new LinearLayout.LayoutParams(0, -2, 1.0f));
            if (this.f209a.getEditText() != null) {
                e();
            }
        }
        if (w(i)) {
            this.f206a.setVisibility(0);
            this.f206a.addView(textView);
        } else {
            this.f207a.addView(textView, new LinearLayout.LayoutParams(-2, -2));
        }
        this.f207a.setVisibility(0);
        this.f201a++;
    }

    public void e() {
        if (f()) {
            EditText editText = this.f209a.getEditText();
            boolean g = tc1.g(this.f203a);
            LinearLayout linearLayout = this.f207a;
            int i = q91.material_helper_text_font_1_3_padding_horizontal;
            ya.A0(linearLayout, s(g, i, ya.I(editText)), s(g, q91.material_helper_text_font_1_3_padding_top, this.f203a.getResources().getDimensionPixelSize(q91.material_helper_text_default_padding_top)), s(g, i, ya.H(editText)), 0);
        }
    }

    public final boolean f() {
        return (this.f207a == null || this.f209a.getEditText() == null) ? false : true;
    }

    public void g() {
        Animator animator = this.f202a;
        if (animator != null) {
            animator.cancel();
        }
    }

    public final void h(List<Animator> list, boolean z, TextView textView, int i, int i2, int i3) {
        if (textView != null && z) {
            if (i == i3 || i == i2) {
                list.add(i(textView, i3 == i));
                if (i3 == i) {
                    list.add(j(textView));
                }
            }
        }
    }

    public final ObjectAnimator i(TextView textView, boolean z) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(textView, View.ALPHA, new float[]{z ? 1.0f : 0.0f});
        ofFloat.setDuration(167);
        ofFloat.setInterpolator(y91.a);
        return ofFloat;
    }

    public final ObjectAnimator j(TextView textView) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(textView, View.TRANSLATION_Y, new float[]{-this.a, 0.0f});
        ofFloat.setDuration(217);
        ofFloat.setInterpolator(y91.d);
        return ofFloat;
    }

    public boolean k() {
        return v(this.c);
    }

    public final TextView l(int i) {
        if (i == 1) {
            return this.f208a;
        }
        if (i != 2) {
            return null;
        }
        return this.f213b;
    }

    public CharSequence m() {
        return this.f214b;
    }

    public CharSequence n() {
        return this.f210a;
    }

    public int o() {
        TextView textView = this.f208a;
        if (textView != null) {
            return textView.getCurrentTextColor();
        }
        return -1;
    }

    public ColorStateList p() {
        TextView textView = this.f208a;
        if (textView != null) {
            return textView.getTextColors();
        }
        return null;
    }

    public CharSequence q() {
        return this.f216c;
    }

    public int r() {
        TextView textView = this.f213b;
        if (textView != null) {
            return textView.getCurrentTextColor();
        }
        return -1;
    }

    public final int s(boolean z, int i, int i2) {
        return z ? this.f203a.getResources().getDimensionPixelSize(i) : i2;
    }

    public void t() {
        this.f210a = null;
        g();
        if (this.b == 1) {
            this.c = (!this.f215b || TextUtils.isEmpty(this.f216c)) ? 0 : 2;
        }
        O(this.b, this.c, L(this.f208a, (CharSequence) null));
    }

    public void u() {
        g();
        int i = this.b;
        if (i == 2) {
            this.c = 0;
        }
        O(i, this.c, L(this.f213b, (CharSequence) null));
    }

    public final boolean v(int i) {
        return i == 1 && this.f208a != null && !TextUtils.isEmpty(this.f210a);
    }

    public boolean w(int i) {
        return i == 0 || i == 1;
    }

    public boolean x() {
        return this.f211a;
    }

    public boolean y() {
        return this.f215b;
    }

    public void z(TextView textView, int i) {
        FrameLayout frameLayout;
        if (this.f207a != null) {
            if (!w(i) || (frameLayout = this.f206a) == null) {
                this.f207a.removeView(textView);
            } else {
                frameLayout.removeView(textView);
            }
            int i2 = this.f201a - 1;
            this.f201a = i2;
            K(this.f207a, i2);
        }
    }
}
