package defpackage;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

/* renamed from: hg  reason: default package */
public class hg implements Executor {
    public Runnable a;

    /* renamed from: a  reason: collision with other field name */
    public final ArrayDeque<Runnable> f2842a = new ArrayDeque<>();

    /* renamed from: a  reason: collision with other field name */
    public final Executor f2843a;

    /* renamed from: hg$a */
    public class a implements Runnable {

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ Runnable f2844a;

        public a(Runnable runnable) {
            this.f2844a = runnable;
        }

        public void run() {
            try {
                this.f2844a.run();
            } finally {
                hg.this.a();
            }
        }
    }

    public hg(Executor executor) {
        this.f2843a = executor;
    }

    public synchronized void a() {
        Runnable poll = this.f2842a.poll();
        this.a = poll;
        if (poll != null) {
            this.f2843a.execute(poll);
        }
    }

    public synchronized void execute(Runnable runnable) {
        this.f2842a.offer(new a(runnable));
        if (this.a == null) {
            a();
        }
    }
}
