package defpackage;

/* renamed from: if0  reason: default package */
public final class if0 extends cl0<jf0, if0> implements mm0 {
    public if0() {
        super(jf0.zzi);
    }

    public /* synthetic */ if0(df0 df0) {
        super(jf0.zzi);
    }

    public final if0 r(String str) {
        if (this.f1285b) {
            n();
            this.f1285b = false;
        }
        jf0.K((jf0) this.b, str);
        return this;
    }
}
