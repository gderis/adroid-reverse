package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: yu0  reason: default package */
public final class yu0 implements Parcelable.Creator<xu0> {
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        Parcel parcel2 = parcel;
        int z = x10.z(parcel);
        long j = 0;
        long j2 = 0;
        long j3 = 0;
        String str = null;
        String str2 = null;
        v51 v51 = null;
        String str3 = null;
        pv0 pv0 = null;
        pv0 pv02 = null;
        pv0 pv03 = null;
        boolean z2 = false;
        while (parcel.dataPosition() < z) {
            int r = x10.r(parcel);
            switch (x10.k(r)) {
                case 2:
                    str = x10.e(parcel2, r);
                    break;
                case 3:
                    str2 = x10.e(parcel2, r);
                    break;
                case 4:
                    v51 = (v51) x10.d(parcel2, r, v51.CREATOR);
                    break;
                case 5:
                    j = x10.u(parcel2, r);
                    break;
                case 6:
                    z2 = x10.l(parcel2, r);
                    break;
                case 7:
                    str3 = x10.e(parcel2, r);
                    break;
                case 8:
                    pv0 = (pv0) x10.d(parcel2, r, pv0.CREATOR);
                    break;
                case 9:
                    j2 = x10.u(parcel2, r);
                    break;
                case 10:
                    pv02 = (pv0) x10.d(parcel2, r, pv0.CREATOR);
                    break;
                case 11:
                    j3 = x10.u(parcel2, r);
                    break;
                case 12:
                    pv03 = (pv0) x10.d(parcel2, r, pv0.CREATOR);
                    break;
                default:
                    x10.y(parcel2, r);
                    break;
            }
        }
        x10.j(parcel2, z);
        return new xu0(str, str2, v51, j, z2, str3, pv0, j2, pv02, j3, pv03);
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new xu0[i];
    }
}
