package defpackage;

import defpackage.ox;

/* renamed from: pz  reason: default package */
public final class pz extends ox<A, ResultT> {
    public final /* synthetic */ ox.a a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public pz(ox.a aVar, yv[] yvVarArr, boolean z, int i) {
        super(yvVarArr, z, i);
        this.a = aVar;
    }

    public final void b(A a2, o81<ResultT> o81) {
        this.a.f4354a.a(a2, o81);
    }
}
