package defpackage;

import java.nio.charset.Charset;
import java.util.Objects;

/* renamed from: ek0  reason: default package */
public class ek0 extends dk0 {
    public final byte[] a;

    public ek0(byte[] bArr) {
        Objects.requireNonNull(bArr);
        this.a = bArr;
    }

    public byte b(int i) {
        return this.a[i];
    }

    public byte c(int i) {
        return this.a[i];
    }

    public int d() {
        return this.a.length;
    }

    public final gk0 e(int i, int i2) {
        int n = gk0.n(0, i2, d());
        return n == 0 ? gk0.f2655a : new ak0(this.a, 0, n);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof gk0) || d() != ((gk0) obj).d()) {
            return false;
        }
        if (d() == 0) {
            return true;
        }
        if (!(obj instanceof ek0)) {
            return obj.equals(this);
        }
        ek0 ek0 = (ek0) obj;
        int m = m();
        int m2 = ek0.m();
        if (m != 0 && m2 != 0 && m != m2) {
            return false;
        }
        int d = d();
        if (d > ek0.d()) {
            int d2 = d();
            StringBuilder sb = new StringBuilder(40);
            sb.append("Length too large: ");
            sb.append(d);
            sb.append(d2);
            throw new IllegalArgumentException(sb.toString());
        } else if (d <= ek0.d()) {
            byte[] bArr = this.a;
            byte[] bArr2 = ek0.a;
            ek0.p();
            int i = 0;
            int i2 = 0;
            while (i < d) {
                if (bArr[i] != bArr2[i2]) {
                    return false;
                }
                i++;
                i2++;
            }
            return true;
        } else {
            int d3 = ek0.d();
            StringBuilder sb2 = new StringBuilder(59);
            sb2.append("Ran off end of other: 0, ");
            sb2.append(d);
            sb2.append(", ");
            sb2.append(d3);
            throw new IllegalArgumentException(sb2.toString());
        }
    }

    public final void f(wj0 wj0) {
        ((lk0) wj0).E(this.a, 0, d());
    }

    public final String g(Charset charset) {
        return new String(this.a, 0, d(), charset);
    }

    public final boolean h() {
        return ao0.b(this.a, 0, d());
    }

    public final int i(int i, int i2, int i3) {
        return ol0.h(i, this.a, 0, i3);
    }

    public int p() {
        return 0;
    }
}
