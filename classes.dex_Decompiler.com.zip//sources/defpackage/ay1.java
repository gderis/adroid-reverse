package defpackage;

import java.util.List;

/* renamed from: ay1  reason: default package */
public interface ay1 {
    void a(String str, List<gy1> list);
}
