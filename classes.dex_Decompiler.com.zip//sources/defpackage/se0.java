package defpackage;

import android.os.Bundle;

/* renamed from: se0  reason: default package */
public final class se0 extends qd0 {
    public final y11 a;

    public se0(y11 y11) {
        this.a = y11;
    }

    public final void a0(String str, String str2, Bundle bundle, long j) {
        this.a.a(str, str2, bundle, j);
    }

    public final int t0() {
        return System.identityHashCode(this.a);
    }
}
