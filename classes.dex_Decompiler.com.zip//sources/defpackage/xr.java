package defpackage;

import android.content.Context;

/* renamed from: xr  reason: default package */
public final class xr implements ir<qs> {
    public final nz1<Context> a;
    public final nz1<pt> b;
    public final nz1<ls> c;
    public final nz1<cu> d;

    public xr(nz1<Context> nz1, nz1<pt> nz12, nz1<ls> nz13, nz1<cu> nz14) {
        this.a = nz1;
        this.b = nz12;
        this.c = nz13;
        this.d = nz14;
    }

    public static xr a(nz1<Context> nz1, nz1<pt> nz12, nz1<ls> nz13, nz1<cu> nz14) {
        return new xr(nz1, nz12, nz13, nz14);
    }

    public static qs c(Context context, pt ptVar, ls lsVar, cu cuVar) {
        return (qs) kr.c(wr.a(context, ptVar, lsVar, cuVar), "Cannot return null from a non-@Nullable @Provides method");
    }

    /* renamed from: b */
    public qs get() {
        return c(this.a.get(), this.b.get(), this.c.get(), this.d.get());
    }
}
