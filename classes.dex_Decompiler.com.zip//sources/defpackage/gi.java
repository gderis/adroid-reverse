package defpackage;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewOverlay;

/* renamed from: gi  reason: default package */
public class gi implements hi {
    public final ViewOverlay a;

    public gi(View view) {
        this.a = view.getOverlay();
    }

    public void b(Drawable drawable) {
        this.a.add(drawable);
    }

    public void c(Drawable drawable) {
        this.a.remove(drawable);
    }
}
