package defpackage;

import defpackage.y52;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: c62  reason: default package */
public final class c62 implements Closeable {
    public static final a a = new a((n12) null);

    /* renamed from: a  reason: collision with other field name */
    public static final Logger f1217a;

    /* renamed from: a  reason: collision with other field name */
    public final b f1218a;

    /* renamed from: a  reason: collision with other field name */
    public final p72 f1219a;

    /* renamed from: a  reason: collision with other field name */
    public final y52.a f1220a;
    public final boolean b;

    /* renamed from: c62$a */
    public static final class a {
        public a() {
        }

        public /* synthetic */ a(n12 n12) {
            this();
        }

        public final Logger a() {
            return c62.f1217a;
        }

        public final int b(int i, int i2, int i3) {
            if ((i2 & 8) != 0) {
                i--;
            }
            if (i3 <= i) {
                return i - i3;
            }
            throw new IOException("PROTOCOL_ERROR padding " + i3 + " > remaining length " + i);
        }
    }

    /* renamed from: c62$b */
    public static final class b implements j82 {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public final p72 f1221a;
        public int b;
        public int c;
        public int d;
        public int e;

        public b(p72 p72) {
            p12.d(p72, "source");
            this.f1221a = p72;
        }

        public final void E(int i) {
            this.e = i;
        }

        public final void F(int i) {
            this.c = i;
        }

        public long Z(n72 n72, long j) {
            p12.d(n72, "sink");
            while (true) {
                int i = this.d;
                if (i == 0) {
                    this.f1221a.m0((long) this.e);
                    this.e = 0;
                    if ((this.b & 4) != 0) {
                        return -1;
                    }
                    o();
                } else {
                    long Z = this.f1221a.Z(n72, Math.min(j, (long) i));
                    if (Z == -1) {
                        return -1;
                    }
                    this.d -= (int) Z;
                    return Z;
                }
            }
        }

        public final int a() {
            return this.d;
        }

        public void close() {
        }

        public k82 k() {
            return this.f1221a.k();
        }

        public final void o() {
            int i = this.c;
            int F = n42.F(this.f1221a);
            this.d = F;
            this.a = F;
            int b2 = n42.b(this.f1221a.q0(), 255);
            this.b = n42.b(this.f1221a.q0(), 255);
            a aVar = c62.a;
            if (aVar.a().isLoggable(Level.FINE)) {
                aVar.a().fine(z52.f6183a.c(true, this.c, this.a, b2, this.b));
            }
            int Q = this.f1221a.Q() & Integer.MAX_VALUE;
            this.c = Q;
            if (b2 != 9) {
                throw new IOException(b2 + " != TYPE_CONTINUATION");
            } else if (Q != i) {
                throw new IOException("TYPE_CONTINUATION streamId changed");
            }
        }

        public final void t(int i) {
            this.b = i;
        }

        public final void v(int i) {
            this.d = i;
        }

        public final void w(int i) {
            this.a = i;
        }
    }

    /* renamed from: c62$c */
    public interface c {
        void a(int i, w52 w52);

        void b(int i, int i2, List<x52> list);

        void c(int i, long j);

        void d(int i, w52 w52, q72 q72);

        void e(boolean z, h62 h62);

        void f(boolean z, int i, p72 p72, int i2);

        void g(int i, int i2, int i3, boolean z);

        void h(boolean z, int i, int i2, List<x52> list);

        void i();

        void j(boolean z, int i, int i2);
    }

    static {
        Logger logger = Logger.getLogger(z52.class.getName());
        p12.c(logger, "Logger.getLogger(Http2::class.java.name)");
        f1217a = logger;
    }

    public c62(p72 p72, boolean z) {
        p12.d(p72, "source");
        this.f1219a = p72;
        this.b = z;
        b bVar = new b(p72);
        this.f1218a = bVar;
        this.f1220a = new y52.a(bVar, 4096, 0, 4, (n12) null);
    }

    public final List<x52> E(int i, int i2, int i3, int i4) {
        this.f1218a.v(i);
        b bVar = this.f1218a;
        bVar.w(bVar.a());
        this.f1218a.E(i2);
        this.f1218a.t(i3);
        this.f1218a.F(i4);
        this.f1220a.k();
        return this.f1220a.e();
    }

    public final void F(c cVar, int i, int i2, int i3) {
        if (i3 != 0) {
            int i4 = 0;
            boolean z = (i2 & 1) != 0;
            if ((i2 & 8) != 0) {
                i4 = n42.b(this.f1219a.q0(), 255);
            }
            if ((i2 & 32) != 0) {
                J(cVar, i3);
                i -= 5;
            }
            cVar.h(z, i3, -1, E(a.b(i, i2, i4), i4, i2, i3));
            return;
        }
        throw new IOException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0");
    }

    public final void H(c cVar, int i, int i2, int i3) {
        if (i != 8) {
            throw new IOException("TYPE_PING length != 8: " + i);
        } else if (i3 == 0) {
            int Q = this.f1219a.Q();
            int Q2 = this.f1219a.Q();
            boolean z = true;
            if ((i2 & 1) == 0) {
                z = false;
            }
            cVar.j(z, Q, Q2);
        } else {
            throw new IOException("TYPE_PING streamId != 0");
        }
    }

    public final void J(c cVar, int i) {
        int Q = this.f1219a.Q();
        cVar.g(i, Q & Integer.MAX_VALUE, n42.b(this.f1219a.q0(), 255) + 1, (Q & ((int) 2147483648L)) != 0);
    }

    public final void K(c cVar, int i, int i2, int i3) {
        if (i != 5) {
            throw new IOException("TYPE_PRIORITY length: " + i + " != 5");
        } else if (i3 != 0) {
            J(cVar, i3);
        } else {
            throw new IOException("TYPE_PRIORITY streamId == 0");
        }
    }

    public final void N(c cVar, int i, int i2, int i3) {
        if (i3 != 0) {
            int b2 = (i2 & 8) != 0 ? n42.b(this.f1219a.q0(), 255) : 0;
            cVar.b(i3, this.f1219a.Q() & Integer.MAX_VALUE, E(a.b(i - 4, i2, b2), b2, i2, i3));
            return;
        }
        throw new IOException("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0");
    }

    public final void S(c cVar, int i, int i2, int i3) {
        if (i != 4) {
            throw new IOException("TYPE_RST_STREAM length: " + i + " != 4");
        } else if (i3 != 0) {
            int Q = this.f1219a.Q();
            w52 a2 = w52.a.a(Q);
            if (a2 != null) {
                cVar.a(i3, a2);
                return;
            }
            throw new IOException("TYPE_RST_STREAM unexpected error code: " + Q);
        } else {
            throw new IOException("TYPE_RST_STREAM streamId == 0");
        }
    }

    public final void b0(c cVar, int i, int i2, int i3) {
        int Q;
        if (i3 != 0) {
            throw new IOException("TYPE_SETTINGS streamId != 0");
        } else if ((i2 & 1) != 0) {
            if (i == 0) {
                cVar.i();
                return;
            }
            throw new IOException("FRAME_SIZE_ERROR ack frame should be empty!");
        } else if (i % 6 == 0) {
            h62 h62 = new h62();
            y12 f = c22.f(c22.g(0, i), 6);
            int b2 = f.b();
            int c2 = f.c();
            int d = f.d();
            if (d < 0 ? b2 >= c2 : b2 <= c2) {
                while (true) {
                    int c3 = n42.c(this.f1219a.e0(), 65535);
                    Q = this.f1219a.Q();
                    if (c3 != 2) {
                        if (c3 == 3) {
                            c3 = 4;
                        } else if (c3 == 4) {
                            c3 = 7;
                            if (Q < 0) {
                                throw new IOException("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1");
                            }
                        } else if (c3 == 5 && (Q < 16384 || Q > 16777215)) {
                        }
                    } else if (!(Q == 0 || Q == 1)) {
                        throw new IOException("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1");
                    }
                    h62.h(c3, Q);
                    if (b2 == c2) {
                        break;
                    }
                    b2 += d;
                }
                throw new IOException("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: " + Q);
            }
            cVar.e(false, h62);
        } else {
            throw new IOException("TYPE_SETTINGS length % 6 != 0: " + i);
        }
    }

    public final void c0(c cVar, int i, int i2, int i3) {
        if (i == 4) {
            long d = n42.d(this.f1219a.Q(), 2147483647L);
            if (d != 0) {
                cVar.c(i3, d);
                return;
            }
            throw new IOException("windowSizeIncrement was 0");
        }
        throw new IOException("TYPE_WINDOW_UPDATE length !=4: " + i);
    }

    public void close() {
        this.f1219a.close();
    }

    public final boolean o(boolean z, c cVar) {
        p12.d(cVar, "handler");
        try {
            this.f1219a.O(9);
            int F = n42.F(this.f1219a);
            if (F <= 16384) {
                int b2 = n42.b(this.f1219a.q0(), 255);
                int b3 = n42.b(this.f1219a.q0(), 255);
                int Q = this.f1219a.Q() & Integer.MAX_VALUE;
                Logger logger = f1217a;
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(z52.f6183a.c(true, Q, F, b2, b3));
                }
                if (!z || b2 == 4) {
                    switch (b2) {
                        case 0:
                            v(cVar, F, b3, Q);
                            return true;
                        case 1:
                            F(cVar, F, b3, Q);
                            return true;
                        case 2:
                            K(cVar, F, b3, Q);
                            return true;
                        case 3:
                            S(cVar, F, b3, Q);
                            return true;
                        case 4:
                            b0(cVar, F, b3, Q);
                            return true;
                        case 5:
                            N(cVar, F, b3, Q);
                            return true;
                        case 6:
                            H(cVar, F, b3, Q);
                            return true;
                        case 7:
                            w(cVar, F, b3, Q);
                            return true;
                        case 8:
                            c0(cVar, F, b3, Q);
                            return true;
                        default:
                            this.f1219a.m0((long) F);
                            return true;
                    }
                } else {
                    throw new IOException("Expected a SETTINGS frame but was " + z52.f6183a.b(b2));
                }
            } else {
                throw new IOException("FRAME_SIZE_ERROR: " + F);
            }
        } catch (EOFException unused) {
            return false;
        }
    }

    public final void t(c cVar) {
        p12.d(cVar, "handler");
        if (!this.b) {
            p72 p72 = this.f1219a;
            q72 q72 = z52.a;
            q72 s = p72.s((long) q72.t());
            Logger logger = f1217a;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(n42.q("<< CONNECTION " + s.k(), new Object[0]));
            }
            if (!p12.a(q72, s)) {
                throw new IOException("Expected a connection header but was " + s.w());
            }
        } else if (!o(true, cVar)) {
            throw new IOException("Required SETTINGS preface not received");
        }
    }

    public final void v(c cVar, int i, int i2, int i3) {
        if (i3 != 0) {
            int i4 = 0;
            boolean z = true;
            boolean z2 = (i2 & 1) != 0;
            if ((i2 & 32) == 0) {
                z = false;
            }
            if (!z) {
                if ((i2 & 8) != 0) {
                    i4 = n42.b(this.f1219a.q0(), 255);
                }
                cVar.f(z2, i3, this.f1219a, a.b(i, i2, i4));
                this.f1219a.m0((long) i4);
                return;
            }
            throw new IOException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA");
        }
        throw new IOException("PROTOCOL_ERROR: TYPE_DATA streamId == 0");
    }

    public final void w(c cVar, int i, int i2, int i3) {
        if (i < 8) {
            throw new IOException("TYPE_GOAWAY length < 8: " + i);
        } else if (i3 == 0) {
            int Q = this.f1219a.Q();
            int Q2 = this.f1219a.Q();
            int i4 = i - 8;
            w52 a2 = w52.a.a(Q2);
            if (a2 != null) {
                q72 q72 = q72.f4588a;
                if (i4 > 0) {
                    q72 = this.f1219a.s((long) i4);
                }
                cVar.d(Q, a2, q72);
                return;
            }
            throw new IOException("TYPE_GOAWAY unexpected error code: " + Q2);
        } else {
            throw new IOException("TYPE_GOAWAY streamId != 0");
        }
    }
}
