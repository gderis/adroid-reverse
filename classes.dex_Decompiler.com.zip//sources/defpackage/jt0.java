package defpackage;

import android.location.Location;
import androidx.annotation.RecentlyNonNull;

/* renamed from: jt0  reason: default package */
public interface jt0 {
    void onLocationChanged(@RecentlyNonNull Location location);
}
