package defpackage;

/* renamed from: oo0  reason: default package */
public interface oo0 {
    boolean a();
}
