package defpackage;

/* renamed from: lm0  reason: default package */
public interface lm0 extends mm0 {
    void a(nk0 nk0);

    int b();

    km0 d();

    gk0 e();

    km0 f();
}
