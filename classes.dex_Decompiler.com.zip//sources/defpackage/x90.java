package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.location.LocationRequest;
import java.util.Collections;
import java.util.List;

/* renamed from: x90  reason: default package */
public final class x90 extends w10 {
    public static final Parcelable.Creator<x90> CREATOR = new y90();
    public static final List<f10> a = Collections.emptyList();

    /* renamed from: a  reason: collision with other field name */
    public long f5800a;

    /* renamed from: a  reason: collision with other field name */
    public final LocationRequest f5801a;

    /* renamed from: a  reason: collision with other field name */
    public final String f5802a;
    public final String b;

    /* renamed from: b  reason: collision with other field name */
    public final List<f10> f5803b;

    /* renamed from: b  reason: collision with other field name */
    public final boolean f5804b;
    public String c;

    /* renamed from: c  reason: collision with other field name */
    public final boolean f5805c;
    public final boolean d;
    public final boolean e;
    public boolean f;

    public x90(LocationRequest locationRequest, List<f10> list, String str, boolean z, boolean z2, boolean z3, String str2, boolean z4, boolean z5, String str3, long j) {
        this.f5801a = locationRequest;
        this.f5803b = list;
        this.f5802a = str;
        this.f5804b = z;
        this.f5805c = z2;
        this.d = z3;
        this.b = str2;
        this.e = z4;
        this.f = z5;
        this.c = str3;
        this.f5800a = j;
    }

    public static x90 A0(String str, LocationRequest locationRequest) {
        return new x90(locationRequest, a, (String) null, false, false, false, (String) null, false, false, (String) null, Long.MAX_VALUE);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof x90) {
            x90 x90 = (x90) obj;
            return q10.a(this.f5801a, x90.f5801a) && q10.a(this.f5803b, x90.f5803b) && q10.a(this.f5802a, x90.f5802a) && this.f5804b == x90.f5804b && this.f5805c == x90.f5805c && this.d == x90.d && q10.a(this.b, x90.b) && this.e == x90.e && this.f == x90.f && q10.a(this.c, x90.c);
        }
    }

    public final int hashCode() {
        return this.f5801a.hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f5801a);
        if (this.f5802a != null) {
            sb.append(" tag=");
            sb.append(this.f5802a);
        }
        if (this.b != null) {
            sb.append(" moduleId=");
            sb.append(this.b);
        }
        if (this.c != null) {
            sb.append(" contextAttributionTag=");
            sb.append(this.c);
        }
        sb.append(" hideAppOps=");
        sb.append(this.f5804b);
        sb.append(" clients=");
        sb.append(this.f5803b);
        sb.append(" forceCoarseLocation=");
        sb.append(this.f5805c);
        if (this.d) {
            sb.append(" exemptFromBackgroundThrottle");
        }
        if (this.e) {
            sb.append(" locationSettingsIgnored");
        }
        if (this.f) {
            sb.append(" inaccurateLocationsDelayed");
        }
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.p(parcel, 1, this.f5801a, i, false);
        y10.v(parcel, 5, this.f5803b, false);
        y10.r(parcel, 6, this.f5802a, false);
        y10.c(parcel, 7, this.f5804b);
        y10.c(parcel, 8, this.f5805c);
        y10.c(parcel, 9, this.d);
        y10.r(parcel, 10, this.b, false);
        y10.c(parcel, 11, this.e);
        y10.c(parcel, 12, this.f);
        y10.r(parcel, 13, this.c, false);
        y10.n(parcel, 14, this.f5800a);
        y10.b(parcel, a2);
    }
}
