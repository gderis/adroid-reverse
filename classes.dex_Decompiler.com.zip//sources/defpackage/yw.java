package defpackage;

import androidx.annotation.RecentlyNonNull;
import defpackage.hw;
import defpackage.hw.d;

/* renamed from: yw  reason: default package */
public final class yw<O extends hw.d> {
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final O f6091a;

    /* renamed from: a  reason: collision with other field name */
    public final hw<O> f6092a;

    /* renamed from: a  reason: collision with other field name */
    public final String f6093a;

    /* renamed from: a  reason: collision with other field name */
    public final boolean f6094a = false;

    public yw(hw<O> hwVar, O o, String str) {
        this.f6092a = hwVar;
        this.f6091a = o;
        this.f6093a = str;
        this.a = q10.b(hwVar, o, str);
    }

    @RecentlyNonNull
    public static <O extends hw.d> yw<O> a(@RecentlyNonNull hw<O> hwVar, O o, String str) {
        return new yw<>(hwVar, o, str);
    }

    @RecentlyNonNull
    public final String b() {
        return this.f6092a.d();
    }

    public final boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof yw)) {
            return false;
        }
        yw ywVar = (yw) obj;
        return q10.a(this.f6092a, ywVar.f6092a) && q10.a(this.f6091a, ywVar.f6091a) && q10.a(this.f6093a, ywVar.f6093a);
    }

    public final int hashCode() {
        return this.a;
    }
}
