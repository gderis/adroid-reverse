package defpackage;

import java.util.List;

/* renamed from: hs0  reason: default package */
public final class hs0 extends pb0 {
    public hs0(js0 js0, String str) {
        super("isAndroid");
    }

    public final wb0 a(zg0 zg0, List<wb0> list) {
        return wb0.f;
    }
}
