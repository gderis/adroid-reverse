package defpackage;

import android.view.ViewGroup;

/* renamed from: qd  reason: default package */
public interface qd {
    pd a(ViewGroup viewGroup);
}
