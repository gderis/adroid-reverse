package defpackage;

import android.os.Bundle;
import defpackage.hw;

/* renamed from: iy  reason: default package */
public interface iy {
    void a();

    <A extends hw.b, T extends ax<? extends rw, A>> T d(T t);

    void e(wv wvVar, hw<?> hwVar, boolean z);

    void f();

    void h(int i);

    <A extends hw.b, R extends rw, T extends ax<R, A>> T i(T t);

    void j(Bundle bundle);

    boolean k();
}
