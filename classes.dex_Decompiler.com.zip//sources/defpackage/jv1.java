package defpackage;

import java.util.UUID;

/* renamed from: jv1  reason: default package */
public class jv1 extends ts1 {
    public long a;

    /* renamed from: a  reason: collision with other field name */
    public String f3321a;

    /* renamed from: a  reason: collision with other field name */
    public UUID f3322a;
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
}
