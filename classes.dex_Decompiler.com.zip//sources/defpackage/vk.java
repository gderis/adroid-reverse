package defpackage;

import android.content.Context;

/* renamed from: vk  reason: default package */
public class vk implements hk {
    public static final String a = qj.f("SystemAlarmScheduler");

    /* renamed from: a  reason: collision with other field name */
    public final Context f5584a;

    public vk(Context context) {
        this.f5584a = context.getApplicationContext();
    }

    public void a(String str) {
        this.f5584a.startService(rk.g(this.f5584a, str));
    }

    public boolean b() {
        return true;
    }

    public final void c(im imVar) {
        qj.c().a(a, String.format("Scheduling work with workSpecId %s", new Object[]{imVar.f3085b}), new Throwable[0]);
        this.f5584a.startService(rk.e(this.f5584a, imVar.f3085b));
    }

    public void d(im... imVarArr) {
        for (im c : imVarArr) {
            c(c);
        }
    }
}
