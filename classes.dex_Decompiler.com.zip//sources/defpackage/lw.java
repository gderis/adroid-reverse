package defpackage;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.GoogleApiActivity;
import defpackage.dx;
import defpackage.g10;
import defpackage.hw;
import defpackage.hw.d;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;

/* renamed from: lw  reason: default package */
public class lw<O extends hw.d> {
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f3727a;

    /* renamed from: a  reason: collision with other field name */
    public final Looper f3728a;

    /* renamed from: a  reason: collision with other field name */
    public final dx f3729a;

    /* renamed from: a  reason: collision with other field name */
    public final O f3730a;

    /* renamed from: a  reason: collision with other field name */
    public final hw<O> f3731a;

    /* renamed from: a  reason: collision with other field name */
    public final String f3732a;
    @NotOnlyInitialized

    /* renamed from: a  reason: collision with other field name */
    public final mw f3733a;

    /* renamed from: a  reason: collision with other field name */
    public final nx f3734a;

    /* renamed from: a  reason: collision with other field name */
    public final yw<O> f3735a;

    /* renamed from: lw$a */
    public static class a {
        @RecentlyNonNull
        public static final a a = new C0047a().a();
        @RecentlyNonNull

        /* renamed from: a  reason: collision with other field name */
        public final Looper f3736a;
        @RecentlyNonNull

        /* renamed from: a  reason: collision with other field name */
        public final nx f3737a;

        /* renamed from: lw$a$a  reason: collision with other inner class name */
        public static class C0047a {
            public Looper a;

            /* renamed from: a  reason: collision with other field name */
            public nx f3738a;

            @RecentlyNonNull
            public a a() {
                if (this.f3738a == null) {
                    this.f3738a = new xw();
                }
                if (this.a == null) {
                    this.a = Looper.getMainLooper();
                }
                return new a(this.f3738a, this.a);
            }

            @RecentlyNonNull
            public C0047a b(@RecentlyNonNull Looper looper) {
                s10.k(looper, "Looper must not be null.");
                this.a = looper;
                return this;
            }

            @RecentlyNonNull
            public C0047a c(@RecentlyNonNull nx nxVar) {
                s10.k(nxVar, "StatusExceptionMapper must not be null.");
                this.f3738a = nxVar;
                return this;
            }
        }

        public a(nx nxVar, Account account, Looper looper) {
            this.f3737a = nxVar;
            this.f3736a = looper;
        }
    }

    public lw(@RecentlyNonNull Activity activity, @RecentlyNonNull hw<O> hwVar, @RecentlyNonNull O o, @RecentlyNonNull a aVar) {
        s10.k(activity, "Null activity is not permitted.");
        s10.k(hwVar, "Api must not be null.");
        s10.k(aVar, "Settings must not be null; use Settings.DEFAULT_SETTINGS instead.");
        Context applicationContext = activity.getApplicationContext();
        this.f3727a = applicationContext;
        String o2 = o(activity);
        this.f3732a = o2;
        this.f3731a = hwVar;
        this.f3730a = o;
        this.f3728a = aVar.f3736a;
        yw<O> a2 = yw.a(hwVar, o, o2);
        this.f3735a = a2;
        this.f3733a = new yy(this);
        dx d = dx.d(applicationContext);
        this.f3729a = d;
        this.a = d.m();
        this.f3734a = aVar.f3737a;
        if (!(activity instanceof GoogleApiActivity) && Looper.myLooper() == Looper.getMainLooper()) {
            q00.q(activity, d, a2);
        }
        d.e(this);
    }

    @Deprecated
    public lw(@RecentlyNonNull Activity activity, @RecentlyNonNull hw<O> hwVar, @RecentlyNonNull O o, @RecentlyNonNull nx nxVar) {
        this(activity, hwVar, o, new a.C0047a().c(nxVar).b(activity.getMainLooper()).a());
    }

    public lw(@RecentlyNonNull Context context, @RecentlyNonNull hw<O> hwVar, @RecentlyNonNull O o, @RecentlyNonNull a aVar) {
        s10.k(context, "Null context is not permitted.");
        s10.k(hwVar, "Api must not be null.");
        s10.k(aVar, "Settings must not be null; use Settings.DEFAULT_SETTINGS instead.");
        Context applicationContext = context.getApplicationContext();
        this.f3727a = applicationContext;
        String o2 = o(context);
        this.f3732a = o2;
        this.f3731a = hwVar;
        this.f3730a = o;
        this.f3728a = aVar.f3736a;
        this.f3735a = yw.a(hwVar, o, o2);
        this.f3733a = new yy(this);
        dx d = dx.d(applicationContext);
        this.f3729a = d;
        this.a = d.m();
        this.f3734a = aVar.f3737a;
        d.e(this);
    }

    public static String o(Object obj) {
        if (!n40.k()) {
            return null;
        }
        try {
            return (String) Context.class.getMethod("getAttributionTag", new Class[0]).invoke(obj, new Object[0]);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            return null;
        }
    }

    @RecentlyNonNull
    public mw b() {
        return this.f3733a;
    }

    @RecentlyNonNull
    public g10.a c() {
        Account account;
        GoogleSignInAccount a2;
        GoogleSignInAccount a3;
        g10.a aVar = new g10.a();
        O o = this.f3730a;
        if (!(o instanceof hw.d.b) || (a3 = ((hw.d.b) o).a()) == null) {
            O o2 = this.f3730a;
            account = o2 instanceof hw.d.a ? ((hw.d.a) o2).b() : null;
        } else {
            account = a3.A0();
        }
        g10.a c = aVar.c(account);
        O o3 = this.f3730a;
        return c.e((!(o3 instanceof hw.d.b) || (a2 = ((hw.d.b) o3).a()) == null) ? Collections.emptySet() : a2.I0()).d(this.f3727a.getClass().getName()).b(this.f3727a.getPackageName());
    }

    @RecentlyNonNull
    public <TResult, A extends hw.b> n81<TResult> d(@RecentlyNonNull ox<A, TResult> oxVar) {
        return n(2, oxVar);
    }

    @RecentlyNonNull
    public <A extends hw.b, T extends ax<? extends rw, A>> T e(@RecentlyNonNull T t) {
        return l(0, t);
    }

    @RecentlyNonNull
    public <A extends hw.b, T extends ax<? extends rw, A>> T f(@RecentlyNonNull T t) {
        return l(1, t);
    }

    @RecentlyNonNull
    public yw<O> g() {
        return this.f3735a;
    }

    @RecentlyNullable
    public String h() {
        return this.f3732a;
    }

    @RecentlyNonNull
    public Looper i() {
        return this.f3728a;
    }

    public final int j() {
        return this.a;
    }

    public final hw.f k(Looper looper, dx.a<O> aVar) {
        Looper looper2 = looper;
        hw.f c = ((hw.a) s10.j(this.f3731a.b())).c(this.f3727a, looper2, c().a(), this.f3730a, aVar, aVar);
        String h = h();
        if (h != null && (c instanceof e10)) {
            ((e10) c).R(h);
        }
        if (h != null && (c instanceof ix)) {
            ((ix) c).w(h);
        }
        return c;
    }

    public final <A extends hw.b, T extends ax<? extends rw, A>> T l(int i, T t) {
        t.q();
        this.f3729a.f(this, i, t);
        return t;
    }

    public final kz m(Context context, Handler handler) {
        return new kz(context, handler, c().a());
    }

    public final <TResult, A extends hw.b> n81<TResult> n(int i, ox<A, TResult> oxVar) {
        o81 o81 = new o81();
        this.f3729a.g(this, i, oxVar, o81, this.f3734a);
        return o81.a();
    }
}
