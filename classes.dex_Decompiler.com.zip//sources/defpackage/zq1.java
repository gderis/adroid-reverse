package defpackage;

import java.util.Calendar;

/* renamed from: zq1  reason: default package */
public class zq1 extends dr1<Long, Calendar> {
    /* renamed from: b */
    public Long a(Calendar calendar) {
        if (calendar == null) {
            return null;
        }
        return Long.valueOf(calendar.getTimeInMillis());
    }
}
