package defpackage;

import defpackage.ls;
import java.util.Objects;
import java.util.Set;

/* renamed from: js  reason: default package */
public final class js extends ls.b {
    public final long a;

    /* renamed from: a  reason: collision with other field name */
    public final Set<ls.c> f3305a;
    public final long b;

    /* renamed from: js$b */
    public static final class b extends ls.b.a {
        public Long a;

        /* renamed from: a  reason: collision with other field name */
        public Set<ls.c> f3306a;
        public Long b;

        public ls.b a() {
            String str = "";
            if (this.a == null) {
                str = str + " delta";
            }
            if (this.b == null) {
                str = str + " maxAllowedDelay";
            }
            if (this.f3306a == null) {
                str = str + " flags";
            }
            if (str.isEmpty()) {
                return new js(this.a.longValue(), this.b.longValue(), this.f3306a);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        public ls.b.a b(long j) {
            this.a = Long.valueOf(j);
            return this;
        }

        public ls.b.a c(Set<ls.c> set) {
            Objects.requireNonNull(set, "Null flags");
            this.f3306a = set;
            return this;
        }

        public ls.b.a d(long j) {
            this.b = Long.valueOf(j);
            return this;
        }
    }

    public js(long j, long j2, Set<ls.c> set) {
        this.a = j;
        this.b = j2;
        this.f3305a = set;
    }

    public long b() {
        return this.a;
    }

    public Set<ls.c> c() {
        return this.f3305a;
    }

    public long d() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ls.b)) {
            return false;
        }
        ls.b bVar = (ls.b) obj;
        return this.a == bVar.b() && this.b == bVar.d() && this.f3305a.equals(bVar.c());
    }

    public int hashCode() {
        long j = this.a;
        long j2 = this.b;
        return this.f3305a.hashCode() ^ ((((((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003) ^ ((int) (j2 ^ (j2 >>> 32)))) * 1000003);
    }

    public String toString() {
        return "ConfigValue{delta=" + this.a + ", maxAllowedDelay=" + this.b + ", flags=" + this.f3305a + "}";
    }
}
