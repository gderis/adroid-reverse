package defpackage;

import defpackage.rl1;

/* renamed from: rl1  reason: default package */
public interface rl1<T extends rl1<T>> {
    <U> T a(Class<U> cls, ml1<? super U> ml1);
}
