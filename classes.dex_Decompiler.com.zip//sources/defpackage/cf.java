package defpackage;

import androidx.recyclerview.widget.RecyclerView;
import defpackage.jf;
import java.util.ArrayList;
import java.util.List;

/* renamed from: cf  reason: default package */
public class cf implements jf.a {
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public final a f1253a;

    /* renamed from: a  reason: collision with other field name */
    public Runnable f1254a;

    /* renamed from: a  reason: collision with other field name */
    public final ArrayList<b> f1255a;

    /* renamed from: a  reason: collision with other field name */
    public final jf f1256a;

    /* renamed from: a  reason: collision with other field name */
    public z9<b> f1257a;

    /* renamed from: a  reason: collision with other field name */
    public final boolean f1258a;
    public final ArrayList<b> b;

    /* renamed from: cf$a */
    public interface a {
        void a(b bVar);

        void b(int i, int i2, Object obj);

        void c(int i, int i2);

        RecyclerView.d0 d(int i);

        void e(int i, int i2);

        void f(int i, int i2);

        void g(b bVar);

        void h(int i, int i2);
    }

    /* renamed from: cf$b */
    public static class b {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public Object f1259a;
        public int b;
        public int c;

        public b(int i, int i2, int i3, Object obj) {
            this.a = i;
            this.b = i2;
            this.c = i3;
            this.f1259a = obj;
        }

        public String a() {
            int i = this.a;
            return i != 1 ? i != 2 ? i != 4 ? i != 8 ? "??" : "mv" : "up" : "rm" : "add";
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || b.class != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            int i = this.a;
            if (i != bVar.a) {
                return false;
            }
            if (i == 8 && Math.abs(this.c - this.b) == 1 && this.c == bVar.b && this.b == bVar.c) {
                return true;
            }
            if (this.c != bVar.c || this.b != bVar.b) {
                return false;
            }
            Object obj2 = this.f1259a;
            Object obj3 = bVar.f1259a;
            if (obj2 != null) {
                if (!obj2.equals(obj3)) {
                    return false;
                }
            } else if (obj3 != null) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (((this.a * 31) + this.b) * 31) + this.c;
        }

        public String toString() {
            return Integer.toHexString(System.identityHashCode(this)) + "[" + a() + ",s:" + this.b + "c:" + this.c + ",p:" + this.f1259a + "]";
        }
    }

    public cf(a aVar) {
        this(aVar, false);
    }

    public cf(a aVar, boolean z) {
        this.f1257a = new aa(30);
        this.f1255a = new ArrayList<>();
        this.b = new ArrayList<>();
        this.a = 0;
        this.f1253a = aVar;
        this.f1258a = z;
        this.f1256a = new jf(this);
    }

    public void a(b bVar) {
        if (!this.f1258a) {
            bVar.f1259a = null;
            this.f1257a.a(bVar);
        }
    }

    public b b(int i, int i2, int i3, Object obj) {
        b b2 = this.f1257a.b();
        if (b2 == null) {
            return new b(i, i2, i3, obj);
        }
        b2.a = i;
        b2.b = i2;
        b2.c = i3;
        b2.f1259a = obj;
        return b2;
    }

    public final void c(b bVar) {
        r(bVar);
    }

    public final void d(b bVar) {
        r(bVar);
    }

    public int e(int i) {
        int size = this.f1255a.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f1255a.get(i2);
            int i3 = bVar.a;
            if (i3 != 1) {
                if (i3 == 2) {
                    int i4 = bVar.b;
                    if (i4 <= i) {
                        int i5 = bVar.c;
                        if (i4 + i5 > i) {
                            return -1;
                        }
                        i -= i5;
                    } else {
                        continue;
                    }
                } else if (i3 == 8) {
                    int i6 = bVar.b;
                    if (i6 == i) {
                        i = bVar.c;
                    } else {
                        if (i6 < i) {
                            i--;
                        }
                        if (bVar.c <= i) {
                            i++;
                        }
                    }
                }
            } else if (bVar.b <= i) {
                i += bVar.c;
            }
        }
        return i;
    }

    public final void f(b bVar) {
        char c;
        boolean z;
        boolean z2;
        int i = bVar.b;
        int i2 = bVar.c + i;
        char c2 = 65535;
        int i3 = i;
        int i4 = 0;
        while (i3 < i2) {
            if (this.f1253a.d(i3) != null || h(i3)) {
                if (c2 == 0) {
                    k(b(2, i, i4, (Object) null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                c = 1;
            } else {
                if (c2 == 1) {
                    r(b(2, i, i4, (Object) null));
                    z = true;
                } else {
                    z = false;
                }
                c = 0;
            }
            if (z) {
                i3 -= i4;
                i2 -= i4;
                i4 = 1;
            } else {
                i4++;
            }
            i3++;
            c2 = c;
        }
        if (i4 != bVar.c) {
            a(bVar);
            bVar = b(2, i, i4, (Object) null);
        }
        if (c2 == 0) {
            k(bVar);
        } else {
            r(bVar);
        }
    }

    public final void g(b bVar) {
        int i = bVar.b;
        int i2 = bVar.c + i;
        int i3 = i;
        char c = 65535;
        int i4 = 0;
        while (i < i2) {
            if (this.f1253a.d(i) != null || h(i)) {
                if (c == 0) {
                    k(b(4, i3, i4, bVar.f1259a));
                    i3 = i;
                    i4 = 0;
                }
                c = 1;
            } else {
                if (c == 1) {
                    r(b(4, i3, i4, bVar.f1259a));
                    i3 = i;
                    i4 = 0;
                }
                c = 0;
            }
            i4++;
            i++;
        }
        if (i4 != bVar.c) {
            Object obj = bVar.f1259a;
            a(bVar);
            bVar = b(4, i3, i4, obj);
        }
        if (c == 0) {
            k(bVar);
        } else {
            r(bVar);
        }
    }

    public final boolean h(int i) {
        int size = this.b.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.b.get(i2);
            int i3 = bVar.a;
            if (i3 == 8) {
                if (n(bVar.c, i2 + 1) == i) {
                    return true;
                }
            } else if (i3 == 1) {
                int i4 = bVar.b;
                int i5 = bVar.c + i4;
                while (i4 < i5) {
                    if (n(i4, i2 + 1) == i) {
                        return true;
                    }
                    i4++;
                }
                continue;
            } else {
                continue;
            }
        }
        return false;
    }

    public void i() {
        int size = this.b.size();
        for (int i = 0; i < size; i++) {
            this.f1253a.g(this.b.get(i));
        }
        t(this.b);
        this.a = 0;
    }

    public void j() {
        i();
        int size = this.f1255a.size();
        for (int i = 0; i < size; i++) {
            b bVar = this.f1255a.get(i);
            int i2 = bVar.a;
            if (i2 == 1) {
                this.f1253a.g(bVar);
                this.f1253a.e(bVar.b, bVar.c);
            } else if (i2 == 2) {
                this.f1253a.g(bVar);
                this.f1253a.c(bVar.b, bVar.c);
            } else if (i2 == 4) {
                this.f1253a.g(bVar);
                this.f1253a.b(bVar.b, bVar.c, bVar.f1259a);
            } else if (i2 == 8) {
                this.f1253a.g(bVar);
                this.f1253a.f(bVar.b, bVar.c);
            }
            Runnable runnable = this.f1254a;
            if (runnable != null) {
                runnable.run();
            }
        }
        t(this.f1255a);
        this.a = 0;
    }

    public final void k(b bVar) {
        int i;
        int i2 = bVar.a;
        if (i2 == 1 || i2 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int v = v(bVar.b, i2);
        int i3 = bVar.b;
        int i4 = bVar.a;
        if (i4 == 2) {
            i = 0;
        } else if (i4 == 4) {
            i = 1;
        } else {
            throw new IllegalArgumentException("op should be remove or update." + bVar);
        }
        int i5 = 1;
        for (int i6 = 1; i6 < bVar.c; i6++) {
            int v2 = v(bVar.b + (i * i6), bVar.a);
            int i7 = bVar.a;
            if (i7 == 2 ? v2 == v : i7 == 4 && v2 == v + 1) {
                i5++;
            } else {
                b b2 = b(i7, v, i5, bVar.f1259a);
                l(b2, i3);
                a(b2);
                if (bVar.a == 4) {
                    i3 += i5;
                }
                v = v2;
                i5 = 1;
            }
        }
        Object obj = bVar.f1259a;
        a(bVar);
        if (i5 > 0) {
            b b3 = b(bVar.a, v, i5, obj);
            l(b3, i3);
            a(b3);
        }
    }

    public void l(b bVar, int i) {
        this.f1253a.a(bVar);
        int i2 = bVar.a;
        if (i2 == 2) {
            this.f1253a.c(i, bVar.c);
        } else if (i2 == 4) {
            this.f1253a.b(i, bVar.c, bVar.f1259a);
        } else {
            throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
        }
    }

    public int m(int i) {
        return n(i, 0);
    }

    public int n(int i, int i2) {
        int size = this.b.size();
        while (i2 < size) {
            b bVar = this.b.get(i2);
            int i3 = bVar.a;
            if (i3 == 8) {
                int i4 = bVar.b;
                if (i4 == i) {
                    i = bVar.c;
                } else {
                    if (i4 < i) {
                        i--;
                    }
                    if (bVar.c <= i) {
                        i++;
                    }
                }
            } else {
                int i5 = bVar.b;
                if (i5 > i) {
                    continue;
                } else if (i3 == 2) {
                    int i6 = bVar.c;
                    if (i < i5 + i6) {
                        return -1;
                    }
                    i -= i6;
                } else if (i3 == 1) {
                    i += bVar.c;
                }
            }
            i2++;
        }
        return i;
    }

    public boolean o(int i) {
        return (i & this.a) != 0;
    }

    public boolean p() {
        return this.f1255a.size() > 0;
    }

    public boolean q() {
        return !this.b.isEmpty() && !this.f1255a.isEmpty();
    }

    public final void r(b bVar) {
        this.b.add(bVar);
        int i = bVar.a;
        if (i == 1) {
            this.f1253a.e(bVar.b, bVar.c);
        } else if (i == 2) {
            this.f1253a.h(bVar.b, bVar.c);
        } else if (i == 4) {
            this.f1253a.b(bVar.b, bVar.c, bVar.f1259a);
        } else if (i == 8) {
            this.f1253a.f(bVar.b, bVar.c);
        } else {
            throw new IllegalArgumentException("Unknown update op type for " + bVar);
        }
    }

    public void s() {
        this.f1256a.b(this.f1255a);
        int size = this.f1255a.size();
        for (int i = 0; i < size; i++) {
            b bVar = this.f1255a.get(i);
            int i2 = bVar.a;
            if (i2 == 1) {
                c(bVar);
            } else if (i2 == 2) {
                f(bVar);
            } else if (i2 == 4) {
                g(bVar);
            } else if (i2 == 8) {
                d(bVar);
            }
            Runnable runnable = this.f1254a;
            if (runnable != null) {
                runnable.run();
            }
        }
        this.f1255a.clear();
    }

    public void t(List<b> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            a(list.get(i));
        }
        list.clear();
    }

    public void u() {
        t(this.f1255a);
        t(this.b);
        this.a = 0;
    }

    public final int v(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        for (int size = this.b.size() - 1; size >= 0; size--) {
            b bVar = this.b.get(size);
            int i9 = bVar.a;
            if (i9 == 8) {
                int i10 = bVar.b;
                int i11 = bVar.c;
                if (i10 < i11) {
                    i5 = i10;
                    i4 = i11;
                } else {
                    i4 = i10;
                    i5 = i11;
                }
                if (i < i5 || i > i4) {
                    if (i < i10) {
                        if (i2 == 1) {
                            bVar.b = i10 + 1;
                            i6 = i11 + 1;
                        } else if (i2 == 2) {
                            bVar.b = i10 - 1;
                            i6 = i11 - 1;
                        }
                        bVar.c = i6;
                    }
                } else if (i5 == i10) {
                    if (i2 == 1) {
                        i8 = i11 + 1;
                    } else {
                        if (i2 == 2) {
                            i8 = i11 - 1;
                        }
                        i++;
                    }
                    bVar.c = i8;
                    i++;
                } else {
                    if (i2 == 1) {
                        i7 = i10 + 1;
                    } else {
                        if (i2 == 2) {
                            i7 = i10 - 1;
                        }
                        i--;
                    }
                    bVar.b = i7;
                    i--;
                }
            } else {
                int i12 = bVar.b;
                if (i12 > i) {
                    if (i2 == 1) {
                        i3 = i12 + 1;
                    } else if (i2 == 2) {
                        i3 = i12 - 1;
                    }
                    bVar.b = i3;
                } else if (i9 == 1) {
                    i -= bVar.c;
                } else if (i9 == 2) {
                    i += bVar.c;
                }
            }
        }
        for (int size2 = this.b.size() - 1; size2 >= 0; size2--) {
            b bVar2 = this.b.get(size2);
            if (bVar2.a == 8) {
                int i13 = bVar2.c;
                if (i13 != bVar2.b && i13 >= 0) {
                }
            } else if (bVar2.c > 0) {
            }
            this.b.remove(size2);
            a(bVar2);
        }
        return i;
    }
}
