package defpackage;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.text.TextUtils;
import defpackage.lj1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/* renamed from: uh1  reason: default package */
public class uh1 {
    public static final String a = String.format(Locale.US, "Crashlytics Android SDK/%s", new Object[]{"18.0.0"});

    /* renamed from: a  reason: collision with other field name */
    public static final Map<String, Integer> f5377a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f5378a;

    /* renamed from: a  reason: collision with other field name */
    public final ci1 f5379a;

    /* renamed from: a  reason: collision with other field name */
    public final cl1 f5380a;

    /* renamed from: a  reason: collision with other field name */
    public final jh1 f5381a;

    static {
        HashMap hashMap = new HashMap();
        f5377a = hashMap;
        hashMap.put("armeabi", 5);
        hashMap.put("armeabi-v7a", 6);
        hashMap.put("arm64-v8a", 9);
        hashMap.put("x86", 0);
        hashMap.put("x86_64", 1);
    }

    public uh1(Context context, ci1 ci1, jh1 jh1, cl1 cl1) {
        this.f5378a = context;
        this.f5379a = ci1;
        this.f5381a = jh1;
        this.f5380a = cl1;
    }

    public static int d() {
        Integer num;
        String str = Build.CPU_ABI;
        if (!TextUtils.isEmpty(str) && (num = f5377a.get(str.toLowerCase(Locale.US))) != null) {
            return num.intValue();
        }
        return 7;
    }

    public final lj1.a a() {
        return lj1.b().h("18.0.0").d(this.f5381a.f3279a).e(this.f5379a.a()).b(this.f5381a.e).c(this.f5381a.f).g(4);
    }

    public lj1.d.C0035d b(Throwable th, Thread thread, String str, long j, int i, int i2, boolean z) {
        int i3 = this.f5378a.getResources().getConfiguration().orientation;
        Throwable th2 = th;
        String str2 = str;
        long j2 = j;
        return lj1.d.C0035d.a().f(str).e(j).b(g(i3, new dl1(th, this.f5380a), thread, i, i2, z)).c(h(i3)).a();
    }

    public lj1 c(String str, long j) {
        return a().i(o(str, j)).a();
    }

    public final lj1.d.C0035d.a.b.C0037a e() {
        return lj1.d.C0035d.a.b.C0037a.a().b(0).d(0).c(this.f5381a.d).e(this.f5381a.b).a();
    }

    public final mj1<lj1.d.C0035d.a.b.C0037a> f() {
        return mj1.c(e());
    }

    public final lj1.d.C0035d.a g(int i, dl1 dl1, Thread thread, int i2, int i3, boolean z) {
        Boolean bool;
        ActivityManager.RunningAppProcessInfo j = ph1.j(this.f5381a.d, this.f5378a);
        if (j != null) {
            bool = Boolean.valueOf(j.importance != 100);
        } else {
            bool = null;
        }
        return lj1.d.C0035d.a.a().b(bool).e(i).d(k(dl1, thread, i2, i3, z)).a();
    }

    public final lj1.d.C0035d.c h(int i) {
        mh1 a2 = mh1.a(this.f5378a);
        Float b = a2.b();
        Double valueOf = b != null ? Double.valueOf(b.doubleValue()) : null;
        int c = a2.c();
        boolean o = ph1.o(this.f5378a);
        return lj1.d.C0035d.c.a().b(valueOf).c(c).f(o).e(i).g(ph1.s() - ph1.a(this.f5378a)).d(ph1.b(Environment.getDataDirectory().getPath())).a();
    }

    public final lj1.d.C0035d.a.b.c i(dl1 dl1, int i, int i2) {
        return j(dl1, i, i2, 0);
    }

    public final lj1.d.C0035d.a.b.c j(dl1 dl1, int i, int i2, int i3) {
        String str = dl1.b;
        String str2 = dl1.f2026a;
        StackTraceElement[] stackTraceElementArr = dl1.f2027a;
        int i4 = 0;
        if (stackTraceElementArr == null) {
            stackTraceElementArr = new StackTraceElement[0];
        }
        dl1 dl12 = dl1.a;
        if (i3 >= i2) {
            dl1 dl13 = dl12;
            while (dl13 != null) {
                dl13 = dl13.a;
                i4++;
            }
        }
        lj1.d.C0035d.a.b.c.C0040a d = lj1.d.C0035d.a.b.c.a().f(str).e(str2).c(mj1.b(m(stackTraceElementArr, i))).d(i4);
        if (dl12 != null && i4 == 0) {
            d.b(j(dl12, i, i2, i3 + 1));
        }
        return d.a();
    }

    public final lj1.d.C0035d.a.b k(dl1 dl1, Thread thread, int i, int i2, boolean z) {
        return lj1.d.C0035d.a.b.a().e(u(dl1, thread, i, z)).c(i(dl1, i, i2)).d(r()).b(f()).a();
    }

    public final lj1.d.C0035d.a.b.e.C0044b l(StackTraceElement stackTraceElement, lj1.d.C0035d.a.b.e.C0044b.C0045a aVar) {
        long j = 0;
        long max = stackTraceElement.isNativeMethod() ? Math.max((long) stackTraceElement.getLineNumber(), 0) : 0;
        String str = stackTraceElement.getClassName() + "." + stackTraceElement.getMethodName();
        String fileName = stackTraceElement.getFileName();
        if (!stackTraceElement.isNativeMethod() && stackTraceElement.getLineNumber() > 0) {
            j = (long) stackTraceElement.getLineNumber();
        }
        return aVar.e(max).f(str).b(fileName).d(j).a();
    }

    public final mj1<lj1.d.C0035d.a.b.e.C0044b> m(StackTraceElement[] stackTraceElementArr, int i) {
        ArrayList arrayList = new ArrayList();
        for (StackTraceElement l : stackTraceElementArr) {
            arrayList.add(l(l, lj1.d.C0035d.a.b.e.C0044b.a().c(i)));
        }
        return mj1.b(arrayList);
    }

    public final lj1.d.a n() {
        lj1.d.a.C0034a f = lj1.d.a.a().e(this.f5379a.f()).g(this.f5381a.e).d(this.f5381a.f).f(this.f5379a.a());
        String a2 = this.f5381a.a.a();
        if (a2 != null) {
            f.b("Unity").c(a2);
        }
        return f.a();
    }

    public final lj1.d o(String str, long j) {
        return lj1.d.a().l(j).i(str).g(a).b(n()).k(q()).d(p()).h(3).a();
    }

    public final lj1.d.c p() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        int d = d();
        int availableProcessors = Runtime.getRuntime().availableProcessors();
        long s = ph1.s();
        long blockCount = ((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize());
        boolean x = ph1.x(this.f5378a);
        int m = ph1.m(this.f5378a);
        String str = Build.MANUFACTURER;
        return lj1.d.c.a().b(d).f(Build.MODEL).c(availableProcessors).h(s).d(blockCount).i(x).j(m).e(str).g(Build.PRODUCT).a();
    }

    public final lj1.d.e q() {
        return lj1.d.e.a().d(3).e(Build.VERSION.RELEASE).b(Build.VERSION.CODENAME).c(ph1.y(this.f5378a)).a();
    }

    public final lj1.d.C0035d.a.b.C0041d r() {
        return lj1.d.C0035d.a.b.C0041d.a().d("0").c("0").b(0).a();
    }

    public final lj1.d.C0035d.a.b.e s(Thread thread, StackTraceElement[] stackTraceElementArr) {
        return t(thread, stackTraceElementArr, 0);
    }

    public final lj1.d.C0035d.a.b.e t(Thread thread, StackTraceElement[] stackTraceElementArr, int i) {
        return lj1.d.C0035d.a.b.e.a().d(thread.getName()).c(i).b(mj1.b(m(stackTraceElementArr, i))).a();
    }

    public final mj1<lj1.d.C0035d.a.b.e> u(dl1 dl1, Thread thread, int i, boolean z) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(t(thread, dl1.f2027a, i));
        if (z) {
            for (Map.Entry next : Thread.getAllStackTraces().entrySet()) {
                Thread thread2 = (Thread) next.getKey();
                if (!thread2.equals(thread)) {
                    arrayList.add(s(thread2, this.f5380a.a((StackTraceElement[]) next.getValue())));
                }
            }
        }
        return mj1.b(arrayList);
    }
}
