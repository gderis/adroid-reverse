package defpackage;

/* renamed from: uf0  reason: default package */
public enum uf0 implements il0 {
    UNKNOWN_MATCH_TYPE(0),
    REGEXP(1),
    BEGINS_WITH(2),
    ENDS_WITH(3),
    PARTIAL(4),
    EXACT(5),
    IN_LIST(6);
    
    public static final jl0<uf0> a = null;

    /* renamed from: a  reason: collision with other field name */
    public final int f5370a;

    /* access modifiers changed from: public */
    static {
        a = new sf0();
    }

    /* access modifiers changed from: public */
    uf0(int i) {
        this.f5370a = i;
    }

    public static uf0 a(int i) {
        switch (i) {
            case 0:
                return UNKNOWN_MATCH_TYPE;
            case 1:
                return REGEXP;
            case 2:
                return BEGINS_WITH;
            case 3:
                return ENDS_WITH;
            case 4:
                return PARTIAL;
            case 5:
                return EXACT;
            case 6:
                return IN_LIST;
            default:
                return null;
        }
    }

    public static kl0 b() {
        return tf0.a;
    }

    public final String toString() {
        return "<" + uf0.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f5370a + " name=" + name() + '>';
    }
}
