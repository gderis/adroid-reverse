package defpackage;

/* renamed from: nq0  reason: default package */
public final class nq0 implements mq0 {
    public static final ui0<Boolean> a;
    public static final ui0<Boolean> b;

    static {
        si0 si0 = new si0(li0.a("com.google.android.gms.measurement"));
        a = si0.b("measurement.sdk.screen.manual_screen_view_logging", true);
        b = si0.b("measurement.sdk.screen.disabling_automatic_reporting", true);
    }

    public final boolean a() {
        return true;
    }

    public final boolean b() {
        return a.e().booleanValue();
    }

    public final boolean c() {
        return b.e().booleanValue();
    }
}
