package defpackage;

import android.database.ContentObserver;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: jr1  reason: default package */
public class jr1 extends ContentObserver {
    public static final AtomicInteger a = new AtomicInteger(0);

    /* renamed from: a  reason: collision with other field name */
    public static boolean f3304a = false;

    public static boolean a() {
        return f3304a || a.get() > 0;
    }
}
