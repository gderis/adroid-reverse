package defpackage;

import android.content.Context;
import android.content.res.ColorStateList;
import android.util.AttributeSet;

/* renamed from: qc1  reason: default package */
public class qc1 extends n2 {
    public static final int a = w91.Widget_MaterialComponents_CompoundButton_RadioButton;

    /* renamed from: a  reason: collision with other field name */
    public static final int[][] f4620a = {new int[]{16842910, 16842912}, new int[]{16842910, -16842912}, new int[]{-16842910, 16842912}, new int[]{-16842910, -16842912}};

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f4621a;
    public boolean b;

    public qc1(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o91.radioButtonStyle);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public qc1(android.content.Context r8, android.util.AttributeSet r9, int r10) {
        /*
            r7 = this;
            int r4 = a
            android.content.Context r8 = defpackage.ee1.c(r8, r9, r10, r4)
            r7.<init>(r8, r9, r10)
            android.content.Context r8 = r7.getContext()
            int[] r2 = defpackage.x91.MaterialRadioButton
            r6 = 0
            int[] r5 = new int[r6]
            r0 = r8
            r1 = r9
            r3 = r10
            android.content.res.TypedArray r9 = defpackage.mc1.h(r0, r1, r2, r3, r4, r5)
            int r10 = defpackage.x91.MaterialRadioButton_buttonTint
            boolean r0 = r9.hasValue(r10)
            if (r0 == 0) goto L_0x0028
            android.content.res.ColorStateList r8 = defpackage.tc1.a(r8, r9, r10)
            defpackage.sb.c(r7, r8)
        L_0x0028:
            int r8 = defpackage.x91.MaterialRadioButton_useMaterialThemeColors
            boolean r8 = r9.getBoolean(r8, r6)
            r7.b = r8
            r9.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.qc1.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    private ColorStateList getMaterialThemeColorsTintList() {
        if (this.f4621a == null) {
            int c = ab1.c(this, o91.colorControlActivated);
            int c2 = ab1.c(this, o91.colorOnSurface);
            int c3 = ab1.c(this, o91.colorSurface);
            int[][] iArr = f4620a;
            int[] iArr2 = new int[iArr.length];
            iArr2[0] = ab1.f(c3, c, 1.0f);
            iArr2[1] = ab1.f(c3, c2, 0.54f);
            iArr2[2] = ab1.f(c3, c2, 0.38f);
            iArr2[3] = ab1.f(c3, c2, 0.38f);
            this.f4621a = new ColorStateList(iArr, iArr2);
        }
        return this.f4621a;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.b && sb.b(this) == null) {
            setUseMaterialThemeColors(true);
        }
    }

    public void setUseMaterialThemeColors(boolean z) {
        this.b = z;
        sb.c(this, z ? getMaterialThemeColorsTintList() : null);
    }
}
