package defpackage;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import defpackage.i1;
import defpackage.u0;
import defpackage.y;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* renamed from: k0  reason: default package */
public class k0 extends y implements ActionBarOverlayLayout.d {
    public static final Interpolator a = new AccelerateInterpolator();
    public static final Interpolator b = new DecelerateInterpolator();

    /* renamed from: a  reason: collision with other field name */
    public int f3328a = -1;

    /* renamed from: a  reason: collision with other field name */
    public a1 f3329a;

    /* renamed from: a  reason: collision with other field name */
    public Activity f3330a;

    /* renamed from: a  reason: collision with other field name */
    public Context f3331a;

    /* renamed from: a  reason: collision with other field name */
    public View f3332a;

    /* renamed from: a  reason: collision with other field name */
    public ActionBarContainer f3333a;

    /* renamed from: a  reason: collision with other field name */
    public ActionBarContextView f3334a;

    /* renamed from: a  reason: collision with other field name */
    public ActionBarOverlayLayout f3335a;

    /* renamed from: a  reason: collision with other field name */
    public final db f3336a = new a();

    /* renamed from: a  reason: collision with other field name */
    public final fb f3337a = new c();

    /* renamed from: a  reason: collision with other field name */
    public ArrayList<?> f3338a = new ArrayList<>();

    /* renamed from: a  reason: collision with other field name */
    public d f3339a;

    /* renamed from: a  reason: collision with other field name */
    public l3 f3340a;

    /* renamed from: a  reason: collision with other field name */
    public u0.a f3341a;

    /* renamed from: a  reason: collision with other field name */
    public u0 f3342a;

    /* renamed from: a  reason: collision with other field name */
    public z2 f3343a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f3344a;

    /* renamed from: b  reason: collision with other field name */
    public int f3345b = 0;

    /* renamed from: b  reason: collision with other field name */
    public Context f3346b;

    /* renamed from: b  reason: collision with other field name */
    public final db f3347b = new b();

    /* renamed from: b  reason: collision with other field name */
    public ArrayList<y.b> f3348b = new ArrayList<>();

    /* renamed from: b  reason: collision with other field name */
    public boolean f3349b;
    public boolean c;
    public boolean d = true;
    public boolean e;
    public boolean f;
    public boolean g;
    public boolean h = true;
    public boolean i;
    public boolean j;

    /* renamed from: k0$a */
    public class a extends eb {
        public a() {
        }

        public void b(View view) {
            View view2;
            k0 k0Var = k0.this;
            if (k0Var.d && (view2 = k0Var.f3332a) != null) {
                view2.setTranslationY(0.0f);
                k0.this.f3333a.setTranslationY(0.0f);
            }
            k0.this.f3333a.setVisibility(8);
            k0.this.f3333a.setTransitioning(false);
            k0 k0Var2 = k0.this;
            k0Var2.f3329a = null;
            k0Var2.x();
            ActionBarOverlayLayout actionBarOverlayLayout = k0.this.f3335a;
            if (actionBarOverlayLayout != null) {
                ya.l0(actionBarOverlayLayout);
            }
        }
    }

    /* renamed from: k0$b */
    public class b extends eb {
        public b() {
        }

        public void b(View view) {
            k0 k0Var = k0.this;
            k0Var.f3329a = null;
            k0Var.f3333a.requestLayout();
        }
    }

    /* renamed from: k0$c */
    public class c implements fb {
        public c() {
        }

        public void a(View view) {
            ((View) k0.this.f3333a.getParent()).invalidate();
        }
    }

    /* renamed from: k0$d */
    public class d extends u0 implements i1.a {
        public final Context a;

        /* renamed from: a  reason: collision with other field name */
        public final i1 f3350a;

        /* renamed from: a  reason: collision with other field name */
        public WeakReference<View> f3351a;

        /* renamed from: a  reason: collision with other field name */
        public u0.a f3353a;

        public d(Context context, u0.a aVar) {
            this.a = context;
            this.f3353a = aVar;
            i1 S = new i1(context).S(1);
            this.f3350a = S;
            S.R(this);
        }

        public void a(i1 i1Var) {
            if (this.f3353a != null) {
                k();
                k0.this.f3334a.l();
            }
        }

        public boolean b(i1 i1Var, MenuItem menuItem) {
            u0.a aVar = this.f3353a;
            if (aVar != null) {
                return aVar.a(this, menuItem);
            }
            return false;
        }

        public void c() {
            k0 k0Var = k0.this;
            if (k0Var.f3339a == this) {
                if (!k0.w(k0Var.e, k0Var.f, false)) {
                    k0 k0Var2 = k0.this;
                    k0Var2.f3342a = this;
                    k0Var2.f3341a = this.f3353a;
                } else {
                    this.f3353a.c(this);
                }
                this.f3353a = null;
                k0.this.v(false);
                k0.this.f3334a.g();
                k0.this.f3343a.y().sendAccessibilityEvent(32);
                k0 k0Var3 = k0.this;
                k0Var3.f3335a.setHideOnContentScrollEnabled(k0Var3.j);
                k0.this.f3339a = null;
            }
        }

        public View d() {
            WeakReference<View> weakReference = this.f3351a;
            if (weakReference != null) {
                return (View) weakReference.get();
            }
            return null;
        }

        public Menu e() {
            return this.f3350a;
        }

        public MenuInflater f() {
            return new z0(this.a);
        }

        public CharSequence g() {
            return k0.this.f3334a.getSubtitle();
        }

        public CharSequence i() {
            return k0.this.f3334a.getTitle();
        }

        public void k() {
            if (k0.this.f3339a == this) {
                this.f3350a.d0();
                try {
                    this.f3353a.d(this, this.f3350a);
                } finally {
                    this.f3350a.c0();
                }
            }
        }

        public boolean l() {
            return k0.this.f3334a.j();
        }

        public void m(View view) {
            k0.this.f3334a.setCustomView(view);
            this.f3351a = new WeakReference<>(view);
        }

        public void n(int i) {
            o(k0.this.f3331a.getResources().getString(i));
        }

        public void o(CharSequence charSequence) {
            k0.this.f3334a.setSubtitle(charSequence);
        }

        public void q(int i) {
            r(k0.this.f3331a.getResources().getString(i));
        }

        public void r(CharSequence charSequence) {
            k0.this.f3334a.setTitle(charSequence);
        }

        public void s(boolean z) {
            super.s(z);
            k0.this.f3334a.setTitleOptional(z);
        }

        public boolean t() {
            this.f3350a.d0();
            try {
                return this.f3353a.b(this, this.f3350a);
            } finally {
                this.f3350a.c0();
            }
        }
    }

    public k0(Activity activity, boolean z) {
        this.f3330a = activity;
        View decorView = activity.getWindow().getDecorView();
        D(decorView);
        if (!z) {
            this.f3332a = decorView.findViewById(16908290);
        }
    }

    public k0(Dialog dialog) {
        D(dialog.getWindow().getDecorView());
    }

    public static boolean w(boolean z, boolean z2, boolean z3) {
        if (z3) {
            return true;
        }
        return !z && !z2;
    }

    public final z2 A(View view) {
        if (view instanceof z2) {
            return (z2) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Can't make a decor toolbar out of ");
        sb.append(view != null ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb.toString());
    }

    public int B() {
        return this.f3343a.x();
    }

    public final void C() {
        if (this.g) {
            this.g = false;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f3335a;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(false);
            }
            M(false);
        }
    }

    public final void D(View view) {
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(t.decor_content_parent);
        this.f3335a = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        this.f3343a = A(view.findViewById(t.action_bar));
        this.f3334a = (ActionBarContextView) view.findViewById(t.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(t.action_bar_container);
        this.f3333a = actionBarContainer;
        z2 z2Var = this.f3343a;
        if (z2Var == null || this.f3334a == null || actionBarContainer == null) {
            throw new IllegalStateException(k0.class.getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f3331a = z2Var.w();
        boolean z = (this.f3343a.m() & 4) != 0;
        if (z) {
            this.f3344a = true;
        }
        t0 b2 = t0.b(this.f3331a);
        J(b2.a() || z);
        H(b2.g());
        TypedArray obtainStyledAttributes = this.f3331a.obtainStyledAttributes((AttributeSet) null, x.ActionBar, o.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(x.ActionBar_hideOnContentScroll, false)) {
            I(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(x.ActionBar_elevation, 0);
        if (dimensionPixelSize != 0) {
            G((float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    public void E(boolean z) {
        F(z ? 4 : 0, 4);
    }

    public void F(int i2, int i3) {
        int m = this.f3343a.m();
        if ((i3 & 4) != 0) {
            this.f3344a = true;
        }
        this.f3343a.q((i2 & i3) | ((i3 ^ -1) & m));
    }

    public void G(float f2) {
        ya.v0(this.f3333a, f2);
    }

    public final void H(boolean z) {
        this.c = z;
        if (!z) {
            this.f3343a.n((l3) null);
            this.f3333a.setTabContainer(this.f3340a);
        } else {
            this.f3333a.setTabContainer((l3) null);
            this.f3343a.n(this.f3340a);
        }
        boolean z2 = true;
        boolean z3 = B() == 2;
        l3 l3Var = this.f3340a;
        if (l3Var != null) {
            if (z3) {
                l3Var.setVisibility(0);
                ActionBarOverlayLayout actionBarOverlayLayout = this.f3335a;
                if (actionBarOverlayLayout != null) {
                    ya.l0(actionBarOverlayLayout);
                }
            } else {
                l3Var.setVisibility(8);
            }
        }
        this.f3343a.t(!this.c && z3);
        ActionBarOverlayLayout actionBarOverlayLayout2 = this.f3335a;
        if (this.c || !z3) {
            z2 = false;
        }
        actionBarOverlayLayout2.setHasNonEmbeddedTabs(z2);
    }

    public void I(boolean z) {
        if (!z || this.f3335a.w()) {
            this.j = z;
            this.f3335a.setHideOnContentScrollEnabled(z);
            return;
        }
        throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
    }

    public void J(boolean z) {
        this.f3343a.j(z);
    }

    public final boolean K() {
        return ya.T(this.f3333a);
    }

    public final void L() {
        if (!this.g) {
            this.g = true;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f3335a;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(true);
            }
            M(false);
        }
    }

    public final void M(boolean z) {
        if (w(this.e, this.f, this.g)) {
            if (!this.h) {
                this.h = true;
                z(z);
            }
        } else if (this.h) {
            this.h = false;
            y(z);
        }
    }

    public void a() {
        if (this.f) {
            this.f = false;
            M(true);
        }
    }

    public void b() {
    }

    public void c(int i2) {
        this.f3345b = i2;
    }

    public void d() {
        a1 a1Var = this.f3329a;
        if (a1Var != null) {
            a1Var.a();
            this.f3329a = null;
        }
    }

    public void e() {
        if (!this.f) {
            this.f = true;
            M(true);
        }
    }

    public void f(boolean z) {
        this.d = z;
    }

    public boolean h() {
        z2 z2Var = this.f3343a;
        if (z2Var == null || !z2Var.h()) {
            return false;
        }
        this.f3343a.k();
        return true;
    }

    public void i(boolean z) {
        if (z != this.f3349b) {
            this.f3349b = z;
            int size = this.f3348b.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f3348b.get(i2).a(z);
            }
        }
    }

    public int j() {
        return this.f3343a.m();
    }

    public Context k() {
        if (this.f3346b == null) {
            TypedValue typedValue = new TypedValue();
            this.f3331a.getTheme().resolveAttribute(o.actionBarWidgetTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                this.f3346b = new ContextThemeWrapper(this.f3331a, i2);
            } else {
                this.f3346b = this.f3331a;
            }
        }
        return this.f3346b;
    }

    public void m(Configuration configuration) {
        H(t0.b(this.f3331a).g());
    }

    public boolean o(int i2, KeyEvent keyEvent) {
        Menu e2;
        d dVar = this.f3339a;
        if (dVar == null || (e2 = dVar.e()) == null) {
            return false;
        }
        boolean z = true;
        if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() == 1) {
            z = false;
        }
        e2.setQwertyMode(z);
        return e2.performShortcut(i2, keyEvent, 0);
    }

    public void r(boolean z) {
        if (!this.f3344a) {
            E(z);
        }
    }

    public void s(boolean z) {
        a1 a1Var;
        this.i = z;
        if (!z && (a1Var = this.f3329a) != null) {
            a1Var.a();
        }
    }

    public void t(CharSequence charSequence) {
        this.f3343a.setWindowTitle(charSequence);
    }

    public u0 u(u0.a aVar) {
        d dVar = this.f3339a;
        if (dVar != null) {
            dVar.c();
        }
        this.f3335a.setHideOnContentScrollEnabled(false);
        this.f3334a.k();
        d dVar2 = new d(this.f3334a.getContext(), aVar);
        if (!dVar2.t()) {
            return null;
        }
        this.f3339a = dVar2;
        dVar2.k();
        this.f3334a.h(dVar2);
        v(true);
        this.f3334a.sendAccessibilityEvent(32);
        return dVar2;
    }

    public void v(boolean z) {
        cb cbVar;
        cb cbVar2;
        if (z) {
            L();
        } else {
            C();
        }
        if (K()) {
            if (z) {
                cbVar = this.f3343a.v(4, 100);
                cbVar2 = this.f3334a.f(0, 200);
            } else {
                cbVar2 = this.f3343a.v(0, 200);
                cbVar = this.f3334a.f(8, 100);
            }
            a1 a1Var = new a1();
            a1Var.d(cbVar, cbVar2);
            a1Var.h();
        } else if (z) {
            this.f3343a.l(4);
            this.f3334a.setVisibility(0);
        } else {
            this.f3343a.l(0);
            this.f3334a.setVisibility(8);
        }
    }

    public void x() {
        u0.a aVar = this.f3341a;
        if (aVar != null) {
            aVar.c(this.f3342a);
            this.f3342a = null;
            this.f3341a = null;
        }
    }

    public void y(boolean z) {
        View view;
        a1 a1Var = this.f3329a;
        if (a1Var != null) {
            a1Var.a();
        }
        if (this.f3345b != 0 || (!this.i && !z)) {
            this.f3336a.b((View) null);
            return;
        }
        this.f3333a.setAlpha(1.0f);
        this.f3333a.setTransitioning(true);
        a1 a1Var2 = new a1();
        float f2 = (float) (-this.f3333a.getHeight());
        if (z) {
            int[] iArr = {0, 0};
            this.f3333a.getLocationInWindow(iArr);
            f2 -= (float) iArr[1];
        }
        cb k = ya.d(this.f3333a).k(f2);
        k.i(this.f3337a);
        a1Var2.c(k);
        if (this.d && (view = this.f3332a) != null) {
            a1Var2.c(ya.d(view).k(f2));
        }
        a1Var2.f(a);
        a1Var2.e(250);
        a1Var2.g(this.f3336a);
        this.f3329a = a1Var2;
        a1Var2.h();
    }

    public void z(boolean z) {
        View view;
        View view2;
        a1 a1Var = this.f3329a;
        if (a1Var != null) {
            a1Var.a();
        }
        this.f3333a.setVisibility(0);
        if (this.f3345b != 0 || (!this.i && !z)) {
            this.f3333a.setAlpha(1.0f);
            this.f3333a.setTranslationY(0.0f);
            if (this.d && (view = this.f3332a) != null) {
                view.setTranslationY(0.0f);
            }
            this.f3347b.b((View) null);
        } else {
            this.f3333a.setTranslationY(0.0f);
            float f2 = (float) (-this.f3333a.getHeight());
            if (z) {
                int[] iArr = {0, 0};
                this.f3333a.getLocationInWindow(iArr);
                f2 -= (float) iArr[1];
            }
            this.f3333a.setTranslationY(f2);
            a1 a1Var2 = new a1();
            cb k = ya.d(this.f3333a).k(0.0f);
            k.i(this.f3337a);
            a1Var2.c(k);
            if (this.d && (view2 = this.f3332a) != null) {
                view2.setTranslationY(f2);
                a1Var2.c(ya.d(this.f3332a).k(0.0f));
            }
            a1Var2.f(b);
            a1Var2.e(250);
            a1Var2.g(this.f3347b);
            this.f3329a = a1Var2;
            a1Var2.h();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f3335a;
        if (actionBarOverlayLayout != null) {
            ya.l0(actionBarOverlayLayout);
        }
    }
}
