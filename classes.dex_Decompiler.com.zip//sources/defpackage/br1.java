package defpackage;

import java.util.Date;

/* renamed from: br1  reason: default package */
public class br1 extends dr1<Long, Date> {
    /* renamed from: b */
    public Long a(Date date) {
        if (date == null) {
            return null;
        }
        return Long.valueOf(date.getTime());
    }
}
