package defpackage;

import defpackage.b52;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: v32  reason: default package */
public final class v32 {
    public int a = 64;

    /* renamed from: a  reason: collision with other field name */
    public Runnable f5506a;

    /* renamed from: a  reason: collision with other field name */
    public final ArrayDeque<b52.a> f5507a = new ArrayDeque<>();

    /* renamed from: a  reason: collision with other field name */
    public ExecutorService f5508a;
    public int b = 5;

    /* renamed from: b  reason: collision with other field name */
    public final ArrayDeque<b52.a> f5509b = new ArrayDeque<>();
    public final ArrayDeque<b52> c = new ArrayDeque<>();

    public final void a(b52.a aVar) {
        b52.a d;
        p12.d(aVar, "call");
        synchronized (this) {
            this.f5507a.add(aVar);
            if (!aVar.b().n() && (d = d(aVar.d())) != null) {
                aVar.e(d);
            }
            xz1 xz1 = xz1.a;
        }
        h();
    }

    public final synchronized void b(b52 b52) {
        p12.d(b52, "call");
        this.c.add(b52);
    }

    public final synchronized ExecutorService c() {
        ExecutorService executorService;
        if (this.f5508a == null) {
            TimeUnit timeUnit = TimeUnit.SECONDS;
            SynchronousQueue synchronousQueue = new SynchronousQueue();
            this.f5508a = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, timeUnit, synchronousQueue, n42.I(n42.f4054a + " Dispatcher", false));
        }
        executorService = this.f5508a;
        p12.b(executorService);
        return executorService;
    }

    public final b52.a d(String str) {
        Iterator<b52.a> it = this.f5509b.iterator();
        while (it.hasNext()) {
            b52.a next = it.next();
            if (p12.a(next.d(), str)) {
                return next;
            }
        }
        Iterator<b52.a> it2 = this.f5507a.iterator();
        while (it2.hasNext()) {
            b52.a next2 = it2.next();
            if (p12.a(next2.d(), str)) {
                return next2;
            }
        }
        return null;
    }

    public final <T> void e(Deque<T> deque, T t) {
        Runnable runnable;
        synchronized (this) {
            if (deque.remove(t)) {
                runnable = this.f5506a;
                xz1 xz1 = xz1.a;
            } else {
                throw new AssertionError("Call wasn't in-flight!");
            }
        }
        if (!h() && runnable != null) {
            runnable.run();
        }
    }

    public final void f(b52.a aVar) {
        p12.d(aVar, "call");
        aVar.c().decrementAndGet();
        e(this.f5509b, aVar);
    }

    public final void g(b52 b52) {
        p12.d(b52, "call");
        e(this.c, b52);
    }

    public final boolean h() {
        int i;
        boolean z;
        if (!n42.f4058a || !Thread.holdsLock(this)) {
            ArrayList arrayList = new ArrayList();
            synchronized (this) {
                Iterator<b52.a> it = this.f5507a.iterator();
                p12.c(it, "readyAsyncCalls.iterator()");
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    b52.a next = it.next();
                    if (this.f5509b.size() >= this.a) {
                        break;
                    } else if (next.c().get() < this.b) {
                        it.remove();
                        next.c().incrementAndGet();
                        p12.c(next, "asyncCall");
                        arrayList.add(next);
                        this.f5509b.add(next);
                    }
                }
                z = i() > 0;
                xz1 xz1 = xz1.a;
            }
            int size = arrayList.size();
            for (i = 0; i < size; i++) {
                ((b52.a) arrayList.get(i)).a(c());
            }
            return z;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        p12.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST NOT hold lock on ");
        sb.append(this);
        throw new AssertionError(sb.toString());
    }

    public final synchronized int i() {
        return this.f5509b.size() + this.c.size();
    }
}
