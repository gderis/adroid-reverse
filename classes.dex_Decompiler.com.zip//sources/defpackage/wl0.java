package defpackage;

import java.util.Collections;
import java.util.List;

/* renamed from: wl0  reason: default package */
public final class wl0 extends yl0 {
    public static final Class<?> a = Collections.unmodifiableList(Collections.emptyList()).getClass();

    public /* synthetic */ wl0(vl0 vl0) {
        super((vl0) null);
    }

    public final void a(Object obj, long j) {
        Object obj2;
        List list = (List) vn0.s(obj, j);
        if (list instanceof ul0) {
            obj2 = ((ul0) list).N();
        } else if (!a.isAssignableFrom(list.getClass())) {
            if (!(list instanceof sm0) || !(list instanceof nl0)) {
                obj2 = Collections.unmodifiableList(list);
            } else {
                nl0 nl0 = (nl0) list;
                if (nl0.a()) {
                    nl0.n0();
                    return;
                }
                return;
            }
        } else {
            return;
        }
        vn0.t(obj, j, obj2);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v10, resolved type: tl0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v15, resolved type: tl0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v16, resolved type: tl0} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x009c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final <E> void b(java.lang.Object r5, java.lang.Object r6, long r7) {
        /*
            r4 = this;
            java.lang.Object r6 = defpackage.vn0.s(r6, r7)
            java.util.List r6 = (java.util.List) r6
            int r0 = r6.size()
            java.lang.Object r1 = defpackage.vn0.s(r5, r7)
            java.util.List r1 = (java.util.List) r1
            boolean r2 = r1.isEmpty()
            if (r2 == 0) goto L_0x0039
            boolean r2 = r1 instanceof defpackage.ul0
            if (r2 == 0) goto L_0x0020
            tl0 r1 = new tl0
            r1.<init>((int) r0)
            goto L_0x0035
        L_0x0020:
            boolean r2 = r1 instanceof defpackage.sm0
            if (r2 == 0) goto L_0x0030
            boolean r2 = r1 instanceof defpackage.nl0
            if (r2 == 0) goto L_0x0030
            nl0 r1 = (defpackage.nl0) r1
            nl0 r0 = r1.o(r0)
            r1 = r0
            goto L_0x0035
        L_0x0030:
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>(r0)
        L_0x0035:
            defpackage.vn0.t(r5, r7, r1)
            goto L_0x008a
        L_0x0039:
            java.lang.Class<?> r2 = a
            java.lang.Class r3 = r1.getClass()
            boolean r2 = r2.isAssignableFrom(r3)
            if (r2 == 0) goto L_0x0057
            java.util.ArrayList r2 = new java.util.ArrayList
            int r3 = r1.size()
            int r3 = r3 + r0
            r2.<init>(r3)
            r2.addAll(r1)
        L_0x0052:
            defpackage.vn0.t(r5, r7, r2)
            r1 = r2
            goto L_0x008a
        L_0x0057:
            boolean r2 = r1 instanceof defpackage.qn0
            if (r2 == 0) goto L_0x006f
            tl0 r2 = new tl0
            int r3 = r1.size()
            int r3 = r3 + r0
            r2.<init>((int) r3)
            qn0 r1 = (defpackage.qn0) r1
            int r0 = r2.size()
            r2.addAll(r0, r1)
            goto L_0x0052
        L_0x006f:
            boolean r2 = r1 instanceof defpackage.sm0
            if (r2 == 0) goto L_0x008a
            boolean r2 = r1 instanceof defpackage.nl0
            if (r2 == 0) goto L_0x008a
            r2 = r1
            nl0 r2 = (defpackage.nl0) r2
            boolean r3 = r2.a()
            if (r3 != 0) goto L_0x008a
            int r1 = r1.size()
            int r1 = r1 + r0
            nl0 r1 = r2.o(r1)
            goto L_0x0035
        L_0x008a:
            int r0 = r1.size()
            int r2 = r6.size()
            if (r0 <= 0) goto L_0x0099
            if (r2 <= 0) goto L_0x0099
            r1.addAll(r6)
        L_0x0099:
            if (r0 > 0) goto L_0x009c
            goto L_0x009d
        L_0x009c:
            r6 = r1
        L_0x009d:
            defpackage.vn0.t(r5, r7, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.wl0.b(java.lang.Object, java.lang.Object, long):void");
    }
}
