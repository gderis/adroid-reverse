package defpackage;

/* renamed from: fm1  reason: default package */
public interface fm1 {
}
