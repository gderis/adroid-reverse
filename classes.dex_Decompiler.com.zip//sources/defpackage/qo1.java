package defpackage;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.Executor;

/* renamed from: qo1  reason: default package */
public class qo1 implements Closeable {
    public volatile InputStream a;

    /* renamed from: a  reason: collision with other field name */
    public final URL f4665a;

    /* renamed from: a  reason: collision with other field name */
    public n81<Bitmap> f4666a;

    public qo1(URL url) {
        this.f4665a = url;
    }

    public static qo1 t(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        try {
            return new qo1(new URL(str));
        } catch (MalformedURLException unused) {
            String valueOf = String.valueOf(str);
            if (valueOf.length() != 0) {
                "Not downloading image, bad URL: ".concat(valueOf);
            } else {
                new String("Not downloading image, bad URL: ");
            }
            return null;
        }
    }

    public Bitmap a() {
        String valueOf = String.valueOf(this.f4665a);
        StringBuilder sb = new StringBuilder(valueOf.length() + 22);
        sb.append("Starting download of: ");
        sb.append(valueOf);
        sb.toString();
        byte[] o = o();
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(o, 0, o.length);
        if (decodeByteArray != null) {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                String valueOf2 = String.valueOf(this.f4665a);
                StringBuilder sb2 = new StringBuilder(valueOf2.length() + 31);
                sb2.append("Successfully downloaded image: ");
                sb2.append(valueOf2);
                sb2.toString();
            }
            return decodeByteArray;
        }
        String valueOf3 = String.valueOf(this.f4665a);
        StringBuilder sb3 = new StringBuilder(valueOf3.length() + 24);
        sb3.append("Failed to decode image: ");
        sb3.append(valueOf3);
        throw new IOException(sb3.toString());
    }

    public void close() {
        try {
            h80.a(this.a);
        } catch (NullPointerException unused) {
        }
    }

    public final byte[] o() {
        URLConnection openConnection = this.f4665a.openConnection();
        if (openConnection.getContentLength() <= 1048576) {
            InputStream inputStream = openConnection.getInputStream();
            try {
                this.a = inputStream;
                byte[] a2 = g80.a(g80.b(inputStream, 1048577));
                if (inputStream != null) {
                    inputStream.close();
                }
                if (Log.isLoggable("FirebaseMessaging", 2)) {
                    String valueOf = String.valueOf(this.f4665a);
                    StringBuilder sb = new StringBuilder(valueOf.length() + 34);
                    sb.append("Downloaded ");
                    sb.append(a2.length);
                    sb.append(" bytes from ");
                    sb.append(valueOf);
                    sb.toString();
                }
                if (a2.length <= 1048576) {
                    return a2;
                }
                throw new IOException("Image exceeds max size of 1048576");
            } catch (Throwable th) {
                o80.a(th, th);
            }
        } else {
            throw new IOException("Content-Length exceeds max size of 1048576");
        }
        throw th;
    }

    public n81<Bitmap> v() {
        return (n81) s10.j(this.f4666a);
    }

    public void w(Executor executor) {
        this.f4666a = q81.c(executor, new po1(this));
    }
}
