package defpackage;

import java.util.concurrent.Callable;

/* renamed from: po1  reason: default package */
public final /* synthetic */ class po1 implements Callable {
    public final qo1 a;

    public po1(qo1 qo1) {
        this.a = qo1;
    }

    public Object call() {
        return this.a.a();
    }
}
