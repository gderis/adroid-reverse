package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: xu0  reason: default package */
public final class xu0 extends w10 {
    public static final Parcelable.Creator<xu0> CREATOR = new yu0();
    public long a;

    /* renamed from: a  reason: collision with other field name */
    public String f5893a;

    /* renamed from: a  reason: collision with other field name */
    public final pv0 f5894a;

    /* renamed from: a  reason: collision with other field name */
    public v51 f5895a;
    public long b;

    /* renamed from: b  reason: collision with other field name */
    public String f5896b;

    /* renamed from: b  reason: collision with other field name */
    public pv0 f5897b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f5898b;
    public final long c;

    /* renamed from: c  reason: collision with other field name */
    public String f5899c;

    /* renamed from: c  reason: collision with other field name */
    public final pv0 f5900c;

    public xu0(String str, String str2, v51 v51, long j, boolean z, String str3, pv0 pv0, long j2, pv0 pv02, long j3, pv0 pv03) {
        this.f5893a = str;
        this.f5896b = str2;
        this.f5895a = v51;
        this.a = j;
        this.f5898b = z;
        this.f5899c = str3;
        this.f5894a = pv0;
        this.b = j2;
        this.f5897b = pv02;
        this.c = j3;
        this.f5900c = pv03;
    }

    public xu0(xu0 xu0) {
        s10.j(xu0);
        this.f5893a = xu0.f5893a;
        this.f5896b = xu0.f5896b;
        this.f5895a = xu0.f5895a;
        this.a = xu0.a;
        this.f5898b = xu0.f5898b;
        this.f5899c = xu0.f5899c;
        this.f5894a = xu0.f5894a;
        this.b = xu0.b;
        this.f5897b = xu0.f5897b;
        this.c = xu0.c;
        this.f5900c = xu0.f5900c;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.r(parcel, 2, this.f5893a, false);
        y10.r(parcel, 3, this.f5896b, false);
        y10.p(parcel, 4, this.f5895a, i, false);
        y10.n(parcel, 5, this.a);
        y10.c(parcel, 6, this.f5898b);
        y10.r(parcel, 7, this.f5899c, false);
        y10.p(parcel, 8, this.f5894a, i, false);
        y10.n(parcel, 9, this.b);
        y10.p(parcel, 10, this.f5897b, i, false);
        y10.n(parcel, 11, this.c);
        y10.p(parcel, 12, this.f5900c, i, false);
        y10.b(parcel, a2);
    }
}
