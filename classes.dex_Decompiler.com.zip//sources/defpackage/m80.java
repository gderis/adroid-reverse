package defpackage;

/* renamed from: m80  reason: default package */
public final class m80 extends i80 {
    public final void a(Throwable th, Throwable th2) {
    }
}
