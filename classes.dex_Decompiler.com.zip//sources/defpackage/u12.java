package defpackage;

/* renamed from: u12  reason: default package */
public class u12 {
    public String a(o12 o12) {
        String obj = o12.getClass().getGenericInterfaces()[0].toString();
        return obj.startsWith("kotlin.jvm.functions.") ? obj.substring(21) : obj;
    }

    public String b(q12 q12) {
        return a(q12);
    }
}
