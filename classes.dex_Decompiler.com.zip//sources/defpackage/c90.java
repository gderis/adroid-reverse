package defpackage;

import android.os.IBinder;

/* renamed from: c90  reason: default package */
public final class c90 extends v80 implements e90 {
    public c90(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.location.internal.IFusedLocationProviderCallback");
    }
}
