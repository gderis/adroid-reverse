package defpackage;

import java.util.Iterator;

/* renamed from: e22  reason: default package */
public final class e22<T> implements g22<T>, f22<T> {
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final g22<T> f2142a;

    /* renamed from: e22$a */
    public static final class a implements Iterator<T>, x12 {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ e22 f2143a;

        /* renamed from: a  reason: collision with other field name */
        public final Iterator<T> f2144a;

        public a(e22 e22) {
            this.f2143a = e22;
            this.f2144a = e22.f2142a.iterator();
            this.a = e22.a;
        }

        public final void a() {
            while (this.a > 0 && this.f2144a.hasNext()) {
                this.f2144a.next();
                this.a--;
            }
        }

        public boolean hasNext() {
            a();
            return this.f2144a.hasNext();
        }

        public T next() {
            a();
            return this.f2144a.next();
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public e22(g22<? extends T> g22, int i) {
        p12.d(g22, "sequence");
        this.f2142a = g22;
        this.a = i;
        if (!(i >= 0)) {
            throw new IllegalArgumentException(("count must be non-negative, but was " + i + '.').toString());
        }
    }

    public g22<T> a(int i) {
        int i2 = this.a + i;
        return i2 < 0 ? new e22(this, i) : new e22(this.f2142a, i2);
    }

    public Iterator<T> iterator() {
        return new a(this);
    }
}
