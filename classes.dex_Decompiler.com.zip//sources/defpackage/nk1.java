package defpackage;

/* renamed from: nk1  reason: default package */
public interface nk1 {
    n81<rk1> a();

    uk1 b();
}
