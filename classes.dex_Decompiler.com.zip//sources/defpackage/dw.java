package defpackage;

import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.util.Log;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.GooglePlayServicesIncorrectManifestValueException;
import com.google.android.gms.common.GooglePlayServicesMissingManifestValueException;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: dw  reason: default package */
public class dw {
    @Deprecated
    public static final int a = 12451000;

    /* renamed from: a  reason: collision with other field name */
    public static final AtomicBoolean f2052a = new AtomicBoolean();

    /* renamed from: a  reason: collision with other field name */
    public static boolean f2053a = false;
    public static final AtomicBoolean b = new AtomicBoolean();

    /* renamed from: b  reason: collision with other field name */
    public static boolean f2054b = false;

    @Deprecated
    public static void a(@RecentlyNonNull Context context) {
        if (!f2052a.getAndSet(true)) {
            try {
                NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
                if (notificationManager != null) {
                    notificationManager.cancel(10436);
                }
            } catch (SecurityException unused) {
            }
        }
    }

    @Deprecated
    public static int b(@RecentlyNonNull Context context) {
        try {
            return context.getPackageManager().getPackageInfo("com.google.android.gms", 0).versionCode;
        } catch (PackageManager.NameNotFoundException unused) {
            return 0;
        }
    }

    @Deprecated
    public static String c(int i) {
        return wv.F0(i);
    }

    @RecentlyNullable
    public static Context d(@RecentlyNonNull Context context) {
        try {
            return context.createPackageContext("com.google.android.gms", 3);
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    @RecentlyNullable
    public static Resources e(@RecentlyNonNull Context context) {
        try {
            return context.getPackageManager().getResourcesForApplication("com.google.android.gms");
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public static boolean f(@RecentlyNonNull Context context) {
        if (!f2054b) {
            try {
                PackageInfo e = z40.a(context).e("com.google.android.gms", 64);
                ew.a(context);
                if (e == null || ew.f(e, false) || !ew.f(e, true)) {
                    f2053a = false;
                } else {
                    f2053a = true;
                }
            } catch (PackageManager.NameNotFoundException unused) {
            } catch (Throwable th) {
                f2054b = true;
                throw th;
            }
            f2054b = true;
        }
        return f2053a || !k40.c();
    }

    @Deprecated
    public static int g(@RecentlyNonNull Context context) {
        return h(context, a);
    }

    @Deprecated
    public static int h(@RecentlyNonNull Context context, int i) {
        try {
            context.getResources().getString(fw.common_google_play_services_unknown_issue);
        } catch (Throwable unused) {
        }
        if (!"com.google.android.gms".equals(context.getPackageName()) && !b.get()) {
            int a2 = u30.a(context);
            if (a2 == 0) {
                throw new GooglePlayServicesMissingManifestValueException();
            } else if (a2 != a) {
                throw new GooglePlayServicesIncorrectManifestValueException(a2);
            }
        }
        return m(context, !k40.f(context) && !k40.g(context), i);
    }

    @Deprecated
    public static boolean i(@RecentlyNonNull Context context, int i) {
        if (i == 18) {
            return true;
        }
        if (i == 1) {
            return n(context, "com.google.android.gms");
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r1 = ((android.os.UserManager) defpackage.s10.j(r1.getSystemService("user"))).getApplicationRestrictions(r1.getPackageName());
     */
    @android.annotation.TargetApi(18)
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean j(@androidx.annotation.RecentlyNonNull android.content.Context r1) {
        /*
            boolean r0 = defpackage.n40.c()
            if (r0 == 0) goto L_0x002c
            java.lang.String r0 = "user"
            java.lang.Object r0 = r1.getSystemService(r0)
            java.lang.Object r0 = defpackage.s10.j(r0)
            android.os.UserManager r0 = (android.os.UserManager) r0
            java.lang.String r1 = r1.getPackageName()
            android.os.Bundle r1 = r0.getApplicationRestrictions(r1)
            if (r1 == 0) goto L_0x002c
            java.lang.String r0 = "restricted_profile"
            java.lang.String r1 = r1.getString(r0)
            java.lang.String r0 = "true"
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L_0x002c
            r1 = 1
            return r1
        L_0x002c:
            r1 = 0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.dw.j(android.content.Context):boolean");
    }

    @Deprecated
    public static boolean k(int i) {
        return i == 1 || i == 2 || i == 3 || i == 9;
    }

    @TargetApi(19)
    @Deprecated
    public static boolean l(@RecentlyNonNull Context context, int i, @RecentlyNonNull String str) {
        return q40.b(context, i, str);
    }

    public static int m(Context context, boolean z, int i) {
        String valueOf;
        String str;
        s10.a(i >= 0);
        String packageName = context.getPackageName();
        PackageManager packageManager = context.getPackageManager();
        PackageInfo packageInfo = null;
        if (z) {
            try {
                packageInfo = packageManager.getPackageInfo("com.android.vending", 8256);
            } catch (PackageManager.NameNotFoundException unused) {
                valueOf = String.valueOf(packageName);
                str = " requires the Google Play Store, but it is missing.";
            }
        }
        try {
            PackageInfo packageInfo2 = packageManager.getPackageInfo("com.google.android.gms", 64);
            ew.a(context);
            if (!ew.f(packageInfo2, true)) {
                valueOf = String.valueOf(packageName);
                str = " requires Google Play services, but their signature is invalid.";
            } else if (z && (!ew.f((PackageInfo) s10.j(packageInfo), true) || !packageInfo.signatures[0].equals(packageInfo2.signatures[0]))) {
                valueOf = String.valueOf(packageName);
                str = " requires Google Play Store, but its signature is invalid.";
            } else if (v40.a(packageInfo2.versionCode) < v40.a(i)) {
                int i2 = packageInfo2.versionCode;
                StringBuilder sb = new StringBuilder(String.valueOf(packageName).length() + 82);
                sb.append("Google Play services out of date for ");
                sb.append(packageName);
                sb.append(".  Requires ");
                sb.append(i);
                sb.append(" but found ");
                sb.append(i2);
                sb.toString();
                return 2;
            } else {
                ApplicationInfo applicationInfo = packageInfo2.applicationInfo;
                if (applicationInfo == null) {
                    try {
                        applicationInfo = packageManager.getApplicationInfo("com.google.android.gms", 0);
                    } catch (PackageManager.NameNotFoundException e) {
                        Log.wtf("GooglePlayServicesUtil", String.valueOf(packageName).concat(" requires Google Play services, but they're missing when getting application info."), e);
                        return 1;
                    }
                }
                return !applicationInfo.enabled ? 3 : 0;
            }
            valueOf.concat(str);
            return 9;
        } catch (PackageManager.NameNotFoundException unused2) {
            String.valueOf(packageName).concat(" requires Google Play services, but they are missing.");
            return 1;
        }
    }

    @TargetApi(21)
    public static boolean n(Context context, String str) {
        boolean equals = str.equals("com.google.android.gms");
        if (n40.f()) {
            try {
                for (PackageInstaller.SessionInfo appPackageName : context.getPackageManager().getPackageInstaller().getAllSessions()) {
                    if (str.equals(appPackageName.getAppPackageName())) {
                        return true;
                    }
                }
            } catch (Exception unused) {
                return false;
            }
        }
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(str, 8192);
            return equals ? applicationInfo.enabled : applicationInfo.enabled && !j(context);
        } catch (PackageManager.NameNotFoundException unused2) {
        }
    }
}
