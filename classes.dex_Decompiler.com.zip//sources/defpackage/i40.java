package defpackage;

import android.content.Context;
import android.os.DropBoxManager;
import androidx.annotation.RecentlyNonNull;
import javax.annotation.concurrent.GuardedBy;

/* renamed from: i40  reason: default package */
public final class i40 {
    public static int a = -1;

    /* renamed from: a  reason: collision with other field name */
    public static DropBoxManager f2965a = null;

    /* renamed from: a  reason: collision with other field name */
    public static boolean f2966a = false;

    /* renamed from: a  reason: collision with other field name */
    public static final String[] f2967a = {"android.", "com.android.", "dalvik.", "java.", "javax."};
    @GuardedBy("CrashUtils.class")
    public static int b = 0;
    @GuardedBy("CrashUtils.class")
    public static int c = 0;

    public static boolean a(@RecentlyNonNull Context context, @RecentlyNonNull Throwable th) {
        return b(context, th, 536870912);
    }

    public static boolean b(Context context, Throwable th, int i) {
        try {
            s10.j(context);
            s10.j(th);
        } catch (Exception unused) {
        }
        return false;
    }
}
