package defpackage;

import java.util.UUID;

/* renamed from: fv1  reason: default package */
public class fv1 extends ts1 {
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public long f2503a;

    /* renamed from: a  reason: collision with other field name */
    public String f2504a;

    /* renamed from: a  reason: collision with other field name */
    public UUID f2505a;
    public String b;
    public String c;
    public String d;
    public String e;

    public String c() {
        return this.d;
    }

    public long d() {
        return this.f2503a;
    }

    public String e() {
        return this.b;
    }

    public String f() {
        return this.e;
    }

    public String g() {
        return this.f2504a;
    }

    public String h() {
        return this.c;
    }

    public int i() {
        return this.a;
    }

    public void j(String str) {
        this.d = str;
    }

    public void k(long j) {
        this.f2503a = j;
    }

    public void l(UUID uuid) {
        this.f2505a = uuid;
    }

    public void m(String str) {
        this.b = str;
    }

    public void n(String str) {
        this.e = str;
    }

    public void o(String str) {
        this.f2504a = str;
    }

    public void p(String str) {
        this.c = str;
    }

    public void q(int i) {
        this.a = i;
    }
}
