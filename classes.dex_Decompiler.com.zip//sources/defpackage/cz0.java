package defpackage;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import java.util.ArrayList;
import java.util.List;

/* renamed from: cz0  reason: default package */
public final class cz0 extends uc0 implements ez0 {
    public cz0(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.measurement.internal.IMeasurementService");
    }

    public final void B(xu0 xu0, g61 g61) {
        Parcel c = c();
        wc0.d(c, xu0);
        wc0.d(c, g61);
        d(12, c);
    }

    public final void D0(g61 g61) {
        Parcel c = c();
        wc0.d(c, g61);
        d(18, c);
    }

    public final byte[] G(pv0 pv0, String str) {
        Parcel c = c();
        wc0.d(c, pv0);
        c.writeString(str);
        Parcel b = b(9, c);
        byte[] createByteArray = b.createByteArray();
        b.recycle();
        return createByteArray;
    }

    public final List<v51> M(String str, String str2, String str3, boolean z) {
        Parcel c = c();
        c.writeString((String) null);
        c.writeString(str2);
        c.writeString(str3);
        wc0.b(c, z);
        Parcel b = b(15, c);
        ArrayList<v51> createTypedArrayList = b.createTypedArrayList(v51.CREATOR);
        b.recycle();
        return createTypedArrayList;
    }

    public final void S(v51 v51, g61 g61) {
        Parcel c = c();
        wc0.d(c, v51);
        wc0.d(c, g61);
        d(2, c);
    }

    public final void c0(g61 g61) {
        Parcel c = c();
        wc0.d(c, g61);
        d(6, c);
    }

    public final List<xu0> d0(String str, String str2, g61 g61) {
        Parcel c = c();
        c.writeString(str);
        c.writeString(str2);
        wc0.d(c, g61);
        Parcel b = b(16, c);
        ArrayList<xu0> createTypedArrayList = b.createTypedArrayList(xu0.CREATOR);
        b.recycle();
        return createTypedArrayList;
    }

    public final void f0(pv0 pv0, g61 g61) {
        Parcel c = c();
        wc0.d(c, pv0);
        wc0.d(c, g61);
        d(1, c);
    }

    public final void h0(g61 g61) {
        Parcel c = c();
        wc0.d(c, g61);
        d(20, c);
    }

    public final void n(Bundle bundle, g61 g61) {
        Parcel c = c();
        wc0.d(c, bundle);
        wc0.d(c, g61);
        d(19, c);
    }

    public final String o(g61 g61) {
        Parcel c = c();
        wc0.d(c, g61);
        Parcel b = b(11, c);
        String readString = b.readString();
        b.recycle();
        return readString;
    }

    public final void r(g61 g61) {
        Parcel c = c();
        wc0.d(c, g61);
        d(4, c);
    }

    public final void r0(long j, String str, String str2, String str3) {
        Parcel c = c();
        c.writeLong(j);
        c.writeString(str);
        c.writeString(str2);
        c.writeString(str3);
        d(10, c);
    }

    public final List<v51> s0(String str, String str2, boolean z, g61 g61) {
        Parcel c = c();
        c.writeString(str);
        c.writeString(str2);
        wc0.b(c, z);
        wc0.d(c, g61);
        Parcel b = b(14, c);
        ArrayList<v51> createTypedArrayList = b.createTypedArrayList(v51.CREATOR);
        b.recycle();
        return createTypedArrayList;
    }

    public final List<xu0> u0(String str, String str2, String str3) {
        Parcel c = c();
        c.writeString((String) null);
        c.writeString(str2);
        c.writeString(str3);
        Parcel b = b(17, c);
        ArrayList<xu0> createTypedArrayList = b.createTypedArrayList(xu0.CREATOR);
        b.recycle();
        return createTypedArrayList;
    }
}
