package defpackage;

/* renamed from: bp1  reason: default package */
public final /* synthetic */ class bp1 implements Runnable {
    public final cp1 a;

    public bp1(cp1 cp1) {
        this.a = cp1;
    }

    public void run() {
        this.a.a();
    }
}
