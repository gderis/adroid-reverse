package defpackage;

import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.api.Status;
import defpackage.hw;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;
import javax.annotation.concurrent.GuardedBy;

/* renamed from: k00  reason: default package */
public final class k00 implements bz {
    @GuardedBy("mLock")
    public int a = 0;

    /* renamed from: a  reason: collision with other field name */
    public final Context f3354a;

    /* renamed from: a  reason: collision with other field name */
    public Bundle f3355a;

    /* renamed from: a  reason: collision with other field name */
    public final Looper f3356a;

    /* renamed from: a  reason: collision with other field name */
    public final gy f3357a;

    /* renamed from: a  reason: collision with other field name */
    public final hw.f f3358a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<hw.c<?>, ly> f3359a;

    /* renamed from: a  reason: collision with other field name */
    public final Set<mx> f3360a = Collections.newSetFromMap(new WeakHashMap());

    /* renamed from: a  reason: collision with other field name */
    public final Lock f3361a;

    /* renamed from: a  reason: collision with other field name */
    public final ly f3362a;

    /* renamed from: a  reason: collision with other field name */
    public wv f3363a = null;

    /* renamed from: a  reason: collision with other field name */
    public boolean f3364a = false;
    public final ly b;

    /* renamed from: b  reason: collision with other field name */
    public wv f3365b = null;

    public k00(Context context, gy gyVar, Lock lock, Looper looper, aw awVar, Map<hw.c<?>, hw.f> map, Map<hw.c<?>, hw.f> map2, g10 g10, hw.a<? extends b81, i71> aVar, hw.f fVar, ArrayList<i00> arrayList, ArrayList<i00> arrayList2, Map<hw<?>, Boolean> map3, Map<hw<?>, Boolean> map4) {
        this.f3354a = context;
        this.f3357a = gyVar;
        this.f3361a = lock;
        this.f3356a = looper;
        this.f3358a = fVar;
        Context context2 = context;
        gy gyVar2 = gyVar;
        Lock lock2 = lock;
        Looper looper2 = looper;
        aw awVar2 = awVar;
        ly lyVar = r3;
        ly lyVar2 = new ly(context2, gyVar2, lock2, looper2, awVar2, map2, (g10) null, map4, (hw.a<? extends b81, i71>) null, arrayList2, new m00(this, (j00) null));
        this.f3362a = lyVar;
        this.b = new ly(context2, gyVar2, lock2, looper2, awVar2, map, g10, map3, aVar, arrayList, new l00(this, (j00) null));
        o4 o4Var = new o4();
        for (hw.c<?> put : map2.keySet()) {
            o4Var.put(put, this.f3362a);
        }
        for (hw.c<?> put2 : map.keySet()) {
            o4Var.put(put2, this.b);
        }
        this.f3359a = Collections.unmodifiableMap(o4Var);
    }

    public static k00 c(Context context, gy gyVar, Lock lock, Looper looper, aw awVar, Map<hw.c<?>, hw.f> map, g10 g10, Map<hw<?>, Boolean> map2, hw.a<? extends b81, i71> aVar, ArrayList<i00> arrayList) {
        Map<hw<?>, Boolean> map3 = map2;
        o4 o4Var = new o4();
        o4 o4Var2 = new o4();
        hw.f fVar = null;
        for (Map.Entry next : map.entrySet()) {
            hw.f fVar2 = (hw.f) next.getValue();
            if (fVar2.q()) {
                fVar = fVar2;
            }
            boolean k = fVar2.k();
            hw.c cVar = (hw.c) next.getKey();
            if (k) {
                o4Var.put(cVar, fVar2);
            } else {
                o4Var2.put(cVar, fVar2);
            }
        }
        s10.n(!o4Var.isEmpty(), "CompositeGoogleApiClient should not be used without any APIs that require sign-in.");
        o4 o4Var3 = new o4();
        o4 o4Var4 = new o4();
        for (hw next2 : map2.keySet()) {
            hw.c<?> c = next2.c();
            if (o4Var.containsKey(c)) {
                o4Var3.put(next2, map3.get(next2));
            } else if (o4Var2.containsKey(c)) {
                o4Var4.put(next2, map3.get(next2));
            } else {
                throw new IllegalStateException("Each API in the isOptionalMap must have a corresponding client in the clients map.");
            }
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            i00 i00 = arrayList.get(i);
            i++;
            i00 i002 = i00;
            if (o4Var3.containsKey(i002.f2917a)) {
                arrayList2.add(i002);
            } else if (o4Var4.containsKey(i002.f2917a)) {
                arrayList3.add(i002);
            } else {
                throw new IllegalStateException("Each ClientCallbacks must have a corresponding API in the isOptionalMap");
            }
        }
        return new k00(context, gyVar, lock, looper, awVar, o4Var, o4Var2, g10, aVar, fVar, arrayList2, arrayList3, o4Var3, o4Var4);
    }

    public static boolean s(wv wvVar) {
        return wvVar != null && wvVar.E0();
    }

    @GuardedBy("mLock")
    public final boolean A() {
        wv wvVar = this.f3365b;
        return wvVar != null && wvVar.A0() == 4;
    }

    public final PendingIntent B() {
        if (this.f3358a == null) {
            return null;
        }
        return PendingIntent.getActivity(this.f3354a, System.identityHashCode(this.f3357a), this.f3358a.u(), 134217728);
    }

    @GuardedBy("mLock")
    public final void a() {
        this.a = 2;
        this.f3364a = false;
        this.f3365b = null;
        this.f3363a = null;
        this.f3362a.a();
        this.b.a();
    }

    @GuardedBy("mLock")
    public final <A extends hw.b, T extends ax<? extends rw, A>> T d(T t) {
        if (!t(t)) {
            return this.f3362a.d(t);
        }
        if (!A()) {
            return this.b.d(t);
        }
        t.z(new Status(4, (String) null, B()));
        return t;
    }

    @GuardedBy("mLock")
    public final void f() {
        this.f3365b = null;
        this.f3363a = null;
        this.a = 0;
        this.f3362a.f();
        this.b.f();
        z();
    }

    public final void g(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append(str).append("authClient").println(":");
        this.b.g(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
        printWriter.append(str).append("anonClient").println(":");
        this.f3362a.g(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
    }

    public final boolean h() {
        this.f3361a.lock();
        try {
            boolean z = true;
            if (!this.f3362a.h() || (!this.b.h() && !A() && this.a != 1)) {
                z = false;
            }
            return z;
        } finally {
            this.f3361a.unlock();
        }
    }

    @GuardedBy("mLock")
    public final <A extends hw.b, R extends rw, T extends ax<R, A>> T i(T t) {
        if (!t(t)) {
            return this.f3362a.i(t);
        }
        if (!A()) {
            return this.b.i(t);
        }
        t.z(new Status(4, (String) null, B()));
        return t;
    }

    @GuardedBy("mLock")
    public final void j() {
        this.f3362a.j();
        this.b.j();
    }

    @GuardedBy("mLock")
    public final void k(int i, boolean z) {
        this.f3357a.b(i, z);
        this.f3365b = null;
        this.f3363a = null;
    }

    public final void l(Bundle bundle) {
        Bundle bundle2 = this.f3355a;
        if (bundle2 == null) {
            this.f3355a = bundle;
        } else if (bundle != null) {
            bundle2.putAll(bundle);
        }
    }

    @GuardedBy("mLock")
    public final void m(wv wvVar) {
        int i = this.a;
        if (i != 1) {
            if (i != 2) {
                Log.wtf("CompositeGAC", "Attempted to call failure callbacks in CONNECTION_MODE_NONE. Callbacks should be disabled via GmsClientSupervisor", new Exception());
                this.a = 0;
            }
            this.f3357a.a(wvVar);
        }
        z();
        this.a = 0;
    }

    public final boolean t(ax<? extends rw, ? extends hw.b> axVar) {
        ly lyVar = this.f3359a.get(axVar.v());
        s10.k(lyVar, "GoogleApiClient is not configured to use the API required for this call.");
        return lyVar.equals(this.b);
    }

    @GuardedBy("mLock")
    public final void y() {
        wv wvVar;
        if (s(this.f3363a)) {
            if (s(this.f3365b) || A()) {
                int i = this.a;
                if (i != 1) {
                    if (i != 2) {
                        Log.wtf("CompositeGAC", "Attempted to call success callbacks in CONNECTION_MODE_NONE. Callbacks should be disabled via GmsClientSupervisor", new AssertionError());
                        this.a = 0;
                        return;
                    }
                    ((gy) s10.j(this.f3357a)).j(this.f3355a);
                }
                z();
                this.a = 0;
                return;
            }
            wv wvVar2 = this.f3365b;
            if (wvVar2 == null) {
                return;
            }
            if (this.a == 1) {
                z();
                return;
            }
            m(wvVar2);
            this.f3362a.f();
        } else if (this.f3363a == null || !s(this.f3365b)) {
            wv wvVar3 = this.f3363a;
            if (wvVar3 != null && (wvVar = this.f3365b) != null) {
                if (this.b.a < this.f3362a.a) {
                    wvVar3 = wvVar;
                }
                m(wvVar3);
            }
        } else {
            this.b.f();
            m((wv) s10.j(this.f3363a));
        }
    }

    @GuardedBy("mLock")
    public final void z() {
        for (mx a2 : this.f3360a) {
            a2.a();
        }
        this.f3360a.clear();
    }
}
