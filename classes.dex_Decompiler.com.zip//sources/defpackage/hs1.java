package defpackage;

import com.raizlabs.android.dbflow.config.FlowManager;
import defpackage.ts1;
import java.util.ArrayList;
import java.util.List;

/* renamed from: hs1  reason: default package */
public class hs1<TModel> extends rr1<TModel> implements qs1<TModel> {
    public int a = -1;

    /* renamed from: a  reason: collision with other field name */
    public cs1 f2889a;

    /* renamed from: a  reason: collision with other field name */
    public final is1<TModel> f2890a;

    /* renamed from: a  reason: collision with other field name */
    public final List<as1> f2891a = new ArrayList();
    public int b = -1;

    /* renamed from: b  reason: collision with other field name */
    public cs1 f2892b;

    /* renamed from: b  reason: collision with other field name */
    public final List<ds1> f2893b = new ArrayList();

    public hs1(is1<TModel> is1, es1... es1Arr) {
        super(is1.b());
        this.f2890a = is1;
        this.f2889a = cs1.y();
        this.f2892b = cs1.y();
        this.f2889a.u(es1Arr);
    }

    public ts1.a a() {
        return this.f2890a.a();
    }

    public String i() {
        or1 e = new or1().a(this.f2890a.i().trim()).f().e("WHERE", this.f2889a.i()).e("GROUP BY", or1.m(",", this.f2891a)).e("HAVING", this.f2892b.i()).e("ORDER BY", or1.m(",", this.f2893b));
        int i = this.a;
        if (i > -1) {
            e.e("LIMIT", String.valueOf(i));
        }
        int i2 = this.b;
        if (i2 > -1) {
            e.e("OFFSET", String.valueOf(i2));
        }
        return e.i();
    }

    public lt1 j() {
        return k(FlowManager.d(b()).u());
    }

    public lt1 k(kt1 kt1) {
        return this.f2890a.g() instanceof gs1 ? kt1.a(i(), (String[]) null) : super.k(kt1);
    }

    public List<TModel> p() {
        q("query");
        return super.p();
    }

    public final void q(String str) {
        if (!(this.f2890a.g() instanceof gs1)) {
            throw new IllegalArgumentException("Please use " + str + "(). The beginning is not a ISelect");
        }
    }

    public hs1<TModel> r(int i) {
        this.a = i;
        return this;
    }

    public hs1<TModel> s(js1 js1, boolean z) {
        this.f2893b.add(new ds1(js1.l(), z));
        return this;
    }
}
