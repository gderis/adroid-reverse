package defpackage;

import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: kj0  reason: default package */
public final class kj0 {
    public final ReferenceQueue<Throwable> a = new ReferenceQueue<>();

    /* renamed from: a  reason: collision with other field name */
    public final ConcurrentHashMap<jj0, List<Throwable>> f3557a = new ConcurrentHashMap<>(16, 0.75f, 10);

    public final List<Throwable> a(Throwable th, boolean z) {
        while (true) {
            Reference<? extends Throwable> poll = this.a.poll();
            if (poll == null) {
                break;
            }
            this.f3557a.remove(poll);
        }
        List<Throwable> list = this.f3557a.get(new jj0(th, (ReferenceQueue<Throwable>) null));
        if (list != null) {
            return list;
        }
        Vector vector = new Vector(2);
        List<Throwable> putIfAbsent = this.f3557a.putIfAbsent(new jj0(th, this.a), vector);
        return putIfAbsent == null ? vector : putIfAbsent;
    }
}
