package defpackage;

import java.util.Arrays;
import java.util.logging.Logger;

/* renamed from: t42  reason: default package */
public final class t42 {
    public static final String b(long j) {
        StringBuilder sb;
        long j2;
        long j3;
        StringBuilder sb2;
        long j4;
        if (j <= ((long) -999500000)) {
            sb = new StringBuilder();
            j2 = j - ((long) 500000000);
        } else {
            if (j <= ((long) -999500)) {
                sb = new StringBuilder();
                j3 = j - ((long) 500000);
            } else {
                if (j <= 0) {
                    sb2 = new StringBuilder();
                    j4 = j - ((long) 500);
                } else if (j < ((long) 999500)) {
                    sb2 = new StringBuilder();
                    j4 = j + ((long) 500);
                } else if (j < ((long) 999500000)) {
                    j3 = j + ((long) 500000);
                } else {
                    sb = new StringBuilder();
                    j2 = j + ((long) 500000000);
                }
                sb2.append(j4 / ((long) 1000));
                sb2.append(" µs");
                String sb3 = sb2.toString();
                v12 v12 = v12.a;
                String format = String.format("%6s", Arrays.copyOf(new Object[]{sb3}, 1));
                p12.c(format, "java.lang.String.format(format, *args)");
                return format;
            }
            sb2.append(j3 / ((long) 1000000));
            sb2.append(" ms");
            String sb32 = sb2.toString();
            v12 v122 = v12.a;
            String format2 = String.format("%6s", Arrays.copyOf(new Object[]{sb32}, 1));
            p12.c(format2, "java.lang.String.format(format, *args)");
            return format2;
        }
        sb2.append(j2 / ((long) 1000000000));
        sb2.append(" s ");
        String sb322 = sb2.toString();
        v12 v1222 = v12.a;
        String format22 = String.format("%6s", Arrays.copyOf(new Object[]{sb322}, 1));
        p12.c(format22, "java.lang.String.format(format, *args)");
        return format22;
    }

    public static final void c(s42 s42, v42 v42, String str) {
        Logger a = w42.f5687a.a();
        StringBuilder sb = new StringBuilder();
        sb.append(v42.f());
        sb.append(' ');
        v12 v12 = v12.a;
        String format = String.format("%-22s", Arrays.copyOf(new Object[]{str}, 1));
        p12.c(format, "java.lang.String.format(format, *args)");
        sb.append(format);
        sb.append(": ");
        sb.append(s42.b());
        a.fine(sb.toString());
    }
}
