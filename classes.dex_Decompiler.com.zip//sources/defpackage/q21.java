package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* renamed from: q21  reason: default package */
public final class q21 implements Runnable {
    public final /* synthetic */ AtomicReference a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ z21 f4558a;

    public q21(z21 z21, AtomicReference atomicReference) {
        this.f4558a = z21;
        this.a = atomicReference;
    }

    public final void run() {
        synchronized (this.a) {
            try {
                this.a.set(Long.valueOf(this.f4558a.a.z().s(this.f4558a.a.a().p(), bz0.L)));
                this.a.notify();
            } catch (Throwable th) {
                this.a.notify();
                throw th;
            }
        }
    }
}
