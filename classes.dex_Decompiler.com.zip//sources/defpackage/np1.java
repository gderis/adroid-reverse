package defpackage;

import android.content.Intent;
import android.os.Binder;
import android.os.Process;
import android.util.Log;
import defpackage.qp1;

/* renamed from: np1  reason: default package */
public class np1 extends Binder {
    public final a a;

    /* renamed from: np1$a */
    public interface a {
        n81<Void> a(Intent intent);
    }

    public np1(a aVar) {
        this.a = aVar;
    }

    public void b(qp1.a aVar) {
        if (Binder.getCallingUid() == Process.myUid()) {
            boolean isLoggable = Log.isLoggable("FirebaseMessaging", 3);
            this.a.a(aVar.a).c(lp1.a, new mp1(aVar));
            return;
        }
        throw new SecurityException("Binding only allowed within app");
    }
}
