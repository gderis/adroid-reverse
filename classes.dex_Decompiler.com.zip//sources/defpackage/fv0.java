package defpackage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* renamed from: fv0  reason: default package */
public final class fv0 extends j51 {
    public static final String[] a = {"last_bundled_timestamp", "ALTER TABLE events ADD COLUMN last_bundled_timestamp INTEGER;", "last_bundled_day", "ALTER TABLE events ADD COLUMN last_bundled_day INTEGER;", "last_sampled_complex_event_id", "ALTER TABLE events ADD COLUMN last_sampled_complex_event_id INTEGER;", "last_sampling_rate", "ALTER TABLE events ADD COLUMN last_sampling_rate INTEGER;", "last_exempt_from_sampling", "ALTER TABLE events ADD COLUMN last_exempt_from_sampling INTEGER;", "current_session_count", "ALTER TABLE events ADD COLUMN current_session_count INTEGER;"};
    public static final String[] b = {"origin", "ALTER TABLE user_attributes ADD COLUMN origin TEXT;"};
    public static final String[] c = {"app_version", "ALTER TABLE apps ADD COLUMN app_version TEXT;", "app_store", "ALTER TABLE apps ADD COLUMN app_store TEXT;", "gmp_version", "ALTER TABLE apps ADD COLUMN gmp_version INTEGER;", "dev_cert_hash", "ALTER TABLE apps ADD COLUMN dev_cert_hash INTEGER;", "measurement_enabled", "ALTER TABLE apps ADD COLUMN measurement_enabled INTEGER;", "last_bundle_start_timestamp", "ALTER TABLE apps ADD COLUMN last_bundle_start_timestamp INTEGER;", "day", "ALTER TABLE apps ADD COLUMN day INTEGER;", "daily_public_events_count", "ALTER TABLE apps ADD COLUMN daily_public_events_count INTEGER;", "daily_events_count", "ALTER TABLE apps ADD COLUMN daily_events_count INTEGER;", "daily_conversions_count", "ALTER TABLE apps ADD COLUMN daily_conversions_count INTEGER;", "remote_config", "ALTER TABLE apps ADD COLUMN remote_config BLOB;", "config_fetched_time", "ALTER TABLE apps ADD COLUMN config_fetched_time INTEGER;", "failed_config_fetch_time", "ALTER TABLE apps ADD COLUMN failed_config_fetch_time INTEGER;", "app_version_int", "ALTER TABLE apps ADD COLUMN app_version_int INTEGER;", "firebase_instance_id", "ALTER TABLE apps ADD COLUMN firebase_instance_id TEXT;", "daily_error_events_count", "ALTER TABLE apps ADD COLUMN daily_error_events_count INTEGER;", "daily_realtime_events_count", "ALTER TABLE apps ADD COLUMN daily_realtime_events_count INTEGER;", "health_monitor_sample", "ALTER TABLE apps ADD COLUMN health_monitor_sample TEXT;", "android_id", "ALTER TABLE apps ADD COLUMN android_id INTEGER;", "adid_reporting_enabled", "ALTER TABLE apps ADD COLUMN adid_reporting_enabled INTEGER;", "ssaid_reporting_enabled", "ALTER TABLE apps ADD COLUMN ssaid_reporting_enabled INTEGER;", "admob_app_id", "ALTER TABLE apps ADD COLUMN admob_app_id TEXT;", "linked_admob_app_id", "ALTER TABLE apps ADD COLUMN linked_admob_app_id TEXT;", "dynamite_version", "ALTER TABLE apps ADD COLUMN dynamite_version INTEGER;", "safelisted_events", "ALTER TABLE apps ADD COLUMN safelisted_events TEXT;", "ga_app_id", "ALTER TABLE apps ADD COLUMN ga_app_id TEXT;", "config_last_modified_time", "ALTER TABLE apps ADD COLUMN config_last_modified_time TEXT;"};
    public static final String[] d = {"realtime", "ALTER TABLE raw_events ADD COLUMN realtime INTEGER;"};
    public static final String[] e = {"has_realtime", "ALTER TABLE queue ADD COLUMN has_realtime INTEGER;", "retry_count", "ALTER TABLE queue ADD COLUMN retry_count INTEGER;"};
    public static final String[] f = {"session_scoped", "ALTER TABLE event_filters ADD COLUMN session_scoped BOOLEAN;"};
    public static final String[] g = {"session_scoped", "ALTER TABLE property_filters ADD COLUMN session_scoped BOOLEAN;"};
    public static final String[] h = {"previous_install_count", "ALTER TABLE app2 ADD COLUMN previous_install_count INTEGER;"};

    /* renamed from: a  reason: collision with other field name */
    public final ev0 f2501a;

    /* renamed from: a  reason: collision with other field name */
    public final f51 f2502a = new f51(this.a.b());

    public fv0(s51 s51) {
        super(s51);
        this.a.z();
        this.f2501a = new ev0(this, this.a.e(), "google_app_measurement.db");
    }

    public static final void J(ContentValues contentValues, String str, Object obj) {
        s10.f("value");
        s10.j(obj);
        if (obj instanceof String) {
            contentValues.put("value", (String) obj);
        } else if (obj instanceof Long) {
            contentValues.put("value", (Long) obj);
        } else if (obj instanceof Double) {
            contentValues.put("value", (Double) obj);
        } else {
            throw new IllegalArgumentException("Invalid value type");
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v5, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v0, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v4, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v15, resolved type: java.lang.String[]} */
    /* JADX WARNING: type inference failed for: r3v0 */
    /* JADX WARNING: type inference failed for: r3v1, types: [android.database.Cursor] */
    /* JADX WARNING: type inference failed for: r3v3 */
    /* JADX WARNING: type inference failed for: r3v6 */
    /* JADX WARNING: type inference failed for: r3v7 */
    /* JADX WARNING: type inference failed for: r3v8 */
    /* JADX WARNING: type inference failed for: r3v10 */
    /* JADX WARNING: type inference failed for: r3v11 */
    /* JADX WARNING: type inference failed for: r3v12 */
    /* JADX WARNING: type inference failed for: r3v13 */
    /* JADX WARNING: type inference failed for: r3v14 */
    /* JADX WARNING: type inference failed for: r3v15 */
    /* JADX WARNING: type inference failed for: r3v16 */
    /* JADX WARNING: type inference failed for: r3v17 */
    /* JADX WARNING: type inference failed for: r3v18 */
    /* JADX WARNING: type inference failed for: r3v19 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x0230  */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x0238  */
    /* JADX WARNING: Removed duplicated region for block: B:122:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:13:0x0040=Splitter:B:13:0x0040, B:31:0x0092=Splitter:B:31:0x0092} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void I(java.lang.String r21, long r22, long r24, defpackage.r51 r26) {
        /*
            r20 = this;
            r1 = r20
            r2 = r26
            defpackage.s10.j(r26)
            r20.h()
            r20.j()
            r3 = 0
            android.database.sqlite.SQLiteDatabase r0 = r20.P()     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            boolean r4 = android.text.TextUtils.isEmpty(r3)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r5 = ""
            r13 = -1
            r15 = 2
            r12 = 1
            r11 = 0
            if (r4 == 0) goto L_0x0079
            int r4 = (r24 > r13 ? 1 : (r24 == r13 ? 0 : -1))
            if (r4 == 0) goto L_0x0032
            java.lang.String[] r4 = new java.lang.String[r15]     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r6 = java.lang.String.valueOf(r24)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r4[r11] = r6     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r6 = java.lang.String.valueOf(r22)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r4[r12] = r6     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            goto L_0x003a
        L_0x0032:
            java.lang.String[] r4 = new java.lang.String[r12]     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r6 = java.lang.String.valueOf(r22)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r4[r11] = r6     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
        L_0x003a:
            int r6 = (r24 > r13 ? 1 : (r24 == r13 ? 0 : -1))
            if (r6 == 0) goto L_0x0040
            java.lang.String r5 = "rowid <= ? and "
        L_0x0040:
            int r6 = r5.length()     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            int r6 = r6 + 148
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r7.<init>(r6)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r6 = "select app_id, metadata_fingerprint from raw_events where "
            r7.append(r6)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r7.append(r5)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r5 = "app_id in (select app_id from apps where config_fetched_time >= ?) order by rowid limit 1;"
            r7.append(r5)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r5 = r7.toString()     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            android.database.Cursor r4 = r0.rawQuery(r5, r4)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            boolean r5 = r4.moveToFirst()     // Catch:{ SQLiteException -> 0x0076 }
            if (r5 != 0) goto L_0x006a
            r4.close()
            return
        L_0x006a:
            java.lang.String r3 = r4.getString(r11)     // Catch:{ SQLiteException -> 0x0076 }
            java.lang.String r5 = r4.getString(r12)     // Catch:{ SQLiteException -> 0x0076 }
            r4.close()     // Catch:{ SQLiteException -> 0x0076 }
            goto L_0x00c3
        L_0x0076:
            r0 = move-exception
            goto L_0x021b
        L_0x0079:
            int r4 = (r24 > r13 ? 1 : (r24 == r13 ? 0 : -1))
            if (r4 == 0) goto L_0x0088
            java.lang.String[] r4 = new java.lang.String[r15]     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r4[r11] = r3     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r6 = java.lang.String.valueOf(r24)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r4[r12] = r6     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            goto L_0x008c
        L_0x0088:
            java.lang.String[] r4 = new java.lang.String[]{r3}     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
        L_0x008c:
            int r6 = (r24 > r13 ? 1 : (r24 == r13 ? 0 : -1))
            if (r6 == 0) goto L_0x0092
            java.lang.String r5 = " and rowid <= ?"
        L_0x0092:
            int r6 = r5.length()     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            int r6 = r6 + 84
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r7.<init>(r6)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r6 = "select metadata_fingerprint from raw_events where app_id = ?"
            r7.append(r6)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            r7.append(r5)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r5 = " order by rowid limit 1;"
            r7.append(r5)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            java.lang.String r5 = r7.toString()     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            android.database.Cursor r4 = r0.rawQuery(r5, r4)     // Catch:{ SQLiteException -> 0x0219, all -> 0x0217 }
            boolean r5 = r4.moveToFirst()     // Catch:{ SQLiteException -> 0x0076 }
            if (r5 != 0) goto L_0x00bc
            r4.close()
            return
        L_0x00bc:
            java.lang.String r5 = r4.getString(r11)     // Catch:{ SQLiteException -> 0x0076 }
            r4.close()     // Catch:{ SQLiteException -> 0x0076 }
        L_0x00c3:
            r16 = r4
            r17 = r5
            java.lang.String r4 = "metadata"
            java.lang.String[] r6 = new java.lang.String[]{r4}     // Catch:{ SQLiteException -> 0x0213, all -> 0x020f }
            java.lang.String[] r8 = new java.lang.String[r15]     // Catch:{ SQLiteException -> 0x0213, all -> 0x020f }
            r8[r11] = r3     // Catch:{ SQLiteException -> 0x0213, all -> 0x020f }
            r8[r12] = r17     // Catch:{ SQLiteException -> 0x0213, all -> 0x020f }
            java.lang.String r5 = "raw_events_metadata"
            java.lang.String r7 = "app_id = ? and metadata_fingerprint = ?"
            r9 = 0
            r10 = 0
            java.lang.String r18 = "rowid"
            java.lang.String r19 = "2"
            r4 = r0
            r15 = 0
            r11 = r18
            r12 = r19
            android.database.Cursor r12 = r4.query(r5, r6, r7, r8, r9, r10, r11, r12)     // Catch:{ SQLiteException -> 0x0213, all -> 0x020f }
            boolean r4 = r12.moveToFirst()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            if (r4 != 0) goto L_0x0104
            w01 r0 = r1.a     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            nz0 r0 = r0.c()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            lz0 r0 = r0.o()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            java.lang.String r2 = "Raw event metadata record is missing. appId"
            java.lang.Object r4 = defpackage.nz0.x(r3)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r0.b(r2, r4)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r12.close()
            return
        L_0x0104:
            byte[] r4 = r12.getBlob(r15)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            ug0 r5 = defpackage.vg0.K0()     // Catch:{ IOException -> 0x01ea }
            km0 r4 = defpackage.u51.J(r5, r4)     // Catch:{ IOException -> 0x01ea }
            ug0 r4 = (defpackage.ug0) r4     // Catch:{ IOException -> 0x01ea }
            gl0 r4 = r4.k()     // Catch:{ IOException -> 0x01ea }
            vg0 r4 = (defpackage.vg0) r4     // Catch:{ IOException -> 0x01ea }
            boolean r5 = r12.moveToNext()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            if (r5 == 0) goto L_0x0131
            w01 r5 = r1.a     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            nz0 r5 = r5.c()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            lz0 r5 = r5.r()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            java.lang.String r6 = "Get multiple raw event metadata records, expected one. appId"
            java.lang.Object r7 = defpackage.nz0.x(r3)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r5.b(r6, r7)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
        L_0x0131:
            r12.close()     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            defpackage.s10.j(r4)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r2.f4726a = r4     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r11 = 3
            int r4 = (r24 > r13 ? 1 : (r24 == r13 ? 0 : -1))
            if (r4 == 0) goto L_0x0151
            java.lang.String r4 = "app_id = ? and metadata_fingerprint = ? and rowid <= ?"
            java.lang.String[] r5 = new java.lang.String[r11]     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r5[r15] = r3     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r13 = 1
            r5[r13] = r17     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            java.lang.String r6 = java.lang.String.valueOf(r24)     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r7 = 2
            r5[r7] = r6     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r7 = r4
            r8 = r5
            goto L_0x015d
        L_0x0151:
            r13 = 1
            java.lang.String r4 = "app_id = ? and metadata_fingerprint = ?"
            r5 = 2
            java.lang.String[] r6 = new java.lang.String[r5]     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r6[r15] = r3     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r6[r13] = r17     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            r7 = r4
            r8 = r6
        L_0x015d:
            java.lang.String r4 = "rowid"
            java.lang.String r5 = "name"
            java.lang.String r6 = "timestamp"
            java.lang.String r9 = "data"
            java.lang.String[] r6 = new java.lang.String[]{r4, r5, r6, r9}     // Catch:{ SQLiteException -> 0x020b, all -> 0x0207 }
            java.lang.String r5 = "raw_events"
            r9 = 0
            r10 = 0
            java.lang.String r14 = "rowid"
            r16 = 0
            r4 = r0
            r13 = 3
            r11 = r14
            r14 = r12
            r12 = r16
            android.database.Cursor r4 = r4.query(r5, r6, r7, r8, r9, r10, r11, r12)     // Catch:{ SQLiteException -> 0x0205, all -> 0x0203 }
            boolean r0 = r4.moveToFirst()     // Catch:{ SQLiteException -> 0x0076 }
            if (r0 == 0) goto L_0x01d3
        L_0x0181:
            long r5 = r4.getLong(r15)     // Catch:{ SQLiteException -> 0x0076 }
            byte[] r0 = r4.getBlob(r13)     // Catch:{ SQLiteException -> 0x0076 }
            mg0 r7 = defpackage.ng0.K()     // Catch:{ IOException -> 0x01b3 }
            km0 r0 = defpackage.u51.J(r7, r0)     // Catch:{ IOException -> 0x01b3 }
            mg0 r0 = (defpackage.mg0) r0     // Catch:{ IOException -> 0x01b3 }
            r7 = 1
            java.lang.String r8 = r4.getString(r7)     // Catch:{ SQLiteException -> 0x0076 }
            r0.H(r8)     // Catch:{ SQLiteException -> 0x0076 }
            r8 = 2
            long r9 = r4.getLong(r8)     // Catch:{ SQLiteException -> 0x0076 }
            r0.K(r9)     // Catch:{ SQLiteException -> 0x0076 }
            gl0 r0 = r0.k()     // Catch:{ SQLiteException -> 0x0076 }
            ng0 r0 = (defpackage.ng0) r0     // Catch:{ SQLiteException -> 0x0076 }
            boolean r0 = r2.a(r5, r0)     // Catch:{ SQLiteException -> 0x0076 }
            if (r0 != 0) goto L_0x01c9
            r4.close()
            return
        L_0x01b3:
            r0 = move-exception
            r7 = 1
            r8 = 2
            w01 r5 = r1.a     // Catch:{ SQLiteException -> 0x0076 }
            nz0 r5 = r5.c()     // Catch:{ SQLiteException -> 0x0076 }
            lz0 r5 = r5.o()     // Catch:{ SQLiteException -> 0x0076 }
            java.lang.String r6 = "Data loss. Failed to merge raw event. appId"
            java.lang.Object r9 = defpackage.nz0.x(r3)     // Catch:{ SQLiteException -> 0x0076 }
            r5.c(r6, r9, r0)     // Catch:{ SQLiteException -> 0x0076 }
        L_0x01c9:
            boolean r0 = r4.moveToNext()     // Catch:{ SQLiteException -> 0x0076 }
            if (r0 != 0) goto L_0x0181
            r4.close()
            return
        L_0x01d3:
            w01 r0 = r1.a     // Catch:{ SQLiteException -> 0x0076 }
            nz0 r0 = r0.c()     // Catch:{ SQLiteException -> 0x0076 }
            lz0 r0 = r0.r()     // Catch:{ SQLiteException -> 0x0076 }
            java.lang.String r2 = "Raw event data disappeared while in transaction. appId"
            java.lang.Object r5 = defpackage.nz0.x(r3)     // Catch:{ SQLiteException -> 0x0076 }
            r0.b(r2, r5)     // Catch:{ SQLiteException -> 0x0076 }
            r4.close()
            return
        L_0x01ea:
            r0 = move-exception
            r14 = r12
            w01 r2 = r1.a     // Catch:{ SQLiteException -> 0x0205, all -> 0x0203 }
            nz0 r2 = r2.c()     // Catch:{ SQLiteException -> 0x0205, all -> 0x0203 }
            lz0 r2 = r2.o()     // Catch:{ SQLiteException -> 0x0205, all -> 0x0203 }
            java.lang.String r4 = "Data loss. Failed to merge raw event metadata. appId"
            java.lang.Object r5 = defpackage.nz0.x(r3)     // Catch:{ SQLiteException -> 0x0205, all -> 0x0203 }
            r2.c(r4, r5, r0)     // Catch:{ SQLiteException -> 0x0205, all -> 0x0203 }
            r14.close()
            return
        L_0x0203:
            r0 = move-exception
            goto L_0x0209
        L_0x0205:
            r0 = move-exception
            goto L_0x020d
        L_0x0207:
            r0 = move-exception
            r14 = r12
        L_0x0209:
            r3 = r14
            goto L_0x0236
        L_0x020b:
            r0 = move-exception
            r14 = r12
        L_0x020d:
            r4 = r14
            goto L_0x021b
        L_0x020f:
            r0 = move-exception
            r3 = r16
            goto L_0x0236
        L_0x0213:
            r0 = move-exception
            r4 = r16
            goto L_0x021b
        L_0x0217:
            r0 = move-exception
            goto L_0x0236
        L_0x0219:
            r0 = move-exception
            r4 = r3
        L_0x021b:
            w01 r2 = r1.a     // Catch:{ all -> 0x0234 }
            nz0 r2 = r2.c()     // Catch:{ all -> 0x0234 }
            lz0 r2 = r2.o()     // Catch:{ all -> 0x0234 }
            java.lang.String r5 = "Data loss. Error selecting raw event. appId"
            java.lang.Object r3 = defpackage.nz0.x(r3)     // Catch:{ all -> 0x0234 }
            r2.c(r5, r3, r0)     // Catch:{ all -> 0x0234 }
            if (r4 == 0) goto L_0x0233
            r4.close()
        L_0x0233:
            return
        L_0x0234:
            r0 = move-exception
            r3 = r4
        L_0x0236:
            if (r3 == 0) goto L_0x023b
            r3.close()
        L_0x023b:
            goto L_0x023d
        L_0x023c:
            throw r0
        L_0x023d:
            goto L_0x023c
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.I(java.lang.String, long, long, r51):void");
    }

    public final long K(String str, String[] strArr) {
        Cursor cursor = null;
        try {
            cursor = P().rawQuery(str, strArr);
            if (cursor.moveToFirst()) {
                long j = cursor.getLong(0);
                cursor.close();
                return j;
            }
            throw new SQLiteException("Database returned empty set");
        } catch (SQLiteException e2) {
            this.a.c().o().c("Database error", str, e2);
            throw e2;
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    public final long L(String str, String[] strArr, long j) {
        Cursor cursor = null;
        try {
            Cursor rawQuery = P().rawQuery(str, strArr);
            if (rawQuery.moveToFirst()) {
                long j2 = rawQuery.getLong(0);
                rawQuery.close();
                return j2;
            }
            rawQuery.close();
            return j;
        } catch (SQLiteException e2) {
            this.a.c().o().c("Database error", str, e2);
            throw e2;
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    public final void M() {
        j();
        P().beginTransaction();
    }

    public final void N() {
        j();
        P().setTransactionSuccessful();
    }

    public final void O() {
        j();
        P().endTransaction();
    }

    public final SQLiteDatabase P() {
        h();
        try {
            return this.f2501a.getWritableDatabase();
        } catch (SQLiteException e2) {
            this.a.c().r().b("Error opening database", e2);
            throw e2;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:58:0x0147  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0150  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final defpackage.lv0 Q(java.lang.String r28, java.lang.String r29) {
        /*
            r27 = this;
            r1 = r27
            r15 = r29
            defpackage.s10.f(r28)
            defpackage.s10.f(r29)
            r27.h()
            r27.j()
            java.util.ArrayList r0 = new java.util.ArrayList
            java.lang.String r2 = "lifetime_count"
            java.lang.String r3 = "current_bundle_count"
            java.lang.String r4 = "last_fire_timestamp"
            java.lang.String r5 = "last_bundled_timestamp"
            java.lang.String r6 = "last_bundled_day"
            java.lang.String r7 = "last_sampled_complex_event_id"
            java.lang.String r8 = "last_sampling_rate"
            java.lang.String r9 = "last_exempt_from_sampling"
            java.lang.String r10 = "current_session_count"
            java.lang.String[] r2 = new java.lang.String[]{r2, r3, r4, r5, r6, r7, r8, r9, r10}
            java.util.List r2 = java.util.Arrays.asList(r2)
            r0.<init>(r2)
            r19 = 0
            android.database.sqlite.SQLiteDatabase r2 = r27.P()     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            r10 = 0
            java.lang.String[] r3 = new java.lang.String[r10]     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            java.lang.Object[] r0 = r0.toArray(r3)     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            r4 = r0
            java.lang.String[] r4 = (java.lang.String[]) r4     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            r0 = 2
            java.lang.String[] r6 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            r6[r10] = r28     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            r11 = 1
            r6[r11] = r15     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            java.lang.String r3 = "events"
            java.lang.String r5 = "app_id=? and name=?"
            r7 = 0
            r8 = 0
            r9 = 0
            android.database.Cursor r13 = r2.query(r3, r4, r5, r6, r7, r8, r9)     // Catch:{ SQLiteException -> 0x0123, all -> 0x0121 }
            boolean r2 = r13.moveToFirst()     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            if (r2 != 0) goto L_0x005c
            r13.close()
            return r19
        L_0x005c:
            long r5 = r13.getLong(r10)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            long r7 = r13.getLong(r11)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            long r16 = r13.getLong(r0)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r0 = 3
            boolean r2 = r13.isNull(r0)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r3 = 0
            if (r2 == 0) goto L_0x0074
            r20 = r3
            goto L_0x0078
        L_0x0074:
            long r20 = r13.getLong(r0)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
        L_0x0078:
            r0 = 4
            boolean r2 = r13.isNull(r0)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            if (r2 == 0) goto L_0x0082
            r0 = r19
            goto L_0x008a
        L_0x0082:
            long r22 = r13.getLong(r0)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            java.lang.Long r0 = java.lang.Long.valueOf(r22)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
        L_0x008a:
            r2 = 5
            boolean r9 = r13.isNull(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            if (r9 == 0) goto L_0x0094
            r18 = r19
            goto L_0x009e
        L_0x0094:
            long r22 = r13.getLong(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            java.lang.Long r2 = java.lang.Long.valueOf(r22)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r18 = r2
        L_0x009e:
            r2 = 6
            boolean r9 = r13.isNull(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            if (r9 == 0) goto L_0x00a8
            r22 = r19
            goto L_0x00b2
        L_0x00a8:
            long r22 = r13.getLong(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            java.lang.Long r2 = java.lang.Long.valueOf(r22)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r22 = r2
        L_0x00b2:
            r2 = 7
            boolean r9 = r13.isNull(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            if (r9 != 0) goto L_0x00cb
            long r23 = r13.getLong(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r25 = 1
            int r2 = (r23 > r25 ? 1 : (r23 == r25 ? 0 : -1))
            if (r2 != 0) goto L_0x00c4
            r10 = 1
        L_0x00c4:
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r10)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r23 = r2
            goto L_0x00cd
        L_0x00cb:
            r23 = r19
        L_0x00cd:
            r2 = 8
            boolean r9 = r13.isNull(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            if (r9 == 0) goto L_0x00d7
            r9 = r3
            goto L_0x00dc
        L_0x00d7:
            long r2 = r13.getLong(r2)     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r9 = r2
        L_0x00dc:
            lv0 r24 = new lv0     // Catch:{ SQLiteException -> 0x011b, all -> 0x0115 }
            r2 = r24
            r3 = r28
            r4 = r29
            r11 = r16
            r25 = r13
            r13 = r20
            r15 = r0
            r16 = r18
            r17 = r22
            r18 = r23
            r2.<init>(r3, r4, r5, r7, r9, r11, r13, r15, r16, r17, r18)     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
            boolean r0 = r25.moveToNext()     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
            if (r0 == 0) goto L_0x010d
            w01 r0 = r1.a     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
            nz0 r0 = r0.c()     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
            lz0 r0 = r0.o()     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
            java.lang.String r2 = "Got multiple records for event aggregates, expected one. appId"
            java.lang.Object r3 = defpackage.nz0.x(r28)     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
            r0.b(r2, r3)     // Catch:{ SQLiteException -> 0x0113, all -> 0x0111 }
        L_0x010d:
            r25.close()
            return r24
        L_0x0111:
            r0 = move-exception
            goto L_0x0118
        L_0x0113:
            r0 = move-exception
            goto L_0x011e
        L_0x0115:
            r0 = move-exception
            r25 = r13
        L_0x0118:
            r19 = r25
            goto L_0x014e
        L_0x011b:
            r0 = move-exception
            r25 = r13
        L_0x011e:
            r13 = r25
            goto L_0x0126
        L_0x0121:
            r0 = move-exception
            goto L_0x014e
        L_0x0123:
            r0 = move-exception
            r13 = r19
        L_0x0126:
            w01 r2 = r1.a     // Catch:{ all -> 0x014b }
            nz0 r2 = r2.c()     // Catch:{ all -> 0x014b }
            lz0 r2 = r2.o()     // Catch:{ all -> 0x014b }
            java.lang.String r3 = "Error querying events. appId"
            java.lang.Object r4 = defpackage.nz0.x(r28)     // Catch:{ all -> 0x014b }
            w01 r5 = r1.a     // Catch:{ all -> 0x014b }
            iz0 r5 = r5.H()     // Catch:{ all -> 0x014b }
            r6 = r29
            java.lang.String r5 = r5.p(r6)     // Catch:{ all -> 0x014b }
            r2.d(r3, r4, r5, r0)     // Catch:{ all -> 0x014b }
            if (r13 == 0) goto L_0x014a
            r13.close()
        L_0x014a:
            return r19
        L_0x014b:
            r0 = move-exception
            r19 = r13
        L_0x014e:
            if (r19 == 0) goto L_0x0153
            r19.close()
        L_0x0153:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.Q(java.lang.String, java.lang.String):lv0");
    }

    public final void R(lv0 lv0) {
        s10.j(lv0);
        h();
        j();
        ContentValues contentValues = new ContentValues();
        contentValues.put("app_id", lv0.f3720a);
        contentValues.put("name", lv0.f3722b);
        contentValues.put("lifetime_count", Long.valueOf(lv0.a));
        contentValues.put("current_bundle_count", Long.valueOf(lv0.b));
        contentValues.put("last_fire_timestamp", Long.valueOf(lv0.d));
        contentValues.put("last_bundled_timestamp", Long.valueOf(lv0.e));
        contentValues.put("last_bundled_day", lv0.f3719a);
        contentValues.put("last_sampled_complex_event_id", lv0.f3721b);
        contentValues.put("last_sampling_rate", lv0.f3723c);
        contentValues.put("current_session_count", Long.valueOf(lv0.c));
        Boolean bool = lv0.f3718a;
        contentValues.put("last_exempt_from_sampling", (bool == null || !bool.booleanValue()) ? null : 1L);
        try {
            if (P().insertWithOnConflict("events", (String) null, contentValues, 5) == -1) {
                this.a.c().o().b("Failed to insert/update event aggregates (got -1). appId", nz0.x(lv0.f3720a));
            }
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error storing event aggregates. appId", nz0.x(lv0.f3720a), e2);
        }
    }

    public final void S(String str, String str2) {
        s10.f(str);
        s10.f(str2);
        h();
        j();
        try {
            P().delete("user_attributes", "app_id=? and name=?", new String[]{str, str2});
        } catch (SQLiteException e2) {
            this.a.c().o().d("Error deleting user property. appId", nz0.x(str), this.a.H().r(str2), e2);
        }
    }

    public final boolean T(x51 x51) {
        s10.j(x51);
        h();
        j();
        if (U(x51.f5788a, x51.c) == null) {
            if (z51.j0(x51.c)) {
                if (K("select count(1) from user_attributes where app_id=? and name not like '!_%' escape '!'", new String[]{x51.f5788a}) >= ((long) this.a.z().u(x51.f5788a, bz0.F, 25, 100))) {
                    return false;
                }
            } else if (!"_npa".equals(x51.c)) {
                long K = K("select count(1) from user_attributes where app_id=? and origin=? AND name like '!_%' escape '!'", new String[]{x51.f5788a, x51.b});
                this.a.z();
                if (K >= 25) {
                    return false;
                }
            }
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("app_id", x51.f5788a);
        contentValues.put("origin", x51.b);
        contentValues.put("name", x51.c);
        contentValues.put("set_timestamp", Long.valueOf(x51.a));
        J(contentValues, "value", x51.f5787a);
        try {
            if (P().insertWithOnConflict("user_attributes", (String) null, contentValues, 5) == -1) {
                this.a.c().o().b("Failed to insert/update user property (got -1). appId", nz0.x(x51.f5788a));
            }
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error storing user property. appId", nz0.x(x51.f5788a), e2);
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x009e  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00a6  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final defpackage.x51 U(java.lang.String r20, java.lang.String r21) {
        /*
            r19 = this;
            r1 = r19
            r9 = r21
            defpackage.s10.f(r20)
            defpackage.s10.f(r21)
            r19.h()
            r19.j()
            r10 = 0
            android.database.sqlite.SQLiteDatabase r11 = r19.P()     // Catch:{ SQLiteException -> 0x007d, all -> 0x007b }
            java.lang.String r0 = "set_timestamp"
            java.lang.String r2 = "value"
            java.lang.String r3 = "origin"
            java.lang.String[] r13 = new java.lang.String[]{r0, r2, r3}     // Catch:{ SQLiteException -> 0x007d, all -> 0x007b }
            r0 = 2
            java.lang.String[] r15 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x007d, all -> 0x007b }
            r2 = 0
            r15[r2] = r20     // Catch:{ SQLiteException -> 0x007d, all -> 0x007b }
            r3 = 1
            r15[r3] = r9     // Catch:{ SQLiteException -> 0x007d, all -> 0x007b }
            java.lang.String r12 = "user_attributes"
            java.lang.String r14 = "app_id=? and name=?"
            r16 = 0
            r17 = 0
            r18 = 0
            android.database.Cursor r11 = r11.query(r12, r13, r14, r15, r16, r17, r18)     // Catch:{ SQLiteException -> 0x007d, all -> 0x007b }
            boolean r4 = r11.moveToFirst()     // Catch:{ SQLiteException -> 0x0079 }
            if (r4 != 0) goto L_0x0040
            r11.close()
            return r10
        L_0x0040:
            long r6 = r11.getLong(r2)     // Catch:{ SQLiteException -> 0x0079 }
            java.lang.Object r8 = r1.o(r11, r3)     // Catch:{ SQLiteException -> 0x0079 }
            if (r8 != 0) goto L_0x004e
            r11.close()
            return r10
        L_0x004e:
            java.lang.String r4 = r11.getString(r0)     // Catch:{ SQLiteException -> 0x0079 }
            x51 r0 = new x51     // Catch:{ SQLiteException -> 0x0079 }
            r2 = r0
            r3 = r20
            r5 = r21
            r2.<init>(r3, r4, r5, r6, r8)     // Catch:{ SQLiteException -> 0x0079 }
            boolean r2 = r11.moveToNext()     // Catch:{ SQLiteException -> 0x0079 }
            if (r2 == 0) goto L_0x0075
            w01 r2 = r1.a     // Catch:{ SQLiteException -> 0x0079 }
            nz0 r2 = r2.c()     // Catch:{ SQLiteException -> 0x0079 }
            lz0 r2 = r2.o()     // Catch:{ SQLiteException -> 0x0079 }
            java.lang.String r3 = "Got multiple records for user property, expected one. appId"
            java.lang.Object r4 = defpackage.nz0.x(r20)     // Catch:{ SQLiteException -> 0x0079 }
            r2.b(r3, r4)     // Catch:{ SQLiteException -> 0x0079 }
        L_0x0075:
            r11.close()
            return r0
        L_0x0079:
            r0 = move-exception
            goto L_0x007f
        L_0x007b:
            r0 = move-exception
            goto L_0x00a4
        L_0x007d:
            r0 = move-exception
            r11 = r10
        L_0x007f:
            w01 r2 = r1.a     // Catch:{ all -> 0x00a2 }
            nz0 r2 = r2.c()     // Catch:{ all -> 0x00a2 }
            lz0 r2 = r2.o()     // Catch:{ all -> 0x00a2 }
            java.lang.String r3 = "Error querying user property. appId"
            java.lang.Object r4 = defpackage.nz0.x(r20)     // Catch:{ all -> 0x00a2 }
            w01 r5 = r1.a     // Catch:{ all -> 0x00a2 }
            iz0 r5 = r5.H()     // Catch:{ all -> 0x00a2 }
            java.lang.String r5 = r5.r(r9)     // Catch:{ all -> 0x00a2 }
            r2.d(r3, r4, r5, r0)     // Catch:{ all -> 0x00a2 }
            if (r11 == 0) goto L_0x00a1
            r11.close()
        L_0x00a1:
            return r10
        L_0x00a2:
            r0 = move-exception
            r10 = r11
        L_0x00a4:
            if (r10 == 0) goto L_0x00a9
            r10.close()
        L_0x00a9:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.U(java.lang.String, java.lang.String):x51");
    }

    public final List<x51> V(String str) {
        s10.f(str);
        h();
        j();
        ArrayList arrayList = new ArrayList();
        Cursor cursor = null;
        try {
            this.a.z();
            Cursor query = P().query("user_attributes", new String[]{"name", "origin", "set_timestamp", "value"}, "app_id=?", new String[]{str}, (String) null, (String) null, "rowid", "1000");
            if (query.moveToFirst()) {
                do {
                    String string = query.getString(0);
                    String string2 = query.getString(1);
                    if (string2 == null) {
                        string2 = "";
                    }
                    String str2 = string2;
                    long j = query.getLong(2);
                    Object o = o(query, 3);
                    if (o == null) {
                        this.a.c().o().b("Read invalid user property value, ignoring it. appId", nz0.x(str));
                    } else {
                        arrayList.add(new x51(str, str2, string, j, o));
                    }
                } while (query.moveToNext());
                query.close();
                return arrayList;
            }
            query.close();
            return arrayList;
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error querying user properties. appId", nz0.x(str), e2);
            List<x51> emptyList = Collections.emptyList();
            if (cursor != null) {
                cursor.close();
            }
            return emptyList;
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:39:0x011d A[DONT_GENERATE] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.util.List<defpackage.x51> W(java.lang.String r17, java.lang.String r18, java.lang.String r19) {
        /*
            r16 = this;
            r1 = r16
            defpackage.s10.f(r17)
            r16.h()
            r16.j()
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.lang.String r10 = "1001"
            r11 = 0
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ SQLiteException -> 0x00ff }
            r12 = 3
            r2.<init>(r12)     // Catch:{ SQLiteException -> 0x00ff }
            r13 = r17
            r2.add(r13)     // Catch:{ SQLiteException -> 0x00fd }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ SQLiteException -> 0x00fd }
            java.lang.String r4 = "app_id=?"
            r3.<init>(r4)     // Catch:{ SQLiteException -> 0x00fd }
            boolean r4 = android.text.TextUtils.isEmpty(r18)     // Catch:{ SQLiteException -> 0x00fd }
            if (r4 != 0) goto L_0x0036
            r14 = r18
            r2.add(r14)     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r4 = " and origin=?"
            r3.append(r4)     // Catch:{ SQLiteException -> 0x00f9 }
            goto L_0x0038
        L_0x0036:
            r14 = r18
        L_0x0038:
            boolean r4 = android.text.TextUtils.isEmpty(r19)     // Catch:{ SQLiteException -> 0x00f9 }
            if (r4 != 0) goto L_0x0050
            java.lang.String r4 = java.lang.String.valueOf(r19)     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r5 = "*"
            java.lang.String r4 = r4.concat(r5)     // Catch:{ SQLiteException -> 0x00f9 }
            r2.add(r4)     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r4 = " and name glob ?"
            r3.append(r4)     // Catch:{ SQLiteException -> 0x00f9 }
        L_0x0050:
            int r4 = r2.size()     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.Object[] r2 = r2.toArray(r4)     // Catch:{ SQLiteException -> 0x00f9 }
            r6 = r2
            java.lang.String[] r6 = (java.lang.String[]) r6     // Catch:{ SQLiteException -> 0x00f9 }
            android.database.sqlite.SQLiteDatabase r2 = r16.P()     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r4 = "user_attributes"
            java.lang.String r5 = "name"
            java.lang.String r7 = "set_timestamp"
            java.lang.String r8 = "value"
            java.lang.String r9 = "origin"
            java.lang.String[] r5 = new java.lang.String[]{r5, r7, r8, r9}     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r7 = r3.toString()     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r9 = "rowid"
            w01 r3 = r1.a     // Catch:{ SQLiteException -> 0x00f9 }
            r3.z()     // Catch:{ SQLiteException -> 0x00f9 }
            r8 = 0
            r15 = 0
            r3 = r4
            r4 = r5
            r5 = r7
            r7 = r8
            r8 = r15
            android.database.Cursor r11 = r2.query(r3, r4, r5, r6, r7, r8, r9, r10)     // Catch:{ SQLiteException -> 0x00f9 }
            boolean r2 = r11.moveToFirst()     // Catch:{ SQLiteException -> 0x00f9 }
            if (r2 != 0) goto L_0x008f
            r11.close()
            return r0
        L_0x008f:
            int r2 = r0.size()     // Catch:{ SQLiteException -> 0x00f9 }
            w01 r3 = r1.a     // Catch:{ SQLiteException -> 0x00f9 }
            r3.z()     // Catch:{ SQLiteException -> 0x00f9 }
            r3 = 1000(0x3e8, float:1.401E-42)
            if (r2 < r3) goto L_0x00b5
            w01 r2 = r1.a     // Catch:{ SQLiteException -> 0x00f9 }
            nz0 r2 = r2.c()     // Catch:{ SQLiteException -> 0x00f9 }
            lz0 r2 = r2.o()     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r4 = "Read more than the max allowed user properties, ignoring excess"
            w01 r5 = r1.a     // Catch:{ SQLiteException -> 0x00f9 }
            r5.z()     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ SQLiteException -> 0x00f9 }
            r2.b(r4, r3)     // Catch:{ SQLiteException -> 0x00f9 }
            goto L_0x00f5
        L_0x00b5:
            r2 = 0
            java.lang.String r6 = r11.getString(r2)     // Catch:{ SQLiteException -> 0x00f9 }
            r2 = 1
            long r7 = r11.getLong(r2)     // Catch:{ SQLiteException -> 0x00f9 }
            r2 = 2
            java.lang.Object r9 = r1.o(r11, r2)     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r14 = r11.getString(r12)     // Catch:{ SQLiteException -> 0x00f9 }
            if (r9 != 0) goto L_0x00e0
            w01 r2 = r1.a     // Catch:{ SQLiteException -> 0x00f9 }
            nz0 r2 = r2.c()     // Catch:{ SQLiteException -> 0x00f9 }
            lz0 r2 = r2.o()     // Catch:{ SQLiteException -> 0x00f9 }
            java.lang.String r3 = "(2)Read invalid user property value, ignoring it"
            java.lang.Object r4 = defpackage.nz0.x(r17)     // Catch:{ SQLiteException -> 0x00f9 }
            r10 = r19
            r2.d(r3, r4, r14, r10)     // Catch:{ SQLiteException -> 0x00f9 }
            goto L_0x00ee
        L_0x00e0:
            r10 = r19
            x51 r2 = new x51     // Catch:{ SQLiteException -> 0x00f9 }
            r3 = r2
            r4 = r17
            r5 = r14
            r3.<init>(r4, r5, r6, r7, r9)     // Catch:{ SQLiteException -> 0x00f9 }
            r0.add(r2)     // Catch:{ SQLiteException -> 0x00f9 }
        L_0x00ee:
            boolean r2 = r11.moveToNext()     // Catch:{ SQLiteException -> 0x00f9 }
            if (r2 == 0) goto L_0x00f5
            goto L_0x008f
        L_0x00f5:
            r11.close()
            return r0
        L_0x00f9:
            r0 = move-exception
            goto L_0x0104
        L_0x00fb:
            r0 = move-exception
            goto L_0x0121
        L_0x00fd:
            r0 = move-exception
            goto L_0x0102
        L_0x00ff:
            r0 = move-exception
            r13 = r17
        L_0x0102:
            r14 = r18
        L_0x0104:
            w01 r2 = r1.a     // Catch:{ all -> 0x00fb }
            nz0 r2 = r2.c()     // Catch:{ all -> 0x00fb }
            lz0 r2 = r2.o()     // Catch:{ all -> 0x00fb }
            java.lang.String r3 = "(2)Error querying user properties"
            java.lang.Object r4 = defpackage.nz0.x(r17)     // Catch:{ all -> 0x00fb }
            r2.d(r3, r4, r14, r0)     // Catch:{ all -> 0x00fb }
            java.util.List r0 = java.util.Collections.emptyList()     // Catch:{ all -> 0x00fb }
            if (r11 == 0) goto L_0x0120
            r11.close()
        L_0x0120:
            return r0
        L_0x0121:
            if (r11 == 0) goto L_0x0126
            r11.close()
        L_0x0126:
            goto L_0x0128
        L_0x0127:
            throw r0
        L_0x0128:
            goto L_0x0127
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.W(java.lang.String, java.lang.String, java.lang.String):java.util.List");
    }

    public final boolean X(xu0 xu0) {
        s10.j(xu0);
        h();
        j();
        String str = xu0.f5893a;
        s10.j(str);
        if (U(str, xu0.f5895a.f5527a) == null) {
            long K = K("SELECT COUNT(1) FROM conditional_properties WHERE app_id=?", new String[]{str});
            this.a.z();
            if (K >= 1000) {
                return false;
            }
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("app_id", str);
        contentValues.put("origin", xu0.f5896b);
        contentValues.put("name", xu0.f5895a.f5527a);
        J(contentValues, "value", s10.j(xu0.f5895a.A0()));
        contentValues.put("active", Boolean.valueOf(xu0.f5898b));
        contentValues.put("trigger_event_name", xu0.f5899c);
        contentValues.put("trigger_timeout", Long.valueOf(xu0.b));
        contentValues.put("timed_out_event", this.a.G().L(xu0.f5894a));
        contentValues.put("creation_timestamp", Long.valueOf(xu0.a));
        contentValues.put("triggered_event", this.a.G().L(xu0.f5897b));
        contentValues.put("triggered_timestamp", Long.valueOf(xu0.f5895a.f5524a));
        contentValues.put("time_to_live", Long.valueOf(xu0.c));
        contentValues.put("expired_event", this.a.G().L(xu0.f5900c));
        try {
            if (P().insertWithOnConflict("conditional_properties", (String) null, contentValues, 5) == -1) {
                this.a.c().o().b("Failed to insert/update conditional user property (got -1)", nz0.x(str));
            }
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error storing conditional user property", nz0.x(str), e2);
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0118  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0120  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final defpackage.xu0 Y(java.lang.String r31, java.lang.String r32) {
        /*
            r30 = this;
            r1 = r30
            r8 = r32
            defpackage.s10.f(r31)
            defpackage.s10.f(r32)
            r30.h()
            r30.j()
            r9 = 0
            android.database.sqlite.SQLiteDatabase r10 = r30.P()     // Catch:{ SQLiteException -> 0x00f7, all -> 0x00f5 }
            java.lang.String r11 = "origin"
            java.lang.String r12 = "value"
            java.lang.String r13 = "active"
            java.lang.String r14 = "trigger_event_name"
            java.lang.String r15 = "trigger_timeout"
            java.lang.String r16 = "timed_out_event"
            java.lang.String r17 = "creation_timestamp"
            java.lang.String r18 = "triggered_event"
            java.lang.String r19 = "triggered_timestamp"
            java.lang.String r20 = "time_to_live"
            java.lang.String r21 = "expired_event"
            java.lang.String[] r12 = new java.lang.String[]{r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21}     // Catch:{ SQLiteException -> 0x00f7, all -> 0x00f5 }
            r0 = 2
            java.lang.String[] r14 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x00f7, all -> 0x00f5 }
            r2 = 0
            r14[r2] = r31     // Catch:{ SQLiteException -> 0x00f7, all -> 0x00f5 }
            r3 = 1
            r14[r3] = r8     // Catch:{ SQLiteException -> 0x00f7, all -> 0x00f5 }
            java.lang.String r11 = "conditional_properties"
            java.lang.String r13 = "app_id=? and name=?"
            r15 = 0
            r16 = 0
            r17 = 0
            android.database.Cursor r10 = r10.query(r11, r12, r13, r14, r15, r16, r17)     // Catch:{ SQLiteException -> 0x00f7, all -> 0x00f5 }
            boolean r4 = r10.moveToFirst()     // Catch:{ SQLiteException -> 0x00f3 }
            if (r4 != 0) goto L_0x004f
            r10.close()
            return r9
        L_0x004f:
            java.lang.String r17 = r10.getString(r2)     // Catch:{ SQLiteException -> 0x00f3 }
            java.lang.Object r6 = r1.o(r10, r3)     // Catch:{ SQLiteException -> 0x00f3 }
            int r0 = r10.getInt(r0)     // Catch:{ SQLiteException -> 0x00f3 }
            if (r0 == 0) goto L_0x0060
            r21 = 1
            goto L_0x0062
        L_0x0060:
            r21 = 0
        L_0x0062:
            r0 = 3
            java.lang.String r22 = r10.getString(r0)     // Catch:{ SQLiteException -> 0x00f3 }
            r0 = 4
            long r24 = r10.getLong(r0)     // Catch:{ SQLiteException -> 0x00f3 }
            s51 r0 = r1.a     // Catch:{ SQLiteException -> 0x00f3 }
            u51 r0 = r0.Z()     // Catch:{ SQLiteException -> 0x00f3 }
            r2 = 5
            byte[] r2 = r10.getBlob(r2)     // Catch:{ SQLiteException -> 0x00f3 }
            android.os.Parcelable$Creator<pv0> r3 = defpackage.pv0.CREATOR     // Catch:{ SQLiteException -> 0x00f3 }
            android.os.Parcelable r0 = r0.B(r2, r3)     // Catch:{ SQLiteException -> 0x00f3 }
            r23 = r0
            pv0 r23 = (defpackage.pv0) r23     // Catch:{ SQLiteException -> 0x00f3 }
            r0 = 6
            long r19 = r10.getLong(r0)     // Catch:{ SQLiteException -> 0x00f3 }
            s51 r0 = r1.a     // Catch:{ SQLiteException -> 0x00f3 }
            u51 r0 = r0.Z()     // Catch:{ SQLiteException -> 0x00f3 }
            r2 = 7
            byte[] r2 = r10.getBlob(r2)     // Catch:{ SQLiteException -> 0x00f3 }
            android.os.Parcelable r0 = r0.B(r2, r3)     // Catch:{ SQLiteException -> 0x00f3 }
            r26 = r0
            pv0 r26 = (defpackage.pv0) r26     // Catch:{ SQLiteException -> 0x00f3 }
            r0 = 8
            long r4 = r10.getLong(r0)     // Catch:{ SQLiteException -> 0x00f3 }
            r0 = 9
            long r27 = r10.getLong(r0)     // Catch:{ SQLiteException -> 0x00f3 }
            s51 r0 = r1.a     // Catch:{ SQLiteException -> 0x00f3 }
            u51 r0 = r0.Z()     // Catch:{ SQLiteException -> 0x00f3 }
            r2 = 10
            byte[] r2 = r10.getBlob(r2)     // Catch:{ SQLiteException -> 0x00f3 }
            android.os.Parcelable r0 = r0.B(r2, r3)     // Catch:{ SQLiteException -> 0x00f3 }
            r29 = r0
            pv0 r29 = (defpackage.pv0) r29     // Catch:{ SQLiteException -> 0x00f3 }
            v51 r18 = new v51     // Catch:{ SQLiteException -> 0x00f3 }
            r2 = r18
            r3 = r32
            r7 = r17
            r2.<init>(r3, r4, r6, r7)     // Catch:{ SQLiteException -> 0x00f3 }
            xu0 r0 = new xu0     // Catch:{ SQLiteException -> 0x00f3 }
            r15 = r0
            r16 = r31
            r15.<init>(r16, r17, r18, r19, r21, r22, r23, r24, r26, r27, r29)     // Catch:{ SQLiteException -> 0x00f3 }
            boolean r2 = r10.moveToNext()     // Catch:{ SQLiteException -> 0x00f3 }
            if (r2 == 0) goto L_0x00ef
            w01 r2 = r1.a     // Catch:{ SQLiteException -> 0x00f3 }
            nz0 r2 = r2.c()     // Catch:{ SQLiteException -> 0x00f3 }
            lz0 r2 = r2.o()     // Catch:{ SQLiteException -> 0x00f3 }
            java.lang.String r3 = "Got multiple records for conditional property, expected one"
            java.lang.Object r4 = defpackage.nz0.x(r31)     // Catch:{ SQLiteException -> 0x00f3 }
            w01 r5 = r1.a     // Catch:{ SQLiteException -> 0x00f3 }
            iz0 r5 = r5.H()     // Catch:{ SQLiteException -> 0x00f3 }
            java.lang.String r5 = r5.r(r8)     // Catch:{ SQLiteException -> 0x00f3 }
            r2.c(r3, r4, r5)     // Catch:{ SQLiteException -> 0x00f3 }
        L_0x00ef:
            r10.close()
            return r0
        L_0x00f3:
            r0 = move-exception
            goto L_0x00f9
        L_0x00f5:
            r0 = move-exception
            goto L_0x011e
        L_0x00f7:
            r0 = move-exception
            r10 = r9
        L_0x00f9:
            w01 r2 = r1.a     // Catch:{ all -> 0x011c }
            nz0 r2 = r2.c()     // Catch:{ all -> 0x011c }
            lz0 r2 = r2.o()     // Catch:{ all -> 0x011c }
            java.lang.String r3 = "Error querying conditional property"
            java.lang.Object r4 = defpackage.nz0.x(r31)     // Catch:{ all -> 0x011c }
            w01 r5 = r1.a     // Catch:{ all -> 0x011c }
            iz0 r5 = r5.H()     // Catch:{ all -> 0x011c }
            java.lang.String r5 = r5.r(r8)     // Catch:{ all -> 0x011c }
            r2.d(r3, r4, r5, r0)     // Catch:{ all -> 0x011c }
            if (r10 == 0) goto L_0x011b
            r10.close()
        L_0x011b:
            return r9
        L_0x011c:
            r0 = move-exception
            r9 = r10
        L_0x011e:
            if (r9 == 0) goto L_0x0123
            r9.close()
        L_0x0123:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.Y(java.lang.String, java.lang.String):xu0");
    }

    public final int Z(String str, String str2) {
        s10.f(str);
        s10.f(str2);
        h();
        j();
        try {
            return P().delete("conditional_properties", "app_id=? and name=?", new String[]{str, str2});
        } catch (SQLiteException e2) {
            this.a.c().o().d("Error deleting conditional property", nz0.x(str), this.a.H().r(str2), e2);
            return 0;
        }
    }

    public final List<xu0> a0(String str, String str2, String str3) {
        s10.f(str);
        h();
        j();
        ArrayList arrayList = new ArrayList(3);
        arrayList.add(str);
        StringBuilder sb = new StringBuilder("app_id=?");
        if (!TextUtils.isEmpty(str2)) {
            arrayList.add(str2);
            sb.append(" and origin=?");
        }
        if (!TextUtils.isEmpty(str3)) {
            arrayList.add(String.valueOf(str3).concat("*"));
            sb.append(" and name glob ?");
        }
        return b0(sb.toString(), (String[]) arrayList.toArray(new String[arrayList.size()]));
    }

    public final List<xu0> b0(String str, String[] strArr) {
        h();
        j();
        ArrayList arrayList = new ArrayList();
        Cursor cursor = null;
        try {
            this.a.z();
            Cursor query = P().query("conditional_properties", new String[]{"app_id", "origin", "name", "value", "active", "trigger_event_name", "trigger_timeout", "timed_out_event", "creation_timestamp", "triggered_event", "triggered_timestamp", "time_to_live", "expired_event"}, str, strArr, (String) null, (String) null, "rowid", "1001");
            if (query.moveToFirst()) {
                while (true) {
                    int size = arrayList.size();
                    this.a.z();
                    if (size < 1000) {
                        String string = query.getString(0);
                        String string2 = query.getString(1);
                        String string3 = query.getString(2);
                        Object o = o(query, 3);
                        boolean z = query.getInt(4) != 0;
                        String string4 = query.getString(5);
                        long j = query.getLong(6);
                        u51 Z = this.a.Z();
                        byte[] blob = query.getBlob(7);
                        Parcelable.Creator creator = pv0.CREATOR;
                        arrayList.add(new xu0(string, string2, new v51(string3, query.getLong(10), o, string2), query.getLong(8), z, string4, (pv0) Z.B(blob, creator), j, (pv0) this.a.Z().B(query.getBlob(9), creator), query.getLong(11), (pv0) this.a.Z().B(query.getBlob(12), creator)));
                        if (!query.moveToNext()) {
                            break;
                        }
                    } else {
                        lz0 o2 = this.a.c().o();
                        this.a.z();
                        o2.b("Read more than the max allowed conditional properties, ignoring extra", 1000);
                        break;
                    }
                }
                query.close();
                return arrayList;
            }
            query.close();
            return arrayList;
        } catch (SQLiteException e2) {
            this.a.c().o().b("Error querying conditional user property value", e2);
            List<xu0> emptyList = Collections.emptyList();
            if (cursor != null) {
                cursor.close();
            }
            return emptyList;
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0117 A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x011b A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0157 A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0170 A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x018c A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x018d A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x019c A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x01bf A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x01d1 A[Catch:{ SQLiteException -> 0x01e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0203  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x020b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final defpackage.c11 c0(java.lang.String r34) {
        /*
            r33 = this;
            r1 = r33
            r2 = r34
            defpackage.s10.f(r34)
            r33.h()
            r33.j()
            r3 = 0
            android.database.sqlite.SQLiteDatabase r4 = r33.P()     // Catch:{ SQLiteException -> 0x01ec, all -> 0x01ea }
            java.lang.String r5 = "app_instance_id"
            java.lang.String r6 = "gmp_app_id"
            java.lang.String r7 = "resettable_device_id_hash"
            java.lang.String r8 = "last_bundle_index"
            java.lang.String r9 = "last_bundle_start_timestamp"
            java.lang.String r10 = "last_bundle_end_timestamp"
            java.lang.String r11 = "app_version"
            java.lang.String r12 = "app_store"
            java.lang.String r13 = "gmp_version"
            java.lang.String r14 = "dev_cert_hash"
            java.lang.String r15 = "measurement_enabled"
            java.lang.String r16 = "day"
            java.lang.String r17 = "daily_public_events_count"
            java.lang.String r18 = "daily_events_count"
            java.lang.String r19 = "daily_conversions_count"
            java.lang.String r20 = "config_fetched_time"
            java.lang.String r21 = "failed_config_fetch_time"
            java.lang.String r22 = "app_version_int"
            java.lang.String r23 = "firebase_instance_id"
            java.lang.String r24 = "daily_error_events_count"
            java.lang.String r25 = "daily_realtime_events_count"
            java.lang.String r26 = "health_monitor_sample"
            java.lang.String r27 = "android_id"
            java.lang.String r28 = "adid_reporting_enabled"
            java.lang.String r29 = "admob_app_id"
            java.lang.String r30 = "dynamite_version"
            java.lang.String r31 = "safelisted_events"
            java.lang.String r32 = "ga_app_id"
            java.lang.String[] r6 = new java.lang.String[]{r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32}     // Catch:{ SQLiteException -> 0x01ec, all -> 0x01ea }
            r0 = 1
            java.lang.String[] r8 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x01ec, all -> 0x01ea }
            r12 = 0
            r8[r12] = r2     // Catch:{ SQLiteException -> 0x01ec, all -> 0x01ea }
            java.lang.String r5 = "apps"
            java.lang.String r7 = "app_id=?"
            r9 = 0
            r10 = 0
            r11 = 0
            android.database.Cursor r4 = r4.query(r5, r6, r7, r8, r9, r10, r11)     // Catch:{ SQLiteException -> 0x01ec, all -> 0x01ea }
            boolean r5 = r4.moveToFirst()     // Catch:{ SQLiteException -> 0x01e8 }
            if (r5 != 0) goto L_0x0069
            r4.close()
            return r3
        L_0x0069:
            c11 r5 = new c11     // Catch:{ SQLiteException -> 0x01e8 }
            s51 r6 = r1.a     // Catch:{ SQLiteException -> 0x01e8 }
            w01 r6 = r6.s()     // Catch:{ SQLiteException -> 0x01e8 }
            r5.<init>(r6, r2)     // Catch:{ SQLiteException -> 0x01e8 }
            java.lang.String r6 = r4.getString(r12)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.P(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            java.lang.String r6 = r4.getString(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.R(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 2
            java.lang.String r6 = r4.getString(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.X(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 3
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.h(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 4
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.b0(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 5
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.d0(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 6
            java.lang.String r6 = r4.getString(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.f0(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 7
            java.lang.String r6 = r4.getString(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.j0(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 8
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.a(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 9
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.c(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 10
            boolean r7 = r4.isNull(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r7 != 0) goto L_0x00d5
            int r6 = r4.getInt(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r6 == 0) goto L_0x00d3
            goto L_0x00d5
        L_0x00d3:
            r6 = 0
            goto L_0x00d6
        L_0x00d5:
            r6 = 1
        L_0x00d6:
            r5.g(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 11
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.p(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 12
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.r(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 13
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.t(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 14
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.v(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 15
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.k(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 16
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.m(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 17
            boolean r7 = r4.isNull(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r7 == 0) goto L_0x011b
            r6 = -2147483648(0xffffffff80000000, double:NaN)
            goto L_0x0120
        L_0x011b:
            int r6 = r4.getInt(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            long r6 = (long) r6     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x0120:
            r5.h0(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 18
            java.lang.String r6 = r4.getString(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.Z(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 19
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.z(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 20
            long r6 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.x(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r6 = 21
            java.lang.String r6 = r4.getString(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.D(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            w01 r6 = r1.a     // Catch:{ SQLiteException -> 0x01e8 }
            bv0 r6 = r6.z()     // Catch:{ SQLiteException -> 0x01e8 }
            zy0<java.lang.Boolean> r7 = defpackage.bz0.t0     // Catch:{ SQLiteException -> 0x01e8 }
            boolean r6 = r6.w(r3, r7)     // Catch:{ SQLiteException -> 0x01e8 }
            r7 = 0
            if (r6 != 0) goto L_0x0168
            r6 = 22
            boolean r9 = r4.isNull(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r9 == 0) goto L_0x0161
            r9 = r7
            goto L_0x0165
        L_0x0161:
            long r9 = r4.getLong(r6)     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x0165:
            r5.F(r9)     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x0168:
            r6 = 23
            boolean r9 = r4.isNull(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r9 != 0) goto L_0x0178
            int r6 = r4.getInt(r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r6 == 0) goto L_0x0177
            goto L_0x0178
        L_0x0177:
            r0 = 0
        L_0x0178:
            r5.H(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            r0 = 24
            java.lang.String r0 = r4.getString(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.T(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            r0 = 25
            boolean r6 = r4.isNull(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r6 == 0) goto L_0x018d
            goto L_0x0191
        L_0x018d:
            long r7 = r4.getLong(r0)     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x0191:
            r5.e(r7)     // Catch:{ SQLiteException -> 0x01e8 }
            r0 = 26
            boolean r6 = r4.isNull(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r6 != 0) goto L_0x01ae
            java.lang.String r0 = r4.getString(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            java.lang.String r6 = ","
            r7 = -1
            java.lang.String[] r0 = r0.split(r6, r7)     // Catch:{ SQLiteException -> 0x01e8 }
            java.util.List r0 = java.util.Arrays.asList(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.L(r0)     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x01ae:
            defpackage.bq0.b()     // Catch:{ SQLiteException -> 0x01e8 }
            w01 r0 = r1.a     // Catch:{ SQLiteException -> 0x01e8 }
            bv0 r0 = r0.z()     // Catch:{ SQLiteException -> 0x01e8 }
            zy0<java.lang.Boolean> r6 = defpackage.bz0.g0     // Catch:{ SQLiteException -> 0x01e8 }
            boolean r0 = r0.w(r2, r6)     // Catch:{ SQLiteException -> 0x01e8 }
            if (r0 == 0) goto L_0x01c8
            r0 = 27
            java.lang.String r0 = r4.getString(r0)     // Catch:{ SQLiteException -> 0x01e8 }
            r5.V(r0)     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x01c8:
            r5.M()     // Catch:{ SQLiteException -> 0x01e8 }
            boolean r0 = r4.moveToNext()     // Catch:{ SQLiteException -> 0x01e8 }
            if (r0 == 0) goto L_0x01e4
            w01 r0 = r1.a     // Catch:{ SQLiteException -> 0x01e8 }
            nz0 r0 = r0.c()     // Catch:{ SQLiteException -> 0x01e8 }
            lz0 r0 = r0.o()     // Catch:{ SQLiteException -> 0x01e8 }
            java.lang.String r6 = "Got multiple records for app, expected one. appId"
            java.lang.Object r7 = defpackage.nz0.x(r34)     // Catch:{ SQLiteException -> 0x01e8 }
            r0.b(r6, r7)     // Catch:{ SQLiteException -> 0x01e8 }
        L_0x01e4:
            r4.close()
            return r5
        L_0x01e8:
            r0 = move-exception
            goto L_0x01ee
        L_0x01ea:
            r0 = move-exception
            goto L_0x0209
        L_0x01ec:
            r0 = move-exception
            r4 = r3
        L_0x01ee:
            w01 r5 = r1.a     // Catch:{ all -> 0x0207 }
            nz0 r5 = r5.c()     // Catch:{ all -> 0x0207 }
            lz0 r5 = r5.o()     // Catch:{ all -> 0x0207 }
            java.lang.String r6 = "Error querying app. appId"
            java.lang.Object r2 = defpackage.nz0.x(r34)     // Catch:{ all -> 0x0207 }
            r5.c(r6, r2, r0)     // Catch:{ all -> 0x0207 }
            if (r4 == 0) goto L_0x0206
            r4.close()
        L_0x0206:
            return r3
        L_0x0207:
            r0 = move-exception
            r3 = r4
        L_0x0209:
            if (r3 == 0) goto L_0x020e
            r3.close()
        L_0x020e:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.c0(java.lang.String):c11");
    }

    public final void d0(c11 c11) {
        s10.j(c11);
        h();
        j();
        String N = c11.N();
        s10.j(N);
        ContentValues contentValues = new ContentValues();
        contentValues.put("app_id", N);
        contentValues.put("app_instance_id", c11.O());
        contentValues.put("gmp_app_id", c11.Q());
        contentValues.put("resettable_device_id_hash", c11.W());
        contentValues.put("last_bundle_index", Long.valueOf(c11.i()));
        contentValues.put("last_bundle_start_timestamp", Long.valueOf(c11.a0()));
        contentValues.put("last_bundle_end_timestamp", Long.valueOf(c11.c0()));
        contentValues.put("app_version", c11.e0());
        contentValues.put("app_store", c11.i0());
        contentValues.put("gmp_version", Long.valueOf(c11.k0()));
        contentValues.put("dev_cert_hash", Long.valueOf(c11.b()));
        contentValues.put("measurement_enabled", Boolean.valueOf(c11.f()));
        contentValues.put("day", Long.valueOf(c11.o()));
        contentValues.put("daily_public_events_count", Long.valueOf(c11.q()));
        contentValues.put("daily_events_count", Long.valueOf(c11.s()));
        contentValues.put("daily_conversions_count", Long.valueOf(c11.u()));
        contentValues.put("config_fetched_time", Long.valueOf(c11.j()));
        contentValues.put("failed_config_fetch_time", Long.valueOf(c11.l()));
        contentValues.put("app_version_int", Long.valueOf(c11.g0()));
        contentValues.put("firebase_instance_id", c11.Y());
        contentValues.put("daily_error_events_count", Long.valueOf(c11.y()));
        contentValues.put("daily_realtime_events_count", Long.valueOf(c11.w()));
        contentValues.put("health_monitor_sample", c11.B());
        contentValues.put("android_id", Long.valueOf(c11.E()));
        contentValues.put("adid_reporting_enabled", Boolean.valueOf(c11.G()));
        contentValues.put("admob_app_id", c11.S());
        contentValues.put("dynamite_version", Long.valueOf(c11.d()));
        List<String> K = c11.K();
        if (K != null) {
            if (K.size() == 0) {
                this.a.c().r().b("Safelisted events should not be an empty list. appId", N);
            } else {
                contentValues.put("safelisted_events", TextUtils.join(",", K));
            }
        }
        bq0.b();
        if (this.a.z().w(N, bz0.g0)) {
            contentValues.put("ga_app_id", c11.U());
        }
        try {
            SQLiteDatabase P = P();
            if (((long) P.update("apps", contentValues, "app_id = ?", new String[]{N})) == 0 && P.insertWithOnConflict("apps", (String) null, contentValues, 5) == -1) {
                this.a.c().o().b("Failed to insert/update app (got -1). appId", nz0.x(N));
            }
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error storing app. appId", nz0.x(N), e2);
        }
    }

    public final dv0 e0(long j, String str, boolean z, boolean z2, boolean z3, boolean z4, boolean z5) {
        return f0(j, str, 1, false, false, z3, false, z5);
    }

    public final dv0 f0(long j, String str, long j2, boolean z, boolean z2, boolean z3, boolean z4, boolean z5) {
        s10.f(str);
        h();
        j();
        String[] strArr = {str};
        dv0 dv0 = new dv0();
        Cursor cursor = null;
        try {
            SQLiteDatabase P = P();
            cursor = P.query("apps", new String[]{"day", "daily_events_count", "daily_public_events_count", "daily_conversions_count", "daily_error_events_count", "daily_realtime_events_count"}, "app_id=?", new String[]{str}, (String) null, (String) null, (String) null);
            if (!cursor.moveToFirst()) {
                this.a.c().r().b("Not updating daily counts, app is not known. appId", nz0.x(str));
                cursor.close();
                return dv0;
            }
            if (cursor.getLong(0) == j) {
                dv0.b = cursor.getLong(1);
                dv0.a = cursor.getLong(2);
                dv0.c = cursor.getLong(3);
                dv0.d = cursor.getLong(4);
                dv0.e = cursor.getLong(5);
            }
            if (z) {
                dv0.b += j2;
            }
            if (z2) {
                dv0.a += j2;
            }
            if (z3) {
                dv0.c += j2;
            }
            if (z4) {
                dv0.d += j2;
            }
            if (z5) {
                dv0.e += j2;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("day", Long.valueOf(j));
            contentValues.put("daily_public_events_count", Long.valueOf(dv0.a));
            contentValues.put("daily_events_count", Long.valueOf(dv0.b));
            contentValues.put("daily_conversions_count", Long.valueOf(dv0.c));
            contentValues.put("daily_error_events_count", Long.valueOf(dv0.d));
            contentValues.put("daily_realtime_events_count", Long.valueOf(dv0.e));
            P.update("apps", contentValues, "app_id=?", strArr);
            cursor.close();
            return dv0;
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error updating daily counts. appId", nz0.x(str), e2);
            if (cursor != null) {
                cursor.close();
            }
            return dv0;
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    public final void g0(String str, byte[] bArr, String str2) {
        s10.f(str);
        h();
        j();
        ContentValues contentValues = new ContentValues();
        contentValues.put("remote_config", bArr);
        contentValues.put("config_last_modified_time", str2);
        try {
            if (((long) P().update("apps", contentValues, "app_id = ?", new String[]{str})) == 0) {
                this.a.c().o().b("Failed to update remote config (got 0). appId", nz0.x(str));
            }
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error storing remote config. appId", nz0.x(str), e2);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0047, code lost:
        if (r2 > (defpackage.bv0.i() + r0)) goto L_0x0049;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean h0(defpackage.vg0 r8, boolean r9) {
        /*
            r7 = this;
            r7.h()
            r7.j()
            defpackage.s10.j(r8)
            java.lang.String r0 = r8.A()
            defpackage.s10.f(r0)
            boolean r0 = r8.C1()
            defpackage.s10.m(r0)
            r7.m()
            w01 r0 = r7.a
            g40 r0 = r0.b()
            long r0 = r0.b()
            long r2 = r8.D1()
            w01 r4 = r7.a
            r4.z()
            long r4 = defpackage.bv0.i()
            long r4 = r0 - r4
            int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r6 < 0) goto L_0x0049
            long r2 = r8.D1()
            w01 r4 = r7.a
            r4.z()
            long r4 = defpackage.bv0.i()
            long r4 = r4 + r0
            int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r6 <= 0) goto L_0x006c
        L_0x0049:
            w01 r2 = r7.a
            nz0 r2 = r2.c()
            lz0 r2 = r2.r()
            java.lang.String r3 = r8.A()
            java.lang.Object r3 = defpackage.nz0.x(r3)
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            long r4 = r8.D1()
            java.lang.Long r1 = java.lang.Long.valueOf(r4)
            java.lang.String r4 = "Storing bundle outside of the max uploading time span. appId, now, timestamp"
            r2.d(r4, r3, r0, r1)
        L_0x006c:
            byte[] r0 = r8.g()
            r1 = 0
            s51 r2 = r7.a     // Catch:{ IOException -> 0x010f }
            u51 r2 = r2.Z()     // Catch:{ IOException -> 0x010f }
            byte[] r0 = r2.I(r0)     // Catch:{ IOException -> 0x010f }
            w01 r2 = r7.a
            nz0 r2 = r2.c()
            lz0 r2 = r2.w()
            int r3 = r0.length
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            java.lang.String r4 = "Saving bundle, size"
            r2.b(r4, r3)
            android.content.ContentValues r2 = new android.content.ContentValues
            r2.<init>()
            java.lang.String r3 = r8.A()
            java.lang.String r4 = "app_id"
            r2.put(r4, r3)
            long r3 = r8.D1()
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            java.lang.String r4 = "bundle_end_timestamp"
            r2.put(r4, r3)
            java.lang.String r3 = "data"
            r2.put(r3, r0)
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)
            java.lang.String r0 = "has_realtime"
            r2.put(r0, r9)
            boolean r9 = r8.C0()
            if (r9 == 0) goto L_0x00cb
            int r9 = r8.D0()
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)
            java.lang.String r0 = "retry_count"
            r2.put(r0, r9)
        L_0x00cb:
            android.database.sqlite.SQLiteDatabase r9 = r7.P()     // Catch:{ SQLiteException -> 0x00f6 }
            java.lang.String r0 = "queue"
            r3 = 0
            long r2 = r9.insert(r0, r3, r2)     // Catch:{ SQLiteException -> 0x00f6 }
            r4 = -1
            int r9 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r9 != 0) goto L_0x00f4
            w01 r9 = r7.a     // Catch:{ SQLiteException -> 0x00f6 }
            nz0 r9 = r9.c()     // Catch:{ SQLiteException -> 0x00f6 }
            lz0 r9 = r9.o()     // Catch:{ SQLiteException -> 0x00f6 }
            java.lang.String r0 = "Failed to insert bundle (got -1). appId"
            java.lang.String r2 = r8.A()     // Catch:{ SQLiteException -> 0x00f6 }
            java.lang.Object r2 = defpackage.nz0.x(r2)     // Catch:{ SQLiteException -> 0x00f6 }
            r9.b(r0, r2)     // Catch:{ SQLiteException -> 0x00f6 }
            return r1
        L_0x00f4:
            r8 = 1
            return r8
        L_0x00f6:
            r9 = move-exception
            w01 r0 = r7.a
            nz0 r0 = r0.c()
            lz0 r0 = r0.o()
            java.lang.String r8 = r8.A()
            java.lang.Object r8 = defpackage.nz0.x(r8)
            java.lang.String r2 = "Error storing bundle. appId"
        L_0x010b:
            r0.c(r2, r8, r9)
            return r1
        L_0x010f:
            r9 = move-exception
            w01 r0 = r7.a
            nz0 r0 = r0.c()
            lz0 r0 = r0.o()
            java.lang.String r8 = r8.A()
            java.lang.Object r8 = defpackage.nz0.x(r8)
            java.lang.String r2 = "Data loss. Failed to serialize bundle. appId"
            goto L_0x010b
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.h0(vg0, boolean):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0036  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0040  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String i0() {
        /*
            r6 = this;
            android.database.sqlite.SQLiteDatabase r0 = r6.P()
            r1 = 0
            java.lang.String r2 = "select app_id from queue order by has_realtime desc, rowid asc limit 1;"
            android.database.Cursor r0 = r0.rawQuery(r2, r1)     // Catch:{ SQLiteException -> 0x0022, all -> 0x0020 }
            boolean r2 = r0.moveToFirst()     // Catch:{ SQLiteException -> 0x001e }
            if (r2 == 0) goto L_0x001a
            r2 = 0
            java.lang.String r1 = r0.getString(r2)     // Catch:{ SQLiteException -> 0x001e }
            r0.close()
            return r1
        L_0x001a:
            r0.close()
            return r1
        L_0x001e:
            r2 = move-exception
            goto L_0x0025
        L_0x0020:
            r0 = move-exception
            goto L_0x003e
        L_0x0022:
            r0 = move-exception
            r2 = r0
            r0 = r1
        L_0x0025:
            w01 r3 = r6.a     // Catch:{ all -> 0x003a }
            nz0 r3 = r3.c()     // Catch:{ all -> 0x003a }
            lz0 r3 = r3.o()     // Catch:{ all -> 0x003a }
            java.lang.String r4 = "Database error getting next bundle app id"
            r3.b(r4, r2)     // Catch:{ all -> 0x003a }
            if (r0 == 0) goto L_0x0039
            r0.close()
        L_0x0039:
            return r1
        L_0x003a:
            r1 = move-exception
            r5 = r1
            r1 = r0
            r0 = r5
        L_0x003e:
            if (r1 == 0) goto L_0x0043
            r1.close()
        L_0x0043:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.i0():java.lang.String");
    }

    public final boolean j0() {
        return K("select count(1) > 0 from queue where has_realtime = 1", (String[]) null) != 0;
    }

    public final boolean k() {
        return false;
    }

    public final void m() {
        h();
        j();
        if (y()) {
            long a2 = this.a.a0().f4391a.a();
            long c2 = this.a.b().c();
            long abs = Math.abs(c2 - a2);
            this.a.z();
            if (abs > bz0.x.b(null).longValue()) {
                this.a.a0().f4391a.b(c2);
                h();
                j();
                if (y()) {
                    SQLiteDatabase P = P();
                    this.a.z();
                    int delete = P.delete("queue", "abs(bundle_end_timestamp - ?) > cast(? as integer)", new String[]{String.valueOf(this.a.b().b()), String.valueOf(bv0.i())});
                    if (delete > 0) {
                        this.a.c().w().b("Deleted stale rows. rowsDeleted", Integer.valueOf(delete));
                    }
                }
            }
        }
    }

    public final void n(List<Long> list) {
        h();
        j();
        s10.j(list);
        s10.l(list.size());
        if (y()) {
            String join = TextUtils.join(",", list);
            StringBuilder sb = new StringBuilder(String.valueOf(join).length() + 2);
            sb.append("(");
            sb.append(join);
            sb.append(")");
            String sb2 = sb.toString();
            StringBuilder sb3 = new StringBuilder(String.valueOf(sb2).length() + 80);
            sb3.append("SELECT COUNT(1) FROM queue WHERE rowid IN ");
            sb3.append(sb2);
            sb3.append(" AND retry_count =  2147483647 LIMIT 1");
            if (K(sb3.toString(), (String[]) null) > 0) {
                this.a.c().r().a("The number of upload retries exceeds the limit. Will remain unchanged.");
            }
            try {
                SQLiteDatabase P = P();
                StringBuilder sb4 = new StringBuilder(String.valueOf(sb2).length() + 127);
                sb4.append("UPDATE queue SET retry_count = IFNULL(retry_count, 0) + 1 WHERE rowid IN ");
                sb4.append(sb2);
                sb4.append(" AND (retry_count IS NULL OR retry_count < ");
                sb4.append(Integer.MAX_VALUE);
                sb4.append(")");
                P.execSQL(sb4.toString());
            } catch (SQLiteException e2) {
                this.a.c().o().b("Error incrementing retry count. error", e2);
            }
        }
    }

    public final Object o(Cursor cursor, int i) {
        int type = cursor.getType(i);
        if (type == 0) {
            this.a.c().o().a("Loaded invalid null value from database");
            return null;
        } else if (type == 1) {
            return Long.valueOf(cursor.getLong(i));
        } else {
            if (type == 2) {
                return Double.valueOf(cursor.getDouble(i));
            }
            if (type == 3) {
                return cursor.getString(i);
            }
            if (type != 4) {
                this.a.c().o().b("Loaded invalid unknown value type, ignoring it", Integer.valueOf(type));
                return null;
            }
            this.a.c().o().a("Loaded invalid blob type value, ignoring it");
            return null;
        }
    }

    public final long p() {
        return L("select max(bundle_end_timestamp) from queue", (String[]) null, 0);
    }

    /* JADX INFO: finally extract failed */
    public final long q(String str, String str2) {
        String str3 = str;
        s10.f(str);
        s10.f("first_open_count");
        h();
        j();
        SQLiteDatabase P = P();
        P.beginTransaction();
        long j = 0;
        try {
            StringBuilder sb = new StringBuilder(48);
            sb.append("select ");
            sb.append("first_open_count");
            sb.append(" from app2 where app_id=?");
            long L = L(sb.toString(), new String[]{str3}, -1);
            if (L == -1) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("app_id", str3);
                contentValues.put("first_open_count", 0);
                contentValues.put("previous_install_count", 0);
                if (P.insertWithOnConflict("app2", (String) null, contentValues, 5) == -1) {
                    this.a.c().o().c("Failed to insert column (got -1). appId", nz0.x(str), "first_open_count");
                    P.endTransaction();
                    return -1;
                }
                L = 0;
            }
            try {
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("app_id", str3);
                contentValues2.put("first_open_count", Long.valueOf(1 + L));
                if (((long) P.update("app2", contentValues2, "app_id = ?", new String[]{str3})) == 0) {
                    this.a.c().o().c("Failed to update column (got 0). appId", nz0.x(str), "first_open_count");
                    P.endTransaction();
                    return -1;
                }
                P.setTransactionSuccessful();
                P.endTransaction();
                return L;
            } catch (SQLiteException e2) {
                e = e2;
                j = L;
                try {
                    this.a.c().o().d("Error inserting column. appId", nz0.x(str), "first_open_count", e);
                    P.endTransaction();
                    return j;
                } catch (Throwable th) {
                    P.endTransaction();
                    throw th;
                }
            }
        } catch (SQLiteException e3) {
            e = e3;
            this.a.c().o().d("Error inserting column. appId", nz0.x(str), "first_open_count", e);
            P.endTransaction();
            return j;
        }
    }

    public final long r() {
        return L("select max(timestamp) from raw_events", (String[]) null, 0);
    }

    public final boolean s() {
        return K("select count(1) > 0 from raw_events", (String[]) null) != 0;
    }

    public final boolean t() {
        return K("select count(1) > 0 from raw_events where realtime = 1", (String[]) null) != 0;
    }

    public final long u(String str) {
        s10.f(str);
        return L("select count(1) from events where app_id=? and name not like '!_%' escape '!'", new String[]{str}, 0);
    }

    public final boolean v(String str, Long l, long j, ng0 ng0) {
        h();
        j();
        s10.j(ng0);
        s10.f(str);
        s10.j(l);
        byte[] g2 = ng0.g();
        this.a.c().w().c("Saving complex main event, appId, data size", this.a.H().p(str), Integer.valueOf(g2.length));
        ContentValues contentValues = new ContentValues();
        contentValues.put("app_id", str);
        contentValues.put("event_id", l);
        contentValues.put("children_to_process", Long.valueOf(j));
        contentValues.put("main_event", g2);
        try {
            if (P().insertWithOnConflict("main_event_params", (String) null, contentValues, 5) != -1) {
                return true;
            }
            this.a.c().o().b("Failed to insert complex main event (got -1). appId", nz0.x(str));
            return false;
        } catch (SQLiteException e2) {
            this.a.c().o().c("Error storing complex main event. appId", nz0.x(str), e2);
            return false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x00d1  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00d9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.os.Bundle w(java.lang.String r8) {
        /*
            r7 = this;
            r7.h()
            r7.j()
            r0 = 0
            android.database.sqlite.SQLiteDatabase r1 = r7.P()     // Catch:{ SQLiteException -> 0x00be, all -> 0x00bc }
            r2 = 1
            java.lang.String[] r2 = new java.lang.String[r2]     // Catch:{ SQLiteException -> 0x00be, all -> 0x00bc }
            r3 = 0
            r2[r3] = r8     // Catch:{ SQLiteException -> 0x00be, all -> 0x00bc }
            java.lang.String r4 = "select parameters from default_event_params where app_id=?"
            android.database.Cursor r1 = r1.rawQuery(r4, r2)     // Catch:{ SQLiteException -> 0x00be, all -> 0x00bc }
            boolean r2 = r1.moveToFirst()     // Catch:{ SQLiteException -> 0x00ba }
            if (r2 != 0) goto L_0x0030
            w01 r8 = r7.a     // Catch:{ SQLiteException -> 0x00ba }
            nz0 r8 = r8.c()     // Catch:{ SQLiteException -> 0x00ba }
            lz0 r8 = r8.w()     // Catch:{ SQLiteException -> 0x00ba }
            java.lang.String r2 = "Default event parameters not found"
            r8.a(r2)     // Catch:{ SQLiteException -> 0x00ba }
            r1.close()
            return r0
        L_0x0030:
            byte[] r2 = r1.getBlob(r3)     // Catch:{ SQLiteException -> 0x00ba }
            mg0 r3 = defpackage.ng0.K()     // Catch:{ IOException -> 0x00a2 }
            km0 r2 = defpackage.u51.J(r3, r2)     // Catch:{ IOException -> 0x00a2 }
            mg0 r2 = (defpackage.mg0) r2     // Catch:{ IOException -> 0x00a2 }
            gl0 r2 = r2.k()     // Catch:{ IOException -> 0x00a2 }
            ng0 r2 = (defpackage.ng0) r2     // Catch:{ IOException -> 0x00a2 }
            s51 r8 = r7.a     // Catch:{ SQLiteException -> 0x00ba }
            r8.Z()     // Catch:{ SQLiteException -> 0x00ba }
            java.util.List r8 = r2.A()     // Catch:{ SQLiteException -> 0x00ba }
            android.os.Bundle r2 = new android.os.Bundle     // Catch:{ SQLiteException -> 0x00ba }
            r2.<init>()     // Catch:{ SQLiteException -> 0x00ba }
            java.util.Iterator r8 = r8.iterator()     // Catch:{ SQLiteException -> 0x00ba }
        L_0x0056:
            boolean r3 = r8.hasNext()     // Catch:{ SQLiteException -> 0x00ba }
            if (r3 == 0) goto L_0x009e
            java.lang.Object r3 = r8.next()     // Catch:{ SQLiteException -> 0x00ba }
            rg0 r3 = (defpackage.rg0) r3     // Catch:{ SQLiteException -> 0x00ba }
            java.lang.String r4 = r3.B()     // Catch:{ SQLiteException -> 0x00ba }
            boolean r5 = r3.I()     // Catch:{ SQLiteException -> 0x00ba }
            if (r5 == 0) goto L_0x0074
            double r5 = r3.J()     // Catch:{ SQLiteException -> 0x00ba }
            r2.putDouble(r4, r5)     // Catch:{ SQLiteException -> 0x00ba }
            goto L_0x0056
        L_0x0074:
            boolean r5 = r3.G()     // Catch:{ SQLiteException -> 0x00ba }
            if (r5 == 0) goto L_0x0082
            float r3 = r3.H()     // Catch:{ SQLiteException -> 0x00ba }
            r2.putFloat(r4, r3)     // Catch:{ SQLiteException -> 0x00ba }
            goto L_0x0056
        L_0x0082:
            boolean r5 = r3.C()     // Catch:{ SQLiteException -> 0x00ba }
            if (r5 == 0) goto L_0x0090
            java.lang.String r3 = r3.D()     // Catch:{ SQLiteException -> 0x00ba }
            r2.putString(r4, r3)     // Catch:{ SQLiteException -> 0x00ba }
            goto L_0x0056
        L_0x0090:
            boolean r5 = r3.E()     // Catch:{ SQLiteException -> 0x00ba }
            if (r5 == 0) goto L_0x0056
            long r5 = r3.F()     // Catch:{ SQLiteException -> 0x00ba }
            r2.putLong(r4, r5)     // Catch:{ SQLiteException -> 0x00ba }
            goto L_0x0056
        L_0x009e:
            r1.close()
            return r2
        L_0x00a2:
            r2 = move-exception
            w01 r3 = r7.a     // Catch:{ SQLiteException -> 0x00ba }
            nz0 r3 = r3.c()     // Catch:{ SQLiteException -> 0x00ba }
            lz0 r3 = r3.o()     // Catch:{ SQLiteException -> 0x00ba }
            java.lang.String r4 = "Failed to retrieve default event parameters. appId"
            java.lang.Object r8 = defpackage.nz0.x(r8)     // Catch:{ SQLiteException -> 0x00ba }
            r3.c(r4, r8, r2)     // Catch:{ SQLiteException -> 0x00ba }
            r1.close()
            return r0
        L_0x00ba:
            r8 = move-exception
            goto L_0x00c0
        L_0x00bc:
            r8 = move-exception
            goto L_0x00d7
        L_0x00be:
            r8 = move-exception
            r1 = r0
        L_0x00c0:
            w01 r2 = r7.a     // Catch:{ all -> 0x00d5 }
            nz0 r2 = r2.c()     // Catch:{ all -> 0x00d5 }
            lz0 r2 = r2.o()     // Catch:{ all -> 0x00d5 }
            java.lang.String r3 = "Error selecting default event parameters"
            r2.b(r3, r8)     // Catch:{ all -> 0x00d5 }
            if (r1 == 0) goto L_0x00d4
            r1.close()
        L_0x00d4:
            return r0
        L_0x00d5:
            r8 = move-exception
            r0 = r1
        L_0x00d7:
            if (r0 == 0) goto L_0x00dc
            r0.close()
        L_0x00dc:
            goto L_0x00de
        L_0x00dd:
            throw r8
        L_0x00de:
            goto L_0x00dd
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.w(java.lang.String):android.os.Bundle");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:100:0x0318, code lost:
        r12 = java.lang.Integer.valueOf(r3.B());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x0321, code lost:
        r12 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x0322, code lost:
        r11.put("filter_id", r12);
        r22 = r0;
        r11.put("property_name", r3.C());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x0334, code lost:
        if (r3.G() == false) goto L_0x033f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x0336, code lost:
        r0 = java.lang.Boolean.valueOf(r3.H());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x033f, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:0x0340, code lost:
        r11.put("session_scoped", r0);
        r11.put("data", r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x0354, code lost:
        if (P().insertWithOnConflict("property_filters", (java.lang.String) null, r11, 5) != -1) goto L_0x036a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x0356, code lost:
        r9.a.c().o().b("Failed to insert property filter (got -1). appId", defpackage.nz0.x(r24));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x036a, code lost:
        r0 = r22;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x036e, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:114:?, code lost:
        r3 = r9.a.c().o();
        r4 = "Error storing property filter. appId";
        r7 = defpackage.nz0.x(r24);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x0381, code lost:
        j();
        h();
        defpackage.s10.f(r24);
        r0 = P();
        r3 = r17;
        r0.delete("property_filters", r3, new java.lang.String[]{r2, java.lang.String.valueOf(r10)});
        r0.delete("event_filters", r3, new java.lang.String[]{r2, java.lang.String.valueOf(r10)});
        r17 = r3;
        r4 = r21;
        r3 = r25;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x03b8, code lost:
        r3 = r25;
        r4 = r21;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x0187, code lost:
        r0.c(r7, r8, r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x018b, code lost:
        r11 = r0.C().iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x0197, code lost:
        if (r11.hasNext() == false) goto L_0x01ba;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x01a3, code lost:
        if (r11.next().A() != false) goto L_0x0193;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x01a5, code lost:
        r0 = r9.a.c().r();
        r7 = "Property filter with no ID. Audience definition ignored. appId, audienceId";
        r8 = defpackage.nz0.x(r24);
        r10 = java.lang.Integer.valueOf(r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x01ba, code lost:
        r11 = r0.F().iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x01d0, code lost:
        if (r11.hasNext() == false) goto L_0x02a6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:?, code lost:
        r12 = r11.next();
        j();
        h();
        defpackage.s10.f(r24);
        defpackage.s10.j(r12);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x01ec, code lost:
        if (android.text.TextUtils.isEmpty(r12.C()) == false) goto L_0x0220;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x01ee, code lost:
        r0 = r9.a.c().r();
        r8 = defpackage.nz0.x(r24);
        r11 = java.lang.Integer.valueOf(r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0206, code lost:
        if (r12.A() == false) goto L_0x0213;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0208, code lost:
        r20 = java.lang.Integer.valueOf(r12.B());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x0213, code lost:
        r20 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x0215, code lost:
        r0.d("Event filter had no event name. Audience definition ignored. appId, audienceId, filterId", r8, r11, java.lang.String.valueOf(r20));
        r21 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0220, code lost:
        r3 = r12.g();
        r21 = r4;
        r4 = new android.content.ContentValues();
        r4.put("app_id", r2);
        r4.put("audience_id", java.lang.Integer.valueOf(r10));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0239, code lost:
        if (r12.A() == false) goto L_0x0244;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x023b, code lost:
        r8 = java.lang.Integer.valueOf(r12.B());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0244, code lost:
        r8 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0245, code lost:
        r4.put("filter_id", r8);
        r4.put("event_name", r12.C());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x0255, code lost:
        if (r12.K() == false) goto L_0x0260;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0257, code lost:
        r8 = java.lang.Boolean.valueOf(r12.L());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0260, code lost:
        r8 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0261, code lost:
        r4.put("session_scoped", r8);
        r4.put("data", r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0275, code lost:
        if (P().insertWithOnConflict("event_filters", (java.lang.String) null, r4, 5) != -1) goto L_0x028a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x0277, code lost:
        r9.a.c().o().b("Failed to insert event filter (got -1). appId", defpackage.nz0.x(r24));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x028a, code lost:
        r3 = r25;
        r4 = r21;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x02a1, code lost:
        r3.c(r4, r7, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x02a6, code lost:
        r21 = r4;
        r0 = r0.C().iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x02b4, code lost:
        if (r0.hasNext() == false) goto L_0x03b8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x02b6, code lost:
        r3 = r0.next();
        j();
        h();
        defpackage.s10.f(r24);
        defpackage.s10.j(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:0x02d0, code lost:
        if (android.text.TextUtils.isEmpty(r3.C()) == false) goto L_0x02ff;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x02d2, code lost:
        r0 = r9.a.c().r();
        r7 = defpackage.nz0.x(r24);
        r8 = java.lang.Integer.valueOf(r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x02ea, code lost:
        if (r3.A() == false) goto L_0x02f5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x02ec, code lost:
        r3 = java.lang.Integer.valueOf(r3.B());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x02f5, code lost:
        r3 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:97:0x02f6, code lost:
        r0.d("Property filter had no property name. Audience definition ignored. appId, audienceId, filterId", r7, r8, java.lang.String.valueOf(r3));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x02ff, code lost:
        r4 = r3.g();
        r11 = new android.content.ContentValues();
        r11.put("app_id", r2);
        r11.put("audience_id", java.lang.Integer.valueOf(r10));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0316, code lost:
        if (r3.A() == false) goto L_0x0321;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void x(java.lang.String r24, java.util.List<defpackage.ff0> r25) {
        /*
            r23 = this;
            r1 = r23
            r2 = r24
            r3 = r25
            java.lang.String r4 = "app_id=? and audience_id=?"
            java.lang.String r0 = "app_id=?"
            java.lang.String r5 = "event_filters"
            java.lang.String r6 = "property_filters"
            defpackage.s10.j(r25)
            r8 = 0
        L_0x0012:
            int r9 = r25.size()
            if (r8 >= r9) goto L_0x00e9
            java.lang.Object r9 = r3.get(r8)
            ff0 r9 = (defpackage.ff0) r9
            cl0 r9 = r9.s()
            ef0 r9 = (defpackage.ef0) r9
            int r11 = r9.x()
            if (r11 == 0) goto L_0x00a6
            r12 = r9
            r11 = 0
        L_0x002c:
            int r13 = r12.x()
            if (r11 >= r13) goto L_0x00a3
            hf0 r13 = r12.y(r11)
            cl0 r13 = r13.s()
            gf0 r13 = (defpackage.gf0) r13
            cl0 r14 = r13.clone()
            gf0 r14 = (defpackage.gf0) r14
            java.lang.String r15 = r13.r()
            java.lang.String r15 = defpackage.u11.b(r15)
            if (r15 == 0) goto L_0x0051
            r14.s(r15)
            r15 = 1
            goto L_0x0052
        L_0x0051:
            r15 = 0
        L_0x0052:
            r7 = 0
        L_0x0053:
            int r10 = r13.u()
            if (r7 >= r10) goto L_0x008b
            jf0 r10 = r13.x(r7)
            r16 = r13
            java.lang.String r13 = r10.H()
            r17 = r4
            java.lang.String[] r4 = defpackage.v11.a
            java.lang.String[] r1 = defpackage.v11.b
            java.lang.String r1 = defpackage.g31.b(r13, r4, r1)
            if (r1 == 0) goto L_0x0082
            cl0 r4 = r10.s()
            if0 r4 = (defpackage.if0) r4
            r4.r(r1)
            gl0 r1 = r4.k()
            jf0 r1 = (defpackage.jf0) r1
            r14.y(r7, r1)
            r15 = 1
        L_0x0082:
            int r7 = r7 + 1
            r1 = r23
            r13 = r16
            r4 = r17
            goto L_0x0053
        L_0x008b:
            r17 = r4
            if (r15 == 0) goto L_0x009c
            r12.z(r11, r14)
            gl0 r1 = r9.k()
            ff0 r1 = (defpackage.ff0) r1
            r3.set(r8, r1)
            r12 = r9
        L_0x009c:
            int r11 = r11 + 1
            r1 = r23
            r4 = r17
            goto L_0x002c
        L_0x00a3:
            r17 = r4
            goto L_0x00a9
        L_0x00a6:
            r17 = r4
            r12 = r9
        L_0x00a9:
            int r1 = r12.r()
            if (r1 == 0) goto L_0x00e1
            r1 = 0
        L_0x00b0:
            int r4 = r12.r()
            if (r1 >= r4) goto L_0x00e1
            qf0 r4 = r12.s(r1)
            java.lang.String r7 = r4.C()
            java.lang.String[] r10 = defpackage.w11.a
            java.lang.String[] r11 = defpackage.w11.b
            java.lang.String r7 = defpackage.g31.b(r7, r10, r11)
            if (r7 == 0) goto L_0x00de
            cl0 r4 = r4.s()
            pf0 r4 = (defpackage.pf0) r4
            r4.r(r7)
            r12.u(r1, r4)
            gl0 r4 = r9.k()
            ff0 r4 = (defpackage.ff0) r4
            r3.set(r8, r4)
            r12 = r9
        L_0x00de:
            int r1 = r1 + 1
            goto L_0x00b0
        L_0x00e1:
            int r8 = r8 + 1
            r1 = r23
            r4 = r17
            goto L_0x0012
        L_0x00e9:
            r17 = r4
            r23.j()
            r23.h()
            defpackage.s10.f(r24)
            defpackage.s10.j(r25)
            android.database.sqlite.SQLiteDatabase r1 = r23.P()
            r1.beginTransaction()
            r23.j()     // Catch:{ all -> 0x04b9 }
            r23.h()     // Catch:{ all -> 0x04b9 }
            defpackage.s10.f(r24)     // Catch:{ all -> 0x04b9 }
            android.database.sqlite.SQLiteDatabase r4 = r23.P()     // Catch:{ all -> 0x04b9 }
            r7 = 1
            java.lang.String[] r8 = new java.lang.String[r7]     // Catch:{ all -> 0x04b9 }
            r9 = 0
            r8[r9] = r2     // Catch:{ all -> 0x04b9 }
            r4.delete(r6, r0, r8)     // Catch:{ all -> 0x04b9 }
            java.lang.String[] r8 = new java.lang.String[r7]     // Catch:{ all -> 0x04b9 }
            r8[r9] = r2     // Catch:{ all -> 0x04b9 }
            r4.delete(r5, r0, r8)     // Catch:{ all -> 0x04b9 }
            java.util.Iterator r4 = r25.iterator()     // Catch:{ all -> 0x04b9 }
        L_0x011f:
            boolean r0 = r4.hasNext()     // Catch:{ all -> 0x04b9 }
            if (r0 == 0) goto L_0x03be
            java.lang.Object r0 = r4.next()     // Catch:{ all -> 0x04b9 }
            ff0 r0 = (defpackage.ff0) r0     // Catch:{ all -> 0x04b9 }
            r23.j()     // Catch:{ all -> 0x04b9 }
            r23.h()     // Catch:{ all -> 0x04b9 }
            defpackage.s10.f(r24)     // Catch:{ all -> 0x04b9 }
            defpackage.s10.j(r0)     // Catch:{ all -> 0x04b9 }
            boolean r9 = r0.A()     // Catch:{ all -> 0x04b9 }
            if (r9 != 0) goto L_0x0153
            r9 = r23
            w01 r0 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x04b7 }
            lz0 r0 = r0.r()     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = "Audience with no ID. appId"
            java.lang.Object r8 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            r0.b(r7, r8)     // Catch:{ all -> 0x04b7 }
            goto L_0x011f
        L_0x0153:
            r9 = r23
            int r10 = r0.B()     // Catch:{ all -> 0x04b7 }
            java.util.List r11 = r0.F()     // Catch:{ all -> 0x04b7 }
            java.util.Iterator r11 = r11.iterator()     // Catch:{ all -> 0x04b7 }
        L_0x0161:
            boolean r12 = r11.hasNext()     // Catch:{ all -> 0x04b7 }
            if (r12 == 0) goto L_0x018b
            java.lang.Object r12 = r11.next()     // Catch:{ all -> 0x04b7 }
            hf0 r12 = (defpackage.hf0) r12     // Catch:{ all -> 0x04b7 }
            boolean r12 = r12.A()     // Catch:{ all -> 0x04b7 }
            if (r12 != 0) goto L_0x0161
            w01 r0 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x04b7 }
            lz0 r0 = r0.r()     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = "Event filter with no ID. Audience definition ignored. appId, audienceId"
            java.lang.Object r8 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x04b7 }
        L_0x0187:
            r0.c(r7, r8, r10)     // Catch:{ all -> 0x04b7 }
            goto L_0x011f
        L_0x018b:
            java.util.List r11 = r0.C()     // Catch:{ all -> 0x04b7 }
            java.util.Iterator r11 = r11.iterator()     // Catch:{ all -> 0x04b7 }
        L_0x0193:
            boolean r12 = r11.hasNext()     // Catch:{ all -> 0x04b7 }
            if (r12 == 0) goto L_0x01ba
            java.lang.Object r12 = r11.next()     // Catch:{ all -> 0x04b7 }
            qf0 r12 = (defpackage.qf0) r12     // Catch:{ all -> 0x04b7 }
            boolean r12 = r12.A()     // Catch:{ all -> 0x04b7 }
            if (r12 != 0) goto L_0x0193
            w01 r0 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x04b7 }
            lz0 r0 = r0.r()     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = "Property filter with no ID. Audience definition ignored. appId, audienceId"
            java.lang.Object r8 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            goto L_0x0187
        L_0x01ba:
            java.util.List r11 = r0.F()     // Catch:{ all -> 0x04b7 }
            java.util.Iterator r11 = r11.iterator()     // Catch:{ all -> 0x04b7 }
        L_0x01c2:
            boolean r12 = r11.hasNext()     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = "data"
            java.lang.String r13 = "session_scoped"
            java.lang.String r14 = "filter_id"
            java.lang.String r8 = "audience_id"
            java.lang.String r15 = "app_id"
            if (r12 == 0) goto L_0x02a6
            java.lang.Object r12 = r11.next()     // Catch:{ all -> 0x04b7 }
            hf0 r12 = (defpackage.hf0) r12     // Catch:{ all -> 0x04b7 }
            r23.j()     // Catch:{ all -> 0x04b7 }
            r23.h()     // Catch:{ all -> 0x04b7 }
            defpackage.s10.f(r24)     // Catch:{ all -> 0x04b7 }
            defpackage.s10.j(r12)     // Catch:{ all -> 0x04b7 }
            java.lang.String r21 = r12.C()     // Catch:{ all -> 0x04b7 }
            boolean r21 = android.text.TextUtils.isEmpty(r21)     // Catch:{ all -> 0x04b7 }
            if (r21 == 0) goto L_0x0220
            w01 r0 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x04b7 }
            lz0 r0 = r0.r()     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = "Event filter had no event name. Audience definition ignored. appId, audienceId, filterId"
            java.lang.Object r8 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r11 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            boolean r13 = r12.A()     // Catch:{ all -> 0x04b7 }
            if (r13 == 0) goto L_0x0213
            int r12 = r12.B()     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)     // Catch:{ all -> 0x04b7 }
            r20 = r12
            goto L_0x0215
        L_0x0213:
            r20 = 0
        L_0x0215:
            java.lang.String r12 = java.lang.String.valueOf(r20)     // Catch:{ all -> 0x04b7 }
            r0.d(r7, r8, r11, r12)     // Catch:{ all -> 0x04b7 }
            r21 = r4
            goto L_0x0381
        L_0x0220:
            byte[] r3 = r12.g()     // Catch:{ all -> 0x04b7 }
            r21 = r4
            android.content.ContentValues r4 = new android.content.ContentValues     // Catch:{ all -> 0x04b7 }
            r4.<init>()     // Catch:{ all -> 0x04b7 }
            r4.put(r15, r2)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r15 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            r4.put(r8, r15)     // Catch:{ all -> 0x04b7 }
            boolean r8 = r12.A()     // Catch:{ all -> 0x04b7 }
            if (r8 == 0) goto L_0x0244
            int r8 = r12.B()     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ all -> 0x04b7 }
            goto L_0x0245
        L_0x0244:
            r8 = 0
        L_0x0245:
            r4.put(r14, r8)     // Catch:{ all -> 0x04b7 }
            java.lang.String r8 = "event_name"
            java.lang.String r14 = r12.C()     // Catch:{ all -> 0x04b7 }
            r4.put(r8, r14)     // Catch:{ all -> 0x04b7 }
            boolean r8 = r12.K()     // Catch:{ all -> 0x04b7 }
            if (r8 == 0) goto L_0x0260
            boolean r8 = r12.L()     // Catch:{ all -> 0x04b7 }
            java.lang.Boolean r8 = java.lang.Boolean.valueOf(r8)     // Catch:{ all -> 0x04b7 }
            goto L_0x0261
        L_0x0260:
            r8 = 0
        L_0x0261:
            r4.put(r13, r8)     // Catch:{ all -> 0x04b7 }
            r4.put(r7, r3)     // Catch:{ all -> 0x04b7 }
            android.database.sqlite.SQLiteDatabase r3 = r23.P()     // Catch:{ SQLiteException -> 0x0290 }
            r7 = 5
            r8 = 0
            long r3 = r3.insertWithOnConflict(r5, r8, r4, r7)     // Catch:{ SQLiteException -> 0x0290 }
            r7 = -1
            int r12 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r12 != 0) goto L_0x028a
            w01 r3 = r9.a     // Catch:{ SQLiteException -> 0x0290 }
            nz0 r3 = r3.c()     // Catch:{ SQLiteException -> 0x0290 }
            lz0 r3 = r3.o()     // Catch:{ SQLiteException -> 0x0290 }
            java.lang.String r4 = "Failed to insert event filter (got -1). appId"
            java.lang.Object r7 = defpackage.nz0.x(r24)     // Catch:{ SQLiteException -> 0x0290 }
            r3.b(r4, r7)     // Catch:{ SQLiteException -> 0x0290 }
        L_0x028a:
            r3 = r25
            r4 = r21
            goto L_0x01c2
        L_0x0290:
            r0 = move-exception
            w01 r3 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r3 = r3.c()     // Catch:{ all -> 0x04b7 }
            lz0 r3 = r3.o()     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = "Error storing event filter. appId"
            java.lang.Object r7 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
        L_0x02a1:
            r3.c(r4, r7, r0)     // Catch:{ all -> 0x04b7 }
            goto L_0x0381
        L_0x02a6:
            r21 = r4
            java.util.List r0 = r0.C()     // Catch:{ all -> 0x04b7 }
            java.util.Iterator r0 = r0.iterator()     // Catch:{ all -> 0x04b7 }
        L_0x02b0:
            boolean r3 = r0.hasNext()     // Catch:{ all -> 0x04b7 }
            if (r3 == 0) goto L_0x03b8
            java.lang.Object r3 = r0.next()     // Catch:{ all -> 0x04b7 }
            qf0 r3 = (defpackage.qf0) r3     // Catch:{ all -> 0x04b7 }
            r23.j()     // Catch:{ all -> 0x04b7 }
            r23.h()     // Catch:{ all -> 0x04b7 }
            defpackage.s10.f(r24)     // Catch:{ all -> 0x04b7 }
            defpackage.s10.j(r3)     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = r3.C()     // Catch:{ all -> 0x04b7 }
            boolean r4 = android.text.TextUtils.isEmpty(r4)     // Catch:{ all -> 0x04b7 }
            if (r4 == 0) goto L_0x02ff
            w01 r0 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x04b7 }
            lz0 r0 = r0.r()     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = "Property filter had no property name. Audience definition ignored. appId, audienceId, filterId"
            java.lang.Object r7 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            boolean r11 = r3.A()     // Catch:{ all -> 0x04b7 }
            if (r11 == 0) goto L_0x02f5
            int r3 = r3.B()     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ all -> 0x04b7 }
            goto L_0x02f6
        L_0x02f5:
            r3 = 0
        L_0x02f6:
            java.lang.String r3 = java.lang.String.valueOf(r3)     // Catch:{ all -> 0x04b7 }
            r0.d(r4, r7, r8, r3)     // Catch:{ all -> 0x04b7 }
            goto L_0x0381
        L_0x02ff:
            byte[] r4 = r3.g()     // Catch:{ all -> 0x04b7 }
            android.content.ContentValues r11 = new android.content.ContentValues     // Catch:{ all -> 0x04b7 }
            r11.<init>()     // Catch:{ all -> 0x04b7 }
            r11.put(r15, r2)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            r11.put(r8, r12)     // Catch:{ all -> 0x04b7 }
            boolean r12 = r3.A()     // Catch:{ all -> 0x04b7 }
            if (r12 == 0) goto L_0x0321
            int r12 = r3.B()     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)     // Catch:{ all -> 0x04b7 }
            goto L_0x0322
        L_0x0321:
            r12 = 0
        L_0x0322:
            r11.put(r14, r12)     // Catch:{ all -> 0x04b7 }
            java.lang.String r12 = "property_name"
            r22 = r0
            java.lang.String r0 = r3.C()     // Catch:{ all -> 0x04b7 }
            r11.put(r12, r0)     // Catch:{ all -> 0x04b7 }
            boolean r0 = r3.G()     // Catch:{ all -> 0x04b7 }
            if (r0 == 0) goto L_0x033f
            boolean r0 = r3.H()     // Catch:{ all -> 0x04b7 }
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch:{ all -> 0x04b7 }
            goto L_0x0340
        L_0x033f:
            r0 = 0
        L_0x0340:
            r11.put(r13, r0)     // Catch:{ all -> 0x04b7 }
            r11.put(r7, r4)     // Catch:{ all -> 0x04b7 }
            android.database.sqlite.SQLiteDatabase r0 = r23.P()     // Catch:{ SQLiteException -> 0x036e }
            r3 = 0
            r4 = 5
            long r11 = r0.insertWithOnConflict(r6, r3, r11, r4)     // Catch:{ SQLiteException -> 0x036e }
            r18 = -1
            int r0 = (r11 > r18 ? 1 : (r11 == r18 ? 0 : -1))
            if (r0 != 0) goto L_0x036a
            w01 r0 = r9.a     // Catch:{ SQLiteException -> 0x036e }
            nz0 r0 = r0.c()     // Catch:{ SQLiteException -> 0x036e }
            lz0 r0 = r0.o()     // Catch:{ SQLiteException -> 0x036e }
            java.lang.String r3 = "Failed to insert property filter (got -1). appId"
            java.lang.Object r4 = defpackage.nz0.x(r24)     // Catch:{ SQLiteException -> 0x036e }
            r0.b(r3, r4)     // Catch:{ SQLiteException -> 0x036e }
            goto L_0x0381
        L_0x036a:
            r0 = r22
            goto L_0x02b0
        L_0x036e:
            r0 = move-exception
            w01 r3 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r3 = r3.c()     // Catch:{ all -> 0x04b7 }
            lz0 r3 = r3.o()     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = "Error storing property filter. appId"
            java.lang.Object r7 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            goto L_0x02a1
        L_0x0381:
            r23.j()     // Catch:{ all -> 0x04b7 }
            r23.h()     // Catch:{ all -> 0x04b7 }
            defpackage.s10.f(r24)     // Catch:{ all -> 0x04b7 }
            android.database.sqlite.SQLiteDatabase r0 = r23.P()     // Catch:{ all -> 0x04b7 }
            r3 = 2
            java.lang.String[] r4 = new java.lang.String[r3]     // Catch:{ all -> 0x04b7 }
            r3 = 0
            r4[r3] = r2     // Catch:{ all -> 0x04b7 }
            java.lang.String r3 = java.lang.String.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            r7 = 1
            r4[r7] = r3     // Catch:{ all -> 0x04b7 }
            r3 = r17
            r0.delete(r6, r3, r4)     // Catch:{ all -> 0x04b7 }
            r4 = 2
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch:{ all -> 0x04b7 }
            r7 = 0
            r4[r7] = r2     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = java.lang.String.valueOf(r10)     // Catch:{ all -> 0x04b7 }
            r8 = 1
            r4[r8] = r7     // Catch:{ all -> 0x04b7 }
            r0.delete(r5, r3, r4)     // Catch:{ all -> 0x04b7 }
            r17 = r3
            r4 = r21
            r3 = r25
            goto L_0x011f
        L_0x03b8:
            r3 = r25
            r4 = r21
            goto L_0x011f
        L_0x03be:
            r3 = 0
            r9 = r23
            java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ all -> 0x04b7 }
            r0.<init>()     // Catch:{ all -> 0x04b7 }
            java.util.Iterator r4 = r25.iterator()     // Catch:{ all -> 0x04b7 }
        L_0x03ca:
            boolean r5 = r4.hasNext()     // Catch:{ all -> 0x04b7 }
            if (r5 == 0) goto L_0x03ea
            java.lang.Object r5 = r4.next()     // Catch:{ all -> 0x04b7 }
            ff0 r5 = (defpackage.ff0) r5     // Catch:{ all -> 0x04b7 }
            boolean r6 = r5.A()     // Catch:{ all -> 0x04b7 }
            if (r6 == 0) goto L_0x03e5
            int r5 = r5.B()     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x04b7 }
            goto L_0x03e6
        L_0x03e5:
            r8 = r3
        L_0x03e6:
            r0.add(r8)     // Catch:{ all -> 0x04b7 }
            goto L_0x03ca
        L_0x03ea:
            defpackage.s10.f(r24)     // Catch:{ all -> 0x04b7 }
            r23.j()     // Catch:{ all -> 0x04b7 }
            r23.h()     // Catch:{ all -> 0x04b7 }
            android.database.sqlite.SQLiteDatabase r3 = r23.P()     // Catch:{ all -> 0x04b7 }
            r4 = 1
            java.lang.String[] r5 = new java.lang.String[r4]     // Catch:{ SQLiteException -> 0x049c }
            r4 = 0
            r5[r4] = r2     // Catch:{ SQLiteException -> 0x049c }
            java.lang.String r4 = "select count(1) from audience_filter_values where app_id=?"
            long r4 = r9.K(r4, r5)     // Catch:{ SQLiteException -> 0x049c }
            w01 r6 = r9.a     // Catch:{ all -> 0x04b7 }
            bv0 r6 = r6.z()     // Catch:{ all -> 0x04b7 }
            r7 = 2000(0x7d0, float:2.803E-42)
            zy0<java.lang.Integer> r8 = defpackage.bz0.E     // Catch:{ all -> 0x04b7 }
            int r6 = r6.t(r2, r8)     // Catch:{ all -> 0x04b7 }
            int r6 = java.lang.Math.min(r7, r6)     // Catch:{ all -> 0x04b7 }
            r7 = 0
            int r6 = java.lang.Math.max(r7, r6)     // Catch:{ all -> 0x04b7 }
            long r7 = (long) r6     // Catch:{ all -> 0x04b7 }
            int r10 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r10 > 0) goto L_0x0421
            goto L_0x04b0
        L_0x0421:
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch:{ all -> 0x04b7 }
            r4.<init>()     // Catch:{ all -> 0x04b7 }
            r5 = 0
        L_0x0427:
            int r7 = r0.size()     // Catch:{ all -> 0x04b7 }
            if (r5 >= r7) goto L_0x0443
            java.lang.Object r7 = r0.get(r5)     // Catch:{ all -> 0x04b7 }
            java.lang.Integer r7 = (java.lang.Integer) r7     // Catch:{ all -> 0x04b7 }
            if (r7 == 0) goto L_0x04b0
            int r7 = r7.intValue()     // Catch:{ all -> 0x04b7 }
            java.lang.String r7 = java.lang.Integer.toString(r7)     // Catch:{ all -> 0x04b7 }
            r4.add(r7)     // Catch:{ all -> 0x04b7 }
            int r5 = r5 + 1
            goto L_0x0427
        L_0x0443:
            java.lang.String r0 = ","
            java.lang.String r0 = android.text.TextUtils.join(r0, r4)     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = java.lang.String.valueOf(r0)     // Catch:{ all -> 0x04b7 }
            int r4 = r4.length()     // Catch:{ all -> 0x04b7 }
            r5 = 2
            int r4 = r4 + r5
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x04b7 }
            r5.<init>(r4)     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = "("
            r5.append(r4)     // Catch:{ all -> 0x04b7 }
            r5.append(r0)     // Catch:{ all -> 0x04b7 }
            java.lang.String r0 = ")"
            r5.append(r0)     // Catch:{ all -> 0x04b7 }
            java.lang.String r0 = r5.toString()     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = "audience_filter_values"
            java.lang.String r5 = java.lang.String.valueOf(r0)     // Catch:{ all -> 0x04b7 }
            int r5 = r5.length()     // Catch:{ all -> 0x04b7 }
            int r5 = r5 + 140
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ all -> 0x04b7 }
            r7.<init>(r5)     // Catch:{ all -> 0x04b7 }
            java.lang.String r5 = "audience_id in (select audience_id from audience_filter_values where app_id=? and audience_id not in "
            r7.append(r5)     // Catch:{ all -> 0x04b7 }
            r7.append(r0)     // Catch:{ all -> 0x04b7 }
            java.lang.String r0 = " order by rowid desc limit -1 offset ?)"
            r7.append(r0)     // Catch:{ all -> 0x04b7 }
            java.lang.String r0 = r7.toString()     // Catch:{ all -> 0x04b7 }
            r5 = 2
            java.lang.String[] r5 = new java.lang.String[r5]     // Catch:{ all -> 0x04b7 }
            r7 = 0
            r5[r7] = r2     // Catch:{ all -> 0x04b7 }
            java.lang.String r2 = java.lang.Integer.toString(r6)     // Catch:{ all -> 0x04b7 }
            r6 = 1
            r5[r6] = r2     // Catch:{ all -> 0x04b7 }
            r3.delete(r4, r0, r5)     // Catch:{ all -> 0x04b7 }
            goto L_0x04b0
        L_0x049c:
            r0 = move-exception
            w01 r3 = r9.a     // Catch:{ all -> 0x04b7 }
            nz0 r3 = r3.c()     // Catch:{ all -> 0x04b7 }
            lz0 r3 = r3.o()     // Catch:{ all -> 0x04b7 }
            java.lang.String r4 = "Database error querying filters. appId"
            java.lang.Object r2 = defpackage.nz0.x(r24)     // Catch:{ all -> 0x04b7 }
            r3.c(r4, r2, r0)     // Catch:{ all -> 0x04b7 }
        L_0x04b0:
            r1.setTransactionSuccessful()     // Catch:{ all -> 0x04b7 }
            r1.endTransaction()
            return
        L_0x04b7:
            r0 = move-exception
            goto L_0x04bc
        L_0x04b9:
            r0 = move-exception
            r9 = r23
        L_0x04bc:
            r1.endTransaction()
            goto L_0x04c1
        L_0x04c0:
            throw r0
        L_0x04c1:
            goto L_0x04c0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fv0.x(java.lang.String, java.util.List):void");
    }

    public final boolean y() {
        Context e2 = this.a.e();
        this.a.z();
        return e2.getDatabasePath("google_app_measurement.db").exists();
    }
}
