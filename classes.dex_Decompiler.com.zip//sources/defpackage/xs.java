package defpackage;

import android.database.sqlite.SQLiteDatabase;
import defpackage.wt;

/* renamed from: xs  reason: default package */
public final /* synthetic */ class xs implements wt.d {
    public final /* synthetic */ SQLiteDatabase a;

    public /* synthetic */ xs(SQLiteDatabase sQLiteDatabase) {
        this.a = sQLiteDatabase;
    }

    public final Object a() {
        Object unused = this.a.beginTransaction();
        return null;
    }
}
