package defpackage;

import android.os.Bundle;
import java.util.List;
import java.util.Map;

/* renamed from: ef1  reason: default package */
public final class ef1 implements a31 {
    public final /* synthetic */ cf0 a;

    public ef1(cf0 cf0) {
        this.a = cf0;
    }

    public final long a() {
        return this.a.F();
    }

    public final void b(String str, String str2, Bundle bundle) {
        this.a.v(str, str2, bundle);
    }

    public final String c() {
        return this.a.a();
    }

    public final void d(String str) {
        this.a.C(str);
    }

    public final String e() {
        return this.a.E();
    }

    public final int f(String str) {
        return this.a.d(str);
    }

    public final List<Bundle> g(String str, String str2) {
        return this.a.z(str, str2);
    }

    public final String h() {
        return this.a.D();
    }

    public final void i(String str, String str2, Bundle bundle) {
        this.a.y(str, str2, bundle);
    }

    public final Map<String, Object> j(String str, String str2, boolean z) {
        return this.a.b(str, str2, z);
    }

    public final void k(Bundle bundle) {
        this.a.x(bundle);
    }

    public final String l() {
        return this.a.G();
    }

    public final void m(String str) {
        this.a.B(str);
    }
}
