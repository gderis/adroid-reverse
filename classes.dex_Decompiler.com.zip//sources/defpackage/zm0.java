package defpackage;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/* renamed from: zm0  reason: default package */
public final class zm0 extends hn0 {
    public zm0(int i) {
        super(i, (zm0) null);
    }

    public final void a() {
        if (!b()) {
            for (int i = 0; i < c(); i++) {
                Map.Entry d = d(i);
                if (((wk0) d.getKey()).c()) {
                    d.setValue(Collections.unmodifiableList((List) d.getValue()));
                }
            }
            for (Map.Entry entry : e()) {
                if (((wk0) entry.getKey()).c()) {
                    entry.setValue(Collections.unmodifiableList((List) entry.getValue()));
                }
            }
        }
        super.a();
    }
}
