package defpackage;

/* renamed from: ce0  reason: default package */
public final class ce0 extends re0 {
    public final /* synthetic */ String a;
    public final /* synthetic */ cf0 b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ce0(cf0 cf0, String str) {
        super(cf0, true);
        this.b = cf0;
        this.a = str;
    }

    public final void a() {
        ((ld0) s10.j(this.b.f1265a)).endAdUnitExposure(this.a, this.b);
    }
}
