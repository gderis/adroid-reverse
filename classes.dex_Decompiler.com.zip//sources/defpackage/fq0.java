package defpackage;

/* renamed from: fq0  reason: default package */
public interface fq0 {
    boolean a();

    boolean b();

    boolean c();

    boolean d();
}
