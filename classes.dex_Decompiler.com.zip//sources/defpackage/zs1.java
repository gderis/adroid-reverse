package defpackage;

/* renamed from: zs1  reason: default package */
public abstract class zs1<TModelView> extends us1<TModelView> {
    public abstract String q();

    public abstract String r();
}
