package defpackage;

import android.os.Bundle;

/* renamed from: qv  reason: default package */
public final /* synthetic */ class qv implements f81 {
    public final Bundle a;

    /* renamed from: a  reason: collision with other field name */
    public final uu f4692a;

    public qv(uu uuVar, Bundle bundle) {
        this.f4692a = uuVar;
        this.a = bundle;
    }

    public final Object a(n81 n81) {
        return this.f4692a.d(this.a, n81);
    }
}
