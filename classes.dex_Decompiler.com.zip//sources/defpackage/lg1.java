package defpackage;

import android.os.Bundle;

/* renamed from: lg1  reason: default package */
public final /* synthetic */ class lg1 implements vg1 {
    public final /* synthetic */ og1 a;

    public /* synthetic */ lg1(og1 og1) {
        this.a = og1;
    }

    public final void b(String str, Bundle bundle) {
        this.a.e(str, bundle);
    }
}
