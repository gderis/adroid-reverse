package defpackage;

import java.util.List;
import java.util.concurrent.Callable;

/* renamed from: e11  reason: default package */
public final class e11 implements Callable<List<xu0>> {
    public final /* synthetic */ String a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ p11 f2138a;
    public final /* synthetic */ String b;
    public final /* synthetic */ String c;

    public e11(p11 p11, String str, String str2, String str3) {
        this.f2138a = p11;
        this.a = str;
        this.b = str2;
        this.c = str3;
    }

    public final /* bridge */ /* synthetic */ Object call() {
        this.f2138a.f4365a.l();
        return this.f2138a.f4365a.V().a0(this.a, this.b, this.c);
    }
}
