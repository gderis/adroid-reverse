package defpackage;

import java.util.List;
import java.util.concurrent.Callable;

/* renamed from: b11  reason: default package */
public final class b11 implements Callable<List<x51>> {
    public final /* synthetic */ String a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ p11 f1010a;
    public final /* synthetic */ String b;
    public final /* synthetic */ String c;

    public b11(p11 p11, String str, String str2, String str3) {
        this.f1010a = p11;
        this.a = str;
        this.b = str2;
        this.c = str3;
    }

    public final /* bridge */ /* synthetic */ Object call() {
        this.f1010a.f4365a.l();
        return this.f1010a.f4365a.V().W(this.a, this.b, this.c);
    }
}
