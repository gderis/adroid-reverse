package defpackage;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* renamed from: h2  reason: default package */
public class h2 extends ImageButton implements xa, cc {
    public final i2 a;

    /* renamed from: a  reason: collision with other field name */
    public final z1 f2727a;

    public h2(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, o.imageButtonStyle);
    }

    public h2(Context context, AttributeSet attributeSet, int i) {
        super(p3.b(context), attributeSet, i);
        n3.a(this, getContext());
        z1 z1Var = new z1(this);
        this.f2727a = z1Var;
        z1Var.e(attributeSet, i);
        i2 i2Var = new i2(this);
        this.a = i2Var;
        i2Var.f(attributeSet, i);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            z1Var.b();
        }
        i2 i2Var = this.a;
        if (i2Var != null) {
            i2Var.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            return z1Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            return z1Var.d();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        i2 i2Var = this.a;
        if (i2Var != null) {
            return i2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        i2 i2Var = this.a;
        if (i2Var != null) {
            return i2Var.d();
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return this.a.e() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            z1Var.f(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            z1Var.g(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        i2 i2Var = this.a;
        if (i2Var != null) {
            i2Var.b();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        i2 i2Var = this.a;
        if (i2Var != null) {
            i2Var.b();
        }
    }

    public void setImageResource(int i) {
        this.a.g(i);
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        i2 i2Var = this.a;
        if (i2Var != null) {
            i2Var.b();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            z1Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        z1 z1Var = this.f2727a;
        if (z1Var != null) {
            z1Var.j(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        i2 i2Var = this.a;
        if (i2Var != null) {
            i2Var.h(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        i2 i2Var = this.a;
        if (i2Var != null) {
            i2Var.i(mode);
        }
    }
}
