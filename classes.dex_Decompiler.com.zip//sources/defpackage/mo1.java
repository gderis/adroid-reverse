package defpackage;

import java.util.concurrent.Executor;

/* renamed from: mo1  reason: default package */
public final /* synthetic */ class mo1 implements Executor {
    public static final Executor a = new mo1();

    public void execute(Runnable runnable) {
        runnable.run();
    }
}
