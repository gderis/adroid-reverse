package defpackage;

/* renamed from: yq  reason: default package */
public interface yq {
    gr a(String str);
}
