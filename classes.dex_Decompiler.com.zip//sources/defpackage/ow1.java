package defpackage;

import android.app.Application;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: ow1  reason: default package */
public class ow1 extends Application {
    public static ix1 a(xt1 xt1, boolean z) {
        Class<uu1> cls = uu1.class;
        JSONArray jSONArray = new JSONArray();
        long j = 0;
        try {
            j = xt1.l(wx1.a(-481406540973827788L));
            int p = xt1.p(wx1.a(-481406592513435340L), 50);
            if (!xt1.a(wx1.a(-481406644053042892L), z)) {
                return new ix1(jSONArray, j);
            }
            xr1<TModel> a = fs1.c(new js1[0]).a(cls);
            ks1<Long> ks1 = vu1.d;
            List<TModel> p2 = a.q(ks1.e(Long.valueOf(j))).s(ks1, true).r(p).p();
            o82.d(wx1.a(-481406695592650444L), ox1.c(j));
            if (p2.size() > 0) {
                double g = xt1.g();
                double k = xt1.k();
                for (int i = 0; i < p2.size(); i++) {
                    try {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put(wx1.a(-481406768607094476L), ((uu1) p2.get(i)).d());
                        jSONObject.put(wx1.a(-481406802966832844L), ox1.c(((uu1) p2.get(i)).e()));
                        jSONObject.put(wx1.a(-481406841621538508L), ((uu1) p2.get(i)).f());
                        jSONObject.put(wx1.a(-481406893161146060L), ((uu1) p2.get(i)).c());
                        jSONObject.put(wx1.a(-481406910341015244L), ((uu1) p2.get(i)).g());
                        jSONObject.put(wx1.a(-481406931815851724L), g);
                        jSONObject.put(wx1.a(-481406970470557388L), k);
                        jSONArray.put(jSONObject);
                        if (((uu1) p2.get(i)).e() > j) {
                            j = ((uu1) p2.get(i)).e();
                        }
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                }
                try {
                    Calendar instance = Calendar.getInstance();
                    instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481407013420230348L)));
                    instance.add(10, -72);
                    fs1.b(cls).q(vu1.d.f(Long.valueOf(instance.getTimeInMillis()))).m().h();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return new ix1(jSONArray, j);
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }
}
