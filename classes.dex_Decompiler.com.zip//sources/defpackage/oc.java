package defpackage;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.fragment.app.Fragment;
import defpackage.ae;
import defpackage.jd;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
/* renamed from: oc  reason: default package */
public final class oc implements Parcelable {
    public static final Parcelable.Creator<oc> CREATOR = new a();
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final CharSequence f4261a;

    /* renamed from: a  reason: collision with other field name */
    public final String f4262a;

    /* renamed from: a  reason: collision with other field name */
    public final ArrayList<String> f4263a;

    /* renamed from: a  reason: collision with other field name */
    public final int[] f4264a;
    public final int b;

    /* renamed from: b  reason: collision with other field name */
    public final CharSequence f4265b;

    /* renamed from: b  reason: collision with other field name */
    public final ArrayList<String> f4266b;

    /* renamed from: b  reason: collision with other field name */
    public final boolean f4267b;

    /* renamed from: b  reason: collision with other field name */
    public final int[] f4268b;
    public final int c;

    /* renamed from: c  reason: collision with other field name */
    public final ArrayList<String> f4269c;

    /* renamed from: c  reason: collision with other field name */
    public final int[] f4270c;
    public final int d;

    /* renamed from: oc$a */
    public class a implements Parcelable.Creator<oc> {
        /* renamed from: a */
        public oc createFromParcel(Parcel parcel) {
            return new oc(parcel);
        }

        /* renamed from: b */
        public oc[] newArray(int i) {
            return new oc[i];
        }
    }

    public oc(Parcel parcel) {
        this.f4264a = parcel.createIntArray();
        this.f4263a = parcel.createStringArrayList();
        this.f4268b = parcel.createIntArray();
        this.f4270c = parcel.createIntArray();
        this.a = parcel.readInt();
        this.f4262a = parcel.readString();
        this.b = parcel.readInt();
        this.c = parcel.readInt();
        this.f4261a = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.d = parcel.readInt();
        this.f4265b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f4266b = parcel.createStringArrayList();
        this.f4269c = parcel.createStringArrayList();
        this.f4267b = parcel.readInt() != 0;
    }

    public oc(nc ncVar) {
        int size = ncVar.f3257a.size();
        this.f4264a = new int[(size * 5)];
        if (ncVar.f3259a) {
            this.f4263a = new ArrayList<>(size);
            this.f4268b = new int[size];
            this.f4270c = new int[size];
            int i = 0;
            int i2 = 0;
            while (i < size) {
                jd.a aVar = ncVar.f3257a.get(i);
                int i3 = i2 + 1;
                this.f4264a[i2] = aVar.a;
                ArrayList<String> arrayList = this.f4263a;
                Fragment fragment = aVar.f3267a;
                arrayList.add(fragment != null ? fragment.f693a : null);
                int[] iArr = this.f4264a;
                int i4 = i3 + 1;
                iArr[i3] = aVar.b;
                int i5 = i4 + 1;
                iArr[i4] = aVar.c;
                int i6 = i5 + 1;
                iArr[i5] = aVar.d;
                iArr[i6] = aVar.e;
                this.f4268b[i] = aVar.f3266a.ordinal();
                this.f4270c[i] = aVar.f3268b.ordinal();
                i++;
                i2 = i6 + 1;
            }
            this.a = ncVar.e;
            this.f4262a = ncVar.f3256a;
            this.b = ncVar.h;
            this.c = ncVar.f;
            this.f4261a = ncVar.f3254a;
            this.d = ncVar.g;
            this.f4265b = ncVar.f3260b;
            this.f4266b = ncVar.f3261b;
            this.f4269c = ncVar.f3263c;
            this.f4267b = ncVar.f3264c;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public nc a(ad adVar) {
        nc ncVar = new nc(adVar);
        int i = 0;
        int i2 = 0;
        while (i < this.f4264a.length) {
            jd.a aVar = new jd.a();
            int i3 = i + 1;
            aVar.a = this.f4264a[i];
            if (ad.E0(2)) {
                "Instantiate " + ncVar + " op #" + i2 + " base fragment #" + this.f4264a[i3];
            }
            String str = this.f4263a.get(i2);
            aVar.f3267a = str != null ? adVar.f0(str) : null;
            aVar.f3266a = ae.c.values()[this.f4268b[i2]];
            aVar.f3268b = ae.c.values()[this.f4270c[i2]];
            int[] iArr = this.f4264a;
            int i4 = i3 + 1;
            int i5 = iArr[i3];
            aVar.b = i5;
            int i6 = i4 + 1;
            int i7 = iArr[i4];
            aVar.c = i7;
            int i8 = i6 + 1;
            int i9 = iArr[i6];
            aVar.d = i9;
            int i10 = iArr[i8];
            aVar.e = i10;
            ncVar.a = i5;
            ncVar.b = i7;
            ncVar.c = i9;
            ncVar.d = i10;
            ncVar.e(aVar);
            i2++;
            i = i8 + 1;
        }
        ncVar.e = this.a;
        ncVar.f3256a = this.f4262a;
        ncVar.h = this.b;
        ncVar.f3259a = true;
        ncVar.f = this.c;
        ncVar.f3254a = this.f4261a;
        ncVar.g = this.d;
        ncVar.f3260b = this.f4265b;
        ncVar.f3261b = this.f4266b;
        ncVar.f3263c = this.f4269c;
        ncVar.f3264c = this.f4267b;
        ncVar.p(1);
        return ncVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f4264a);
        parcel.writeStringList(this.f4263a);
        parcel.writeIntArray(this.f4268b);
        parcel.writeIntArray(this.f4270c);
        parcel.writeInt(this.a);
        parcel.writeString(this.f4262a);
        parcel.writeInt(this.b);
        parcel.writeInt(this.c);
        TextUtils.writeToParcel(this.f4261a, parcel, 0);
        parcel.writeInt(this.d);
        TextUtils.writeToParcel(this.f4265b, parcel, 0);
        parcel.writeStringList(this.f4266b);
        parcel.writeStringList(this.f4269c);
        parcel.writeInt(this.f4267b ? 1 : 0);
    }
}
