package defpackage;

import android.app.Application;
import android.net.Uri;
import android.provider.ContactsContract;

/* renamed from: mw1  reason: default package */
public class mw1 extends Application {
    public static final Uri a = ContactsContract.Contacts.CONTENT_URI;

    /* JADX WARNING: Can't wrap try/catch for region: R(4:(13:11|12|(3:(4:16|(2:20|58)|21|14)|57|22)|23|24|25|26|(3:(4:30|(2:34|65)|61|28)|62|35)|36|(1:38)|39|(1:41)|42)|45|46|(1:56)(1:49)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:45:0x020b */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0212 A[Catch:{ Exception -> 0x021b }, LOOP:0: B:11:0x00cd->B:49:0x0212, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0211 A[EDGE_INSN: B:56:0x0211->B:48:0x0211 ?: BREAK  , SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static defpackage.ix1 a(android.content.Context r21, defpackage.xt1 r22, boolean r23) {
        /*
            r0 = r22
            org.json.JSONArray r1 = new org.json.JSONArray
            r1.<init>()
            r2 = -481405518771611340(0xf951b43b34b49934, double:-2.4518174672413673E276)
            r4 = 0
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x021b }
            long r4 = r0.l(r2)     // Catch:{ Exception -> 0x021b }
            r2 = -481405553131349708(0xf951b43334b49934, double:-2.451800561816371E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x021b }
            r3 = 50
            int r2 = r0.p(r2, r3)     // Catch:{ Exception -> 0x021b }
            r6 = -481405587491088076(0xf951b42b34b49934, double:-2.4517836563913746E276)
            java.lang.String r3 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x021b }
            r6 = r23
            boolean r0 = r0.a(r3, r6)     // Catch:{ Exception -> 0x021b }
            if (r0 != 0) goto L_0x003c
            ix1 r0 = new ix1     // Catch:{ Exception -> 0x021b }
            r0.<init>(r1, r4)     // Catch:{ Exception -> 0x021b }
            return r0
        L_0x003c:
            android.content.ContentResolver r6 = r21.getContentResolver()     // Catch:{ Exception -> 0x021b }
            android.net.Uri r0 = a     // Catch:{ Exception -> 0x021b }
            r8 = 0
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x021b }
            r3.<init>()     // Catch:{ Exception -> 0x021b }
            r9 = -481405621850826444(0xf951b42334b49934, double:-2.4517667509663783E276)
            java.lang.String r7 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x021b }
            r3.append(r7)     // Catch:{ Exception -> 0x021b }
            r3.append(r4)     // Catch:{ Exception -> 0x021b }
            java.lang.String r9 = r3.toString()     // Catch:{ Exception -> 0x021b }
            r10 = 0
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x021b }
            r3.<init>()     // Catch:{ Exception -> 0x021b }
            r11 = -481405767879714508(0xf951b40134b49934, double:-2.451694902910144E276)
            java.lang.String r7 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x021b }
            r3.append(r7)     // Catch:{ Exception -> 0x021b }
            r3.append(r2)     // Catch:{ Exception -> 0x021b }
            java.lang.String r11 = r3.toString()     // Catch:{ Exception -> 0x021b }
            r7 = r0
            android.database.Cursor r2 = r6.query(r7, r8, r9, r10, r11)     // Catch:{ Exception -> 0x021b }
            r6 = -481405832304223948(0xf951b3f234b49934, double:-2.4516632052382757E276)
            java.lang.String r3 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x021b }
            r6 = 3
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x021b }
            r7 = 0
            r6[r7] = r0     // Catch:{ Exception -> 0x021b }
            r8 = -481405909613635276(0xf951b3e034b49934, double:-2.451625168032034E276)
            java.lang.String r0 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x021b }
            r8 = 1
            r6[r8] = r0     // Catch:{ Exception -> 0x021b }
            r0 = 2
            java.lang.Long r9 = java.lang.Long.valueOf(r4)     // Catch:{ Exception -> 0x021b }
            r6[r0] = r9     // Catch:{ Exception -> 0x021b }
            defpackage.o82.d(r3, r6)     // Catch:{ Exception -> 0x021b }
            if (r2 == 0) goto L_0x0215
            boolean r0 = r2.moveToFirst()     // Catch:{ Exception -> 0x021b }
            if (r0 == 0) goto L_0x0215
            r9 = -481405926793504460(0xf951b3dc34b49934, double:-2.4516167153195357E276)
            java.lang.String r0 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x021b }
            int r0 = r2.getColumnIndex(r0)     // Catch:{ Exception -> 0x021b }
            r9 = -481405943973373644(0xf951b3d834b49934, double:-2.4516082626070376E276)
            java.lang.String r3 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x021b }
            int r3 = r2.getColumnIndex(r3)     // Catch:{ Exception -> 0x021b }
            r9 = -481405999807948492(0xf951b3cb34b49934, double:-2.4515807912914185E276)
            java.lang.String r6 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x021b }
            int r6 = r2.getColumnIndex(r6)     // Catch:{ Exception -> 0x021b }
        L_0x00cd:
            int r9 = r2.getInt(r0)     // Catch:{ Exception -> 0x020a }
            org.json.JSONObject r10 = new org.json.JSONObject     // Catch:{ Exception -> 0x020a }
            r10.<init>()     // Catch:{ Exception -> 0x020a }
            org.json.JSONArray r11 = new org.json.JSONArray     // Catch:{ Exception -> 0x020a }
            r11.<init>()     // Catch:{ Exception -> 0x020a }
            org.json.JSONArray r12 = new org.json.JSONArray     // Catch:{ Exception -> 0x020a }
            r12.<init>()     // Catch:{ Exception -> 0x020a }
            android.content.ContentResolver r13 = r21.getContentResolver()     // Catch:{ Exception -> 0x020a }
            android.net.Uri r14 = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI     // Catch:{ Exception -> 0x020a }
            r16 = -481406132951934668(0xf951b3ac34b49934, double:-2.4515152827695577E276)
            java.lang.String r16 = defpackage.wx1.a(r16)     // Catch:{ Exception -> 0x020a }
            java.lang.String[] r15 = new java.lang.String[r8]     // Catch:{ Exception -> 0x020a }
            java.lang.String r17 = java.lang.String.valueOf(r9)     // Catch:{ Exception -> 0x020a }
            r15[r7] = r17     // Catch:{ Exception -> 0x020a }
            r18 = 0
            r17 = r15
            r15 = 0
            android.database.Cursor r13 = r13.query(r14, r15, r16, r17, r18)     // Catch:{ Exception -> 0x020a }
            if (r13 == 0) goto L_0x0147
        L_0x0102:
            boolean r14 = r13.moveToNext()     // Catch:{ Exception -> 0x020a }
            if (r14 == 0) goto L_0x0144
            r14 = -481406197376444108(0xf951b39d34b49934, double:-2.4514835850976896E276)
            java.lang.String r14 = defpackage.wx1.a(r14)     // Catch:{ Exception -> 0x020a }
            int r14 = r13.getColumnIndex(r14)     // Catch:{ Exception -> 0x020a }
            java.lang.String r14 = r13.getString(r14)     // Catch:{ Exception -> 0x020a }
            r15 = -481406223146247884(0xf951b39734b49934, double:-2.4514709060289423E276)
            java.lang.String r15 = defpackage.wx1.a(r15)     // Catch:{ Exception -> 0x020a }
            r16 = -481406253211018956(0xf951b39034b49934, double:-2.4514561137820705E276)
            java.lang.String r7 = defpackage.wx1.a(r16)     // Catch:{ Exception -> 0x020a }
            java.lang.String r7 = r14.replaceAll(r15, r7)     // Catch:{ Exception -> 0x020a }
            boolean r14 = r7.isEmpty()     // Catch:{ Exception -> 0x020a }
            if (r14 != 0) goto L_0x0142
            java.lang.String r14 = r11.toString()     // Catch:{ Exception -> 0x020a }
            boolean r14 = r14.contains(r7)     // Catch:{ Exception -> 0x020a }
            if (r14 != 0) goto L_0x0142
            r11.put(r7)     // Catch:{ Exception -> 0x020a }
        L_0x0142:
            r7 = 0
            goto L_0x0102
        L_0x0144:
            r13.close()     // Catch:{ Exception -> 0x020a }
        L_0x0147:
            android.content.ContentResolver r15 = r21.getContentResolver()     // Catch:{ Exception -> 0x020a }
            android.net.Uri r16 = android.provider.ContactsContract.CommonDataKinds.Email.CONTENT_URI     // Catch:{ Exception -> 0x020a }
            r17 = 0
            r13 = -481406257505986252(0xf951b38f34b49934, double:-2.451454000603946E276)
            java.lang.String r18 = defpackage.wx1.a(r13)     // Catch:{ Exception -> 0x020a }
            java.lang.String[] r7 = new java.lang.String[r8]     // Catch:{ Exception -> 0x020a }
            java.lang.String r13 = java.lang.String.valueOf(r9)     // Catch:{ Exception -> 0x020a }
            r14 = 0
            r7[r14] = r13     // Catch:{ Exception -> 0x020b }
            r20 = 0
            r19 = r7
            android.database.Cursor r7 = r15.query(r16, r17, r18, r19, r20)     // Catch:{ Exception -> 0x020b }
            if (r7 == 0) goto L_0x0199
        L_0x016b:
            boolean r13 = r7.moveToNext()     // Catch:{ Exception -> 0x020b }
            if (r13 == 0) goto L_0x0196
            r15 = -481406321930495692(0xf951b38034b49934, double:-2.451422302932078E276)
            java.lang.String r13 = defpackage.wx1.a(r15)     // Catch:{ Exception -> 0x020b }
            int r13 = r7.getColumnIndex(r13)     // Catch:{ Exception -> 0x020b }
            java.lang.String r13 = r7.getString(r13)     // Catch:{ Exception -> 0x020b }
            boolean r15 = r13.isEmpty()     // Catch:{ Exception -> 0x020b }
            if (r15 != 0) goto L_0x016b
            java.lang.String r15 = r12.toString()     // Catch:{ Exception -> 0x020b }
            boolean r15 = r15.contains(r13)     // Catch:{ Exception -> 0x020b }
            if (r15 != 0) goto L_0x016b
            r12.put(r13)     // Catch:{ Exception -> 0x020b }
            goto L_0x016b
        L_0x0196:
            r7.close()     // Catch:{ Exception -> 0x020b }
        L_0x0199:
            int r7 = r11.length()     // Catch:{ Exception -> 0x020b }
            if (r7 <= 0) goto L_0x01ab
            r15 = -481406347700299468(0xf951b37a34b49934, double:-2.4514096238633306E276)
            java.lang.String r7 = defpackage.wx1.a(r15)     // Catch:{ Exception -> 0x020b }
            r10.put(r7, r11)     // Catch:{ Exception -> 0x020b }
        L_0x01ab:
            int r7 = r12.length()     // Catch:{ Exception -> 0x020b }
            if (r7 <= 0) goto L_0x01bd
            r15 = -481406373470103244(0xf951b37434b49934, double:-2.4513969447945833E276)
            java.lang.String r7 = defpackage.wx1.a(r15)     // Catch:{ Exception -> 0x020b }
            r10.put(r7, r12)     // Catch:{ Exception -> 0x020b }
        L_0x01bd:
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch:{ Exception -> 0x020b }
            r7.<init>()     // Catch:{ Exception -> 0x020b }
            r11 = -481406399239907020(0xf951b36e34b49934, double:-2.451384265725836E276)
            java.lang.String r11 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x020b }
            r7.put(r11, r9)     // Catch:{ Exception -> 0x020b }
            r11 = -481406446484547276(0xf951b36334b49934, double:-2.451361020766466E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x020b }
            java.lang.String r11 = r2.getString(r3)     // Catch:{ Exception -> 0x020b }
            r7.put(r9, r11)     // Catch:{ Exception -> 0x020b }
            r11 = -481406467959383756(0xf951b35e34b49934, double:-2.4513504548758434E276)
            java.lang.String r9 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x020b }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x020b }
            r7.put(r9, r10)     // Catch:{ Exception -> 0x020b }
            r9 = -481406502319122124(0xf951b35634b49934, double:-2.451333549450847E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x020b }
            long r10 = r2.getLong(r6)     // Catch:{ Exception -> 0x020b }
            java.lang.String r10 = defpackage.ox1.c(r10)     // Catch:{ Exception -> 0x020b }
            r7.put(r9, r10)     // Catch:{ Exception -> 0x020b }
            r1.put(r7)     // Catch:{ Exception -> 0x020b }
            long r4 = r2.getLong(r6)     // Catch:{ Exception -> 0x020b }
            goto L_0x020b
        L_0x020a:
            r14 = 0
        L_0x020b:
            boolean r7 = r2.moveToNext()     // Catch:{ Exception -> 0x021b }
            if (r7 != 0) goto L_0x0212
            goto L_0x0215
        L_0x0212:
            r7 = 0
            goto L_0x00cd
        L_0x0215:
            if (r2 == 0) goto L_0x0226
            r2.close()     // Catch:{ Exception -> 0x021b }
            goto L_0x0226
        L_0x021b:
            r0 = move-exception
            qg1 r2 = defpackage.qg1.a()
            r2.c(r0)
            r0.printStackTrace()
        L_0x0226:
            ix1 r0 = new ix1
            r0.<init>(r1, r4)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.mw1.a(android.content.Context, xt1, boolean):ix1");
    }
}
