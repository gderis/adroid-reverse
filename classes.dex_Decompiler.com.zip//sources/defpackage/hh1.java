package defpackage;

import defpackage.lj1;
import java.util.Comparator;

/* renamed from: hh1  reason: default package */
public final /* synthetic */ class hh1 implements Comparator {
    public static final /* synthetic */ hh1 a = new hh1();

    public final int compare(Object obj, Object obj2) {
        return ((lj1.b) obj).b().compareTo(((lj1.b) obj2).b());
    }
}
