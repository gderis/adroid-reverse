package defpackage;

import java.util.concurrent.Callable;

/* renamed from: k01  reason: default package */
public final /* synthetic */ class k01 implements Callable {
    public final o01 a;

    public k01(o01 o01) {
        this.a = o01;
    }

    public final Object call() {
        return new es0(this.a.a);
    }
}
