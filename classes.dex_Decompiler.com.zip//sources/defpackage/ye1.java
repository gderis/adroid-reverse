package defpackage;

import android.os.Bundle;
import defpackage.vu0;

/* renamed from: ye1  reason: default package */
public final class ye1 implements vu0.a {
    public final /* synthetic */ ze1 a;

    public ye1(ze1 ze1) {
        this.a = ze1;
    }

    public final void a(String str, String str2, Bundle bundle, long j) {
        if (this.a.a.contains(str2)) {
            Bundle bundle2 = new Bundle();
            bundle2.putString("events", xe1.f(str2));
            this.a.f6220a.a(2, bundle2);
        }
    }
}
