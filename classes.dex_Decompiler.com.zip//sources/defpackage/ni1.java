package defpackage;

import android.content.Context;
import java.io.File;

/* renamed from: ni1  reason: default package */
public class ni1 {
    public static final c a = new c();

    /* renamed from: a  reason: collision with other field name */
    public final Context f4148a;

    /* renamed from: a  reason: collision with other field name */
    public mi1 f4149a;

    /* renamed from: a  reason: collision with other field name */
    public final b f4150a;

    /* renamed from: ni1$b */
    public interface b {
        File a();
    }

    /* renamed from: ni1$c */
    public static final class c implements mi1 {
        public c() {
        }

        public void a() {
        }

        public String b() {
            return null;
        }

        public byte[] c() {
            return null;
        }

        public void d(long j, String str) {
        }

        public void e() {
        }
    }

    public ni1(Context context, b bVar) {
        this(context, bVar, (String) null);
    }

    public ni1(Context context, b bVar, String str) {
        this.f4148a = context;
        this.f4150a = bVar;
        this.f4149a = a;
        e(str);
    }

    public void a() {
        this.f4149a.e();
    }

    public byte[] b() {
        return this.f4149a.c();
    }

    public String c() {
        return this.f4149a.b();
    }

    public final File d(String str) {
        return new File(this.f4150a.a(), "crashlytics-userlog-" + str + ".temp");
    }

    public final void e(String str) {
        this.f4149a.a();
        this.f4149a = a;
        if (str != null) {
            if (!ph1.k(this.f4148a, "com.crashlytics.CollectCustomLogs", true)) {
                sg1.f().b("Preferences requested no custom logs. Aborting log file creation.");
            } else {
                f(d(str), 65536);
            }
        }
    }

    public void f(File file, int i) {
        this.f4149a = new pi1(file, i);
    }

    public void g(long j, String str) {
        this.f4149a.d(j, str);
    }
}
