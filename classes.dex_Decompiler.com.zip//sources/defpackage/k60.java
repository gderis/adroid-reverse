package defpackage;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* renamed from: k60  reason: default package */
public class k60 implements IInterface {
    public final IBinder a;

    /* renamed from: a  reason: collision with other field name */
    public final String f3440a;

    public k60(IBinder iBinder, String str) {
        this.a = iBinder;
        this.f3440a = str;
    }

    public IBinder asBinder() {
        return this.a;
    }

    public final Parcel b() {
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.f3440a);
        return obtain;
    }

    public final Parcel c(int i, Parcel parcel) {
        parcel = Parcel.obtain();
        try {
            this.a.transact(i, parcel, parcel, 0);
            parcel.readException();
            return parcel;
        } catch (RuntimeException e) {
            throw e;
        } finally {
            parcel.recycle();
        }
    }
}
