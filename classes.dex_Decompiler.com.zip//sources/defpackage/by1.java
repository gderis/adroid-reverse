package defpackage;

import android.location.Location;

/* renamed from: by1  reason: default package */
public interface by1 {
    void a(Location location);
}
