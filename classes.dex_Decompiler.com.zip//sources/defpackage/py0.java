package defpackage;

/* renamed from: py0  reason: default package */
public final /* synthetic */ class py0 implements xy0 {
    public static final xy0 a = new py0();

    public final Object a() {
        zy0<Long> zy0 = bz0.f1148a;
        return Boolean.valueOf(jp0.c());
    }
}
