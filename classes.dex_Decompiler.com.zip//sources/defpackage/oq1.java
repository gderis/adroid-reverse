package defpackage;

/* renamed from: oq1  reason: default package */
public final class oq1 extends qq1 {
    public oq1(rq1 rq1) {
        a(new su1(rq1, this), rq1);
        a(new vu1(rq1, this), rq1);
        a(new wu1(rq1, this), rq1);
        a(new yu1(rq1, this), rq1);
        a(new bv1(rq1, this), rq1);
        a(new cv1(rq1, this), rq1);
        a(new ev1(rq1, this), rq1);
        a(new gv1(rq1, this), rq1);
        a(new iv1(rq1, this), rq1);
        a(new kv1(rq1, this), rq1);
        a(new mv1(rq1, this), rq1);
        a(new ov1(this), rq1);
        a(new qv1(rq1, this), rq1);
        a(new sv1(rq1, this), rq1);
        a(new uv1(rq1, this), rq1);
        a(new wv1(rq1, this), rq1);
        a(new yv1(rq1, this), rq1);
        a(new aw1(rq1, this), rq1);
        a(new cw1(rq1, this), rq1);
    }

    public final boolean c() {
        return false;
    }

    public final boolean d() {
        return false;
    }

    public final Class<?> g() {
        return wt1.class;
    }

    public final String j() {
        return "zgoicsifmc";
    }

    public final int k() {
        return 1;
    }

    public final boolean v() {
        return false;
    }
}
