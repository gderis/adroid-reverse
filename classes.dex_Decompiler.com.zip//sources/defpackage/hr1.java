package defpackage;

import android.database.ContentObserver;
import com.raizlabs.android.dbflow.config.FlowManager;
import defpackage.ts1;

/* renamed from: hr1  reason: default package */
public class hr1 implements kr1 {
    public final String a;

    public hr1(String str) {
        this.a = str;
    }

    public <T> void a(T t, ys1<T> ys1, ts1.a aVar) {
        if (jr1.a()) {
            FlowManager.c().getContentResolver().notifyChange(pr1.b(this.a, ys1.h(), aVar, ys1.j(t).w()), (ContentObserver) null, true);
        }
    }

    public <T> void b(Class<T> cls, ts1.a aVar) {
        if (jr1.a()) {
            FlowManager.c().getContentResolver().notifyChange(pr1.c(this.a, cls, aVar, (es1[]) null), (ContentObserver) null, true);
        }
    }
}
