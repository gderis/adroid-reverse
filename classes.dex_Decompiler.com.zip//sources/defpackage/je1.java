package defpackage;

@Deprecated
/* renamed from: je1  reason: default package */
public class je1 extends wa1 {
}
