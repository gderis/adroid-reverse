package defpackage;

/* renamed from: it1  reason: default package */
public interface it1 {
    long a();

    long b();

    void c(int i, String str);

    void close();

    String d();

    void e(int i, long j);

    void f(int i, String str);

    long g();

    void h(int i);
}
