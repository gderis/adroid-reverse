package defpackage;

/* renamed from: nv1  reason: default package */
public class nv1 extends ts1 {
    public long a;

    /* renamed from: a  reason: collision with other field name */
    public String f4204a;
}
