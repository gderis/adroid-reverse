package defpackage;

import com.google.auto.value.AutoValue;
import defpackage.bn1;
import defpackage.dn1;

@AutoValue
/* renamed from: en1  reason: default package */
public abstract class en1 {
    public static en1 a = a().a();

    @AutoValue.Builder
    /* renamed from: en1$a */
    public static abstract class a {
        public abstract en1 a();

        public abstract a b(String str);

        public abstract a c(long j);

        public abstract a d(String str);

        public abstract a e(String str);

        public abstract a f(String str);

        public abstract a g(dn1.a aVar);

        public abstract a h(long j);
    }

    public static a a() {
        return new bn1.b().h(0).g(dn1.a.ATTEMPT_MIGRATION).c(0);
    }

    public abstract String b();

    public abstract long c();

    public abstract String d();

    public abstract String e();

    public abstract String f();

    public abstract dn1.a g();

    public abstract long h();

    public boolean i() {
        return g() == dn1.a.REGISTER_ERROR;
    }

    public boolean j() {
        return g() == dn1.a.NOT_GENERATED || g() == dn1.a.ATTEMPT_MIGRATION;
    }

    public boolean k() {
        return g() == dn1.a.REGISTERED;
    }

    public boolean l() {
        return g() == dn1.a.UNREGISTERED;
    }

    public boolean m() {
        return g() == dn1.a.ATTEMPT_MIGRATION;
    }

    public abstract a n();

    public en1 o(String str, long j, long j2) {
        return n().b(str).c(j).h(j2).a();
    }

    public en1 p() {
        return n().b((String) null).a();
    }

    public en1 q(String str) {
        return n().e(str).g(dn1.a.REGISTER_ERROR).a();
    }

    public en1 r() {
        return n().g(dn1.a.NOT_GENERATED).a();
    }

    public en1 s(String str, String str2, long j, String str3, long j2) {
        return n().d(str).g(dn1.a.REGISTERED).b(str3).f(str2).c(j2).h(j).a();
    }

    public en1 t(String str) {
        return n().d(str).g(dn1.a.UNREGISTERED).a();
    }
}
