package defpackage;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;

/* renamed from: ge1  reason: default package */
public class ge1 extends ConstraintLayout {
    public hd1 a;

    /* renamed from: a  reason: collision with other field name */
    public final Runnable f2617a;
    public int o;

    /* renamed from: ge1$a */
    public class a implements Runnable {
        public a() {
        }

        public void run() {
            ge1.this.y();
        }
    }

    public ge1(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ge1(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        LayoutInflater.from(context).inflate(u91.material_radial_view_group, this);
        ya.r0(this, u());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x91.RadialViewGroup, i, 0);
        this.o = obtainStyledAttributes.getDimensionPixelSize(x91.RadialViewGroup_materialCircleRadius, 0);
        this.f2617a = new a();
        obtainStyledAttributes.recycle();
    }

    public static boolean x(View view) {
        return "skip".equals(view.getTag());
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (view.getId() == -1) {
            view.setId(ya.k());
        }
        z();
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        y();
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        z();
    }

    public void setBackgroundColor(int i) {
        this.a.W(ColorStateList.valueOf(i));
    }

    public final Drawable u() {
        hd1 hd1 = new hd1();
        this.a = hd1;
        hd1.U(new jd1(0.5f));
        this.a.W(ColorStateList.valueOf(-1));
        return this.a;
    }

    public int v() {
        return this.o;
    }

    public void w(int i) {
        this.o = i;
        y();
    }

    public void y() {
        int childCount = getChildCount();
        int i = 1;
        for (int i2 = 0; i2 < childCount; i2++) {
            if (x(getChildAt(i2))) {
                i++;
            }
        }
        n6 n6Var = new n6();
        n6Var.g(this);
        float f = 0.0f;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            int id = childAt.getId();
            int i4 = s91.circle_center;
            if (id != i4 && !x(childAt)) {
                n6Var.i(childAt.getId(), i4, this.o, f);
                f += 360.0f / ((float) (childCount - i));
            }
        }
        n6Var.c(this);
    }

    public final void z() {
        Handler handler = getHandler();
        if (handler != null) {
            handler.removeCallbacks(this.f2617a);
            handler.post(this.f2617a);
        }
    }
}
