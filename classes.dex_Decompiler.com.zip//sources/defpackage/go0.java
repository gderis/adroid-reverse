package defpackage;

/* renamed from: go0  reason: default package */
public final class go0 implements fo0 {
    public static final ui0<Boolean> a = new si0(li0.a("com.google.android.gms.measurement")).b("measurement.sdk.collection.validate_param_names_alphabetical", true);

    public final boolean a() {
        return a.e().booleanValue();
    }
}
