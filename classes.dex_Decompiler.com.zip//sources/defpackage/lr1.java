package defpackage;

import com.raizlabs.android.dbflow.config.FlowManager;
import defpackage.ts1;

/* renamed from: lr1  reason: default package */
public class lr1 implements kr1 {
    public static lr1 a;

    public static lr1 c() {
        if (a == null) {
            a = new lr1();
        }
        return a;
    }

    public <TModel> void a(TModel tmodel, ys1<TModel> ys1, ts1.a aVar) {
        FlowManager.h(ys1.h()).a(tmodel, ys1, aVar);
    }

    public <TModel> void b(Class<TModel> cls, ts1.a aVar) {
        FlowManager.h(cls).b(cls, aVar);
    }
}
