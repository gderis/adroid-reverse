package defpackage;

import defpackage.xf1;

/* renamed from: jf1  reason: default package */
public final /* synthetic */ class jf1 implements km1 {
    public final /* synthetic */ wf1 a;

    public /* synthetic */ jf1(wf1 wf1) {
        this.a = wf1;
    }

    public final Object get() {
        wf1 wf1 = this.a;
        xf1.b.e(wf1);
        return wf1;
    }
}
