package defpackage;

import defpackage.c81;

/* renamed from: d81  reason: default package */
public final class d81 implements c81.a {
}
