package defpackage;

import defpackage.lj1;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPOutputStream;

/* renamed from: bi1  reason: default package */
public class bi1 implements gi1 {
    public final File a;

    /* renamed from: a  reason: collision with other field name */
    public final String f1097a;
    public final String b;

    public bi1(String str, String str2, File file) {
        this.f1097a = str;
        this.b = str2;
        this.a = file;
    }

    public lj1.c.b a() {
        byte[] d = d();
        if (d != null) {
            return lj1.c.b.a().b(d).c(this.f1097a).a();
        }
        return null;
    }

    public String b() {
        return this.b;
    }

    public InputStream c() {
        if (this.a.exists() && this.a.isFile()) {
            try {
                return new FileInputStream(this.a);
            } catch (FileNotFoundException unused) {
            }
        }
        return null;
    }

    public final byte[] d() {
        GZIPOutputStream gZIPOutputStream;
        byte[] bArr = new byte[8192];
        try {
            InputStream c = c();
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
                    if (c == null) {
                        gZIPOutputStream.close();
                        byteArrayOutputStream.close();
                        if (c != null) {
                            c.close();
                        }
                        return null;
                    }
                    while (true) {
                        int read = c.read(bArr);
                        if (read > 0) {
                            gZIPOutputStream.write(bArr, 0, read);
                        } else {
                            gZIPOutputStream.finish();
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            gZIPOutputStream.close();
                            byteArrayOutputStream.close();
                            c.close();
                            return byteArray;
                        }
                    }
                } catch (Throwable th) {
                    byteArrayOutputStream.close();
                    throw th;
                }
                throw th;
            } catch (Throwable th2) {
                if (c != null) {
                    c.close();
                }
                throw th2;
            }
        } catch (IOException unused) {
            return null;
        } catch (Throwable th3) {
            th2.addSuppressed(th3);
        }
    }
}
