package defpackage;

import com.google.android.gms.measurement.internal.AppMeasurementDynamiteService;

/* renamed from: d31  reason: default package */
public final class d31 implements Runnable {
    public final /* synthetic */ AppMeasurementDynamiteService a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ String f1911a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ od0 f1912a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ pv0 f1913a;

    public d31(AppMeasurementDynamiteService appMeasurementDynamiteService, od0 od0, pv0 pv0, String str) {
        this.a = appMeasurementDynamiteService;
        this.f1912a = od0;
        this.f1913a = pv0;
        this.f1911a = str;
    }

    public final void run() {
        this.a.f1353a.R().u(this.f1912a, this.f1913a, this.f1911a);
    }
}
