package defpackage;

import android.app.Activity;

/* renamed from: af0  reason: default package */
public final class af0 extends re0 {
    public final /* synthetic */ Activity a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ bf0 f220a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public af0(bf0 bf0, Activity activity) {
        super(bf0.a, true);
        this.f220a = bf0;
        this.a = activity;
    }

    public final void a() {
        ((ld0) s10.j(this.f220a.a.f1265a)).onActivityDestroyed(v50.e(this.a), this.b);
    }
}
