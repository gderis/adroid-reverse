package defpackage;

/* renamed from: kq0  reason: default package */
public final class kq0 implements jq0 {
    public static final ui0<Long> a;
    public static final ui0<Boolean> b;
    public static final ui0<Boolean> c;
    public static final ui0<Boolean> d;
    public static final ui0<Long> e;

    static {
        si0 si0 = new si0(li0.a("com.google.android.gms.measurement"));
        a = si0.a("measurement.id.lifecycle.app_in_background_parameter", 0);
        b = si0.b("measurement.lifecycle.app_backgrounded_engagement", false);
        c = si0.b("measurement.lifecycle.app_backgrounded_tracking", true);
        d = si0.b("measurement.lifecycle.app_in_background_parameter", false);
        e = si0.a("measurement.id.lifecycle.app_backgrounded_tracking", 0);
    }

    public final boolean a() {
        return b.e().booleanValue();
    }

    public final boolean b() {
        return d.e().booleanValue();
    }
}
