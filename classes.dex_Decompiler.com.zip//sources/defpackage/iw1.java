package defpackage;

import com.zgoicsifmc.tasks._SyncWorker;
import defpackage.zn;
import org.json.JSONObject;

/* renamed from: iw1  reason: default package */
public final /* synthetic */ class iw1 implements zn.b {
    public final /* synthetic */ JSONObject a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ xt1 f3162a;

    public /* synthetic */ iw1(JSONObject jSONObject, xt1 xt1) {
        this.a = jSONObject;
        this.f3162a = xt1;
    }

    public final void a(Object obj) {
        _SyncWorker.p(this.a, this.f3162a, (JSONObject) obj);
    }
}
