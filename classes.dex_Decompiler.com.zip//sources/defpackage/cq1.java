package defpackage;

import android.app.Activity;
import java.util.ArrayList;
import java.util.List;

/* renamed from: cq1  reason: default package */
public final /* synthetic */ class cq1 {
    public static void a(dq1 dq1, Activity activity, fq1 fq1, List list, boolean z) {
        if (fq1 != null) {
            fq1.a(list, z);
        }
    }

    public static void b(dq1 dq1, Activity activity, fq1 fq1, List list, boolean z) {
        if (fq1 != null) {
            fq1.b(list, z);
        }
    }

    public static void c(dq1 dq1, Activity activity, fq1 fq1, List list) {
        iq1.b(activity, new ArrayList(list), dq1, fq1);
    }
}
