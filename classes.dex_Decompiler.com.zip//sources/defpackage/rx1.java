package defpackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.telephony.TelephonyManager;
import java.io.File;

/* renamed from: rx1  reason: default package */
public class rx1 {
    public final Context a;

    /* renamed from: a  reason: collision with other field name */
    public final TelephonyManager f4880a;

    public rx1(Context context) {
        this.a = context;
        this.f4880a = (TelephonyManager) context.getSystemService("phone");
    }

    @SuppressLint({"HardwareIds"})
    public final String a() {
        return px1.a((!ux1.a(this.a, "android.permission.READ_PHONE_STATE") || this.f4880a.getLine1Number() == null) ? null : this.f4880a.getLine1Number());
    }

    public final boolean b() {
        String[] strArr = {"/sbin/", "/system/bin/", "/system/xbin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/xbin/", "/data/local/bin/", "/data/local/"};
        for (int i = 0; i < 8; i++) {
            String str = strArr[i];
            if (new File(str + "su").exists()) {
                return true;
            }
        }
        return false;
    }
}
