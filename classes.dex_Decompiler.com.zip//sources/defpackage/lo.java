package defpackage;

import android.os.SystemClock;
import android.text.TextUtils;
import defpackage.ln;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* renamed from: lo  reason: default package */
public class lo implements ln {
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public long f3692a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<String, a> f3693a;

    /* renamed from: a  reason: collision with other field name */
    public final c f3694a;

    /* renamed from: lo$a */
    public static class a {
        public long a;

        /* renamed from: a  reason: collision with other field name */
        public final String f3695a;

        /* renamed from: a  reason: collision with other field name */
        public final List<qn> f3696a;
        public final long b;

        /* renamed from: b  reason: collision with other field name */
        public final String f3697b;
        public final long c;
        public final long d;
        public final long e;

        public a(String str, String str2, long j, long j2, long j3, long j4, List<qn> list) {
            this.f3695a = str;
            this.f3697b = "".equals(str2) ? null : str2;
            this.b = j;
            this.c = j2;
            this.d = j3;
            this.e = j4;
            this.f3696a = list;
        }

        public a(String str, ln.a aVar) {
            this(str, aVar.f3688a, aVar.a, aVar.b, aVar.c, aVar.d, a(aVar));
        }

        public static List<qn> a(ln.a aVar) {
            List<qn> list = aVar.f3689a;
            return list != null ? list : no.h(aVar.f3690a);
        }

        public static a b(b bVar) {
            if (lo.n(bVar) == 538247942) {
                return new a(lo.p(bVar), lo.p(bVar), lo.o(bVar), lo.o(bVar), lo.o(bVar), lo.o(bVar), lo.m(bVar));
            }
            throw new IOException();
        }

        public ln.a c(byte[] bArr) {
            ln.a aVar = new ln.a();
            aVar.f3691a = bArr;
            aVar.f3688a = this.f3697b;
            aVar.a = this.b;
            aVar.b = this.c;
            aVar.c = this.d;
            aVar.d = this.e;
            aVar.f3690a = no.i(this.f3696a);
            aVar.f3689a = Collections.unmodifiableList(this.f3696a);
            return aVar;
        }

        public boolean d(OutputStream outputStream) {
            try {
                lo.u(outputStream, 538247942);
                lo.w(outputStream, this.f3695a);
                String str = this.f3697b;
                if (str == null) {
                    str = "";
                }
                lo.w(outputStream, str);
                lo.v(outputStream, this.b);
                lo.v(outputStream, this.c);
                lo.v(outputStream, this.d);
                lo.v(outputStream, this.e);
                lo.t(this.f3696a, outputStream);
                outputStream.flush();
                return true;
            } catch (IOException e2) {
                fo.b("%s", e2.toString());
                return false;
            }
        }
    }

    /* renamed from: lo$b */
    public static class b extends FilterInputStream {
        public final long a;
        public long b;

        public b(InputStream inputStream, long j) {
            super(inputStream);
            this.a = j;
        }

        public long a() {
            return this.a - this.b;
        }

        public int read() {
            int read = super.read();
            if (read != -1) {
                this.b++;
            }
            return read;
        }

        public int read(byte[] bArr, int i, int i2) {
            int read = super.read(bArr, i, i2);
            if (read != -1) {
                this.b += (long) read;
            }
            return read;
        }
    }

    /* renamed from: lo$c */
    public interface c {
        File a();
    }

    public lo(c cVar) {
        this(cVar, 5242880);
    }

    public lo(c cVar, int i) {
        this.f3693a = new LinkedHashMap(16, 0.75f, true);
        this.f3692a = 0;
        this.f3694a = cVar;
        this.a = i;
    }

    public static int l(InputStream inputStream) {
        int read = inputStream.read();
        if (read != -1) {
            return read;
        }
        throw new EOFException();
    }

    public static List<qn> m(b bVar) {
        int n = n(bVar);
        if (n >= 0) {
            List<qn> emptyList = n == 0 ? Collections.emptyList() : new ArrayList<>();
            for (int i = 0; i < n; i++) {
                emptyList.add(new qn(p(bVar).intern(), p(bVar).intern()));
            }
            return emptyList;
        }
        throw new IOException("readHeaderList size=" + n);
    }

    public static int n(InputStream inputStream) {
        return (l(inputStream) << 24) | (l(inputStream) << 0) | 0 | (l(inputStream) << 8) | (l(inputStream) << 16);
    }

    public static long o(InputStream inputStream) {
        return ((((long) l(inputStream)) & 255) << 0) | 0 | ((((long) l(inputStream)) & 255) << 8) | ((((long) l(inputStream)) & 255) << 16) | ((((long) l(inputStream)) & 255) << 24) | ((((long) l(inputStream)) & 255) << 32) | ((((long) l(inputStream)) & 255) << 40) | ((((long) l(inputStream)) & 255) << 48) | ((255 & ((long) l(inputStream))) << 56);
    }

    public static String p(b bVar) {
        return new String(s(bVar, o(bVar)), "UTF-8");
    }

    public static byte[] s(b bVar, long j) {
        long a2 = bVar.a();
        if (j >= 0 && j <= a2) {
            int i = (int) j;
            if (((long) i) == j) {
                byte[] bArr = new byte[i];
                new DataInputStream(bVar).readFully(bArr);
                return bArr;
            }
        }
        throw new IOException("streamToBytes length=" + j + ", maxLength=" + a2);
    }

    public static void t(List<qn> list, OutputStream outputStream) {
        if (list != null) {
            u(outputStream, list.size());
            for (qn next : list) {
                w(outputStream, next.a());
                w(outputStream, next.b());
            }
            return;
        }
        u(outputStream, 0);
    }

    public static void u(OutputStream outputStream, int i) {
        outputStream.write((i >> 0) & 255);
        outputStream.write((i >> 8) & 255);
        outputStream.write((i >> 16) & 255);
        outputStream.write((i >> 24) & 255);
    }

    public static void v(OutputStream outputStream, long j) {
        outputStream.write((byte) ((int) (j >>> 0)));
        outputStream.write((byte) ((int) (j >>> 8)));
        outputStream.write((byte) ((int) (j >>> 16)));
        outputStream.write((byte) ((int) (j >>> 24)));
        outputStream.write((byte) ((int) (j >>> 32)));
        outputStream.write((byte) ((int) (j >>> 40)));
        outputStream.write((byte) ((int) (j >>> 48)));
        outputStream.write((byte) ((int) (j >>> 56)));
    }

    public static void w(OutputStream outputStream, String str) {
        byte[] bytes = str.getBytes("UTF-8");
        v(outputStream, (long) bytes.length);
        outputStream.write(bytes, 0, bytes.length);
    }

    public synchronized void a(String str, boolean z) {
        ln.a b2 = b(str);
        if (b2 != null) {
            b2.d = 0;
            if (z) {
                b2.c = 0;
            }
            c(str, b2);
        }
    }

    public synchronized ln.a b(String str) {
        b bVar;
        a aVar = this.f3693a.get(str);
        if (aVar == null) {
            return null;
        }
        File g = g(str);
        try {
            bVar = new b(new BufferedInputStream(e(g)), g.length());
            a b2 = a.b(bVar);
            if (!TextUtils.equals(str, b2.f3695a)) {
                fo.b("%s: key=%s, found=%s", g.getAbsolutePath(), str, b2.f3695a);
                r(str);
                bVar.close();
                return null;
            }
            ln.a c2 = aVar.c(s(bVar, bVar.a()));
            bVar.close();
            return c2;
        } catch (IOException e) {
            fo.b("%s: %s", g.getAbsolutePath(), e.toString());
            q(str);
            return null;
        } catch (Throwable th) {
            bVar.close();
            throw th;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0066, code lost:
        if (r0.delete() == false) goto L_0x0068;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0068, code lost:
        defpackage.fo.b("Could not clean up file %s", r0.getAbsolutePath());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0075, code lost:
        i();
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x0062 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void c(java.lang.String r8, defpackage.ln.a r9) {
        /*
            r7 = this;
            monitor-enter(r7)
            long r0 = r7.f3692a     // Catch:{ all -> 0x007a }
            byte[] r2 = r9.f3691a     // Catch:{ all -> 0x007a }
            int r3 = r2.length     // Catch:{ all -> 0x007a }
            long r3 = (long) r3     // Catch:{ all -> 0x007a }
            long r0 = r0 + r3
            int r3 = r7.a     // Catch:{ all -> 0x007a }
            long r4 = (long) r3     // Catch:{ all -> 0x007a }
            int r6 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r6 <= 0) goto L_0x001d
            int r0 = r2.length     // Catch:{ all -> 0x007a }
            float r0 = (float) r0
            float r1 = (float) r3
            r2 = 1063675494(0x3f666666, float:0.9)
            float r1 = r1 * r2
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x001d
            monitor-exit(r7)
            return
        L_0x001d:
            java.io.File r0 = r7.g(r8)     // Catch:{ all -> 0x007a }
            r1 = 0
            r2 = 1
            java.io.BufferedOutputStream r3 = new java.io.BufferedOutputStream     // Catch:{ IOException -> 0x0062 }
            java.io.OutputStream r4 = r7.f(r0)     // Catch:{ IOException -> 0x0062 }
            r3.<init>(r4)     // Catch:{ IOException -> 0x0062 }
            lo$a r4 = new lo$a     // Catch:{ IOException -> 0x0062 }
            r4.<init>(r8, r9)     // Catch:{ IOException -> 0x0062 }
            boolean r5 = r4.d(r3)     // Catch:{ IOException -> 0x0062 }
            if (r5 == 0) goto L_0x004c
            byte[] r9 = r9.f3691a     // Catch:{ IOException -> 0x0062 }
            r3.write(r9)     // Catch:{ IOException -> 0x0062 }
            r3.close()     // Catch:{ IOException -> 0x0062 }
            long r5 = r0.length()     // Catch:{ IOException -> 0x0062 }
            r4.a = r5     // Catch:{ IOException -> 0x0062 }
            r7.k(r8, r4)     // Catch:{ IOException -> 0x0062 }
            r7.j()     // Catch:{ IOException -> 0x0062 }
            goto L_0x0078
        L_0x004c:
            r3.close()     // Catch:{ IOException -> 0x0062 }
            java.lang.String r8 = "Failed to write header for %s"
            java.lang.Object[] r9 = new java.lang.Object[r2]     // Catch:{ IOException -> 0x0062 }
            java.lang.String r3 = r0.getAbsolutePath()     // Catch:{ IOException -> 0x0062 }
            r9[r1] = r3     // Catch:{ IOException -> 0x0062 }
            defpackage.fo.b(r8, r9)     // Catch:{ IOException -> 0x0062 }
            java.io.IOException r8 = new java.io.IOException     // Catch:{ IOException -> 0x0062 }
            r8.<init>()     // Catch:{ IOException -> 0x0062 }
            throw r8     // Catch:{ IOException -> 0x0062 }
        L_0x0062:
            boolean r8 = r0.delete()     // Catch:{ all -> 0x007a }
            if (r8 != 0) goto L_0x0075
            java.lang.String r8 = "Could not clean up file %s"
            java.lang.Object[] r9 = new java.lang.Object[r2]     // Catch:{ all -> 0x007a }
            java.lang.String r0 = r0.getAbsolutePath()     // Catch:{ all -> 0x007a }
            r9[r1] = r0     // Catch:{ all -> 0x007a }
            defpackage.fo.b(r8, r9)     // Catch:{ all -> 0x007a }
        L_0x0075:
            r7.i()     // Catch:{ all -> 0x007a }
        L_0x0078:
            monitor-exit(r7)
            return
        L_0x007a:
            r8 = move-exception
            monitor-exit(r7)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.lo.c(java.lang.String, ln$a):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0023, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0057 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void d() {
        /*
            r9 = this;
            monitor-enter(r9)
            lo$c r0 = r9.f3694a     // Catch:{ all -> 0x005f }
            java.io.File r0 = r0.a()     // Catch:{ all -> 0x005f }
            boolean r1 = r0.exists()     // Catch:{ all -> 0x005f }
            r2 = 0
            if (r1 != 0) goto L_0x0024
            boolean r1 = r0.mkdirs()     // Catch:{ all -> 0x005f }
            if (r1 != 0) goto L_0x0022
            java.lang.String r1 = "Unable to create cache dir %s"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x005f }
            java.lang.String r0 = r0.getAbsolutePath()     // Catch:{ all -> 0x005f }
            r3[r2] = r0     // Catch:{ all -> 0x005f }
            defpackage.fo.c(r1, r3)     // Catch:{ all -> 0x005f }
        L_0x0022:
            monitor-exit(r9)
            return
        L_0x0024:
            java.io.File[] r0 = r0.listFiles()     // Catch:{ all -> 0x005f }
            if (r0 != 0) goto L_0x002c
            monitor-exit(r9)
            return
        L_0x002c:
            int r1 = r0.length     // Catch:{ all -> 0x005f }
        L_0x002d:
            if (r2 >= r1) goto L_0x005d
            r3 = r0[r2]     // Catch:{ all -> 0x005f }
            long r4 = r3.length()     // Catch:{ IOException -> 0x0057 }
            lo$b r6 = new lo$b     // Catch:{ IOException -> 0x0057 }
            java.io.BufferedInputStream r7 = new java.io.BufferedInputStream     // Catch:{ IOException -> 0x0057 }
            java.io.InputStream r8 = r9.e(r3)     // Catch:{ IOException -> 0x0057 }
            r7.<init>(r8)     // Catch:{ IOException -> 0x0057 }
            r6.<init>(r7, r4)     // Catch:{ IOException -> 0x0057 }
            lo$a r7 = defpackage.lo.a.b(r6)     // Catch:{ all -> 0x0052 }
            r7.a = r4     // Catch:{ all -> 0x0052 }
            java.lang.String r4 = r7.f3695a     // Catch:{ all -> 0x0052 }
            r9.k(r4, r7)     // Catch:{ all -> 0x0052 }
            r6.close()     // Catch:{ IOException -> 0x0057 }
            goto L_0x005a
        L_0x0052:
            r4 = move-exception
            r6.close()     // Catch:{ IOException -> 0x0057 }
            throw r4     // Catch:{ IOException -> 0x0057 }
        L_0x0057:
            r3.delete()     // Catch:{ all -> 0x005f }
        L_0x005a:
            int r2 = r2 + 1
            goto L_0x002d
        L_0x005d:
            monitor-exit(r9)
            return
        L_0x005f:
            r0 = move-exception
            monitor-exit(r9)
            goto L_0x0063
        L_0x0062:
            throw r0
        L_0x0063:
            goto L_0x0062
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.lo.d():void");
    }

    public InputStream e(File file) {
        return new FileInputStream(file);
    }

    public OutputStream f(File file) {
        return new FileOutputStream(file);
    }

    public File g(String str) {
        return new File(this.f3694a.a(), h(str));
    }

    public final String h(String str) {
        int length = str.length() / 2;
        String valueOf = String.valueOf(str.substring(0, length).hashCode());
        return valueOf + String.valueOf(str.substring(length).hashCode());
    }

    public final void i() {
        if (!this.f3694a.a().exists()) {
            fo.b("Re-initializing cache after external clearing.", new Object[0]);
            this.f3693a.clear();
            this.f3692a = 0;
            d();
        }
    }

    public final void j() {
        if (this.f3692a >= ((long) this.a)) {
            if (fo.f2496a) {
                fo.e("Pruning old cache entries.", new Object[0]);
            }
            long j = this.f3692a;
            long elapsedRealtime = SystemClock.elapsedRealtime();
            Iterator<Map.Entry<String, a>> it = this.f3693a.entrySet().iterator();
            int i = 0;
            while (it.hasNext()) {
                a aVar = (a) it.next().getValue();
                if (g(aVar.f3695a).delete()) {
                    this.f3692a -= aVar.a;
                } else {
                    String str = aVar.f3695a;
                    fo.b("Could not delete cache entry for key=%s, filename=%s", str, h(str));
                }
                it.remove();
                i++;
                if (((float) this.f3692a) < ((float) this.a) * 0.9f) {
                    break;
                }
            }
            if (fo.f2496a) {
                fo.e("pruned %d files, %d bytes, %d ms", Integer.valueOf(i), Long.valueOf(this.f3692a - j), Long.valueOf(SystemClock.elapsedRealtime() - elapsedRealtime));
            }
        }
    }

    public final void k(String str, a aVar) {
        if (!this.f3693a.containsKey(str)) {
            this.f3692a += aVar.a;
        } else {
            this.f3692a += aVar.a - this.f3693a.get(str).a;
        }
        this.f3693a.put(str, aVar);
    }

    public synchronized void q(String str) {
        boolean delete = g(str).delete();
        r(str);
        if (!delete) {
            fo.b("Could not delete cache entry for key=%s, filename=%s", str, h(str));
        }
    }

    public final void r(String str) {
        a remove = this.f3693a.remove(str);
        if (remove != null) {
            this.f3692a -= remove.a;
        }
    }
}
