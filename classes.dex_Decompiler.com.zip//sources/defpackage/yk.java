package defpackage;

/* renamed from: yk  reason: default package */
public interface yk<T> {
    void a(T t);
}
