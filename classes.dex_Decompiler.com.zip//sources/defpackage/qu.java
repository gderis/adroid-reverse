package defpackage;

/* renamed from: qu  reason: default package */
public final class qu {
    public static final int common_google_play_services_enable_button = 2131623979;
    public static final int common_google_play_services_enable_text = 2131623980;
    public static final int common_google_play_services_enable_title = 2131623981;
    public static final int common_google_play_services_install_button = 2131623982;
    public static final int common_google_play_services_install_text = 2131623983;
    public static final int common_google_play_services_install_title = 2131623984;
    public static final int common_google_play_services_notification_channel_name = 2131623985;
    public static final int common_google_play_services_notification_ticker = 2131623986;
    public static final int common_google_play_services_unsupported_text = 2131623988;
    public static final int common_google_play_services_update_button = 2131623989;
    public static final int common_google_play_services_update_text = 2131623990;
    public static final int common_google_play_services_update_title = 2131623991;
    public static final int common_google_play_services_updating_text = 2131623992;
    public static final int common_google_play_services_wear_update_text = 2131623993;
    public static final int common_open_on_phone = 2131623994;
    public static final int common_signin_button_text = 2131623995;
    public static final int common_signin_button_text_long = 2131623996;
}
