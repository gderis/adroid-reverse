package defpackage;

/* renamed from: dj  reason: default package */
public interface dj {
}
