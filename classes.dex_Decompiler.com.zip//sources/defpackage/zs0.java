package defpackage;

import android.os.Handler;
import android.os.Looper;

/* renamed from: zs0  reason: default package */
public final class zs0 extends Handler {
    public zs0(Looper looper) {
        super(looper);
    }
}
