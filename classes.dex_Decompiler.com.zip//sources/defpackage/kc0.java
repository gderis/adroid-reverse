package defpackage;

import java.util.List;

/* renamed from: kc0  reason: default package */
public final class kc0 extends dc0 {
    public kc0() {
        this.a.add(tc0.AND);
        this.a.add(tc0.NOT);
        this.a.add(tc0.OR);
    }

    public final wb0 a(String str, zg0 zg0, List<wb0> list) {
        tc0 tc0 = tc0.ADD;
        int ordinal = ai0.e(str).ordinal();
        if (ordinal == 1) {
            ai0.a(tc0.AND.name(), 2, list);
            wb0 a = zg0.a(list.get(0));
            if (!a.h().booleanValue()) {
                return a;
            }
        } else if (ordinal == 47) {
            ai0.a(tc0.NOT.name(), 1, list);
            return new mb0(Boolean.valueOf(!zg0.a(list.get(0)).h().booleanValue()));
        } else if (ordinal != 50) {
            return super.b(str);
        } else {
            ai0.a(tc0.OR.name(), 2, list);
            wb0 a2 = zg0.a(list.get(0));
            if (a2.h().booleanValue()) {
                return a2;
            }
        }
        return zg0.a(list.get(1));
    }
}
