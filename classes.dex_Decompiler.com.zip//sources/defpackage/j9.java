package defpackage;

import android.os.Handler;
import android.os.Looper;

/* renamed from: j9  reason: default package */
public class j9 {
    public static Handler a() {
        return Looper.myLooper() == null ? new Handler(Looper.getMainLooper()) : new Handler();
    }
}
