package defpackage;

import java.util.Iterator;

/* renamed from: pn0  reason: default package */
public final class pn0 implements Iterator<String> {
    public final Iterator<String> a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ qn0 f4516a;

    public pn0(qn0 qn0) {
        this.f4516a = qn0;
        this.a = qn0.a.iterator();
    }

    public final boolean hasNext() {
        return this.a.hasNext();
    }

    public final /* bridge */ /* synthetic */ Object next() {
        return this.a.next();
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
