package defpackage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
/* renamed from: k  reason: default package */
public final class k implements Parcelable {
    public static final Parcelable.Creator<k> CREATOR = new a();
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final Intent f3324a;

    /* renamed from: a  reason: collision with other field name */
    public final IntentSender f3325a;
    public final int b;

    /* renamed from: k$a */
    public class a implements Parcelable.Creator<k> {
        /* renamed from: a */
        public k createFromParcel(Parcel parcel) {
            return new k(parcel);
        }

        /* renamed from: b */
        public k[] newArray(int i) {
            return new k[i];
        }
    }

    /* renamed from: k$b */
    public static final class b {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public Intent f3326a;

        /* renamed from: a  reason: collision with other field name */
        public IntentSender f3327a;
        public int b;

        public b(IntentSender intentSender) {
            this.f3327a = intentSender;
        }

        public k a() {
            return new k(this.f3327a, this.f3326a, this.a, this.b);
        }

        public b b(Intent intent) {
            this.f3326a = intent;
            return this;
        }

        public b c(int i, int i2) {
            this.b = i;
            this.a = i2;
            return this;
        }
    }

    public k(IntentSender intentSender, Intent intent, int i, int i2) {
        this.f3325a = intentSender;
        this.f3324a = intent;
        this.a = i;
        this.b = i2;
    }

    public k(Parcel parcel) {
        this.f3325a = (IntentSender) parcel.readParcelable(IntentSender.class.getClassLoader());
        this.f3324a = (Intent) parcel.readParcelable(Intent.class.getClassLoader());
        this.a = parcel.readInt();
        this.b = parcel.readInt();
    }

    public Intent a() {
        return this.f3324a;
    }

    public int b() {
        return this.a;
    }

    public int c() {
        return this.b;
    }

    public IntentSender d() {
        return this.f3325a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f3325a, i);
        parcel.writeParcelable(this.f3324a, i);
        parcel.writeInt(this.a);
        parcel.writeInt(this.b);
    }
}
