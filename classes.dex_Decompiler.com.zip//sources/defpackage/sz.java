package defpackage;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* renamed from: sz  reason: default package */
public final class sz {
    public static final Status a = new Status(8, "The connection to Google Play services was lost");

    /* renamed from: a  reason: collision with other field name */
    public final Set<BasePendingResult<?>> f5119a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));

    /* renamed from: a  reason: collision with other field name */
    public final uz f5120a = new vz(this);

    public final void a() {
        for (BasePendingResult basePendingResult : (BasePendingResult[]) this.f5119a.toArray(new BasePendingResult[0])) {
            basePendingResult.n((uz) null);
            if (basePendingResult.o()) {
                this.f5119a.remove(basePendingResult);
            }
        }
    }

    public final void b(BasePendingResult<? extends rw> basePendingResult) {
        this.f5119a.add(basePendingResult);
        basePendingResult.n(this.f5120a);
    }
}
