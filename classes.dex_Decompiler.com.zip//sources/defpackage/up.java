package defpackage;

import com.google.auto.value.AutoValue;
import defpackage.op;

@AutoValue
/* renamed from: up  reason: default package */
public abstract class up {

    @AutoValue.Builder
    /* renamed from: up$a */
    public static abstract class a {
        public abstract up a();

        public abstract a b(kp kpVar);

        public abstract a c(b bVar);
    }

    /* renamed from: up$b */
    public enum b {
        UNKNOWN(0),
        ANDROID_FIREBASE(23);
        

        /* renamed from: a  reason: collision with other field name */
        public final int f5427a;

        /* access modifiers changed from: public */
        b(int i) {
            this.f5427a = i;
        }
    }

    public static a a() {
        return new op.b();
    }

    public abstract kp b();

    public abstract b c();
}
