package defpackage;

/* renamed from: i12  reason: default package */
public interface i12<P1, R> {
    R b(P1 p1);
}
