package defpackage;

/* renamed from: d32  reason: default package */
public class d32 extends c32 {
    public static final String m0(String str, int i) {
        p12.d(str, "$this$take");
        if (i >= 0) {
            String substring = str.substring(0, c22.c(i, str.length()));
            p12.c(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            return substring;
        }
        throw new IllegalArgumentException(("Requested character count " + i + " is less than zero.").toString());
    }
}
