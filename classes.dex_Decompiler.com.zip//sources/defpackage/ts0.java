package defpackage;

import android.os.IBinder;
import android.os.Parcel;

/* renamed from: ts0  reason: default package */
public final class ts0 extends ls0 implements ss0 {
    public ts0(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.safetynet.internal.ISafetyNetService");
    }

    public final void y(qs0 qs0) {
        Parcel b = b();
        ns0.b(b, qs0);
        c(14, b);
    }
}
