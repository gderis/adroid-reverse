package defpackage;

import android.content.Context;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* renamed from: sq1  reason: default package */
public final class sq1 {
    public final Context a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<Class<?>, pq1> f5091a;

    /* renamed from: a  reason: collision with other field name */
    public final Set<Class<? extends rq1>> f5092a;

    /* renamed from: a  reason: collision with other field name */
    public final boolean f5093a;

    /* renamed from: sq1$a */
    public static class a {
        public final Context a;

        /* renamed from: a  reason: collision with other field name */
        public final Map<Class<?>, pq1> f5094a = new HashMap();

        /* renamed from: a  reason: collision with other field name */
        public Set<Class<? extends rq1>> f5095a = new HashSet();

        /* renamed from: a  reason: collision with other field name */
        public boolean f5096a;

        public a(Context context) {
            this.a = context.getApplicationContext();
        }

        public sq1 a() {
            return new sq1(this);
        }
    }

    public sq1(a aVar) {
        this.f5092a = Collections.unmodifiableSet(aVar.f5095a);
        this.f5091a = aVar.f5094a;
        this.a = aVar.a;
        this.f5093a = aVar.f5096a;
    }

    public Map<Class<?>, pq1> a() {
        return this.f5091a;
    }

    public Set<Class<? extends rq1>> b() {
        return this.f5092a;
    }

    public pq1 c(Class<?> cls) {
        return a().get(cls);
    }

    public Context d() {
        return this.a;
    }

    public boolean e() {
        return this.f5093a;
    }
}
