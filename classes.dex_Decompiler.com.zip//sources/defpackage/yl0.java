package defpackage;

/* renamed from: yl0  reason: default package */
public abstract class yl0 {
    public static final yl0 a = new wl0((vl0) null);
    public static final yl0 b = new xl0((vl0) null);

    public /* synthetic */ yl0(vl0 vl0) {
    }

    public static yl0 c() {
        return a;
    }

    public static yl0 d() {
        return b;
    }

    public abstract void a(Object obj, long j);

    public abstract <L> void b(Object obj, Object obj2, long j);
}
