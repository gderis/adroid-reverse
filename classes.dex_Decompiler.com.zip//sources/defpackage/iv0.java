package defpackage;

import android.os.Handler;

/* renamed from: iv0  reason: default package */
public abstract class iv0 {
    public static volatile Handler a;

    /* renamed from: a  reason: collision with other field name */
    public volatile long f3156a;

    /* renamed from: a  reason: collision with other field name */
    public final Runnable f3157a;

    /* renamed from: a  reason: collision with other field name */
    public final s11 f3158a;

    public iv0(s11 s11) {
        s10.j(s11);
        this.f3158a = s11;
        this.f3157a = new hv0(this, s11);
    }

    public abstract void a();

    public final void b(long j) {
        d();
        if (j >= 0) {
            this.f3156a = this.f3158a.b().b();
            if (!f().postDelayed(this.f3157a, j)) {
                this.f3158a.c().o().b("Failed to schedule delayed post. time", Long.valueOf(j));
            }
        }
    }

    public final boolean c() {
        return this.f3156a != 0;
    }

    public final void d() {
        this.f3156a = 0;
        f().removeCallbacks(this.f3157a);
    }

    public final Handler f() {
        Handler handler;
        if (a != null) {
            return a;
        }
        synchronized (iv0.class) {
            if (a == null) {
                a = new gd0(this.f3158a.e().getMainLooper());
            }
            handler = a;
        }
        return handler;
    }
}
