package defpackage;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import java.io.IOException;

/* renamed from: jp1  reason: default package */
public class jp1 implements Runnable {
    public static Boolean a;

    /* renamed from: a  reason: collision with other field name */
    public static final Object f3297a = new Object();
    public static Boolean b;

    /* renamed from: a  reason: collision with other field name */
    public final long f3298a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f3299a;

    /* renamed from: a  reason: collision with other field name */
    public final PowerManager.WakeLock f3300a;

    /* renamed from: a  reason: collision with other field name */
    public final ip1 f3301a;

    /* renamed from: a  reason: collision with other field name */
    public final to1 f3302a;

    /* renamed from: jp1$a */
    public class a extends BroadcastReceiver {
        public jp1 a;

        public a(jp1 jp1) {
            this.a = jp1;
        }

        public void a() {
            boolean b2 = jp1.j();
            jp1.this.f3299a.registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }

        public synchronized void onReceive(Context context, Intent intent) {
            jp1 jp1 = this.a;
            if (jp1 != null) {
                if (jp1.i()) {
                    boolean b2 = jp1.j();
                    this.a.f3301a.k(this.a, 0);
                    context.unregisterReceiver(this);
                    this.a = null;
                }
            }
        }
    }

    public jp1(ip1 ip1, Context context, to1 to1, long j) {
        this.f3301a = ip1;
        this.f3299a = context;
        this.f3298a = j;
        this.f3302a = to1;
        this.f3300a = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "wake:com.google.firebase.messaging");
    }

    public static String e(String str) {
        StringBuilder sb = new StringBuilder(str.length() + 142);
        sb.append("Missing Permission: ");
        sb.append(str);
        sb.append(". This permission should normally be included by the manifest merger, but may needed to be manually added to your manifest");
        return sb.toString();
    }

    public static boolean f(Context context) {
        boolean booleanValue;
        synchronized (f3297a) {
            Boolean bool = b;
            Boolean valueOf = Boolean.valueOf(bool == null ? g(context, "android.permission.ACCESS_NETWORK_STATE", bool) : bool.booleanValue());
            b = valueOf;
            booleanValue = valueOf.booleanValue();
        }
        return booleanValue;
    }

    public static boolean g(Context context, String str, Boolean bool) {
        if (bool != null) {
            return bool.booleanValue();
        }
        boolean z = context.checkCallingOrSelfPermission(str) == 0;
        if (z || !Log.isLoggable("FirebaseMessaging", 3)) {
            return z;
        }
        e(str);
        return false;
    }

    public static boolean h(Context context) {
        boolean booleanValue;
        synchronized (f3297a) {
            Boolean bool = a;
            Boolean valueOf = Boolean.valueOf(bool == null ? g(context, "android.permission.WAKE_LOCK", bool) : bool.booleanValue());
            a = valueOf;
            booleanValue = valueOf.booleanValue();
        }
        return booleanValue;
    }

    public static boolean j() {
        return Log.isLoggable("FirebaseMessaging", 3) || (Build.VERSION.SDK_INT == 23 && Log.isLoggable("FirebaseMessaging", 3));
    }

    public final synchronized boolean i() {
        NetworkInfo activeNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) this.f3299a.getSystemService("connectivity");
        activeNetworkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @SuppressLint({"Wakelock"})
    public void run() {
        if (h(this.f3299a)) {
            this.f3300a.acquire(pn1.a);
        }
        try {
            this.f3301a.l(true);
            if (!this.f3302a.g()) {
                this.f3301a.l(false);
                if (h(this.f3299a)) {
                    try {
                        this.f3300a.release();
                    } catch (RuntimeException unused) {
                    }
                }
            } else if (!f(this.f3299a) || i()) {
                if (this.f3301a.o()) {
                    this.f3301a.l(false);
                } else {
                    this.f3301a.p(this.f3298a);
                }
                if (h(this.f3299a)) {
                    try {
                        this.f3300a.release();
                    } catch (RuntimeException unused2) {
                    }
                }
            } else {
                new a(this).a();
                if (h(this.f3299a)) {
                    try {
                        this.f3300a.release();
                    } catch (RuntimeException unused3) {
                    }
                }
            }
        } catch (IOException e) {
            String valueOf = String.valueOf(e.getMessage());
            if (valueOf.length() != 0) {
                "Failed to sync topics. Won't retry sync. ".concat(valueOf);
            } else {
                new String("Failed to sync topics. Won't retry sync. ");
            }
            this.f3301a.l(false);
            if (h(this.f3299a)) {
                try {
                    this.f3300a.release();
                } catch (RuntimeException unused4) {
                }
            }
        } catch (Throwable th) {
            if (h(this.f3299a)) {
                try {
                    this.f3300a.release();
                } catch (RuntimeException unused5) {
                }
            }
            throw th;
        }
    }
}
