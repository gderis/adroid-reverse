package defpackage;

/* renamed from: y22  reason: default package */
public class y22 extends x22 {
}
