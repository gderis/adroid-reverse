package defpackage;

/* renamed from: bg  reason: default package */
public class bg {
    public static String a(String str) {
        return "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '" + str + "')";
    }
}
