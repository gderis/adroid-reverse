package defpackage;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: z90  reason: default package */
public final class z90 extends w10 {
    public static final Parcelable.Creator<z90> CREATOR = new aa0();
    public final int a;

    /* renamed from: a  reason: collision with other field name */
    public final PendingIntent f6195a;

    /* renamed from: a  reason: collision with other field name */
    public final au0 f6196a;

    /* renamed from: a  reason: collision with other field name */
    public final e90 f6197a;

    /* renamed from: a  reason: collision with other field name */
    public final x90 f6198a;

    /* renamed from: a  reason: collision with other field name */
    public final xt0 f6199a;

    public z90(int i, x90 x90, IBinder iBinder, PendingIntent pendingIntent, IBinder iBinder2, IBinder iBinder3) {
        this.a = i;
        this.f6198a = x90;
        e90 e90 = null;
        this.f6196a = iBinder == null ? null : zt0.c(iBinder);
        this.f6195a = pendingIntent;
        this.f6199a = iBinder2 == null ? null : wt0.c(iBinder2);
        if (iBinder3 != null) {
            IInterface queryLocalInterface = iBinder3.queryLocalInterface("com.google.android.gms.location.internal.IFusedLocationProviderCallback");
            e90 = queryLocalInterface instanceof e90 ? (e90) queryLocalInterface : new c90(iBinder3);
        }
        this.f6197a = e90;
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.os.IBinder] */
    /* JADX WARNING: type inference failed for: r3v0, types: [android.os.IBinder] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static defpackage.z90 A0(defpackage.au0 r8, defpackage.e90 r9) {
        /*
            z90 r7 = new z90
            if (r9 != 0) goto L_0x0005
            r9 = 0
        L_0x0005:
            r6 = r9
            r1 = 2
            r2 = 0
            r4 = 0
            r5 = 0
            r0 = r7
            r3 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z90.A0(au0, e90):z90");
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.os.IBinder] */
    /* JADX WARNING: type inference failed for: r5v0, types: [android.os.IBinder] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static defpackage.z90 B0(defpackage.xt0 r8, defpackage.e90 r9) {
        /*
            z90 r7 = new z90
            if (r9 != 0) goto L_0x0005
            r9 = 0
        L_0x0005:
            r6 = r9
            r1 = 2
            r2 = 0
            r3 = 0
            r4 = 0
            r0 = r7
            r5 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z90.B0(xt0, e90):z90");
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.l(parcel, 1, this.a);
        y10.p(parcel, 2, this.f6198a, i, false);
        au0 au0 = this.f6196a;
        IBinder iBinder = null;
        y10.k(parcel, 3, au0 == null ? null : au0.asBinder(), false);
        y10.p(parcel, 4, this.f6195a, i, false);
        xt0 xt0 = this.f6199a;
        y10.k(parcel, 5, xt0 == null ? null : xt0.asBinder(), false);
        e90 e90 = this.f6197a;
        if (e90 != null) {
            iBinder = e90.asBinder();
        }
        y10.k(parcel, 6, iBinder, false);
        y10.b(parcel, a2);
    }
}
