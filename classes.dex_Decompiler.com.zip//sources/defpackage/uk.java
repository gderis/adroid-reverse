package defpackage;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

/* renamed from: uk  reason: default package */
public class uk implements ek {
    public static final String a = qj.f("SystemAlarmDispatcher");

    /* renamed from: a  reason: collision with other field name */
    public final Context f5403a;

    /* renamed from: a  reason: collision with other field name */
    public Intent f5404a;

    /* renamed from: a  reason: collision with other field name */
    public final Handler f5405a;

    /* renamed from: a  reason: collision with other field name */
    public final dn f5406a;

    /* renamed from: a  reason: collision with other field name */
    public final gk f5407a;

    /* renamed from: a  reason: collision with other field name */
    public final hn f5408a;

    /* renamed from: a  reason: collision with other field name */
    public final List<Intent> f5409a;

    /* renamed from: a  reason: collision with other field name */
    public final mk f5410a;

    /* renamed from: a  reason: collision with other field name */
    public final rk f5411a;

    /* renamed from: a  reason: collision with other field name */
    public c f5412a;

    /* renamed from: uk$a */
    public class a implements Runnable {
        public a() {
        }

        public void run() {
            d dVar;
            uk ukVar;
            synchronized (uk.this.f5409a) {
                uk ukVar2 = uk.this;
                ukVar2.f5404a = ukVar2.f5409a.get(0);
            }
            Intent intent = uk.this.f5404a;
            if (intent != null) {
                String action = intent.getAction();
                int intExtra = uk.this.f5404a.getIntExtra("KEY_START_ID", 0);
                qj c = qj.c();
                String str = uk.a;
                c.a(str, String.format("Processing command %s, %s", new Object[]{uk.this.f5404a, Integer.valueOf(intExtra)}), new Throwable[0]);
                PowerManager.WakeLock b = an.b(uk.this.f5403a, String.format("%s (%s)", new Object[]{action, Integer.valueOf(intExtra)}));
                try {
                    qj.c().a(str, String.format("Acquiring operation wake lock (%s) %s", new Object[]{action, b}), new Throwable[0]);
                    b.acquire();
                    uk ukVar3 = uk.this;
                    ukVar3.f5411a.p(ukVar3.f5404a, intExtra, ukVar3);
                    qj.c().a(str, String.format("Releasing operation wake lock (%s) %s", new Object[]{action, b}), new Throwable[0]);
                    b.release();
                    ukVar = uk.this;
                    dVar = new d(ukVar);
                } catch (Throwable th) {
                    qj.c().a(uk.a, String.format("Releasing operation wake lock (%s) %s", new Object[]{action, b}), new Throwable[0]);
                    b.release();
                    uk ukVar4 = uk.this;
                    ukVar4.k(new d(ukVar4));
                    throw th;
                }
                ukVar.k(dVar);
            }
        }
    }

    /* renamed from: uk$b */
    public static class b implements Runnable {
        public final int a;

        /* renamed from: a  reason: collision with other field name */
        public final Intent f5413a;

        /* renamed from: a  reason: collision with other field name */
        public final uk f5414a;

        public b(uk ukVar, Intent intent, int i) {
            this.f5414a = ukVar;
            this.f5413a = intent;
            this.a = i;
        }

        public void run() {
            this.f5414a.a(this.f5413a, this.a);
        }
    }

    /* renamed from: uk$c */
    public interface c {
        void a();
    }

    /* renamed from: uk$d */
    public static class d implements Runnable {
        public final uk a;

        public d(uk ukVar) {
            this.a = ukVar;
        }

        public void run() {
            this.a.c();
        }
    }

    public uk(Context context) {
        this(context, (gk) null, (mk) null);
    }

    public uk(Context context, gk gkVar, mk mkVar) {
        Context applicationContext = context.getApplicationContext();
        this.f5403a = applicationContext;
        this.f5411a = new rk(applicationContext);
        this.f5406a = new dn();
        mkVar = mkVar == null ? mk.p(context) : mkVar;
        this.f5410a = mkVar;
        gkVar = gkVar == null ? mkVar.r() : gkVar;
        this.f5407a = gkVar;
        this.f5408a = mkVar.v();
        gkVar.b(this);
        this.f5409a = new ArrayList();
        this.f5404a = null;
        this.f5405a = new Handler(Looper.getMainLooper());
    }

    public boolean a(Intent intent, int i) {
        qj c2 = qj.c();
        String str = a;
        boolean z = false;
        c2.a(str, String.format("Adding command %s (%s)", new Object[]{intent, Integer.valueOf(i)}), new Throwable[0]);
        b();
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            qj.c().h(str, "Unknown command. Ignoring", new Throwable[0]);
            return false;
        } else if ("ACTION_CONSTRAINTS_CHANGED".equals(action) && i("ACTION_CONSTRAINTS_CHANGED")) {
            return false;
        } else {
            intent.putExtra("KEY_START_ID", i);
            synchronized (this.f5409a) {
                if (!this.f5409a.isEmpty()) {
                    z = true;
                }
                this.f5409a.add(intent);
                if (!z) {
                    l();
                }
            }
            return true;
        }
    }

    public final void b() {
        if (this.f5405a.getLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException("Needs to be invoked on the main thread.");
        }
    }

    public void c() {
        qj c2 = qj.c();
        String str = a;
        c2.a(str, "Checking if commands are complete.", new Throwable[0]);
        b();
        synchronized (this.f5409a) {
            if (this.f5404a != null) {
                qj.c().a(str, String.format("Removing command %s", new Object[]{this.f5404a}), new Throwable[0]);
                if (this.f5409a.remove(0).equals(this.f5404a)) {
                    this.f5404a = null;
                } else {
                    throw new IllegalStateException("Dequeue-d command is not the first.");
                }
            }
            wm b2 = this.f5408a.b();
            if (!this.f5411a.o() && this.f5409a.isEmpty() && !b2.a()) {
                qj.c().a(str, "No more commands & intents.", new Throwable[0]);
                c cVar = this.f5412a;
                if (cVar != null) {
                    cVar.a();
                }
            } else if (!this.f5409a.isEmpty()) {
                l();
            }
        }
    }

    public gk d() {
        return this.f5407a;
    }

    public hn e() {
        return this.f5408a;
    }

    public void f(String str, boolean z) {
        k(new b(this, rk.c(this.f5403a, str, z), 0));
    }

    public mk g() {
        return this.f5410a;
    }

    public dn h() {
        return this.f5406a;
    }

    public final boolean i(String str) {
        b();
        synchronized (this.f5409a) {
            for (Intent action : this.f5409a) {
                if (str.equals(action.getAction())) {
                    return true;
                }
            }
            return false;
        }
    }

    public void j() {
        qj.c().a(a, "Destroying SystemAlarmDispatcher", new Throwable[0]);
        this.f5407a.h(this);
        this.f5406a.a();
        this.f5412a = null;
    }

    public void k(Runnable runnable) {
        this.f5405a.post(runnable);
    }

    public final void l() {
        b();
        PowerManager.WakeLock b2 = an.b(this.f5403a, "ProcessCommand");
        try {
            b2.acquire();
            this.f5410a.v().a(new a());
        } finally {
            b2.release();
        }
    }

    public void m(c cVar) {
        if (this.f5412a != null) {
            qj.c().b(a, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
        } else {
            this.f5412a = cVar;
        }
    }
}
