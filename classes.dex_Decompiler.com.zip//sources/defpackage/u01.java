package defpackage;

import java.util.Map;

/* renamed from: u01  reason: default package */
public final /* synthetic */ class u01 {
    public final w01 a;

    public u01(w01 w01) {
        this.a = w01;
    }

    public final void a(String str, int i, Throwable th, byte[] bArr, Map map) {
        this.a.s(str, i, th, bArr, map);
    }
}
