package defpackage;

/* renamed from: ig  reason: default package */
public abstract class ig {
    public final int a;
    public final int b;

    public ig(int i, int i2) {
        this.a = i;
        this.b = i2;
    }

    public abstract void a(ug ugVar);
}
