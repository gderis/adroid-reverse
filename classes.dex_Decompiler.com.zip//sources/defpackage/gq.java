package defpackage;

import java.util.Set;

/* renamed from: gq  reason: default package */
public interface gq extends fq {
    Set<yo> c();
}
