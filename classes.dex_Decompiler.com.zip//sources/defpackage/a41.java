package defpackage;

import android.os.RemoteException;

/* renamed from: a41  reason: default package */
public final class a41 implements Runnable {
    public final /* synthetic */ g61 a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ o41 f24a;

    public a41(o41 o41, g61 g61) {
        this.f24a = o41;
        this.a = g61;
    }

    public final void run() {
        ez0 A = this.f24a.a;
        if (A == null) {
            this.f24a.a.c().o().a("Failed to send measurementEnabled to service");
            return;
        }
        try {
            s10.j(this.a);
            A.c0(this.a);
            this.f24a.D();
        } catch (RemoteException e) {
            this.f24a.a.c().o().b("Failed to send measurementEnabled to the service", e);
        }
    }
}
