package defpackage;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.os.CancellationSignal;
import android.util.Pair;
import java.util.List;

/* renamed from: zg  reason: default package */
public class zg implements ug {
    public static final String[] a = {"", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE "};
    public static final String[] b = new String[0];

    /* renamed from: a  reason: collision with other field name */
    public final SQLiteDatabase f6224a;

    /* renamed from: zg$a */
    public class a implements SQLiteDatabase.CursorFactory {
        public final /* synthetic */ xg a;

        public a(xg xgVar) {
            this.a = xgVar;
        }

        public Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
            this.a.a(new ch(sQLiteQuery));
            return new SQLiteCursor(sQLiteCursorDriver, str, sQLiteQuery);
        }
    }

    /* renamed from: zg$b */
    public class b implements SQLiteDatabase.CursorFactory {
        public final /* synthetic */ xg a;

        public b(xg xgVar) {
            this.a = xgVar;
        }

        public Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
            this.a.a(new ch(sQLiteQuery));
            return new SQLiteCursor(sQLiteCursorDriver, str, sQLiteQuery);
        }
    }

    public zg(SQLiteDatabase sQLiteDatabase) {
        this.f6224a = sQLiteDatabase;
    }

    public String T() {
        return this.f6224a.getPath();
    }

    public Cursor V(xg xgVar, CancellationSignal cancellationSignal) {
        return this.f6224a.rawQueryWithFactory(new b(xgVar), xgVar.o(), b, (String) null, cancellationSignal);
    }

    public Cursor W(xg xgVar) {
        return this.f6224a.rawQueryWithFactory(new a(xgVar), xgVar.o(), b, (String) null);
    }

    public boolean a(SQLiteDatabase sQLiteDatabase) {
        return this.f6224a == sQLiteDatabase;
    }

    public void b() {
        this.f6224a.endTransaction();
    }

    public void close() {
        this.f6224a.close();
    }

    public void d() {
        this.f6224a.beginTransaction();
    }

    public void i() {
        this.f6224a.setTransactionSuccessful();
    }

    public boolean isOpen() {
        return this.f6224a.isOpen();
    }

    public void j(String str) {
        this.f6224a.execSQL(str);
    }

    public boolean k0() {
        return this.f6224a.inTransaction();
    }

    public List<Pair<String, String>> l0() {
        return this.f6224a.getAttachedDbs();
    }

    public yg o0(String str) {
        return new dh(this.f6224a.compileStatement(str));
    }

    public Cursor p(String str) {
        return W(new tg(str));
    }

    public void r0(String str, Object[] objArr) {
        this.f6224a.execSQL(str, objArr);
    }
}
