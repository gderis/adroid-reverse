package defpackage;

/* renamed from: s32  reason: default package */
public /* synthetic */ class s32 {
    public static /* synthetic */ int a(boolean z) {
        return z ? 1231 : 1237;
    }
}
