package defpackage;

import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.RecentlyNonNull;

/* renamed from: f40  reason: default package */
public class f40 {
    public static boolean a() {
        return false;
    }

    public static boolean b(@RecentlyNonNull Context context, @RecentlyNonNull String str) {
        "com.google.android.gms".equals(str);
        try {
            return (z40.a(context).c(str, 0).flags & 2097152) != 0;
        } catch (PackageManager.NameNotFoundException unused) {
        }
    }
}
