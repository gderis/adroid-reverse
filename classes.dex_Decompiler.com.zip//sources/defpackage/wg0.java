package defpackage;

/* renamed from: wg0  reason: default package */
public final class wg0 extends cl0<bh0, wg0> implements mm0 {
    public wg0() {
        super(bh0.zzg);
    }

    public /* synthetic */ wg0(eg0 eg0) {
        super(bh0.zzg);
    }

    public final wg0 r(og0 og0) {
        if (this.f1285b) {
            n();
            this.f1285b = false;
        }
        bh0.C((bh0) this.b, (pg0) og0.k());
        return this;
    }
}
