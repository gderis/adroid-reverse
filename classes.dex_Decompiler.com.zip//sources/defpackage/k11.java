package defpackage;

import java.util.concurrent.Callable;

/* renamed from: k11  reason: default package */
public final class k11 implements Callable<byte[]> {
    public final /* synthetic */ String a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ p11 f3394a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ pv0 f3395a;

    public k11(p11 p11, pv0 pv0, String str) {
        this.f3394a = p11;
        this.f3395a = pv0;
        this.a = str;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0162, code lost:
        if (android.text.TextUtils.isEmpty(r8) == false) goto L_0x0164;
     */
    /* JADX WARNING: Removed duplicated region for block: B:111:0x036c A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }, LOOP:2: B:109:0x0366->B:111:0x036c, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:114:0x040b A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x0433 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x0469 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x04b9 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x0525 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x053b A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x0546 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x054a A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:150:0x02a4 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x01b7 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x026e A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x0293 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x02f7 A[Catch:{ SecurityException -> 0x01f4, all -> 0x05f2 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* bridge */ /* synthetic */ java.lang.Object call() {
        /*
            r31 = this;
            r1 = r31
            java.lang.String r0 = "_r"
            p11 r2 = r1.f3394a
            s51 r2 = r2.f4365a
            r2.l()
            p11 r2 = r1.f3394a
            s51 r2 = r2.f4365a
            f31 r2 = r2.Y()
            pv0 r3 = r1.f3395a
            java.lang.String r13 = r1.a
            r2.h()
            defpackage.w01.u()
            defpackage.s10.j(r3)
            defpackage.s10.f(r13)
            w01 r4 = r2.a
            bv0 r4 = r4.z()
            zy0<java.lang.Boolean> r5 = defpackage.bz0.U
            boolean r4 = r4.w(r13, r5)
            r14 = 0
            r5 = 0
            if (r4 != 0) goto L_0x004a
            w01 r0 = r2.a
            nz0 r0 = r0.c()
            lz0 r0 = r0.v()
            java.lang.String r2 = "Generating ScionPayload disabled. packageName"
            r0.b(r2, r13)
            byte[] r14 = new byte[r5]
            goto L_0x05f1
        L_0x004a:
            java.lang.String r4 = r3.f4541a
            java.lang.String r6 = "_iap"
            boolean r4 = r6.equals(r4)
            if (r4 != 0) goto L_0x0071
            java.lang.String r4 = r3.f4541a
            java.lang.String r6 = "_iapx"
            boolean r4 = r6.equals(r4)
            if (r4 != 0) goto L_0x0071
            w01 r0 = r2.a
            nz0 r0 = r0.c()
            lz0 r0 = r0.v()
            java.lang.String r2 = r3.f4541a
            java.lang.String r3 = "Generating a payload for this event is not available. package_name, event_name"
            r0.c(r3, r13, r2)
            goto L_0x05f1
        L_0x0071:
            sg0 r6 = defpackage.tg0.C()
            s51 r4 = r2.a
            fv0 r4 = r4.V()
            r4.M()
            s51 r4 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r4 = r4.V()     // Catch:{ all -> 0x05f2 }
            c11 r4 = r4.c0(r13)     // Catch:{ all -> 0x05f2 }
            if (r4 != 0) goto L_0x00a6
            w01 r0 = r2.a     // Catch:{ all -> 0x05f2 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x05f2 }
            lz0 r0 = r0.v()     // Catch:{ all -> 0x05f2 }
            java.lang.String r3 = "Log and bundle not available. package_name"
            r0.b(r3, r13)     // Catch:{ all -> 0x05f2 }
        L_0x0099:
            byte[] r14 = new byte[r5]     // Catch:{ all -> 0x05f2 }
        L_0x009b:
            s51 r0 = r2.a
            fv0 r0 = r0.V()
            r0.O()
            goto L_0x05f1
        L_0x00a6:
            boolean r7 = r4.f()     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x00bc
            w01 r0 = r2.a     // Catch:{ all -> 0x05f2 }
            nz0 r0 = r0.c()     // Catch:{ all -> 0x05f2 }
            lz0 r0 = r0.v()     // Catch:{ all -> 0x05f2 }
            java.lang.String r3 = "Log and bundle disabled. package_name"
            r0.b(r3, r13)     // Catch:{ all -> 0x05f2 }
            goto L_0x0099
        L_0x00bc:
            ug0 r15 = defpackage.vg0.K0()     // Catch:{ all -> 0x05f2 }
            r11 = 1
            r15.W(r11)     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = "android"
            r15.r(r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = r4.N()     // Catch:{ all -> 0x05f2 }
            boolean r7 = android.text.TextUtils.isEmpty(r7)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x00da
            java.lang.String r7 = r4.N()     // Catch:{ all -> 0x05f2 }
            r15.B(r7)     // Catch:{ all -> 0x05f2 }
        L_0x00da:
            java.lang.String r7 = r4.i0()     // Catch:{ all -> 0x05f2 }
            boolean r7 = android.text.TextUtils.isEmpty(r7)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x00f1
            java.lang.String r7 = r4.i0()     // Catch:{ all -> 0x05f2 }
            java.lang.Object r7 = defpackage.s10.j(r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ all -> 0x05f2 }
            r15.z(r7)     // Catch:{ all -> 0x05f2 }
        L_0x00f1:
            java.lang.String r7 = r4.e0()     // Catch:{ all -> 0x05f2 }
            boolean r7 = android.text.TextUtils.isEmpty(r7)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x0108
            java.lang.String r7 = r4.e0()     // Catch:{ all -> 0x05f2 }
            java.lang.Object r7 = defpackage.s10.j(r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ all -> 0x05f2 }
            r15.C(r7)     // Catch:{ all -> 0x05f2 }
        L_0x0108:
            long r7 = r4.g0()     // Catch:{ all -> 0x05f2 }
            r9 = -2147483648(0xffffffff80000000, double:NaN)
            int r12 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r12 == 0) goto L_0x011b
            long r7 = r4.g0()     // Catch:{ all -> 0x05f2 }
            int r8 = (int) r7     // Catch:{ all -> 0x05f2 }
            r15.Y(r8)     // Catch:{ all -> 0x05f2 }
        L_0x011b:
            long r7 = r4.k0()     // Catch:{ all -> 0x05f2 }
            r15.D(r7)     // Catch:{ all -> 0x05f2 }
            long r7 = r4.d()     // Catch:{ all -> 0x05f2 }
            r15.i0(r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = r4.Q()     // Catch:{ all -> 0x05f2 }
            java.lang.String r8 = r4.S()     // Catch:{ all -> 0x05f2 }
            defpackage.bq0.b()     // Catch:{ all -> 0x05f2 }
            w01 r9 = r2.a     // Catch:{ all -> 0x05f2 }
            bv0 r9 = r9.z()     // Catch:{ all -> 0x05f2 }
            java.lang.String r10 = r4.N()     // Catch:{ all -> 0x05f2 }
            zy0<java.lang.Boolean> r12 = defpackage.bz0.g0     // Catch:{ all -> 0x05f2 }
            boolean r9 = r9.w(r10, r12)     // Catch:{ all -> 0x05f2 }
            if (r9 == 0) goto L_0x0168
            java.lang.String r9 = r4.U()     // Catch:{ all -> 0x05f2 }
            boolean r10 = android.text.TextUtils.isEmpty(r7)     // Catch:{ all -> 0x05f2 }
            if (r10 != 0) goto L_0x0154
        L_0x0150:
            r15.S(r7)     // Catch:{ all -> 0x05f2 }
            goto L_0x0176
        L_0x0154:
            boolean r7 = android.text.TextUtils.isEmpty(r9)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x015e
            r15.l0(r9)     // Catch:{ all -> 0x05f2 }
            goto L_0x0176
        L_0x015e:
            boolean r7 = android.text.TextUtils.isEmpty(r8)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x0176
        L_0x0164:
            r15.f0(r8)     // Catch:{ all -> 0x05f2 }
            goto L_0x0176
        L_0x0168:
            boolean r9 = android.text.TextUtils.isEmpty(r7)     // Catch:{ all -> 0x05f2 }
            if (r9 != 0) goto L_0x016f
            goto L_0x0150
        L_0x016f:
            boolean r7 = android.text.TextUtils.isEmpty(r8)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x0176
            goto L_0x0164
        L_0x0176:
            s51 r7 = r2.a     // Catch:{ all -> 0x05f2 }
            cv0 r7 = r7.f0(r13)     // Catch:{ all -> 0x05f2 }
            long r8 = r4.b()     // Catch:{ all -> 0x05f2 }
            r15.N(r8)     // Catch:{ all -> 0x05f2 }
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            boolean r8 = r8.k()     // Catch:{ all -> 0x05f2 }
            if (r8 == 0) goto L_0x01aa
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            bv0 r8 = r8.z()     // Catch:{ all -> 0x05f2 }
            java.lang.String r9 = r15.A()     // Catch:{ all -> 0x05f2 }
            boolean r8 = r8.F(r9)     // Catch:{ all -> 0x05f2 }
            if (r8 == 0) goto L_0x01aa
            boolean r8 = r7.f()     // Catch:{ all -> 0x05f2 }
            if (r8 == 0) goto L_0x01aa
            boolean r8 = android.text.TextUtils.isEmpty(r14)     // Catch:{ all -> 0x05f2 }
            if (r8 != 0) goto L_0x01aa
            r15.c0(r14)     // Catch:{ all -> 0x05f2 }
        L_0x01aa:
            java.lang.String r8 = r7.d()     // Catch:{ all -> 0x05f2 }
            r15.m0(r8)     // Catch:{ all -> 0x05f2 }
            boolean r8 = r7.f()     // Catch:{ all -> 0x05f2 }
            if (r8 == 0) goto L_0x020a
            s51 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            p41 r8 = r8.a0()     // Catch:{ all -> 0x05f2 }
            java.lang.String r9 = r4.N()     // Catch:{ all -> 0x05f2 }
            android.util.Pair r8 = r8.m(r9, r7)     // Catch:{ all -> 0x05f2 }
            boolean r9 = r4.G()     // Catch:{ all -> 0x05f2 }
            if (r9 == 0) goto L_0x020a
            java.lang.Object r9 = r8.first     // Catch:{ all -> 0x05f2 }
            java.lang.CharSequence r9 = (java.lang.CharSequence) r9     // Catch:{ all -> 0x05f2 }
            boolean r9 = android.text.TextUtils.isEmpty(r9)     // Catch:{ all -> 0x05f2 }
            if (r9 != 0) goto L_0x020a
            java.lang.Object r9 = r8.first     // Catch:{ SecurityException -> 0x01f4 }
            java.lang.String r9 = (java.lang.String) r9     // Catch:{ SecurityException -> 0x01f4 }
            long r11 = r3.a     // Catch:{ SecurityException -> 0x01f4 }
            java.lang.String r10 = java.lang.Long.toString(r11)     // Catch:{ SecurityException -> 0x01f4 }
            java.lang.String r9 = defpackage.f31.m(r9, r10)     // Catch:{ SecurityException -> 0x01f4 }
            r15.H(r9)     // Catch:{ SecurityException -> 0x01f4 }
            java.lang.Object r8 = r8.second     // Catch:{ all -> 0x05f2 }
            if (r8 == 0) goto L_0x020a
            java.lang.Boolean r8 = (java.lang.Boolean) r8     // Catch:{ all -> 0x05f2 }
            boolean r8 = r8.booleanValue()     // Catch:{ all -> 0x05f2 }
            r15.J(r8)     // Catch:{ all -> 0x05f2 }
            goto L_0x020a
        L_0x01f4:
            r0 = move-exception
            w01 r3 = r2.a     // Catch:{ all -> 0x05f2 }
            nz0 r3 = r3.c()     // Catch:{ all -> 0x05f2 }
            lz0 r3 = r3.v()     // Catch:{ all -> 0x05f2 }
            java.lang.String r4 = "Resettable device id encryption failed"
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x05f2 }
            r3.b(r4, r0)     // Catch:{ all -> 0x05f2 }
            goto L_0x0099
        L_0x020a:
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            jv0 r8 = r8.S()     // Catch:{ all -> 0x05f2 }
            r8.l()     // Catch:{ all -> 0x05f2 }
            java.lang.String r8 = android.os.Build.MODEL     // Catch:{ all -> 0x05f2 }
            r15.u(r8)     // Catch:{ all -> 0x05f2 }
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            jv0 r8 = r8.S()     // Catch:{ all -> 0x05f2 }
            r8.l()     // Catch:{ all -> 0x05f2 }
            java.lang.String r8 = android.os.Build.VERSION.RELEASE     // Catch:{ all -> 0x05f2 }
            r15.s(r8)     // Catch:{ all -> 0x05f2 }
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            jv0 r8 = r8.S()     // Catch:{ all -> 0x05f2 }
            long r8 = r8.o()     // Catch:{ all -> 0x05f2 }
            int r9 = (int) r8     // Catch:{ all -> 0x05f2 }
            r15.y(r9)     // Catch:{ all -> 0x05f2 }
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            jv0 r8 = r8.S()     // Catch:{ all -> 0x05f2 }
            java.lang.String r8 = r8.p()     // Catch:{ all -> 0x05f2 }
            r15.x(r8)     // Catch:{ all -> 0x05f2 }
            boolean r7 = r7.h()     // Catch:{ SecurityException -> 0x05d8 }
            if (r7 == 0) goto L_0x0264
            java.lang.String r7 = r4.O()     // Catch:{ SecurityException -> 0x05d8 }
            if (r7 == 0) goto L_0x0264
            java.lang.String r7 = r4.O()     // Catch:{ SecurityException -> 0x05d8 }
            java.lang.Object r7 = defpackage.s10.j(r7)     // Catch:{ SecurityException -> 0x05d8 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ SecurityException -> 0x05d8 }
            long r8 = r3.a     // Catch:{ SecurityException -> 0x05d8 }
            java.lang.String r8 = java.lang.Long.toString(r8)     // Catch:{ SecurityException -> 0x05d8 }
            java.lang.String r7 = defpackage.f31.m(r7, r8)     // Catch:{ SecurityException -> 0x05d8 }
            r15.L(r7)     // Catch:{ SecurityException -> 0x05d8 }
        L_0x0264:
            java.lang.String r7 = r4.Y()     // Catch:{ all -> 0x05f2 }
            boolean r7 = android.text.TextUtils.isEmpty(r7)     // Catch:{ all -> 0x05f2 }
            if (r7 != 0) goto L_0x027b
            java.lang.String r7 = r4.Y()     // Catch:{ all -> 0x05f2 }
            java.lang.Object r7 = defpackage.s10.j(r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ all -> 0x05f2 }
            r15.X(r7)     // Catch:{ all -> 0x05f2 }
        L_0x027b:
            java.lang.String r7 = r4.N()     // Catch:{ all -> 0x05f2 }
            s51 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r8 = r8.V()     // Catch:{ all -> 0x05f2 }
            java.util.List r8 = r8.V(r7)     // Catch:{ all -> 0x05f2 }
            java.util.Iterator r9 = r8.iterator()     // Catch:{ all -> 0x05f2 }
        L_0x028d:
            boolean r10 = r9.hasNext()     // Catch:{ all -> 0x05f2 }
            if (r10 == 0) goto L_0x02a4
            java.lang.Object r10 = r9.next()     // Catch:{ all -> 0x05f2 }
            x51 r10 = (defpackage.x51) r10     // Catch:{ all -> 0x05f2 }
            java.lang.String r11 = "_lte"
            java.lang.String r12 = r10.c     // Catch:{ all -> 0x05f2 }
            boolean r11 = r11.equals(r12)     // Catch:{ all -> 0x05f2 }
            if (r11 == 0) goto L_0x028d
            goto L_0x02a5
        L_0x02a4:
            r10 = r14
        L_0x02a5:
            r24 = 0
            if (r10 == 0) goto L_0x02ad
            java.lang.Object r9 = r10.f5787a     // Catch:{ all -> 0x05f2 }
            if (r9 != 0) goto L_0x02d4
        L_0x02ad:
            x51 r9 = new x51     // Catch:{ all -> 0x05f2 }
            java.lang.String r19 = "auto"
            java.lang.String r20 = "_lte"
            w01 r10 = r2.a     // Catch:{ all -> 0x05f2 }
            g40 r10 = r10.b()     // Catch:{ all -> 0x05f2 }
            long r21 = r10.b()     // Catch:{ all -> 0x05f2 }
            java.lang.Long r23 = java.lang.Long.valueOf(r24)     // Catch:{ all -> 0x05f2 }
            r17 = r9
            r18 = r7
            r17.<init>(r18, r19, r20, r21, r23)     // Catch:{ all -> 0x05f2 }
            r8.add(r9)     // Catch:{ all -> 0x05f2 }
            s51 r7 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r7 = r7.V()     // Catch:{ all -> 0x05f2 }
            r7.T(r9)     // Catch:{ all -> 0x05f2 }
        L_0x02d4:
            s51 r7 = r2.a     // Catch:{ all -> 0x05f2 }
            u51 r7 = r7.Z()     // Catch:{ all -> 0x05f2 }
            w01 r9 = r7.a     // Catch:{ all -> 0x05f2 }
            nz0 r9 = r9.c()     // Catch:{ all -> 0x05f2 }
            lz0 r9 = r9.w()     // Catch:{ all -> 0x05f2 }
            java.lang.String r10 = "Checking account type status for ad personalization signals"
            r9.a(r10)     // Catch:{ all -> 0x05f2 }
            w01 r9 = r7.a     // Catch:{ all -> 0x05f2 }
            jv0 r9 = r9.S()     // Catch:{ all -> 0x05f2 }
            boolean r9 = r9.s()     // Catch:{ all -> 0x05f2 }
            r10 = 1
            if (r9 == 0) goto L_0x035f
            java.lang.String r9 = r4.N()     // Catch:{ all -> 0x05f2 }
            defpackage.s10.j(r9)     // Catch:{ all -> 0x05f2 }
            boolean r12 = r4.G()     // Catch:{ all -> 0x05f2 }
            if (r12 == 0) goto L_0x035f
            s51 r12 = r7.a     // Catch:{ all -> 0x05f2 }
            o01 r12 = r12.T()     // Catch:{ all -> 0x05f2 }
            boolean r12 = r12.q(r9)     // Catch:{ all -> 0x05f2 }
            if (r12 == 0) goto L_0x035f
            w01 r12 = r7.a     // Catch:{ all -> 0x05f2 }
            nz0 r12 = r12.c()     // Catch:{ all -> 0x05f2 }
            lz0 r12 = r12.v()     // Catch:{ all -> 0x05f2 }
            java.lang.String r14 = "Turning off ad personalization due to account type"
            r12.a(r14)     // Catch:{ all -> 0x05f2 }
            java.util.Iterator r12 = r8.iterator()     // Catch:{ all -> 0x05f2 }
        L_0x0323:
            boolean r14 = r12.hasNext()     // Catch:{ all -> 0x05f2 }
            if (r14 == 0) goto L_0x0341
            java.lang.String r14 = "_npa"
            java.lang.Object r17 = r12.next()     // Catch:{ all -> 0x05f2 }
            r5 = r17
            x51 r5 = (defpackage.x51) r5     // Catch:{ all -> 0x05f2 }
            java.lang.String r5 = r5.c     // Catch:{ all -> 0x05f2 }
            boolean r5 = r14.equals(r5)     // Catch:{ all -> 0x05f2 }
            if (r5 == 0) goto L_0x033f
            r12.remove()     // Catch:{ all -> 0x05f2 }
            goto L_0x0341
        L_0x033f:
            r5 = 0
            goto L_0x0323
        L_0x0341:
            x51 r5 = new x51     // Catch:{ all -> 0x05f2 }
            java.lang.String r19 = "auto"
            java.lang.String r20 = "_npa"
            w01 r7 = r7.a     // Catch:{ all -> 0x05f2 }
            g40 r7 = r7.b()     // Catch:{ all -> 0x05f2 }
            long r21 = r7.b()     // Catch:{ all -> 0x05f2 }
            java.lang.Long r23 = java.lang.Long.valueOf(r10)     // Catch:{ all -> 0x05f2 }
            r17 = r5
            r18 = r9
            r17.<init>(r18, r19, r20, r21, r23)     // Catch:{ all -> 0x05f2 }
            r8.add(r5)     // Catch:{ all -> 0x05f2 }
        L_0x035f:
            int r5 = r8.size()     // Catch:{ all -> 0x05f2 }
            hh0[] r5 = new defpackage.hh0[r5]     // Catch:{ all -> 0x05f2 }
            r7 = 0
        L_0x0366:
            int r9 = r8.size()     // Catch:{ all -> 0x05f2 }
            if (r7 >= r9) goto L_0x03a4
            gh0 r9 = defpackage.hh0.J()     // Catch:{ all -> 0x05f2 }
            java.lang.Object r12 = r8.get(r7)     // Catch:{ all -> 0x05f2 }
            x51 r12 = (defpackage.x51) r12     // Catch:{ all -> 0x05f2 }
            java.lang.String r12 = r12.c     // Catch:{ all -> 0x05f2 }
            r9.s(r12)     // Catch:{ all -> 0x05f2 }
            java.lang.Object r12 = r8.get(r7)     // Catch:{ all -> 0x05f2 }
            x51 r12 = (defpackage.x51) r12     // Catch:{ all -> 0x05f2 }
            long r10 = r12.a     // Catch:{ all -> 0x05f2 }
            r9.r(r10)     // Catch:{ all -> 0x05f2 }
            s51 r10 = r2.a     // Catch:{ all -> 0x05f2 }
            u51 r10 = r10.Z()     // Catch:{ all -> 0x05f2 }
            java.lang.Object r11 = r8.get(r7)     // Catch:{ all -> 0x05f2 }
            x51 r11 = (defpackage.x51) r11     // Catch:{ all -> 0x05f2 }
            java.lang.Object r11 = r11.f5787a     // Catch:{ all -> 0x05f2 }
            r10.v(r9, r11)     // Catch:{ all -> 0x05f2 }
            gl0 r9 = r9.k()     // Catch:{ all -> 0x05f2 }
            hh0 r9 = (defpackage.hh0) r9     // Catch:{ all -> 0x05f2 }
            r5[r7] = r9     // Catch:{ all -> 0x05f2 }
            int r7 = r7 + 1
            r10 = 1
            goto L_0x0366
        L_0x03a4:
            java.util.List r5 = java.util.Arrays.asList(r5)     // Catch:{ all -> 0x05f2 }
            r15.B0(r5)     // Catch:{ all -> 0x05f2 }
            oz0 r5 = defpackage.oz0.a(r3)     // Catch:{ all -> 0x05f2 }
            w01 r7 = r2.a     // Catch:{ all -> 0x05f2 }
            z51 r7 = r7.G()     // Catch:{ all -> 0x05f2 }
            android.os.Bundle r8 = r5.f4361a     // Catch:{ all -> 0x05f2 }
            s51 r9 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r9 = r9.V()     // Catch:{ all -> 0x05f2 }
            android.os.Bundle r9 = r9.w(r13)     // Catch:{ all -> 0x05f2 }
            r7.v(r8, r9)     // Catch:{ all -> 0x05f2 }
            w01 r7 = r2.a     // Catch:{ all -> 0x05f2 }
            z51 r7 = r7.G()     // Catch:{ all -> 0x05f2 }
            w01 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            bv0 r8 = r8.z()     // Catch:{ all -> 0x05f2 }
            int r8 = r8.n(r13)     // Catch:{ all -> 0x05f2 }
            r7.u(r5, r8)     // Catch:{ all -> 0x05f2 }
            android.os.Bundle r14 = r5.f4361a     // Catch:{ all -> 0x05f2 }
            java.lang.String r5 = "_c"
            r7 = 1
            r14.putLong(r5, r7)     // Catch:{ all -> 0x05f2 }
            w01 r5 = r2.a     // Catch:{ all -> 0x05f2 }
            nz0 r5 = r5.c()     // Catch:{ all -> 0x05f2 }
            lz0 r5 = r5.v()     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = "Marking in-app purchase as real-time"
            r5.a(r7)     // Catch:{ all -> 0x05f2 }
            r7 = 1
            r14.putLong(r0, r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r5 = "_o"
            java.lang.String r7 = r3.b     // Catch:{ all -> 0x05f2 }
            r14.putString(r5, r7)     // Catch:{ all -> 0x05f2 }
            w01 r5 = r2.a     // Catch:{ all -> 0x05f2 }
            z51 r5 = r5.G()     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = r15.A()     // Catch:{ all -> 0x05f2 }
            boolean r5 = r5.H(r7)     // Catch:{ all -> 0x05f2 }
            if (r5 == 0) goto L_0x0425
            w01 r5 = r2.a     // Catch:{ all -> 0x05f2 }
            z51 r5 = r5.G()     // Catch:{ all -> 0x05f2 }
            r7 = 1
            java.lang.Long r7 = java.lang.Long.valueOf(r7)     // Catch:{ all -> 0x05f2 }
            java.lang.String r8 = "_dbg"
            r5.z(r14, r8, r7)     // Catch:{ all -> 0x05f2 }
            w01 r5 = r2.a     // Catch:{ all -> 0x05f2 }
            z51 r5 = r5.G()     // Catch:{ all -> 0x05f2 }
            r5.z(r14, r0, r7)     // Catch:{ all -> 0x05f2 }
        L_0x0425:
            s51 r0 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r0 = r0.V()     // Catch:{ all -> 0x05f2 }
            java.lang.String r5 = r3.f4541a     // Catch:{ all -> 0x05f2 }
            lv0 r0 = r0.Q(r13, r5)     // Catch:{ all -> 0x05f2 }
            if (r0 != 0) goto L_0x0469
            lv0 r0 = new lv0     // Catch:{ all -> 0x05f2 }
            java.lang.String r5 = r3.f4541a     // Catch:{ all -> 0x05f2 }
            long r11 = r3.a     // Catch:{ all -> 0x05f2 }
            r7 = 0
            r9 = 0
            r17 = 0
            r21 = r11
            r11 = r17
            r16 = 0
            r28 = r15
            r15 = r16
            r17 = 0
            r18 = 0
            r19 = 0
            r20 = 0
            r23 = r4
            r4 = r0
            r27 = r5
            r5 = r13
            r29 = r6
            r6 = r27
            r27 = r13
            r30 = r14
            r26 = 0
            r13 = r21
            r4.<init>(r5, r6, r7, r9, r11, r13, r15, r17, r18, r19, r20)     // Catch:{ all -> 0x05f2 }
            r11 = r24
            goto L_0x047e
        L_0x0469:
            r23 = r4
            r29 = r6
            r27 = r13
            r30 = r14
            r28 = r15
            r26 = 0
            long r4 = r0.d     // Catch:{ all -> 0x05f2 }
            long r6 = r3.a     // Catch:{ all -> 0x05f2 }
            lv0 r0 = r0.a(r6)     // Catch:{ all -> 0x05f2 }
            r11 = r4
        L_0x047e:
            s51 r4 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r4 = r4.V()     // Catch:{ all -> 0x05f2 }
            r4.R(r0)     // Catch:{ all -> 0x05f2 }
            kv0 r14 = new kv0     // Catch:{ all -> 0x05f2 }
            w01 r5 = r2.a     // Catch:{ all -> 0x05f2 }
            java.lang.String r6 = r3.b     // Catch:{ all -> 0x05f2 }
            java.lang.String r8 = r3.f4541a     // Catch:{ all -> 0x05f2 }
            long r9 = r3.a     // Catch:{ all -> 0x05f2 }
            r4 = r14
            r7 = r27
            r13 = r30
            r4.<init>((defpackage.w01) r5, (java.lang.String) r6, (java.lang.String) r7, (java.lang.String) r8, (long) r9, (long) r11, (android.os.Bundle) r13)     // Catch:{ all -> 0x05f2 }
            mg0 r4 = defpackage.ng0.K()     // Catch:{ all -> 0x05f2 }
            long r5 = r14.a     // Catch:{ all -> 0x05f2 }
            r4.K(r5)     // Catch:{ all -> 0x05f2 }
            java.lang.String r5 = r14.f3579b     // Catch:{ all -> 0x05f2 }
            r4.H(r5)     // Catch:{ all -> 0x05f2 }
            long r5 = r14.b     // Catch:{ all -> 0x05f2 }
            r4.M(r5)     // Catch:{ all -> 0x05f2 }
            nv0 r5 = r14.f3578a     // Catch:{ all -> 0x05f2 }
            mv0 r6 = new mv0     // Catch:{ all -> 0x05f2 }
            r6.<init>(r5)     // Catch:{ all -> 0x05f2 }
        L_0x04b3:
            boolean r5 = r6.hasNext()     // Catch:{ all -> 0x05f2 }
            if (r5 == 0) goto L_0x04d9
            java.lang.String r5 = r6.next()     // Catch:{ all -> 0x05f2 }
            qg0 r7 = defpackage.rg0.M()     // Catch:{ all -> 0x05f2 }
            r7.r(r5)     // Catch:{ all -> 0x05f2 }
            nv0 r8 = r14.f3578a     // Catch:{ all -> 0x05f2 }
            java.lang.Object r5 = r8.A0(r5)     // Catch:{ all -> 0x05f2 }
            if (r5 == 0) goto L_0x04b3
            s51 r8 = r2.a     // Catch:{ all -> 0x05f2 }
            u51 r8 = r8.Z()     // Catch:{ all -> 0x05f2 }
            r8.w(r7, r5)     // Catch:{ all -> 0x05f2 }
            r4.A(r7)     // Catch:{ all -> 0x05f2 }
            goto L_0x04b3
        L_0x04d9:
            r5 = r28
            r5.r0(r4)     // Catch:{ all -> 0x05f2 }
            wg0 r6 = defpackage.bh0.A()     // Catch:{ all -> 0x05f2 }
            og0 r7 = defpackage.pg0.A()     // Catch:{ all -> 0x05f2 }
            long r8 = r0.a     // Catch:{ all -> 0x05f2 }
            r7.s(r8)     // Catch:{ all -> 0x05f2 }
            java.lang.String r0 = r3.f4541a     // Catch:{ all -> 0x05f2 }
            r7.r(r0)     // Catch:{ all -> 0x05f2 }
            r6.r(r7)     // Catch:{ all -> 0x05f2 }
            r5.g0(r6)     // Catch:{ all -> 0x05f2 }
            s51 r0 = r2.a     // Catch:{ all -> 0x05f2 }
            p61 r6 = r0.X()     // Catch:{ all -> 0x05f2 }
            java.lang.String r7 = r23.N()     // Catch:{ all -> 0x05f2 }
            java.util.List r8 = java.util.Collections.emptyList()     // Catch:{ all -> 0x05f2 }
            java.util.List r9 = r5.v0()     // Catch:{ all -> 0x05f2 }
            long r10 = r4.J()     // Catch:{ all -> 0x05f2 }
            java.lang.Long r10 = java.lang.Long.valueOf(r10)     // Catch:{ all -> 0x05f2 }
            long r11 = r4.J()     // Catch:{ all -> 0x05f2 }
            java.lang.Long r11 = java.lang.Long.valueOf(r11)     // Catch:{ all -> 0x05f2 }
            java.util.List r0 = r6.m(r7, r8, r9, r10, r11)     // Catch:{ all -> 0x05f2 }
            r5.U(r0)     // Catch:{ all -> 0x05f2 }
            boolean r0 = r4.I()     // Catch:{ all -> 0x05f2 }
            if (r0 == 0) goto L_0x0533
            long r6 = r4.J()     // Catch:{ all -> 0x05f2 }
            r5.F0(r6)     // Catch:{ all -> 0x05f2 }
            long r3 = r4.J()     // Catch:{ all -> 0x05f2 }
            r5.H0(r3)     // Catch:{ all -> 0x05f2 }
        L_0x0533:
            long r3 = r23.c0()     // Catch:{ all -> 0x05f2 }
            int r0 = (r3 > r24 ? 1 : (r3 == r24 ? 0 : -1))
            if (r0 == 0) goto L_0x053e
            r5.K0(r3)     // Catch:{ all -> 0x05f2 }
        L_0x053e:
            long r6 = r23.a0()     // Catch:{ all -> 0x05f2 }
            int r0 = (r6 > r24 ? 1 : (r6 == r24 ? 0 : -1))
            if (r0 == 0) goto L_0x054a
            r5.I0(r6)     // Catch:{ all -> 0x05f2 }
            goto L_0x0551
        L_0x054a:
            int r0 = (r3 > r24 ? 1 : (r3 == r24 ? 0 : -1))
            if (r0 == 0) goto L_0x0551
            r5.I0(r3)     // Catch:{ all -> 0x05f2 }
        L_0x0551:
            r23.n()     // Catch:{ all -> 0x05f2 }
            long r3 = r23.i()     // Catch:{ all -> 0x05f2 }
            int r0 = (int) r3     // Catch:{ all -> 0x05f2 }
            r5.O(r0)     // Catch:{ all -> 0x05f2 }
            w01 r0 = r2.a     // Catch:{ all -> 0x05f2 }
            bv0 r0 = r0.z()     // Catch:{ all -> 0x05f2 }
            r0.p()     // Catch:{ all -> 0x05f2 }
            r3 = 42004(0xa414, double:2.07527E-319)
            r5.G(r3)     // Catch:{ all -> 0x05f2 }
            w01 r0 = r2.a     // Catch:{ all -> 0x05f2 }
            g40 r0 = r0.b()     // Catch:{ all -> 0x05f2 }
            long r3 = r0.b()     // Catch:{ all -> 0x05f2 }
            r5.D0(r3)     // Catch:{ all -> 0x05f2 }
            r0 = 1
            r5.T(r0)     // Catch:{ all -> 0x05f2 }
            r0 = r29
            r0.s(r5)     // Catch:{ all -> 0x05f2 }
            long r3 = r5.E0()     // Catch:{ all -> 0x05f2 }
            r6 = r23
            r6.b0(r3)     // Catch:{ all -> 0x05f2 }
            long r3 = r5.G0()     // Catch:{ all -> 0x05f2 }
            r6.d0(r3)     // Catch:{ all -> 0x05f2 }
            s51 r3 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r3 = r3.V()     // Catch:{ all -> 0x05f2 }
            r3.d0(r6)     // Catch:{ all -> 0x05f2 }
            s51 r3 = r2.a     // Catch:{ all -> 0x05f2 }
            fv0 r3 = r3.V()     // Catch:{ all -> 0x05f2 }
            r3.N()     // Catch:{ all -> 0x05f2 }
            s51 r3 = r2.a
            fv0 r3 = r3.V()
            r3.O()
            s51 r3 = r2.a     // Catch:{ IOException -> 0x05c1 }
            u51 r3 = r3.Z()     // Catch:{ IOException -> 0x05c1 }
            gl0 r0 = r0.k()     // Catch:{ IOException -> 0x05c1 }
            tg0 r0 = (defpackage.tg0) r0     // Catch:{ IOException -> 0x05c1 }
            byte[] r0 = r0.g()     // Catch:{ IOException -> 0x05c1 }
            byte[] r14 = r3.I(r0)     // Catch:{ IOException -> 0x05c1 }
            goto L_0x05f1
        L_0x05c1:
            r0 = move-exception
            w01 r2 = r2.a
            nz0 r2 = r2.c()
            lz0 r2 = r2.o()
            java.lang.Object r3 = defpackage.nz0.x(r27)
            java.lang.String r4 = "Data loss. Failed to bundle and serialize. appId"
            r2.c(r4, r3, r0)
            r14 = r26
            goto L_0x05f1
        L_0x05d8:
            r0 = move-exception
            w01 r3 = r2.a     // Catch:{ all -> 0x05f2 }
            nz0 r3 = r3.c()     // Catch:{ all -> 0x05f2 }
            lz0 r3 = r3.v()     // Catch:{ all -> 0x05f2 }
            java.lang.String r4 = "app instance id encryption failed"
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x05f2 }
            r3.b(r4, r0)     // Catch:{ all -> 0x05f2 }
            r3 = 0
            byte[] r14 = new byte[r3]     // Catch:{ all -> 0x05f2 }
            goto L_0x009b
        L_0x05f1:
            return r14
        L_0x05f2:
            r0 = move-exception
            s51 r2 = r2.a
            fv0 r2 = r2.V()
            r2.O()
            goto L_0x05fe
        L_0x05fd:
            throw r0
        L_0x05fe:
            goto L_0x05fd
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.k11.call():java.lang.Object");
    }
}
