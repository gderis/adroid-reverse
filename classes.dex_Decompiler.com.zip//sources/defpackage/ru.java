package defpackage;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: ru  reason: default package */
public final class ru extends w10 {
    public static final Parcelable.Creator<ru> CREATOR = new wu();
    public Intent a;

    public ru(Intent intent) {
        this.a = intent;
    }

    public final Intent A0() {
        return this.a;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.p(parcel, 1, this.a, i, false);
        y10.b(parcel, a2);
    }
}
