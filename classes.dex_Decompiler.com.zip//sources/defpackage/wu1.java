package defpackage;

import com.raizlabs.android.dbflow.config.FlowManager;
import defpackage.ls1;
import java.util.UUID;

/* renamed from: wu1  reason: default package */
public final class wu1 extends ys1<tu1> {
    public static final ks1<String> a;

    /* renamed from: a  reason: collision with other field name */
    public static final ls1<String, UUID> f5748a;

    /* renamed from: a  reason: collision with other field name */
    public static final js1[] f5749a;
    public static final ks1<String> b;
    public static final ks1<String> c;
    public static final ks1<String> d;
    public static final ks1<Long> e;
    public static final ks1<String> f;

    /* renamed from: a  reason: collision with other field name */
    public final er1 f5750a;

    /* renamed from: wu1$a */
    public class a implements ls1.b {
        public dr1 a(Class<?> cls) {
            return ((wu1) FlowManager.e(cls)).f5750a;
        }
    }

    static {
        Class<tu1> cls = tu1.class;
        ls1<String, UUID> ls1 = new ls1<>((Class<?>) cls, "id", true, (ls1.b) new a());
        f5748a = ls1;
        ks1<String> ks1 = new ks1<>((Class<?>) cls, "name");
        a = ks1;
        ks1<String> ks12 = new ks1<>((Class<?>) cls, "message");
        b = ks12;
        ks1<String> ks13 = new ks1<>((Class<?>) cls, "time");
        c = ks13;
        ks1<String> ks14 = new ks1<>((Class<?>) cls, "date");
        d = ks14;
        ks1<Long> ks15 = new ks1<>((Class<?>) cls, "datetime");
        e = ks15;
        ks1<String> ks16 = new ks1<>((Class<?>) cls, "messageClean");
        f = ks16;
        f5749a = new js1[]{ls1, ks1, ks12, ks13, ks14, ks15, ks16};
    }

    public wu1(rq1 rq1, qq1 qq1) {
        super(qq1);
        this.f5750a = (er1) rq1.getTypeConverterForClass(UUID.class);
    }

    public final String B() {
        return "UPDATE `tableDiscord` SET `id`=?,`name`=?,`message`=?,`time`=?,`date`=?,`datetime`=?,`messageClean`=? WHERE `id`=?";
    }

    /* renamed from: H */
    public final void c(it1 it1, tu1 tu1, int i) {
        UUID uuid = tu1.f5240a;
        it1.f(i + 1, uuid != null ? this.f5750a.a(uuid) : null);
        it1.f(i + 2, tu1.f5239a);
        it1.f(i + 3, tu1.b);
        it1.f(i + 4, tu1.c);
        it1.f(i + 5, tu1.d);
        it1.e(i + 6, tu1.a);
        it1.f(i + 7, tu1.e);
    }

    /* renamed from: I */
    public final void a(it1 it1, tu1 tu1) {
        UUID uuid = tu1.f5240a;
        String b2 = uuid != null ? this.f5750a.a(uuid) : null;
        it1.f(1, b2);
        it1.f(2, tu1.f5239a);
        it1.f(3, tu1.b);
        it1.f(4, tu1.c);
        it1.f(5, tu1.d);
        it1.e(6, tu1.a);
        it1.f(7, tu1.e);
        it1.f(8, b2);
    }

    /* renamed from: J */
    public final boolean f(tu1 tu1, kt1 kt1) {
        return fs1.d(new js1[0]).a(tu1.class).q(j(tu1)).f(kt1);
    }

    /* renamed from: K */
    public final cs1 j(tu1 tu1) {
        cs1 v = cs1.v();
        UUID uuid = tu1.f5240a;
        v.s(f5748a.j().a(uuid != null ? this.f5750a.a(uuid) : null));
        return v;
    }

    /* renamed from: L */
    public final void m(lt1 lt1, tu1 tu1) {
        int columnIndex = lt1.getColumnIndex("id");
        tu1.f5240a = (columnIndex == -1 || lt1.isNull(columnIndex)) ? this.f5750a.c((String) null) : this.f5750a.c(lt1.getString(columnIndex));
        tu1.f5239a = lt1.F("name");
        tu1.b = lt1.F("message");
        tu1.c = lt1.F("time");
        tu1.d = lt1.F("date");
        tu1.a = lt1.w("datetime");
        tu1.e = lt1.F("messageClean");
    }

    /* renamed from: M */
    public final tu1 p() {
        return new tu1();
    }

    public final String b() {
        return "`tableDiscord`";
    }

    public final Class<tu1> h() {
        return tu1.class;
    }

    public final String t() {
        return "INSERT INTO `tableDiscord`(`id`,`name`,`message`,`time`,`date`,`datetime`,`messageClean`) VALUES (?,?,?,?,?,?,?)";
    }

    public final String u() {
        return "CREATE TABLE IF NOT EXISTS `tableDiscord`(`id` TEXT, `name` TEXT, `message` TEXT, `time` TEXT, `date` TEXT, `datetime` INTEGER, `messageClean` TEXT, UNIQUE(`name`,`date`,`messageClean`) ON CONFLICT FAIL, PRIMARY KEY(`id`))";
    }
}
