package defpackage;

import com.raizlabs.android.dbflow.config.FlowManager;
import defpackage.ls1;
import java.util.UUID;

/* renamed from: yv1  reason: default package */
public final class yv1 extends ys1<xv1> {
    public static final ks1<String> a;

    /* renamed from: a  reason: collision with other field name */
    public static final ls1<String, UUID> f6088a;

    /* renamed from: a  reason: collision with other field name */
    public static final js1[] f6089a;
    public static final ks1<String> b;
    public static final ks1<String> c;
    public static final ks1<Long> d;

    /* renamed from: a  reason: collision with other field name */
    public final er1 f6090a;

    /* renamed from: yv1$a */
    public class a implements ls1.b {
        public dr1 a(Class<?> cls) {
            return ((yv1) FlowManager.e(cls)).f6090a;
        }
    }

    static {
        Class<xv1> cls = xv1.class;
        ls1<String, UUID> ls1 = new ls1<>((Class<?>) cls, "id", true, (ls1.b) new a());
        f6088a = ls1;
        ks1<String> ks1 = new ks1<>((Class<?>) cls, "packagename");
        a = ks1;
        ks1<String> ks12 = new ks1<>((Class<?>) cls, "keyword");
        b = ks12;
        ks1<String> ks13 = new ks1<>((Class<?>) cls, "date");
        c = ks13;
        ks1<Long> ks14 = new ks1<>((Class<?>) cls, "datetime");
        d = ks14;
        f6089a = new js1[]{ls1, ks1, ks12, ks13, ks14};
    }

    public yv1(rq1 rq1, qq1 qq1) {
        super(qq1);
        this.f6090a = (er1) rq1.getTypeConverterForClass(UUID.class);
    }

    public final String B() {
        return "UPDATE `tableWebSearch` SET `id`=?,`packagename`=?,`keyword`=?,`date`=?,`datetime`=? WHERE `id`=?";
    }

    /* renamed from: H */
    public final void c(it1 it1, xv1 xv1, int i) {
        UUID uuid = xv1.f5908a;
        it1.f(i + 1, uuid != null ? this.f6090a.a(uuid) : null);
        it1.f(i + 2, xv1.f5907a);
        it1.f(i + 3, xv1.b);
        it1.f(i + 4, xv1.c);
        it1.e(i + 5, xv1.a);
    }

    /* renamed from: I */
    public final void a(it1 it1, xv1 xv1) {
        UUID uuid = xv1.f5908a;
        String b2 = uuid != null ? this.f6090a.a(uuid) : null;
        it1.f(1, b2);
        it1.f(2, xv1.f5907a);
        it1.f(3, xv1.b);
        it1.f(4, xv1.c);
        it1.e(5, xv1.a);
        it1.f(6, b2);
    }

    /* renamed from: J */
    public final boolean f(xv1 xv1, kt1 kt1) {
        return fs1.d(new js1[0]).a(xv1.class).q(j(xv1)).f(kt1);
    }

    /* renamed from: K */
    public final cs1 j(xv1 xv1) {
        cs1 v = cs1.v();
        UUID uuid = xv1.f5908a;
        v.s(f6088a.j().a(uuid != null ? this.f6090a.a(uuid) : null));
        return v;
    }

    /* renamed from: L */
    public final void m(lt1 lt1, xv1 xv1) {
        int columnIndex = lt1.getColumnIndex("id");
        xv1.f5908a = (columnIndex == -1 || lt1.isNull(columnIndex)) ? this.f6090a.c((String) null) : this.f6090a.c(lt1.getString(columnIndex));
        xv1.f5907a = lt1.F("packagename");
        xv1.b = lt1.F("keyword");
        xv1.c = lt1.F("date");
        xv1.a = lt1.w("datetime");
    }

    /* renamed from: M */
    public final xv1 p() {
        return new xv1();
    }

    public final String b() {
        return "`tableWebSearch`";
    }

    public final Class<xv1> h() {
        return xv1.class;
    }

    public final String t() {
        return "INSERT INTO `tableWebSearch`(`id`,`packagename`,`keyword`,`date`,`datetime`) VALUES (?,?,?,?,?)";
    }

    public final String u() {
        return "CREATE TABLE IF NOT EXISTS `tableWebSearch`(`id` TEXT, `packagename` TEXT, `keyword` TEXT, `date` TEXT, `datetime` INTEGER, UNIQUE(`packagename`,`keyword`,`date`) ON CONFLICT ROLLBACK, PRIMARY KEY(`id`))";
    }
}
