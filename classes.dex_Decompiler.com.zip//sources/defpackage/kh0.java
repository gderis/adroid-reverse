package defpackage;

import java.util.List;

/* renamed from: kh0  reason: default package */
public final class kh0 extends gl0<kh0, jh0> implements mm0 {
    /* access modifiers changed from: private */
    public static final kh0 zze;
    private nl0<mh0> zza = gl0.p();

    static {
        kh0 kh0 = new kh0();
        zze = kh0;
        gl0.x(kh0.class, kh0);
    }

    public static kh0 C() {
        return zze;
    }

    public final List<mh0> A() {
        return this.zza;
    }

    public final int B() {
        return this.zza.size();
    }

    public final Object z(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return gl0.y(zze, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zza", mh0.class});
        } else if (i2 == 3) {
            return new kh0();
        } else {
            if (i2 == 4) {
                return new jh0((ih0) null);
            }
            if (i2 != 5) {
                return null;
            }
            return zze;
        }
    }
}
