package defpackage;

import java.util.LinkedHashSet;
import java.util.Set;

/* renamed from: f52  reason: default package */
public final class f52 {
    public final Set<k42> a = new LinkedHashSet();

    public final synchronized void a(k42 k42) {
        p12.d(k42, "route");
        this.a.remove(k42);
    }

    public final synchronized void b(k42 k42) {
        p12.d(k42, "failedRoute");
        this.a.add(k42);
    }

    public final synchronized boolean c(k42 k42) {
        p12.d(k42, "route");
        return this.a.contains(k42);
    }
}
