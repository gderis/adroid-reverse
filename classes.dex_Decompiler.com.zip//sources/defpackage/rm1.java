package defpackage;

import android.text.TextUtils;
import defpackage.tm1;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: rm1  reason: default package */
public class rm1 implements sm1 {
    public static final Object a = new Object();

    /* renamed from: a  reason: collision with other field name */
    public static final ThreadFactory f4828a = new a();

    /* renamed from: a  reason: collision with other field name */
    public final cn1 f4829a;

    /* renamed from: a  reason: collision with other field name */
    public final dn1 f4830a;

    /* renamed from: a  reason: collision with other field name */
    public final hn1 f4831a;

    /* renamed from: a  reason: collision with other field name */
    public String f4832a;

    /* renamed from: a  reason: collision with other field name */
    public final List<ym1> f4833a;

    /* renamed from: a  reason: collision with other field name */
    public Set<an1> f4834a;

    /* renamed from: a  reason: collision with other field name */
    public final ExecutorService f4835a;

    /* renamed from: a  reason: collision with other field name */
    public final re1 f4836a;

    /* renamed from: a  reason: collision with other field name */
    public final xm1 f4837a;

    /* renamed from: a  reason: collision with other field name */
    public final zm1 f4838a;
    public final Object b;

    /* renamed from: b  reason: collision with other field name */
    public final ExecutorService f4839b;

    /* renamed from: rm1$a */
    public class a implements ThreadFactory {
        public final AtomicInteger a = new AtomicInteger(1);

        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, String.format("firebase-installations-executor-%d", new Object[]{Integer.valueOf(this.a.getAndIncrement())}));
        }
    }

    /* renamed from: rm1$b */
    public static /* synthetic */ class b {
        public static final /* synthetic */ int[] a;
        public static final /* synthetic */ int[] b;

        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0039 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x001d */
        static {
            /*
                kn1$b[] r0 = defpackage.kn1.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                b = r0
                r1 = 1
                kn1$b r2 = defpackage.kn1.b.OK     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = b     // Catch:{ NoSuchFieldError -> 0x001d }
                kn1$b r3 = defpackage.kn1.b.BAD_CONFIG     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r2 = b     // Catch:{ NoSuchFieldError -> 0x0028 }
                kn1$b r3 = defpackage.kn1.b.AUTH_ERROR     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r4 = 3
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                in1$b[] r2 = defpackage.in1.b.values()
                int r2 = r2.length
                int[] r2 = new int[r2]
                a = r2
                in1$b r3 = defpackage.in1.b.OK     // Catch:{ NoSuchFieldError -> 0x0039 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0039 }
                r2[r3] = r1     // Catch:{ NoSuchFieldError -> 0x0039 }
            L_0x0039:
                int[] r1 = a     // Catch:{ NoSuchFieldError -> 0x0043 }
                in1$b r2 = defpackage.in1.b.BAD_CONFIG     // Catch:{ NoSuchFieldError -> 0x0043 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0043 }
                r1[r2] = r0     // Catch:{ NoSuchFieldError -> 0x0043 }
            L_0x0043:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: defpackage.rm1.b.<clinit>():void");
        }
    }

    public rm1(ExecutorService executorService, re1 re1, hn1 hn1, dn1 dn1, zm1 zm1, cn1 cn1, xm1 xm1) {
        this.b = new Object();
        this.f4834a = new HashSet();
        this.f4833a = new ArrayList();
        this.f4836a = re1;
        this.f4831a = hn1;
        this.f4830a = dn1;
        this.f4838a = zm1;
        this.f4829a = cn1;
        this.f4837a = xm1;
        this.f4835a = executorService;
        this.f4839b = new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue(), f4828a);
    }

    public rm1(re1 re1, km1<bq1> km1, km1<gm1> km12) {
        this(new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue(), f4828a), re1, new hn1(re1.g(), km1, km12), new dn1(re1), zm1.c(), new cn1(re1), new xm1());
    }

    public static rm1 l() {
        return m(re1.h());
    }

    public static rm1 m(re1 re1) {
        s10.b(re1 != null, "Null is not a valid value of FirebaseApp.");
        return (rm1) re1.f(sm1.class);
    }

    /* access modifiers changed from: private */
    /* renamed from: t */
    public /* synthetic */ void u() {
        v(false);
    }

    public final void A(Exception exc) {
        synchronized (this.b) {
            Iterator<ym1> it = this.f4833a.iterator();
            while (it.hasNext()) {
                if (it.next().b(exc)) {
                    it.remove();
                }
            }
        }
    }

    public final void B(en1 en1) {
        synchronized (this.b) {
            Iterator<ym1> it = this.f4833a.iterator();
            while (it.hasNext()) {
                if (it.next().a(en1)) {
                    it.remove();
                }
            }
        }
    }

    public final synchronized void C(String str) {
        this.f4832a = str;
    }

    public final synchronized void D(en1 en1, en1 en12) {
        if (this.f4834a.size() != 0 && !en1.d().equals(en12.d())) {
            for (an1 a2 : this.f4834a) {
                a2.a(en12.d());
            }
        }
    }

    public n81<wm1> a(boolean z) {
        x();
        n81<wm1> c = c();
        this.f4835a.execute(new nm1(this, z));
        return c;
    }

    public n81<String> b() {
        x();
        String k = k();
        if (k != null) {
            return q81.e(k);
        }
        n81<String> d = d();
        this.f4835a.execute(new mm1(this));
        return d;
    }

    public final n81<wm1> c() {
        o81 o81 = new o81();
        e(new um1(this.f4838a, o81));
        return o81.a();
    }

    public final n81<String> d() {
        o81 o81 = new o81();
        e(new vm1(o81));
        return o81.a();
    }

    public final void e(ym1 ym1) {
        synchronized (this.b) {
            this.f4833a.add(ym1);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x003f  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x004a  */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void r(boolean r3) {
        /*
            r2 = this;
            en1 r0 = r2.n()
            boolean r1 = r0.i()     // Catch:{ tm1 -> 0x005c }
            if (r1 != 0) goto L_0x0022
            boolean r1 = r0.l()     // Catch:{ tm1 -> 0x005c }
            if (r1 == 0) goto L_0x0011
            goto L_0x0022
        L_0x0011:
            if (r3 != 0) goto L_0x001d
            zm1 r3 = r2.f4838a     // Catch:{ tm1 -> 0x005c }
            boolean r3 = r3.f(r0)     // Catch:{ tm1 -> 0x005c }
            if (r3 == 0) goto L_0x001c
            goto L_0x001d
        L_0x001c:
            return
        L_0x001d:
            en1 r3 = r2.h(r0)     // Catch:{ tm1 -> 0x005c }
            goto L_0x0026
        L_0x0022:
            en1 r3 = r2.z(r0)     // Catch:{ tm1 -> 0x005c }
        L_0x0026:
            r2.q(r3)
            r2.D(r0, r3)
            boolean r0 = r3.k()
            if (r0 == 0) goto L_0x0039
            java.lang.String r0 = r3.d()
            r2.C(r0)
        L_0x0039:
            boolean r0 = r3.i()
            if (r0 == 0) goto L_0x004a
            tm1 r3 = new tm1
            tm1$a r0 = defpackage.tm1.a.BAD_CONFIG
            r3.<init>(r0)
        L_0x0046:
            r2.A(r3)
            goto L_0x005b
        L_0x004a:
            boolean r0 = r3.j()
            if (r0 == 0) goto L_0x0058
            java.io.IOException r3 = new java.io.IOException
            java.lang.String r0 = "Installation ID could not be validated with the Firebase servers (maybe it was deleted). Firebase Installations will need to create a new Installation ID and auth token. Please retry your last request."
            r3.<init>(r0)
            goto L_0x0046
        L_0x0058:
            r2.B(r3)
        L_0x005b:
            return
        L_0x005c:
            r3 = move-exception
            r2.A(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.rm1.r(boolean):void");
    }

    /* renamed from: g */
    public final void v(boolean z) {
        en1 o = o();
        if (z) {
            o = o.p();
        }
        B(o);
        this.f4839b.execute(new lm1(this, z));
    }

    public final en1 h(en1 en1) {
        kn1 e = this.f4831a.e(i(), en1.d(), p(), en1.f());
        int i = b.b[e.b().ordinal()];
        if (i == 1) {
            return en1.o(e.c(), e.d(), this.f4838a.b());
        } else if (i == 2) {
            return en1.q("BAD CONFIG");
        } else {
            if (i == 3) {
                C((String) null);
                return en1.r();
            }
            throw new tm1("Firebase Installations Service is unavailable. Please try again later.", tm1.a.UNAVAILABLE);
        }
    }

    public String i() {
        return this.f4836a.j().b();
    }

    public String j() {
        return this.f4836a.j().c();
    }

    public final synchronized String k() {
        return this.f4832a;
    }

    public final en1 n() {
        en1 c;
        synchronized (a) {
            qm1 a2 = qm1.a(this.f4836a.g(), "generatefid.lock");
            try {
                c = this.f4830a.c();
                if (a2 != null) {
                    a2.b();
                }
            } catch (Throwable th) {
                if (a2 != null) {
                    a2.b();
                }
                throw th;
            }
        }
        return c;
    }

    public final en1 o() {
        en1 c;
        synchronized (a) {
            qm1 a2 = qm1.a(this.f4836a.g(), "generatefid.lock");
            try {
                c = this.f4830a.c();
                if (c.j()) {
                    c = this.f4830a.a(c.t(y(c)));
                }
                if (a2 != null) {
                    a2.b();
                }
            } catch (Throwable th) {
                if (a2 != null) {
                    a2.b();
                }
                throw th;
            }
        }
        return c;
    }

    public String p() {
        return this.f4836a.j().e();
    }

    public final void q(en1 en1) {
        synchronized (a) {
            qm1 a2 = qm1.a(this.f4836a.g(), "generatefid.lock");
            try {
                this.f4830a.a(en1);
                if (a2 != null) {
                    a2.b();
                }
            } catch (Throwable th) {
                if (a2 != null) {
                    a2.b();
                }
                throw th;
            }
        }
    }

    public final void x() {
        s10.g(j(), "Please set your Application ID. A valid Firebase App ID is required to communicate with Firebase server APIs: It identifies your application with Firebase.Please refer to https://firebase.google.com/support/privacy/init-options.");
        s10.g(p(), "Please set your Project ID. A valid Firebase Project ID is required to communicate with Firebase server APIs: It identifies your application with Firebase.Please refer to https://firebase.google.com/support/privacy/init-options.");
        s10.g(i(), "Please set a valid API key. A Firebase API key is required to communicate with Firebase server APIs: It authenticates your project with Google.Please refer to https://firebase.google.com/support/privacy/init-options.");
        s10.b(zm1.h(j()), "Please set your Application ID. A valid Firebase App ID is required to communicate with Firebase server APIs: It identifies your application with Firebase.Please refer to https://firebase.google.com/support/privacy/init-options.");
        s10.b(zm1.g(i()), "Please set a valid API key. A Firebase API key is required to communicate with Firebase server APIs: It authenticates your project with Google.Please refer to https://firebase.google.com/support/privacy/init-options.");
    }

    public final String y(en1 en1) {
        if ((!this.f4836a.i().equals("CHIME_ANDROID_SDK") && !this.f4836a.q()) || !en1.m()) {
            return this.f4837a.a();
        }
        String f = this.f4829a.f();
        return TextUtils.isEmpty(f) ? this.f4837a.a() : f;
    }

    public final en1 z(en1 en1) {
        in1 d = this.f4831a.d(i(), en1.d(), p(), j(), (en1.d() == null || en1.d().length() != 11) ? null : this.f4829a.i());
        int i = b.a[d.e().ordinal()];
        if (i == 1) {
            return en1.s(d.c(), d.d(), this.f4838a.b(), d.b().c(), d.b().d());
        } else if (i == 2) {
            return en1.q("BAD CONFIG");
        } else {
            throw new tm1("Firebase Installations Service is unavailable. Please try again later.", tm1.a.UNAVAILABLE);
        }
    }
}
