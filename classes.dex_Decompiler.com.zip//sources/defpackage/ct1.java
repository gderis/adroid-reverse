package defpackage;

import android.database.sqlite.SQLiteDatabase;

/* renamed from: ct1  reason: default package */
public class ct1 implements kt1 {
    public final SQLiteDatabase a;

    public ct1(SQLiteDatabase sQLiteDatabase) {
        this.a = sQLiteDatabase;
    }

    public static ct1 f(SQLiteDatabase sQLiteDatabase) {
        return new ct1(sQLiteDatabase);
    }

    public lt1 a(String str, String[] strArr) {
        return lt1.a(this.a.rawQuery(str, strArr));
    }

    public void b() {
        this.a.endTransaction();
    }

    public int c() {
        return this.a.getVersion();
    }

    public void d() {
        this.a.beginTransaction();
    }

    public it1 e(String str) {
        return dt1.i(this.a.compileStatement(str), this.a);
    }

    public SQLiteDatabase g() {
        return this.a;
    }

    public void i() {
        this.a.setTransactionSuccessful();
    }

    public void j(String str) {
        this.a.execSQL(str);
    }
}
