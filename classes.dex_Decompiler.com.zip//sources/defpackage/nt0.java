package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RecentlyNonNull;

/* renamed from: nt0  reason: default package */
public final class nt0 extends w10 {
    @RecentlyNonNull
    public static final Parcelable.Creator<nt0> CREATOR = new ku0();
    public final boolean b;
    public final boolean c;
    public final boolean d;
    public final boolean e;
    public final boolean f;
    public final boolean g;

    public nt0(boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6) {
        this.b = z;
        this.c = z2;
        this.d = z3;
        this.e = z4;
        this.f = z5;
        this.g = z6;
    }

    public boolean A0() {
        return this.g;
    }

    public boolean B0() {
        return this.d;
    }

    public boolean C0() {
        return this.e;
    }

    public boolean D0() {
        return this.b;
    }

    public boolean E0() {
        return this.f;
    }

    public boolean F0() {
        return this.c;
    }

    public void writeToParcel(@RecentlyNonNull Parcel parcel, int i) {
        int a = y10.a(parcel);
        y10.c(parcel, 1, D0());
        y10.c(parcel, 2, F0());
        y10.c(parcel, 3, B0());
        y10.c(parcel, 4, C0());
        y10.c(parcel, 5, E0());
        y10.c(parcel, 6, A0());
        y10.b(parcel, a);
    }
}
