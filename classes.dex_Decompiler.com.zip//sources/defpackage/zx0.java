package defpackage;

import android.os.Bundle;
import java.util.Map;

/* renamed from: zx0  reason: default package */
public final class zx0 extends az0 {
    public long a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<String, Long> f6279a = new o4();
    public final Map<String, Integer> b = new o4();

    public zx0(w01 w01) {
        super(w01);
    }

    public static /* synthetic */ void l(zx0 zx0, String str, long j) {
        zx0.h();
        s10.f(str);
        if (zx0.b.isEmpty()) {
            zx0.a = j;
        }
        Integer num = zx0.b.get(str);
        if (num != null) {
            zx0.b.put(str, Integer.valueOf(num.intValue() + 1));
        } else if (zx0.b.size() >= 100) {
            zx0.a.c().r().a("Too many ads visible");
        } else {
            zx0.b.put(str, 1);
            zx0.f6279a.put(str, Long.valueOf(j));
        }
    }

    public static /* synthetic */ void m(zx0 zx0, String str, long j) {
        zx0.h();
        s10.f(str);
        Integer num = zx0.b.get(str);
        if (num != null) {
            h31 s = zx0.a.Q().s(false);
            int intValue = num.intValue() - 1;
            if (intValue == 0) {
                zx0.b.remove(str);
                Long l = zx0.f6279a.get(str);
                if (l == null) {
                    zx0.a.c().o().a("First ad unit exposure time was never set");
                } else {
                    long longValue = l.longValue();
                    zx0.f6279a.remove(str);
                    zx0.p(str, j - longValue, s);
                }
                if (zx0.b.isEmpty()) {
                    long j2 = zx0.a;
                    if (j2 == 0) {
                        zx0.a.c().o().a("First ad exposure time was never set");
                        return;
                    }
                    zx0.o(j - j2, s);
                    zx0.a = 0;
                    return;
                }
                return;
            }
            zx0.b.put(str, Integer.valueOf(intValue));
            return;
        }
        zx0.a.c().o().b("Call to endAdUnitExposure for unknown ad unit id", str);
    }

    public final void i(String str, long j) {
        if (str == null || str.length() == 0) {
            this.a.c().o().a("Ad unit id must be a non-empty string");
        } else {
            this.a.f().r(new wu0(this, str, j));
        }
    }

    public final void j(String str, long j) {
        if (str == null || str.length() == 0) {
            this.a.c().o().a("Ad unit id must be a non-empty string");
        } else {
            this.a.f().r(new xv0(this, str, j));
        }
    }

    public final void k(long j) {
        h31 s = this.a.Q().s(false);
        for (String next : this.f6279a.keySet()) {
            p(next, j - this.f6279a.get(next).longValue(), s);
        }
        if (!this.f6279a.isEmpty()) {
            o(j - this.a, s);
        }
        q(j);
    }

    public final void o(long j, h31 h31) {
        if (h31 == null) {
            this.a.c().w().a("Not logging ad exposure. No active activity");
        } else if (j < 1000) {
            this.a.c().w().b("Not logging ad exposure. Less than 1000 ms. exposure", Long.valueOf(j));
        } else {
            Bundle bundle = new Bundle();
            bundle.putLong("_xt", j);
            o31.x(h31, bundle, true);
            this.a.F().X("am", "_xa", bundle);
        }
    }

    public final void p(String str, long j, h31 h31) {
        if (h31 == null) {
            this.a.c().w().a("Not logging ad unit exposure. No active activity");
        } else if (j < 1000) {
            this.a.c().w().b("Not logging ad unit exposure. Less than 1000 ms. exposure", Long.valueOf(j));
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("_ai", str);
            bundle.putLong("_xt", j);
            o31.x(h31, bundle, true);
            this.a.F().X("am", "_xu", bundle);
        }
    }

    public final void q(long j) {
        for (String put : this.f6279a.keySet()) {
            this.f6279a.put(put, Long.valueOf(j));
        }
        if (!this.f6279a.isEmpty()) {
            this.a = j;
        }
    }
}
