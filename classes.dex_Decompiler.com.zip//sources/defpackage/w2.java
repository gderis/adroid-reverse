package defpackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: w2  reason: default package */
public class w2 {
    public static final RectF a = new RectF();
    @SuppressLint({"BanConcurrentHashMap"})

    /* renamed from: a  reason: collision with other field name */
    public static ConcurrentHashMap<String, Method> f5662a = new ConcurrentHashMap<>();
    @SuppressLint({"BanConcurrentHashMap"})
    public static ConcurrentHashMap<String, Field> b = new ConcurrentHashMap<>();

    /* renamed from: a  reason: collision with other field name */
    public float f5663a = -1.0f;

    /* renamed from: a  reason: collision with other field name */
    public int f5664a = 0;

    /* renamed from: a  reason: collision with other field name */
    public final Context f5665a;

    /* renamed from: a  reason: collision with other field name */
    public TextPaint f5666a;

    /* renamed from: a  reason: collision with other field name */
    public final TextView f5667a;

    /* renamed from: a  reason: collision with other field name */
    public final c f5668a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f5669a = false;

    /* renamed from: a  reason: collision with other field name */
    public int[] f5670a = new int[0];

    /* renamed from: b  reason: collision with other field name */
    public float f5671b = -1.0f;

    /* renamed from: b  reason: collision with other field name */
    public boolean f5672b = false;
    public float c = -1.0f;

    /* renamed from: w2$a */
    public static class a extends c {
        public void a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection((TextDirectionHeuristic) w2.r(textView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
        }
    }

    /* renamed from: w2$b */
    public static class b extends a {
        public void a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection(textView.getTextDirectionHeuristic());
        }

        public boolean b(TextView textView) {
            return textView.isHorizontallyScrollable();
        }
    }

    /* renamed from: w2$c */
    public static class c {
        public void a(StaticLayout.Builder builder, TextView textView) {
        }

        public boolean b(TextView textView) {
            return ((Boolean) w2.r(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
        }
    }

    public w2(TextView textView) {
        this.f5667a = textView;
        this.f5665a = textView.getContext();
        int i = Build.VERSION.SDK_INT;
        this.f5668a = i >= 29 ? new b() : i >= 23 ? new a() : new c();
    }

    public static <T> T a(Object obj, String str, T t) {
        try {
            Field o = o(str);
            return o == null ? t : o.get(obj);
        } catch (IllegalAccessException unused) {
            "Failed to access TextView#" + str + " member";
            return t;
        }
    }

    public static Field o(String str) {
        try {
            Field field = b.get(str);
            if (field == null && (field = TextView.class.getDeclaredField(str)) != null) {
                field.setAccessible(true);
                b.put(str, field);
            }
            return field;
        } catch (NoSuchFieldException unused) {
            "Failed to access TextView#" + str + " member";
            return null;
        }
    }

    public static Method p(String str) {
        try {
            Method method = f5662a.get(str);
            if (method == null && (method = TextView.class.getDeclaredMethod(str, new Class[0])) != null) {
                method.setAccessible(true);
                f5662a.put(str, method);
            }
            return method;
        } catch (Exception unused) {
            "Failed to retrieve TextView#" + str + "() method";
            return null;
        }
    }

    public static <T> T r(Object obj, String str, T t) {
        try {
            return p(str).invoke(obj, new Object[0]);
        } catch (Exception unused) {
            "Failed to invoke TextView#" + str + "() method";
            return t;
        }
    }

    public final void A(TypedArray typedArray) {
        int length = typedArray.length();
        int[] iArr = new int[length];
        if (length > 0) {
            for (int i = 0; i < length; i++) {
                iArr[i] = typedArray.getDimensionPixelSize(i, -1);
            }
            this.f5670a = c(iArr);
            B();
        }
    }

    public final boolean B() {
        int[] iArr = this.f5670a;
        int length = iArr.length;
        boolean z = length > 0;
        this.f5672b = z;
        if (z) {
            this.f5664a = 1;
            this.f5671b = (float) iArr[0];
            this.c = (float) iArr[length - 1];
            this.f5663a = -1.0f;
        }
        return z;
    }

    public final boolean C(int i, RectF rectF) {
        CharSequence transformation;
        CharSequence text = this.f5667a.getText();
        TransformationMethod transformationMethod = this.f5667a.getTransformationMethod();
        if (!(transformationMethod == null || (transformation = transformationMethod.getTransformation(text, this.f5667a)) == null)) {
            text = transformation;
        }
        int maxLines = Build.VERSION.SDK_INT >= 16 ? this.f5667a.getMaxLines() : -1;
        q(i);
        StaticLayout e = e(text, (Layout.Alignment) r(this.f5667a, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(rectF.right), maxLines);
        return (maxLines == -1 || (e.getLineCount() <= maxLines && e.getLineEnd(e.getLineCount() - 1) == text.length())) && ((float) e.getHeight()) <= rectF.bottom;
    }

    public final boolean D() {
        return !(this.f5667a instanceof f2);
    }

    public final void E(float f, float f2, float f3) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f + "px) is less or equal to (0px)");
        } else if (f2 <= f) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f2 + "px) is less or equal to minimum auto-size text size (" + f + "px)");
        } else if (f3 > 0.0f) {
            this.f5664a = 1;
            this.f5671b = f;
            this.c = f2;
            this.f5663a = f3;
            this.f5672b = false;
        } else {
            throw new IllegalArgumentException("The auto-size step granularity (" + f3 + "px) is less or equal to (0px)");
        }
    }

    public void b() {
        if (s()) {
            if (this.f5669a) {
                if (this.f5667a.getMeasuredHeight() > 0 && this.f5667a.getMeasuredWidth() > 0) {
                    int measuredWidth = this.f5668a.b(this.f5667a) ? 1048576 : (this.f5667a.getMeasuredWidth() - this.f5667a.getTotalPaddingLeft()) - this.f5667a.getTotalPaddingRight();
                    int height = (this.f5667a.getHeight() - this.f5667a.getCompoundPaddingBottom()) - this.f5667a.getCompoundPaddingTop();
                    if (measuredWidth > 0 && height > 0) {
                        RectF rectF = a;
                        synchronized (rectF) {
                            rectF.setEmpty();
                            rectF.right = (float) measuredWidth;
                            rectF.bottom = (float) height;
                            float i = (float) i(rectF);
                            if (i != this.f5667a.getTextSize()) {
                                y(0, i);
                            }
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f5669a = true;
        }
    }

    public final int[] c(int[] iArr) {
        if (r0 == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            if (i > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i)) < 0) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        if (r0 == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            iArr2[i2] = ((Integer) arrayList.get(i2)).intValue();
        }
        return iArr2;
    }

    public final void d() {
        this.f5664a = 0;
        this.f5671b = -1.0f;
        this.c = -1.0f;
        this.f5663a = -1.0f;
        this.f5670a = new int[0];
        this.f5669a = false;
    }

    public StaticLayout e(CharSequence charSequence, Layout.Alignment alignment, int i, int i2) {
        int i3 = Build.VERSION.SDK_INT;
        return i3 >= 23 ? f(charSequence, alignment, i, i2) : i3 >= 16 ? h(charSequence, alignment, i) : g(charSequence, alignment, i);
    }

    public final StaticLayout f(CharSequence charSequence, Layout.Alignment alignment, int i, int i2) {
        StaticLayout.Builder obtain = StaticLayout.Builder.obtain(charSequence, 0, charSequence.length(), this.f5666a, i);
        StaticLayout.Builder hyphenationFrequency = obtain.setAlignment(alignment).setLineSpacing(this.f5667a.getLineSpacingExtra(), this.f5667a.getLineSpacingMultiplier()).setIncludePad(this.f5667a.getIncludeFontPadding()).setBreakStrategy(this.f5667a.getBreakStrategy()).setHyphenationFrequency(this.f5667a.getHyphenationFrequency());
        if (i2 == -1) {
            i2 = Integer.MAX_VALUE;
        }
        hyphenationFrequency.setMaxLines(i2);
        try {
            this.f5668a.a(obtain, this.f5667a);
        } catch (ClassCastException unused) {
        }
        return obtain.build();
    }

    public final StaticLayout g(CharSequence charSequence, Layout.Alignment alignment, int i) {
        return new StaticLayout(charSequence, this.f5666a, i, alignment, ((Float) a(this.f5667a, "mSpacingMult", Float.valueOf(1.0f))).floatValue(), ((Float) a(this.f5667a, "mSpacingAdd", Float.valueOf(0.0f))).floatValue(), ((Boolean) a(this.f5667a, "mIncludePad", Boolean.TRUE)).booleanValue());
    }

    public final StaticLayout h(CharSequence charSequence, Layout.Alignment alignment, int i) {
        return new StaticLayout(charSequence, this.f5666a, i, alignment, this.f5667a.getLineSpacingMultiplier(), this.f5667a.getLineSpacingExtra(), this.f5667a.getIncludeFontPadding());
    }

    public final int i(RectF rectF) {
        int length = this.f5670a.length;
        if (length != 0) {
            int i = length - 1;
            int i2 = 1;
            int i3 = 0;
            while (i2 <= i) {
                int i4 = (i2 + i) / 2;
                if (C(this.f5670a[i4], rectF)) {
                    int i5 = i4 + 1;
                    i3 = i2;
                    i2 = i5;
                } else {
                    i3 = i4 - 1;
                    i = i3;
                }
            }
            return this.f5670a[i3];
        }
        throw new IllegalStateException("No available text sizes to choose from.");
    }

    public int j() {
        return Math.round(this.c);
    }

    public int k() {
        return Math.round(this.f5671b);
    }

    public int l() {
        return Math.round(this.f5663a);
    }

    public int[] m() {
        return this.f5670a;
    }

    public int n() {
        return this.f5664a;
    }

    public void q(int i) {
        TextPaint textPaint = this.f5666a;
        if (textPaint == null) {
            this.f5666a = new TextPaint();
        } else {
            textPaint.reset();
        }
        this.f5666a.set(this.f5667a.getPaint());
        this.f5666a.setTextSize((float) i);
    }

    public boolean s() {
        return D() && this.f5664a != 0;
    }

    public void t(AttributeSet attributeSet, int i) {
        int resourceId;
        Context context = this.f5665a;
        int[] iArr = x.AppCompatTextView;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        TextView textView = this.f5667a;
        ya.m0(textView, textView.getContext(), iArr, attributeSet, obtainStyledAttributes, i, 0);
        int i2 = x.AppCompatTextView_autoSizeTextType;
        if (obtainStyledAttributes.hasValue(i2)) {
            this.f5664a = obtainStyledAttributes.getInt(i2, 0);
        }
        int i3 = x.AppCompatTextView_autoSizeStepGranularity;
        float dimension = obtainStyledAttributes.hasValue(i3) ? obtainStyledAttributes.getDimension(i3, -1.0f) : -1.0f;
        int i4 = x.AppCompatTextView_autoSizeMinTextSize;
        float dimension2 = obtainStyledAttributes.hasValue(i4) ? obtainStyledAttributes.getDimension(i4, -1.0f) : -1.0f;
        int i5 = x.AppCompatTextView_autoSizeMaxTextSize;
        float dimension3 = obtainStyledAttributes.hasValue(i5) ? obtainStyledAttributes.getDimension(i5, -1.0f) : -1.0f;
        int i6 = x.AppCompatTextView_autoSizePresetSizes;
        if (obtainStyledAttributes.hasValue(i6) && (resourceId = obtainStyledAttributes.getResourceId(i6, 0)) > 0) {
            TypedArray obtainTypedArray = obtainStyledAttributes.getResources().obtainTypedArray(resourceId);
            A(obtainTypedArray);
            obtainTypedArray.recycle();
        }
        obtainStyledAttributes.recycle();
        if (!D()) {
            this.f5664a = 0;
        } else if (this.f5664a == 1) {
            if (!this.f5672b) {
                DisplayMetrics displayMetrics = this.f5665a.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(2, 112.0f, displayMetrics);
                }
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                E(dimension2, dimension3, dimension);
            }
            z();
        }
    }

    public void u(int i, int i2, int i3, int i4) {
        if (D()) {
            DisplayMetrics displayMetrics = this.f5665a.getResources().getDisplayMetrics();
            E(TypedValue.applyDimension(i4, (float) i, displayMetrics), TypedValue.applyDimension(i4, (float) i2, displayMetrics), TypedValue.applyDimension(i4, (float) i3, displayMetrics));
            if (z()) {
                b();
            }
        }
    }

    public void v(int[] iArr, int i) {
        if (D()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = this.f5665a.getResources().getDisplayMetrics();
                    for (int i2 = 0; i2 < length; i2++) {
                        iArr2[i2] = Math.round(TypedValue.applyDimension(i, (float) iArr[i2], displayMetrics));
                    }
                }
                this.f5670a = c(iArr2);
                if (!B()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                this.f5672b = false;
            }
            if (z()) {
                b();
            }
        }
    }

    public void w(int i) {
        if (!D()) {
            return;
        }
        if (i == 0) {
            d();
        } else if (i == 1) {
            DisplayMetrics displayMetrics = this.f5665a.getResources().getDisplayMetrics();
            E(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (z()) {
                b();
            }
        } else {
            throw new IllegalArgumentException("Unknown auto-size text type: " + i);
        }
    }

    public final void x(float f) {
        if (f != this.f5667a.getPaint().getTextSize()) {
            this.f5667a.getPaint().setTextSize(f);
            boolean isInLayout = Build.VERSION.SDK_INT >= 18 ? this.f5667a.isInLayout() : false;
            if (this.f5667a.getLayout() != null) {
                this.f5669a = false;
                try {
                    Method p = p("nullLayouts");
                    if (p != null) {
                        p.invoke(this.f5667a, new Object[0]);
                    }
                } catch (Exception unused) {
                }
                if (!isInLayout) {
                    this.f5667a.requestLayout();
                } else {
                    this.f5667a.forceLayout();
                }
                this.f5667a.invalidate();
            }
        }
    }

    public void y(int i, float f) {
        Context context = this.f5665a;
        x(TypedValue.applyDimension(i, f, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics()));
    }

    public final boolean z() {
        if (!D() || this.f5664a != 1) {
            this.f5669a = false;
        } else {
            if (!this.f5672b || this.f5670a.length == 0) {
                int floor = ((int) Math.floor((double) ((this.c - this.f5671b) / this.f5663a))) + 1;
                int[] iArr = new int[floor];
                for (int i = 0; i < floor; i++) {
                    iArr[i] = Math.round(this.f5671b + (((float) i) * this.f5663a));
                }
                this.f5670a = c(iArr);
            }
            this.f5669a = true;
        }
        return this.f5669a;
    }
}
