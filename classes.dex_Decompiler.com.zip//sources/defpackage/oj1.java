package defpackage;

import android.util.JsonReader;
import defpackage.tj1;

/* renamed from: oj1  reason: default package */
public final /* synthetic */ class oj1 implements tj1.a {
    public static final /* synthetic */ oj1 a = new oj1();

    public final Object a(JsonReader jsonReader) {
        return tj1.s(jsonReader);
    }
}
