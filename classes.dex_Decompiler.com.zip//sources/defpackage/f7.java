package defpackage;

import android.app.Activity;
import android.app.Application;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/* renamed from: f7  reason: default package */
public final class f7 {
    public static final Handler a = new Handler(Looper.getMainLooper());

    /* renamed from: a  reason: collision with other field name */
    public static final Class<?> f2419a;

    /* renamed from: a  reason: collision with other field name */
    public static final Field f2420a = b();

    /* renamed from: a  reason: collision with other field name */
    public static final Method f2421a;
    public static final Field b = f();

    /* renamed from: b  reason: collision with other field name */
    public static final Method f2422b;
    public static final Method c;

    /* renamed from: f7$a */
    public class a implements Runnable {
        public final /* synthetic */ d a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ Object f2423a;

        public a(d dVar, Object obj) {
            this.a = dVar;
            this.f2423a = obj;
        }

        public void run() {
            this.a.f2426a = this.f2423a;
        }
    }

    /* renamed from: f7$b */
    public class b implements Runnable {
        public final /* synthetic */ Application a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ d f2424a;

        public b(Application application, d dVar) {
            this.a = application;
            this.f2424a = dVar;
        }

        public void run() {
            this.a.unregisterActivityLifecycleCallbacks(this.f2424a);
        }
    }

    /* renamed from: f7$c */
    public class c implements Runnable {
        public final /* synthetic */ Object a;
        public final /* synthetic */ Object b;

        public c(Object obj, Object obj2) {
            this.a = obj;
            this.b = obj2;
        }

        public void run() {
            try {
                Method method = f7.f2421a;
                if (method != null) {
                    method.invoke(this.a, new Object[]{this.b, Boolean.FALSE, "AppCompat recreation"});
                    return;
                }
                f7.f2422b.invoke(this.a, new Object[]{this.b, Boolean.FALSE});
            } catch (RuntimeException e) {
                if (e.getClass() == RuntimeException.class && e.getMessage() != null && e.getMessage().startsWith("Unable to stop")) {
                    throw e;
                }
            } catch (Throwable unused) {
            }
        }
    }

    /* renamed from: f7$d */
    public static final class d implements Application.ActivityLifecycleCallbacks {
        public final int a;

        /* renamed from: a  reason: collision with other field name */
        public Activity f2425a;

        /* renamed from: a  reason: collision with other field name */
        public Object f2426a;
        public boolean b = false;
        public boolean c = false;
        public boolean d = false;

        public d(Activity activity) {
            this.f2425a = activity;
            this.a = activity.hashCode();
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        public void onActivityDestroyed(Activity activity) {
            if (this.f2425a == activity) {
                this.f2425a = null;
                this.c = true;
            }
        }

        public void onActivityPaused(Activity activity) {
            if (this.c && !this.d && !this.b && f7.h(this.f2426a, this.a, activity)) {
                this.d = true;
                this.f2426a = null;
            }
        }

        public void onActivityResumed(Activity activity) {
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        public void onActivityStarted(Activity activity) {
            if (this.f2425a == activity) {
                this.b = true;
            }
        }

        public void onActivityStopped(Activity activity) {
        }
    }

    static {
        Class<?> a2 = a();
        f2419a = a2;
        f2421a = d(a2);
        f2422b = c(a2);
        c = e(a2);
    }

    public static Class<?> a() {
        try {
            return Class.forName("android.app.ActivityThread");
        } catch (Throwable unused) {
            return null;
        }
    }

    public static Field b() {
        try {
            Field declaredField = Activity.class.getDeclaredField("mMainThread");
            declaredField.setAccessible(true);
            return declaredField;
        } catch (Throwable unused) {
            return null;
        }
    }

    public static Method c(Class<?> cls) {
        if (cls == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("performStopActivity", new Class[]{IBinder.class, Boolean.TYPE});
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (Throwable unused) {
            return null;
        }
    }

    public static Method d(Class<?> cls) {
        if (cls == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("performStopActivity", new Class[]{IBinder.class, Boolean.TYPE, String.class});
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (Throwable unused) {
            return null;
        }
    }

    public static Method e(Class<?> cls) {
        if (g() && cls != null) {
            try {
                Class cls2 = Boolean.TYPE;
                Method declaredMethod = cls.getDeclaredMethod("requestRelaunchActivity", new Class[]{IBinder.class, List.class, List.class, Integer.TYPE, cls2, Configuration.class, Configuration.class, cls2, cls2});
                declaredMethod.setAccessible(true);
                return declaredMethod;
            } catch (Throwable unused) {
            }
        }
        return null;
    }

    public static Field f() {
        try {
            Field declaredField = Activity.class.getDeclaredField("mToken");
            declaredField.setAccessible(true);
            return declaredField;
        } catch (Throwable unused) {
            return null;
        }
    }

    public static boolean g() {
        int i = Build.VERSION.SDK_INT;
        return i == 26 || i == 27;
    }

    public static boolean h(Object obj, int i, Activity activity) {
        try {
            Object obj2 = b.get(activity);
            if (obj2 == obj) {
                if (activity.hashCode() == i) {
                    a.postAtFrontOfQueue(new c(f2420a.get(activity), obj2));
                    return true;
                }
            }
        } catch (Throwable unused) {
        }
        return false;
    }

    public static boolean i(Activity activity) {
        Object obj;
        Application application;
        d dVar;
        if (Build.VERSION.SDK_INT >= 28) {
            activity.recreate();
            return true;
        } else if (g() && c == null) {
            return false;
        } else {
            if (f2422b == null && f2421a == null) {
                return false;
            }
            try {
                Object obj2 = b.get(activity);
                if (obj2 == null || (obj = f2420a.get(activity)) == null) {
                    return false;
                }
                application = activity.getApplication();
                dVar = new d(activity);
                application.registerActivityLifecycleCallbacks(dVar);
                Handler handler = a;
                handler.post(new a(dVar, obj2));
                if (g()) {
                    Method method = c;
                    Boolean bool = Boolean.FALSE;
                    method.invoke(obj, new Object[]{obj2, null, null, 0, bool, null, null, bool, bool});
                } else {
                    activity.recreate();
                }
                handler.post(new b(application, dVar));
                return true;
            } catch (Throwable unused) {
                return false;
            }
        }
    }
}
