package defpackage;

/* renamed from: z01  reason: default package */
public final class z01 implements Runnable {
    public final /* synthetic */ p11 a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ xu0 f6126a;

    public z01(p11 p11, xu0 xu0) {
        this.a = p11;
        this.f6126a = xu0;
    }

    public final void run() {
        this.a.f4365a.l();
        if (this.f6126a.f5895a.A0() == null) {
            this.a.f4365a.w(this.f6126a);
        } else {
            this.a.f4365a.u(this.f6126a);
        }
    }
}
