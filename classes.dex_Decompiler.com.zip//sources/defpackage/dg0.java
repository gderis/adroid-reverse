package defpackage;

/* renamed from: dg0  reason: default package */
public final class dg0 extends gl0<dg0, cg0> implements mm0 {
    /* access modifiers changed from: private */
    public static final dg0 zzg;
    private int zza;
    private String zze = "";
    private String zzf = "";

    static {
        dg0 dg0 = new dg0();
        zzg = dg0;
        gl0.x(dg0.class, dg0);
    }

    public final String A() {
        return this.zze;
    }

    public final String B() {
        return this.zzf;
    }

    public final Object z(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return gl0.y(zzg, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဈ\u0001", new Object[]{"zza", "zze", "zzf"});
        } else if (i2 == 3) {
            return new dg0();
        } else {
            if (i2 == 4) {
                return new cg0((wf0) null);
            }
            if (i2 != 5) {
                return null;
            }
            return zzg;
        }
    }
}
