package defpackage;

/* renamed from: v40  reason: default package */
public final class v40 {
    public static int a(int i) {
        if (i == -1) {
            return -1;
        }
        return i / 1000;
    }
}
