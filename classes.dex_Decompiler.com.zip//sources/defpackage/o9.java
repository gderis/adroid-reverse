package defpackage;

import android.os.Handler;
import android.os.Process;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* renamed from: o9  reason: default package */
public class o9 {

    /* renamed from: o9$a */
    public static class a implements ThreadFactory {
        public int a;

        /* renamed from: a  reason: collision with other field name */
        public String f4246a;

        /* renamed from: o9$a$a  reason: collision with other inner class name */
        public static class C0048a extends Thread {
            public final int a;

            public C0048a(Runnable runnable, String str, int i) {
                super(runnable, str);
                this.a = i;
            }

            public void run() {
                Process.setThreadPriority(this.a);
                super.run();
            }
        }

        public a(String str, int i) {
            this.f4246a = str;
            this.a = i;
        }

        public Thread newThread(Runnable runnable) {
            return new C0048a(runnable, this.f4246a, this.a);
        }
    }

    /* renamed from: o9$b */
    public static class b<T> implements Runnable {
        public Handler a;

        /* renamed from: a  reason: collision with other field name */
        public Callable<T> f4247a;

        /* renamed from: a  reason: collision with other field name */
        public v9<T> f4248a;

        /* renamed from: o9$b$a */
        public class a implements Runnable {
            public final /* synthetic */ Object a;

            /* renamed from: a  reason: collision with other field name */
            public final /* synthetic */ v9 f4250a;

            public a(v9 v9Var, Object obj) {
                this.f4250a = v9Var;
                this.a = obj;
            }

            public void run() {
                this.f4250a.a(this.a);
            }
        }

        public b(Handler handler, Callable<T> callable, v9<T> v9Var) {
            this.f4247a = callable;
            this.f4248a = v9Var;
            this.a = handler;
        }

        public void run() {
            T t;
            try {
                t = this.f4247a.call();
            } catch (Exception unused) {
                t = null;
            }
            this.a.post(new a(this.f4248a, t));
        }
    }

    public static ThreadPoolExecutor a(String str, int i, int i2) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, (long) i2, TimeUnit.MILLISECONDS, new LinkedBlockingDeque(), new a(str, i));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    public static <T> void b(Executor executor, Callable<T> callable, v9<T> v9Var) {
        executor.execute(new b(j9.a(), callable, v9Var));
    }

    public static <T> T c(ExecutorService executorService, Callable<T> callable, int i) {
        try {
            return executorService.submit(callable).get((long) i, TimeUnit.MILLISECONDS);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e2) {
            throw e2;
        } catch (TimeoutException unused) {
            throw new InterruptedException("timeout");
        }
    }
}
