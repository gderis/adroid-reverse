package defpackage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

/* renamed from: i  reason: default package */
public abstract class i {
    public final Bundle a = new Bundle();

    /* renamed from: a  reason: collision with other field name */
    public ArrayList<String> f2907a = new ArrayList<>();

    /* renamed from: a  reason: collision with other field name */
    public final Map<Integer, String> f2908a = new HashMap();

    /* renamed from: a  reason: collision with other field name */
    public Random f2909a = new Random();
    public final Map<String, Integer> b = new HashMap();
    public final Map<String, c> c = new HashMap();
    public final transient Map<String, b<?>> d = new HashMap();
    public final Map<String, Object> e = new HashMap();

    /* renamed from: i$a */
    public class a extends h<I> {
        public final /* synthetic */ int a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ String f2911a;

        /* renamed from: a  reason: collision with other field name */
        public final /* synthetic */ l f2912a;

        public a(String str, int i, l lVar) {
            this.f2911a = str;
            this.a = i;
            this.f2912a = lVar;
        }

        public void b(I i, e7 e7Var) {
            i.this.f2907a.add(this.f2911a);
            i.this.f(this.a, this.f2912a, i, e7Var);
        }

        public void c() {
            i.this.k(this.f2911a);
        }
    }

    /* renamed from: i$b */
    public static class b<O> {
        public final g<O> a;

        /* renamed from: a  reason: collision with other field name */
        public final l<?, O> f2913a;

        public b(g<O> gVar, l<?, O> lVar) {
            this.a = gVar;
            this.f2913a = lVar;
        }
    }

    /* renamed from: i$c */
    public static class c {
        public final ae a;

        /* renamed from: a  reason: collision with other field name */
        public final ArrayList<be> f2914a;

        public void a() {
            Iterator<be> it = this.f2914a.iterator();
            while (it.hasNext()) {
                this.a.c(it.next());
            }
            this.f2914a.clear();
        }
    }

    public final void a(int i, String str) {
        this.f2908a.put(Integer.valueOf(i), str);
        this.b.put(str, Integer.valueOf(i));
    }

    public final boolean b(int i, int i2, Intent intent) {
        String str = this.f2908a.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        this.f2907a.remove(str);
        d(str, i2, intent, this.d.get(str));
        return true;
    }

    public final <O> boolean c(int i, @SuppressLint({"UnknownNullness"}) O o) {
        g<O> gVar;
        String str = this.f2908a.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        this.f2907a.remove(str);
        b bVar = this.d.get(str);
        if (bVar == null || (gVar = bVar.a) == null) {
            this.a.remove(str);
            this.e.put(str, o);
            return true;
        }
        gVar.a(o);
        return true;
    }

    public final <O> void d(String str, int i, Intent intent, b<O> bVar) {
        g<O> gVar;
        if (bVar == null || (gVar = bVar.a) == null) {
            this.e.remove(str);
            this.a.putParcelable(str, new f(i, intent));
            return;
        }
        gVar.a(bVar.f2913a.c(i, intent));
    }

    public final int e() {
        int nextInt = this.f2909a.nextInt(2147418112);
        while (true) {
            int i = nextInt + 65536;
            if (!this.f2908a.containsKey(Integer.valueOf(i))) {
                return i;
            }
            nextInt = this.f2909a.nextInt(2147418112);
        }
    }

    public abstract <I, O> void f(int i, l<I, O> lVar, @SuppressLint({"UnknownNullness"}) I i2, e7 e7Var);

    public final void g(Bundle bundle) {
        if (bundle != null) {
            ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                int size = stringArrayList.size();
                for (int i = 0; i < size; i++) {
                    a(integerArrayList.get(i).intValue(), stringArrayList.get(i));
                }
                this.f2907a = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                this.f2909a = (Random) bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
                this.a.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
            }
        }
    }

    public final void h(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.f2908a.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.f2908a.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(this.f2907a));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.a.clone());
        bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.f2909a);
    }

    public final <I, O> h<I> i(String str, l<I, O> lVar, g<O> gVar) {
        int j = j(str);
        this.d.put(str, new b(gVar, lVar));
        if (this.e.containsKey(str)) {
            Object obj = this.e.get(str);
            this.e.remove(str);
            gVar.a(obj);
        }
        f fVar = (f) this.a.getParcelable(str);
        if (fVar != null) {
            this.a.remove(str);
            gVar.a(lVar.c(fVar.b(), fVar.a()));
        }
        return new a(str, j, lVar);
    }

    public final int j(String str) {
        Integer num = this.b.get(str);
        if (num != null) {
            return num.intValue();
        }
        int e2 = e();
        a(e2, str);
        return e2;
    }

    public final void k(String str) {
        Integer remove;
        if (!this.f2907a.contains(str) && (remove = this.b.remove(str)) != null) {
            this.f2908a.remove(remove);
        }
        this.d.remove(str);
        if (this.e.containsKey(str)) {
            "Dropping pending result for request " + str + ": " + this.e.get(str);
            this.e.remove(str);
        }
        if (this.a.containsKey(str)) {
            "Dropping pending result for request " + str + ": " + this.a.getParcelable(str);
            this.a.remove(str);
        }
        c cVar = this.c.get(str);
        if (cVar != null) {
            cVar.a();
            this.c.remove(str);
        }
    }
}
