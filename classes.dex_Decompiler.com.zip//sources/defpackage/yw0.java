package defpackage;

/* renamed from: yw0  reason: default package */
public final class yw0 implements Runnable {
    public final /* synthetic */ long a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ zx0 f6095a;

    public yw0(zx0 zx0, long j) {
        this.f6095a = zx0;
        this.a = j;
    }

    public final void run() {
        this.f6095a.q(this.a);
    }
}
