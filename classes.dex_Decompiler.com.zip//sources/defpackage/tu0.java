package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: tu0  reason: default package */
public final class tu0 implements Parcelable.Creator<su0> {
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        Parcel parcel2 = parcel;
        int z = x10.z(parcel);
        long j = 50;
        long j2 = Long.MAX_VALUE;
        boolean z2 = true;
        float f = 0.0f;
        int i = Integer.MAX_VALUE;
        while (parcel.dataPosition() < z) {
            int r = x10.r(parcel);
            int k = x10.k(r);
            if (k == 1) {
                z2 = x10.l(parcel2, r);
            } else if (k == 2) {
                j = x10.u(parcel2, r);
            } else if (k == 3) {
                f = x10.p(parcel2, r);
            } else if (k == 4) {
                j2 = x10.u(parcel2, r);
            } else if (k != 5) {
                x10.y(parcel2, r);
            } else {
                i = x10.t(parcel2, r);
            }
        }
        x10.j(parcel2, z);
        return new su0(z2, j, f, j2, i);
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new su0[i];
    }
}
