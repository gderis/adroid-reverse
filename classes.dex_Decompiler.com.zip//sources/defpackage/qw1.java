package defpackage;

import android.app.Application;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: qw1  reason: default package */
public class qw1 extends Application {
    public static ix1 a(xt1 xt1, boolean z) {
        Class<zu1> cls = zu1.class;
        JSONArray jSONArray = new JSONArray();
        long j = 0;
        try {
            j = xt1.l(wx1.a(-481407528816305868L));
            int p = xt1.p(wx1.a(-481407571765978828L), 50);
            if (!xt1.a(wx1.a(-481407614715651788L), z)) {
                return new ix1(jSONArray, j);
            }
            xr1<TModel> a = fs1.c(new js1[0]).a(cls);
            ks1<Long> ks1 = cv1.f;
            List<TModel> p2 = a.q(ks1.e(Long.valueOf(j))).s(ks1, true).r(p).p();
            o82.d(wx1.a(-481407657665324748L), ox1.c(j));
            if (p2.size() > 0) {
                for (int i = 0; i < p2.size(); i++) {
                    try {
                        String g = ((zu1) p2.get(i)).g();
                        JSONObject jSONObject = new JSONObject();
                        JSONObject jSONObject2 = new JSONObject();
                        jSONObject2.put(wx1.a(-481407730679768780L), g);
                        jSONObject.put(wx1.a(-481407752154605260L), jSONObject2);
                        jSONObject.put(wx1.a(-481407786514343628L), ((zu1) p2.get(i)).e());
                        jSONObject.put(wx1.a(-481407820874081996L), ((zu1) p2.get(i)).h());
                        jSONObject.put(wx1.a(-481407842348918476L), ((zu1) p2.get(i)).i());
                        jSONObject.put(wx1.a(-481407863823754956L), ((zu1) p2.get(i)).c());
                        jSONObject.put(wx1.a(-481407885298591436L), ox1.c(((zu1) p2.get(i)).d()));
                        jSONObject.put(wx1.a(-481407923953297100L), ((zu1) p2.get(i)).f());
                        jSONArray.put(jSONObject);
                        if (((zu1) p2.get(i)).d() > j) {
                            j = ((zu1) p2.get(i)).d();
                        }
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                }
                try {
                    Calendar instance = Calendar.getInstance();
                    instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481407984082839244L)));
                    instance.add(10, -72);
                    fs1.b(cls).q(cv1.f.f(Long.valueOf(instance.getTimeInMillis()))).m().h();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return new ix1(jSONArray, j);
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }
}
