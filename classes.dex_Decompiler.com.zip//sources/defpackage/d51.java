package defpackage;

import android.os.Handler;
import android.os.Looper;

/* renamed from: d51  reason: default package */
public final class d51 extends b01 {
    public Handler a;

    /* renamed from: a  reason: collision with other field name */
    public final b51 f1928a = new b51(this);

    /* renamed from: a  reason: collision with other field name */
    public final c51 f1929a = new c51(this);

    /* renamed from: a  reason: collision with other field name */
    public final z41 f1930a = new z41(this);

    public d51(w01 w01) {
        super(w01);
    }

    public static /* synthetic */ void o(d51 d51, long j) {
        d51.h();
        d51.s();
        d51.a.c().w().b("Activity resumed, time", Long.valueOf(j));
        bv0 z = d51.a.z();
        zy0<Boolean> zy0 = bz0.r0;
        if (z.w((String) null, zy0)) {
            if (d51.a.z().C() || d51.a.A().f1887c.a()) {
                d51.f1928a.a(j);
            }
            d51.f1930a.a();
        } else {
            d51.f1930a.a();
            if (d51.a.z().C()) {
                d51.f1928a.a(j);
            }
        }
        c51 c51 = d51.f1929a;
        c51.a.h();
        if (c51.a.a.k()) {
            if (!c51.a.a.z().w((String) null, zy0)) {
                c51.a.a.A().f1887c.b(false);
            }
            c51.b(c51.a.a.b().b(), false);
        }
    }

    public static /* synthetic */ void p(d51 d51, long j) {
        d51.h();
        d51.s();
        d51.a.c().w().b("Activity paused, time", Long.valueOf(j));
        d51.f1930a.b(j);
        if (d51.a.z().C()) {
            d51.f1928a.b(j);
        }
        c51 c51 = d51.f1929a;
        if (!c51.a.a.z().w((String) null, bz0.r0)) {
            c51.a.a.A().f1887c.b(true);
        }
    }

    public final boolean m() {
        return false;
    }

    public final void s() {
        h();
        if (this.a == null) {
            this.a = new gd0(Looper.getMainLooper());
        }
    }
}
