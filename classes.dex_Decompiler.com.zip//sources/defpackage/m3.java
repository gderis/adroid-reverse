package defpackage;

import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;

/* renamed from: m3  reason: default package */
public class m3 extends fc implements View.OnClickListener {
    public final SearchableInfo a;

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f3772a;

    /* renamed from: a  reason: collision with other field name */
    public final SearchView f3773a;

    /* renamed from: a  reason: collision with other field name */
    public final WeakHashMap<String, Drawable.ConstantState> f3774a;
    public final Context b;
    public final int d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f3775d = false;
    public int e = 1;
    public int f = -1;
    public int g = -1;
    public int h = -1;
    public int i = -1;
    public int j = -1;
    public int k = -1;

    /* renamed from: m3$a */
    public static final class a {
        public final ImageView a;

        /* renamed from: a  reason: collision with other field name */
        public final TextView f3776a;
        public final ImageView b;

        /* renamed from: b  reason: collision with other field name */
        public final TextView f3777b;
        public final ImageView c;

        public a(View view) {
            this.f3776a = (TextView) view.findViewById(16908308);
            this.f3777b = (TextView) view.findViewById(16908309);
            this.a = (ImageView) view.findViewById(16908295);
            this.b = (ImageView) view.findViewById(16908296);
            this.c = (ImageView) view.findViewById(t.edit_query);
        }
    }

    public m3(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap<String, Drawable.ConstantState> weakHashMap) {
        super(context, searchView.getSuggestionRowLayout(), (Cursor) null, true);
        this.f3773a = searchView;
        this.a = searchableInfo;
        this.d = searchView.getSuggestionCommitIconResId();
        this.b = context;
        this.f3774a = weakHashMap;
    }

    public static String o(Cursor cursor, String str) {
        return w(cursor, cursor.getColumnIndex(str));
    }

    public static String w(Cursor cursor, int i2) {
        if (i2 == -1) {
            return null;
        }
        try {
            return cursor.getString(i2);
        } catch (Exception unused) {
            return null;
        }
    }

    public final void A(String str, Drawable drawable) {
        if (drawable != null) {
            this.f3774a.put(str, drawable.getConstantState());
        }
    }

    public final void B(Cursor cursor) {
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras == null || extras.getBoolean("in_progress")) {
        }
    }

    public CharSequence a(Cursor cursor) {
        String o;
        String o2;
        if (cursor == null) {
            return null;
        }
        String o3 = o(cursor, "suggest_intent_query");
        if (o3 != null) {
            return o3;
        }
        if (this.a.shouldRewriteQueryFromData() && (o2 = o(cursor, "suggest_intent_data")) != null) {
            return o2;
        }
        if (!this.a.shouldRewriteQueryFromText() || (o = o(cursor, "suggest_text_1")) == null) {
            return null;
        }
        return o;
    }

    public Cursor c(CharSequence charSequence) {
        String charSequence2 = charSequence == null ? "" : charSequence.toString();
        if (this.f3773a.getVisibility() == 0 && this.f3773a.getWindowVisibility() == 0) {
            try {
                Cursor v = v(this.a, charSequence2, 50);
                if (v != null) {
                    v.getCount();
                    return v;
                }
            } catch (RuntimeException unused) {
            }
        }
        return null;
    }

    public void d(Cursor cursor) {
        if (!this.f3775d) {
            try {
                super.d(cursor);
                if (cursor != null) {
                    this.f = cursor.getColumnIndex("suggest_text_1");
                    this.g = cursor.getColumnIndex("suggest_text_2");
                    this.h = cursor.getColumnIndex("suggest_text_2_url");
                    this.i = cursor.getColumnIndex("suggest_icon_1");
                    this.j = cursor.getColumnIndex("suggest_icon_2");
                    this.k = cursor.getColumnIndex("suggest_flags");
                }
            } catch (Exception unused) {
            }
        } else if (cursor != null) {
            cursor.close();
        }
    }

    public void e(View view, Context context, Cursor cursor) {
        a aVar = (a) view.getTag();
        int i2 = this.k;
        int i3 = i2 != -1 ? cursor.getInt(i2) : 0;
        if (aVar.f3776a != null) {
            z(aVar.f3776a, w(cursor, this.f));
        }
        if (aVar.f3777b != null) {
            String w = w(cursor, this.h);
            CharSequence l = w != null ? l(w) : w(cursor, this.g);
            if (TextUtils.isEmpty(l)) {
                TextView textView = aVar.f3776a;
                if (textView != null) {
                    textView.setSingleLine(false);
                    aVar.f3776a.setMaxLines(2);
                }
            } else {
                TextView textView2 = aVar.f3776a;
                if (textView2 != null) {
                    textView2.setSingleLine(true);
                    aVar.f3776a.setMaxLines(1);
                }
            }
            z(aVar.f3777b, l);
        }
        ImageView imageView = aVar.a;
        if (imageView != null) {
            y(imageView, t(cursor), 4);
        }
        ImageView imageView2 = aVar.b;
        if (imageView2 != null) {
            y(imageView2, u(cursor), 8);
        }
        int i4 = this.e;
        if (i4 == 2 || (i4 == 1 && (i3 & 1) != 0)) {
            aVar.c.setVisibility(0);
            aVar.c.setTag(aVar.f3776a.getText());
            aVar.c.setOnClickListener(this);
            return;
        }
        aVar.c.setVisibility(8);
    }

    public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i2, view, viewGroup);
        } catch (RuntimeException e2) {
            View g2 = g(this.b, b(), viewGroup);
            if (g2 != null) {
                ((a) g2.getTag()).f3776a.setText(e2.toString());
            }
            return g2;
        }
    }

    public View getView(int i2, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i2, view, viewGroup);
        } catch (RuntimeException e2) {
            View h2 = h(this.b, b(), viewGroup);
            if (h2 != null) {
                ((a) h2.getTag()).f3776a.setText(e2.toString());
            }
            return h2;
        }
    }

    public View h(Context context, Cursor cursor, ViewGroup viewGroup) {
        View h2 = super.h(context, cursor, viewGroup);
        h2.setTag(new a(h2));
        ((ImageView) h2.findViewById(t.edit_query)).setImageResource(this.d);
        return h2;
    }

    public boolean hasStableIds() {
        return false;
    }

    public final Drawable k(String str) {
        Drawable.ConstantState constantState = this.f3774a.get(str);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    public final CharSequence l(CharSequence charSequence) {
        if (this.f3772a == null) {
            TypedValue typedValue = new TypedValue();
            this.b.getTheme().resolveAttribute(o.textColorSearchUrl, typedValue, true);
            this.f3772a = this.b.getResources().getColorStateList(typedValue.resourceId);
        }
        SpannableString spannableString = new SpannableString(charSequence);
        spannableString.setSpan(new TextAppearanceSpan((String) null, 0, 0, this.f3772a, (ColorStateList) null), 0, charSequence.length(), 33);
        return spannableString;
    }

    public final Drawable m(ComponentName componentName) {
        PackageManager packageManager = this.b.getPackageManager();
        try {
            ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, 128);
            int iconResource = activityInfo.getIconResource();
            if (iconResource == 0) {
                return null;
            }
            Drawable drawable = packageManager.getDrawable(componentName.getPackageName(), iconResource, activityInfo.applicationInfo);
            if (drawable != null) {
                return drawable;
            }
            "Invalid icon resource " + iconResource + " for " + componentName.flattenToShortString();
            return null;
        } catch (PackageManager.NameNotFoundException e2) {
            e2.toString();
            return null;
        }
    }

    public final Drawable n(ComponentName componentName) {
        String flattenToShortString = componentName.flattenToShortString();
        Drawable.ConstantState constantState = null;
        if (this.f3774a.containsKey(flattenToShortString)) {
            Drawable.ConstantState constantState2 = this.f3774a.get(flattenToShortString);
            if (constantState2 == null) {
                return null;
            }
            return constantState2.newDrawable(this.b.getResources());
        }
        Drawable m = m(componentName);
        if (m != null) {
            constantState = m.getConstantState();
        }
        this.f3774a.put(flattenToShortString, constantState);
        return m;
    }

    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        B(b());
    }

    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        B(b());
    }

    public void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.f3773a.U((CharSequence) tag);
        }
    }

    public final Drawable p() {
        Drawable n = n(this.a.getSearchActivity());
        return n != null ? n : this.b.getPackageManager().getDefaultActivityIcon();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:7|8|9) */
    /* JADX WARNING: Can't wrap try/catch for region: R(6:19|20|21|22|23|24) */
    /* JADX WARNING: Can't wrap try/catch for region: R(7:12|13|14|15|16|17|18) */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x002a, code lost:
        throw new java.io.FileNotFoundException("Resource does not exist: " + r5);
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:16:0x003f */
    /* JADX WARNING: Missing exception handler attribute for start block: B:22:0x0053 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0014 */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:22:0x0053=Splitter:B:22:0x0053, B:4:0x000f=Splitter:B:4:0x000f, B:16:0x003f=Splitter:B:16:0x003f} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.graphics.drawable.Drawable q(android.net.Uri r5) {
        /*
            r4 = this;
            java.lang.String r0 = "Error closing icon stream for "
            r1 = 0
            java.lang.String r2 = r5.getScheme()     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.String r3 = "android.resource"
            boolean r2 = r3.equals(r2)     // Catch:{ FileNotFoundException -> 0x0079 }
            if (r2 == 0) goto L_0x002b
            android.graphics.drawable.Drawable r5 = r4.r(r5)     // Catch:{ NotFoundException -> 0x0014 }
            return r5
        L_0x0014:
            java.io.FileNotFoundException r0 = new java.io.FileNotFoundException     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.<init>()     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.String r3 = "Resource does not exist: "
            r2.append(r3)     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.append(r5)     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.String r2 = r2.toString()     // Catch:{ FileNotFoundException -> 0x0079 }
            r0.<init>(r2)     // Catch:{ FileNotFoundException -> 0x0079 }
            throw r0     // Catch:{ FileNotFoundException -> 0x0079 }
        L_0x002b:
            android.content.Context r2 = r4.b     // Catch:{ FileNotFoundException -> 0x0079 }
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ FileNotFoundException -> 0x0079 }
            java.io.InputStream r2 = r2.openInputStream(r5)     // Catch:{ FileNotFoundException -> 0x0079 }
            if (r2 == 0) goto L_0x0062
            android.graphics.drawable.Drawable r3 = android.graphics.drawable.Drawable.createFromStream(r2, r1)     // Catch:{ all -> 0x004e }
            r2.close()     // Catch:{ IOException -> 0x003f }
            goto L_0x004d
        L_0x003f:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.<init>()     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.append(r0)     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.append(r5)     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.toString()     // Catch:{ FileNotFoundException -> 0x0079 }
        L_0x004d:
            return r3
        L_0x004e:
            r3 = move-exception
            r2.close()     // Catch:{ IOException -> 0x0053 }
            goto L_0x0061
        L_0x0053:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.<init>()     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.append(r0)     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.append(r5)     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.toString()     // Catch:{ FileNotFoundException -> 0x0079 }
        L_0x0061:
            throw r3     // Catch:{ FileNotFoundException -> 0x0079 }
        L_0x0062:
            java.io.FileNotFoundException r0 = new java.io.FileNotFoundException     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.<init>()     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.String r3 = "Failed to open "
            r2.append(r3)     // Catch:{ FileNotFoundException -> 0x0079 }
            r2.append(r5)     // Catch:{ FileNotFoundException -> 0x0079 }
            java.lang.String r2 = r2.toString()     // Catch:{ FileNotFoundException -> 0x0079 }
            r0.<init>(r2)     // Catch:{ FileNotFoundException -> 0x0079 }
            throw r0     // Catch:{ FileNotFoundException -> 0x0079 }
        L_0x0079:
            r0 = move-exception
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Icon not found: "
            r2.append(r3)
            r2.append(r5)
            java.lang.String r5 = ", "
            r2.append(r5)
            java.lang.String r5 = r0.getMessage()
            r2.append(r5)
            r2.toString()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.m3.q(android.net.Uri):android.graphics.drawable.Drawable");
    }

    public Drawable r(Uri uri) {
        int i2;
        String authority = uri.getAuthority();
        if (!TextUtils.isEmpty(authority)) {
            try {
                Resources resourcesForApplication = this.b.getPackageManager().getResourcesForApplication(authority);
                List<String> pathSegments = uri.getPathSegments();
                if (pathSegments != null) {
                    int size = pathSegments.size();
                    if (size == 1) {
                        try {
                            i2 = Integer.parseInt(pathSegments.get(0));
                        } catch (NumberFormatException unused) {
                            throw new FileNotFoundException("Single path segment is not a resource ID: " + uri);
                        }
                    } else if (size == 2) {
                        i2 = resourcesForApplication.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority);
                    } else {
                        throw new FileNotFoundException("More than two path segments: " + uri);
                    }
                    if (i2 != 0) {
                        return resourcesForApplication.getDrawable(i2);
                    }
                    throw new FileNotFoundException("No resource found for: " + uri);
                }
                throw new FileNotFoundException("No path: " + uri);
            } catch (PackageManager.NameNotFoundException unused2) {
                throw new FileNotFoundException("No package found for authority: " + uri);
            }
        } else {
            throw new FileNotFoundException("No authority: " + uri);
        }
    }

    public final Drawable s(String str) {
        if (str == null || str.isEmpty() || "0".equals(str)) {
            return null;
        }
        try {
            int parseInt = Integer.parseInt(str);
            String str2 = "android.resource://" + this.b.getPackageName() + "/" + parseInt;
            Drawable k2 = k(str2);
            if (k2 != null) {
                return k2;
            }
            Drawable f2 = r7.f(this.b, parseInt);
            A(str2, f2);
            return f2;
        } catch (NumberFormatException unused) {
            Drawable k3 = k(str);
            if (k3 != null) {
                return k3;
            }
            Drawable q = q(Uri.parse(str));
            A(str, q);
            return q;
        } catch (Resources.NotFoundException unused2) {
            "Icon resource not found: " + str;
            return null;
        }
    }

    public final Drawable t(Cursor cursor) {
        int i2 = this.i;
        if (i2 == -1) {
            return null;
        }
        Drawable s = s(cursor.getString(i2));
        return s != null ? s : p();
    }

    public final Drawable u(Cursor cursor) {
        int i2 = this.j;
        if (i2 == -1) {
            return null;
        }
        return s(cursor.getString(i2));
    }

    public Cursor v(SearchableInfo searchableInfo, String str, int i2) {
        String suggestAuthority;
        String[] strArr = null;
        if (searchableInfo == null || (suggestAuthority = searchableInfo.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder fragment = new Uri.Builder().scheme("content").authority(suggestAuthority).query("").fragment("");
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            fragment.appendEncodedPath(suggestPath);
        }
        fragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            fragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        if (i2 > 0) {
            fragment.appendQueryParameter("limit", String.valueOf(i2));
        }
        return this.b.getContentResolver().query(fragment.build(), (String[]) null, suggestSelection, strArr2, (String) null);
    }

    public void x(int i2) {
        this.e = i2;
    }

    public final void y(ImageView imageView, Drawable drawable, int i2) {
        imageView.setImageDrawable(drawable);
        if (drawable == null) {
            imageView.setVisibility(i2);
            return;
        }
        imageView.setVisibility(0);
        drawable.setVisible(false, false);
        drawable.setVisible(true, false);
    }

    public final void z(TextView textView, CharSequence charSequence) {
        textView.setText(charSequence);
        textView.setVisibility(TextUtils.isEmpty(charSequence) ? 8 : 0);
    }
}
