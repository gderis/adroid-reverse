package defpackage;

/* renamed from: w22  reason: default package */
public class w22 extends v22 {
}
