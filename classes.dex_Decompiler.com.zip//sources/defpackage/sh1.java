package defpackage;

import android.content.Context;
import android.text.TextUtils;
import defpackage.ni1;
import java.io.File;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* renamed from: sh1  reason: default package */
public class sh1 {
    public final long a = System.currentTimeMillis();

    /* renamed from: a  reason: collision with other field name */
    public final Context f5046a;

    /* renamed from: a  reason: collision with other field name */
    public final ch1 f5047a;

    /* renamed from: a  reason: collision with other field name */
    public final ci1 f5048a;

    /* renamed from: a  reason: collision with other field name */
    public final ExecutorService f5049a;

    /* renamed from: a  reason: collision with other field name */
    public final qh1 f5050a;

    /* renamed from: a  reason: collision with other field name */
    public final re1 f5051a;

    /* renamed from: a  reason: collision with other field name */
    public final rg1 f5052a;

    /* renamed from: a  reason: collision with other field name */
    public rh1 f5053a;

    /* renamed from: a  reason: collision with other field name */
    public th1 f5054a;

    /* renamed from: a  reason: collision with other field name */
    public final vg1 f5055a;

    /* renamed from: a  reason: collision with other field name */
    public final yh1 f5056a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f5057a;
    public th1 b;

    /* renamed from: sh1$a */
    public class a implements Callable<n81<Void>> {
        public final /* synthetic */ nk1 a;

        public a(nk1 nk1) {
            this.a = nk1;
        }

        /* renamed from: a */
        public n81<Void> call() {
            return sh1.this.f(this.a);
        }
    }

    /* renamed from: sh1$b */
    public class b implements Runnable {
        public final /* synthetic */ nk1 a;

        public b(nk1 nk1) {
            this.a = nk1;
        }

        public void run() {
            n81 unused = sh1.this.f(this.a);
        }
    }

    /* renamed from: sh1$c */
    public class c implements Callable<Boolean> {
        public c() {
        }

        /* renamed from: a */
        public Boolean call() {
            try {
                boolean d = sh1.this.f5054a.d();
                if (!d) {
                    sg1.f().k("Initialization marker file was not properly removed.");
                }
                return Boolean.valueOf(d);
            } catch (Exception e) {
                sg1.f().e("Problem encountered deleting Crashlytics initialization marker.", e);
                return Boolean.FALSE;
            }
        }
    }

    /* renamed from: sh1$d */
    public class d implements Callable<Boolean> {
        public d() {
        }

        /* renamed from: a */
        public Boolean call() {
            return Boolean.valueOf(sh1.this.f5053a.o());
        }
    }

    /* renamed from: sh1$e */
    public static final class e implements ni1.b {
        public final ek1 a;

        public e(ek1 ek1) {
            this.a = ek1;
        }

        public File a() {
            File file = new File(this.a.b(), "log-files");
            if (!file.exists()) {
                file.mkdirs();
            }
            return file;
        }
    }

    public sh1(re1 re1, ci1 ci1, rg1 rg1, yh1 yh1, ch1 ch1, vg1 vg1, ExecutorService executorService) {
        this.f5051a = re1;
        this.f5056a = yh1;
        this.f5046a = re1.g();
        this.f5048a = ci1;
        this.f5052a = rg1;
        this.f5047a = ch1;
        this.f5055a = vg1;
        this.f5049a = executorService;
        this.f5050a = new qh1(executorService);
    }

    public static String i() {
        return "18.0.0";
    }

    public static boolean j(String str, boolean z) {
        if (z) {
            return !TextUtils.isEmpty(str);
        }
        sg1.f().i("Configured not to require a build ID.");
        return true;
    }

    public final void d() {
        boolean z;
        try {
            z = Boolean.TRUE.equals((Boolean) li1.a(this.f5050a.h(new d())));
        } catch (Exception unused) {
            z = false;
        }
        this.f5057a = z;
    }

    public boolean e() {
        return this.f5054a.c();
    }

    public final n81<Void> f(nk1 nk1) {
        n();
        try {
            this.f5047a.b(new fh1(this));
            if (!nk1.b().b().a) {
                sg1.f().b("Collection of crash reports disabled in Crashlytics settings.");
                return q81.d(new RuntimeException("Collection of crash reports disabled in Crashlytics settings."));
            }
            if (!this.f5053a.w()) {
                sg1.f().k("Previous sessions could not be finalized.");
            }
            n81<Void> P = this.f5053a.P(nk1.a());
            m();
            return P;
        } catch (Exception e2) {
            sg1.f().e("Crashlytics encountered a problem during asynchronous initialization.", e2);
            return q81.d(e2);
        } finally {
            m();
        }
    }

    public n81<Void> g(nk1 nk1) {
        return li1.b(this.f5049a, new a(nk1));
    }

    public final void h(nk1 nk1) {
        String str;
        sg1 sg1;
        Future<?> submit = this.f5049a.submit(new b(nk1));
        sg1.f().b("Crashlytics detected incomplete initialization on previous app launch. Will initialize synchronously.");
        try {
            submit.get(4, TimeUnit.SECONDS);
            return;
        } catch (InterruptedException e2) {
            e = e2;
            sg1 = sg1.f();
            str = "Crashlytics was interrupted during initialization.";
        } catch (ExecutionException e3) {
            e = e3;
            sg1 = sg1.f();
            str = "Crashlytics encountered a problem during initialization.";
        } catch (TimeoutException e4) {
            e = e4;
            sg1 = sg1.f();
            str = "Crashlytics timed out during initialization.";
        }
        sg1.e(str, e);
    }

    public void k(String str) {
        this.f5053a.W(System.currentTimeMillis() - this.a, str);
    }

    public void l(Throwable th) {
        this.f5053a.S(Thread.currentThread(), th);
    }

    public void m() {
        this.f5050a.h(new c());
    }

    public void n() {
        this.f5050a.b();
        this.f5054a.a();
        sg1.f().i("Initialization marker file was created.");
    }

    public boolean o(jh1 jh1, nk1 nk1) {
        nk1 nk12 = nk1;
        if (j(jh1.b, ph1.k(this.f5046a, "com.crashlytics.RequireBuildId", true))) {
            try {
                fk1 fk1 = new fk1(this.f5046a);
                this.b = new th1("crash_marker", fk1);
                this.f5054a = new th1("initialization_marker", fk1);
                ki1 ki1 = new ki1();
                e eVar = new e(fk1);
                ni1 ni1 = new ni1(this.f5046a, eVar);
                ii1 a2 = ii1.a(this.f5046a, this.f5048a, fk1, jh1, ni1, ki1, new zk1(1024, new bl1(10)), nk1);
                Context context = this.f5046a;
                qh1 qh1 = this.f5050a;
                ni1 ni12 = ni1;
                Context context2 = context;
                e eVar2 = eVar;
                qh1 qh12 = qh1;
                fk1 fk12 = fk1;
                this.f5053a = new rh1(context2, qh12, this.f5048a, this.f5056a, fk12, this.b, jh1, ki1, ni12, eVar2, a2, this.f5052a, this.f5055a);
                boolean e2 = e();
                d();
                this.f5053a.t(Thread.getDefaultUncaughtExceptionHandler(), nk12);
                if (!e2 || !ph1.c(this.f5046a)) {
                    sg1.f().b("Successfully configured exception handler.");
                    return true;
                }
                sg1.f().b("Crashlytics did not finish previous background initialization. Initializing synchronously.");
                h(nk12);
                return false;
            } catch (Exception e3) {
                sg1.f().e("Crashlytics was not started due to an exception during initialization", e3);
                this.f5053a = null;
                return false;
            }
        } else {
            throw new IllegalStateException("The Crashlytics build ID is missing. This occurs when Crashlytics tooling is absent from your app's build configuration. Please review Crashlytics onboarding instructions and ensure you have a valid Crashlytics account.");
        }
    }

    public void p(String str) {
        this.f5053a.O(str);
    }
}
