package defpackage;

/* renamed from: at1  reason: default package */
public abstract class at1<TQueryModel> extends us1<TQueryModel> {
}
