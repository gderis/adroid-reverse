package defpackage;

import android.os.Process;
import android.os.StrictMode;
import androidx.annotation.RecentlyNullable;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.annotation.Nullable;

/* renamed from: o40  reason: default package */
public class o40 {
    public static int a;
    @Nullable

    /* renamed from: a  reason: collision with other field name */
    public static String f4227a;

    @RecentlyNullable
    public static String a() {
        if (f4227a == null) {
            if (a == 0) {
                a = Process.myPid();
            }
            f4227a = c(a);
        }
        return f4227a;
    }

    public static BufferedReader b(String str) {
        StrictMode.ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
        try {
            return new BufferedReader(new FileReader(str));
        } finally {
            StrictMode.setThreadPolicy(allowThreadDiskReads);
        }
    }

    @Nullable
    public static String c(int i) {
        BufferedReader bufferedReader;
        Throwable th;
        String str = null;
        if (i <= 0) {
            return null;
        }
        try {
            StringBuilder sb = new StringBuilder(25);
            sb.append("/proc/");
            sb.append(i);
            sb.append("/cmdline");
            bufferedReader = b(sb.toString());
            try {
                str = ((String) s10.j(bufferedReader.readLine())).trim();
            } catch (IOException unused) {
            } catch (Throwable th2) {
                th = th2;
                m40.a(bufferedReader);
                throw th;
            }
        } catch (IOException unused2) {
            bufferedReader = null;
        } catch (Throwable th3) {
            th = th3;
            bufferedReader = null;
            m40.a(bufferedReader);
            throw th;
        }
        m40.a(bufferedReader);
        return str;
    }
}
