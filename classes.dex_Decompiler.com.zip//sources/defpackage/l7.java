package defpackage;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import defpackage.k7;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: l7  reason: default package */
public class l7 implements j7 {
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public final Notification.Builder f3642a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f3643a;

    /* renamed from: a  reason: collision with other field name */
    public final Bundle f3644a = new Bundle();

    /* renamed from: a  reason: collision with other field name */
    public RemoteViews f3645a;

    /* renamed from: a  reason: collision with other field name */
    public final List<Bundle> f3646a = new ArrayList();

    /* renamed from: a  reason: collision with other field name */
    public final k7.e f3647a;
    public RemoteViews b;
    public RemoteViews c;

    public l7(k7.e eVar) {
        Notification.Builder builder;
        Icon icon;
        List<String> e;
        String str;
        Bundle bundle;
        this.f3647a = eVar;
        this.f3643a = eVar.f3463a;
        int i = Build.VERSION.SDK_INT;
        Context context = eVar.f3463a;
        if (i >= 26) {
            String str2 = eVar.f3490d;
        } else {
            builder = new Notification.Builder(context);
        }
        this.f3642a = builder;
        Notification notification = eVar.f3476b;
        this.f3642a.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, eVar.f3467a).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(eVar.f3468a).setContentText(eVar.f3479b).setContentInfo(eVar.f3484c).setContentIntent(eVar.f3462a).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(eVar.f3477b, (notification.flags & 128) != 0).setLargeIcon(eVar.f3464a).setNumber(eVar.a).setProgress(eVar.c, eVar.d, eVar.f3487c);
        if (i < 21) {
            this.f3642a.setSound(notification.sound, notification.audioStreamType);
        }
        if (i >= 16) {
            this.f3642a.setSubText(eVar.f3489d).setUsesChronometer(eVar.f3482b).setPriority(eVar.b);
            Iterator<k7.a> it = eVar.f3470a.iterator();
            while (it.hasNext()) {
                b(it.next());
            }
            Bundle bundle2 = eVar.f3466a;
            if (bundle2 != null) {
                this.f3644a.putAll(bundle2);
            }
            if (Build.VERSION.SDK_INT < 20) {
                if (eVar.f3495e) {
                    this.f3644a.putBoolean("android.support.localOnly", true);
                }
                String str3 = eVar.f3469a;
                if (str3 != null) {
                    this.f3644a.putString("android.support.groupKey", str3);
                    if (eVar.f3492d) {
                        bundle = this.f3644a;
                        str = "android.support.isGroupSummary";
                    } else {
                        bundle = this.f3644a;
                        str = "android.support.useSideChannel";
                    }
                    bundle.putBoolean(str, true);
                }
                String str4 = eVar.f3480b;
                if (str4 != null) {
                    this.f3644a.putString("android.support.sortKey", str4);
                }
            }
            this.f3645a = eVar.f3478b;
            this.b = eVar.f3483c;
        }
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 17) {
            this.f3642a.setShowWhen(eVar.f3474a);
        }
        if (i2 >= 19 && i2 < 21 && (e = e(g(eVar.f3481b), eVar.f3491d)) != null && !e.isEmpty()) {
            this.f3644a.putStringArray("android.people", (String[]) e.toArray(new String[e.size()]));
        }
        if (i2 >= 20) {
            this.f3642a.setLocalOnly(eVar.f3495e).setGroup(eVar.f3469a).setGroupSummary(eVar.f3492d).setSortKey(eVar.f3480b);
            this.a = eVar.h;
        }
        if (i2 >= 21) {
            this.f3642a.setCategory(eVar.f3485c).setColor(eVar.e).setVisibility(eVar.f).setPublicVersion(eVar.f3461a).setSound(notification.sound, notification.audioAttributes);
            List<String> e2 = i2 < 28 ? e(g(eVar.f3481b), eVar.f3491d) : eVar.f3491d;
            if (e2 != null && !e2.isEmpty()) {
                for (String addPerson : e2) {
                    this.f3642a.addPerson(addPerson);
                }
            }
            this.c = eVar.f3488d;
            if (eVar.f3486c.size() > 0) {
                Bundle bundle3 = eVar.c().getBundle("android.car.EXTENSIONS");
                bundle3 = bundle3 == null ? new Bundle() : bundle3;
                Bundle bundle4 = new Bundle(bundle3);
                Bundle bundle5 = new Bundle();
                for (int i3 = 0; i3 < eVar.f3486c.size(); i3++) {
                    bundle5.putBundle(Integer.toString(i3), m7.b(eVar.f3486c.get(i3)));
                }
                bundle3.putBundle("invisible_actions", bundle5);
                bundle4.putBundle("invisible_actions", bundle5);
                eVar.c().putBundle("android.car.EXTENSIONS", bundle3);
                this.f3644a.putBundle("android.car.EXTENSIONS", bundle4);
            }
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 23 && (icon = eVar.f3465a) != null) {
            this.f3642a.setSmallIcon(icon);
        }
        if (i4 >= 24) {
            this.f3642a.setExtras(eVar.f3466a).setRemoteInputHistory(eVar.f3475a);
            RemoteViews remoteViews = eVar.f3478b;
            if (remoteViews != null) {
                this.f3642a.setCustomContentView(remoteViews);
            }
            RemoteViews remoteViews2 = eVar.f3483c;
            if (remoteViews2 != null) {
                this.f3642a.setCustomBigContentView(remoteViews2);
            }
            RemoteViews remoteViews3 = eVar.f3488d;
            if (remoteViews3 != null) {
                this.f3642a.setCustomHeadsUpContentView(remoteViews3);
            }
        }
        if (i4 >= 26) {
            this.f3642a.setBadgeIconType(eVar.g).setSettingsText(eVar.f3493e).setShortcutId(eVar.f3494e).setTimeoutAfter(eVar.f3460a).setGroupAlertBehavior(eVar.h);
            if (eVar.f3497g) {
                this.f3642a.setColorized(eVar.f3496f);
            }
            if (!TextUtils.isEmpty(eVar.f3490d)) {
                this.f3642a.setSound((Uri) null).setDefaults(0).setLights(0, 0, 0).setVibrate((long[]) null);
            }
        }
        if (i4 >= 28) {
            Iterator<n7> it2 = eVar.f3481b.iterator();
            while (it2.hasNext()) {
                this.f3642a.addPerson(it2.next().h());
            }
        }
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 29) {
            this.f3642a.setAllowSystemGeneratedContextualActions(eVar.f3498h);
            this.f3642a.setBubbleMetadata(k7.d.a(eVar.f3471a));
            if (eVar.f3473a != null) {
                throw null;
            }
        }
        if (eVar.i) {
            if (this.f3647a.f3492d) {
                this.a = 2;
            } else {
                this.a = 1;
            }
            this.f3642a.setVibrate((long[]) null);
            this.f3642a.setSound((Uri) null);
            int i6 = notification.defaults & -2;
            notification.defaults = i6;
            int i7 = i6 & -3;
            notification.defaults = i7;
            this.f3642a.setDefaults(i7);
            if (i5 >= 26) {
                if (TextUtils.isEmpty(this.f3647a.f3469a)) {
                    this.f3642a.setGroup("silent");
                }
                this.f3642a.setGroupAlertBehavior(this.a);
            }
        }
    }

    public static List<String> e(List<String> list, List<String> list2) {
        if (list == null) {
            return list2;
        }
        if (list2 == null) {
            return list;
        }
        p4 p4Var = new p4(list.size() + list2.size());
        p4Var.addAll(list);
        p4Var.addAll(list2);
        return new ArrayList(p4Var);
    }

    public static List<String> g(List<n7> list) {
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        for (n7 g : list) {
            arrayList.add(g.g());
        }
        return arrayList;
    }

    public Notification.Builder a() {
        return this.f3642a;
    }

    public final void b(k7.a aVar) {
        Notification.Action.Builder builder;
        int i = Build.VERSION.SDK_INT;
        if (i >= 20) {
            IconCompat e = aVar.e();
            if (i >= 23) {
                builder = new Notification.Action.Builder(e != null ? e.p() : null, aVar.i(), aVar.a());
            } else {
                builder = new Notification.Action.Builder(e != null ? e.e() : 0, aVar.i(), aVar.a());
            }
            if (aVar.f() != null) {
                for (RemoteInput addRemoteInput : o7.b(aVar.f())) {
                    builder.addRemoteInput(addRemoteInput);
                }
            }
            Bundle bundle = aVar.d() != null ? new Bundle(aVar.d()) : new Bundle();
            bundle.putBoolean("android.support.allowGeneratedReplies", aVar.b());
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 24) {
                builder.setAllowGeneratedReplies(aVar.b());
            }
            bundle.putInt("android.support.action.semanticAction", aVar.g());
            if (i2 >= 28) {
                builder.setSemanticAction(aVar.g());
            }
            if (i2 >= 29) {
                builder.setContextual(aVar.j());
            }
            bundle.putBoolean("android.support.action.showsUserInterface", aVar.h());
            builder.addExtras(bundle);
            this.f3642a.addAction(builder.build());
        } else if (i >= 16) {
            this.f3646a.add(m7.f(this.f3642a, aVar));
        }
    }

    public Notification c() {
        Bundle a2;
        RemoteViews f;
        RemoteViews d;
        k7.f fVar = this.f3647a.f3472a;
        if (fVar != null) {
            fVar.b(this);
        }
        RemoteViews e = fVar != null ? fVar.e(this) : null;
        Notification d2 = d();
        if (!(e == null && (e = this.f3647a.f3478b) == null)) {
            d2.contentView = e;
        }
        int i = Build.VERSION.SDK_INT;
        if (!(i < 16 || fVar == null || (d = fVar.d(this)) == null)) {
            d2.bigContentView = d;
        }
        if (!(i < 21 || fVar == null || (f = this.f3647a.f3472a.f(this)) == null)) {
            d2.headsUpContentView = f;
        }
        if (!(i < 16 || fVar == null || (a2 = k7.a(d2)) == null)) {
            fVar.a(a2);
        }
        return d2;
    }

    public Notification d() {
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            return this.f3642a.build();
        }
        if (i >= 24) {
            Notification build = this.f3642a.build();
            if (this.a != 0) {
                if (!(build.getGroup() == null || (build.flags & 512) == 0 || this.a != 2)) {
                    h(build);
                }
                if (build.getGroup() != null && (build.flags & 512) == 0 && this.a == 1) {
                    h(build);
                }
            }
            return build;
        } else if (i >= 21) {
            this.f3642a.setExtras(this.f3644a);
            Notification build2 = this.f3642a.build();
            RemoteViews remoteViews = this.f3645a;
            if (remoteViews != null) {
                build2.contentView = remoteViews;
            }
            RemoteViews remoteViews2 = this.b;
            if (remoteViews2 != null) {
                build2.bigContentView = remoteViews2;
            }
            RemoteViews remoteViews3 = this.c;
            if (remoteViews3 != null) {
                build2.headsUpContentView = remoteViews3;
            }
            if (this.a != 0) {
                if (!(build2.getGroup() == null || (build2.flags & 512) == 0 || this.a != 2)) {
                    h(build2);
                }
                if (build2.getGroup() != null && (build2.flags & 512) == 0 && this.a == 1) {
                    h(build2);
                }
            }
            return build2;
        } else if (i >= 20) {
            this.f3642a.setExtras(this.f3644a);
            Notification build3 = this.f3642a.build();
            RemoteViews remoteViews4 = this.f3645a;
            if (remoteViews4 != null) {
                build3.contentView = remoteViews4;
            }
            RemoteViews remoteViews5 = this.b;
            if (remoteViews5 != null) {
                build3.bigContentView = remoteViews5;
            }
            if (this.a != 0) {
                if (!(build3.getGroup() == null || (build3.flags & 512) == 0 || this.a != 2)) {
                    h(build3);
                }
                if (build3.getGroup() != null && (build3.flags & 512) == 0 && this.a == 1) {
                    h(build3);
                }
            }
            return build3;
        } else if (i >= 19) {
            SparseArray<Bundle> a2 = m7.a(this.f3646a);
            if (a2 != null) {
                this.f3644a.putSparseParcelableArray("android.support.actionExtras", a2);
            }
            this.f3642a.setExtras(this.f3644a);
            Notification build4 = this.f3642a.build();
            RemoteViews remoteViews6 = this.f3645a;
            if (remoteViews6 != null) {
                build4.contentView = remoteViews6;
            }
            RemoteViews remoteViews7 = this.b;
            if (remoteViews7 != null) {
                build4.bigContentView = remoteViews7;
            }
            return build4;
        } else if (i < 16) {
            return this.f3642a.getNotification();
        } else {
            Notification build5 = this.f3642a.build();
            Bundle a3 = k7.a(build5);
            Bundle bundle = new Bundle(this.f3644a);
            for (String str : this.f3644a.keySet()) {
                if (a3.containsKey(str)) {
                    bundle.remove(str);
                }
            }
            a3.putAll(bundle);
            SparseArray<Bundle> a4 = m7.a(this.f3646a);
            if (a4 != null) {
                k7.a(build5).putSparseParcelableArray("android.support.actionExtras", a4);
            }
            RemoteViews remoteViews8 = this.f3645a;
            if (remoteViews8 != null) {
                build5.contentView = remoteViews8;
            }
            RemoteViews remoteViews9 = this.b;
            if (remoteViews9 != null) {
                build5.bigContentView = remoteViews9;
            }
            return build5;
        }
    }

    public Context f() {
        return this.f3643a;
    }

    public final void h(Notification notification) {
        notification.sound = null;
        notification.vibrate = null;
        int i = notification.defaults & -2;
        notification.defaults = i;
        notification.defaults = i & -3;
    }
}
