package defpackage;

import java.lang.Throwable;

/* renamed from: mr  reason: default package */
public interface mr<TInput, TResult, TException extends Throwable> {
    TResult a(TInput tinput);
}
