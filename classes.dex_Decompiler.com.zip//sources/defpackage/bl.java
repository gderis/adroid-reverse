package defpackage;

import android.content.Context;
import defpackage.el;
import java.util.ArrayList;
import java.util.List;

/* renamed from: bl  reason: default package */
public class bl implements el.a {
    public static final String a = qj.f("WorkConstraintsTracker");

    /* renamed from: a  reason: collision with other field name */
    public final al f1108a;

    /* renamed from: a  reason: collision with other field name */
    public final Object f1109a = new Object();

    /* renamed from: a  reason: collision with other field name */
    public final el<?>[] f1110a;

    public bl(Context context, hn hnVar, al alVar) {
        Context applicationContext = context.getApplicationContext();
        this.f1108a = alVar;
        this.f1110a = new el[]{new cl(applicationContext, hnVar), new dl(applicationContext, hnVar), new jl(applicationContext, hnVar), new fl(applicationContext, hnVar), new il(applicationContext, hnVar), new hl(applicationContext, hnVar), new gl(applicationContext, hnVar)};
    }

    public void a(List<String> list) {
        synchronized (this.f1109a) {
            ArrayList arrayList = new ArrayList();
            for (String next : list) {
                if (c(next)) {
                    qj.c().a(a, String.format("Constraints met for %s", new Object[]{next}), new Throwable[0]);
                    arrayList.add(next);
                }
            }
            al alVar = this.f1108a;
            if (alVar != null) {
                alVar.e(arrayList);
            }
        }
    }

    public void b(List<String> list) {
        synchronized (this.f1109a) {
            al alVar = this.f1108a;
            if (alVar != null) {
                alVar.c(list);
            }
        }
    }

    public boolean c(String str) {
        synchronized (this.f1109a) {
            for (el<?> elVar : this.f1110a) {
                if (elVar.d(str)) {
                    qj.c().a(a, String.format("Work %s constrained by %s", new Object[]{str, elVar.getClass().getSimpleName()}), new Throwable[0]);
                    return false;
                }
            }
            return true;
        }
    }

    public void d(Iterable<im> iterable) {
        synchronized (this.f1109a) {
            for (el<?> g : this.f1110a) {
                g.g((el.a) null);
            }
            for (el<?> e : this.f1110a) {
                e.e(iterable);
            }
            for (el<?> g2 : this.f1110a) {
                g2.g(this);
            }
        }
    }

    public void e() {
        synchronized (this.f1109a) {
            for (el<?> f : this.f1110a) {
                f.f();
            }
        }
    }
}
