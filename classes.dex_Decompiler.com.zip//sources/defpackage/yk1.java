package defpackage;

import org.json.JSONObject;

/* renamed from: yk1  reason: default package */
public interface yk1 {
    JSONObject a(wk1 wk1, boolean z);
}
