package defpackage;

import java.io.File;
import java.io.InputStream;
import java.net.Socket;

/* renamed from: x72  reason: default package */
public final class x72 {
    public static final o72 a(h82 h82) {
        return z72.a(h82);
    }

    public static final p72 b(j82 j82) {
        return z72.b(j82);
    }

    public static final boolean c(AssertionError assertionError) {
        return y72.b(assertionError);
    }

    public static final h82 d(Socket socket) {
        return y72.c(socket);
    }

    public static final j82 e(File file) {
        return y72.d(file);
    }

    public static final j82 f(InputStream inputStream) {
        return y72.e(inputStream);
    }

    public static final j82 g(Socket socket) {
        return y72.f(socket);
    }
}
