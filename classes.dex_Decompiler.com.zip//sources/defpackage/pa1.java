package defpackage;

import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import com.google.android.material.button.MaterialButton;

/* renamed from: pa1  reason: default package */
public class pa1 {
    public static final boolean a = (Build.VERSION.SDK_INT >= 21);

    /* renamed from: a  reason: collision with other field name */
    public int f4420a;

    /* renamed from: a  reason: collision with other field name */
    public ColorStateList f4421a;

    /* renamed from: a  reason: collision with other field name */
    public PorterDuff.Mode f4422a;

    /* renamed from: a  reason: collision with other field name */
    public Drawable f4423a;

    /* renamed from: a  reason: collision with other field name */
    public LayerDrawable f4424a;

    /* renamed from: a  reason: collision with other field name */
    public final MaterialButton f4425a;

    /* renamed from: a  reason: collision with other field name */
    public ld1 f4426a;
    public int b;

    /* renamed from: b  reason: collision with other field name */
    public ColorStateList f4427b;

    /* renamed from: b  reason: collision with other field name */
    public boolean f4428b = false;
    public int c;

    /* renamed from: c  reason: collision with other field name */
    public ColorStateList f4429c;

    /* renamed from: c  reason: collision with other field name */
    public boolean f4430c = false;
    public int d;

    /* renamed from: d  reason: collision with other field name */
    public boolean f4431d = false;
    public int e;

    /* renamed from: e  reason: collision with other field name */
    public boolean f4432e;
    public int f;
    public int g;

    public pa1(MaterialButton materialButton, ld1 ld1) {
        this.f4425a = materialButton;
        this.f4426a = ld1;
    }

    public void A(ColorStateList colorStateList) {
        if (this.f4427b != colorStateList) {
            this.f4427b = colorStateList;
            I();
        }
    }

    public void B(int i) {
        if (this.f != i) {
            this.f = i;
            I();
        }
    }

    public void C(ColorStateList colorStateList) {
        if (this.f4421a != colorStateList) {
            this.f4421a = colorStateList;
            if (f() != null) {
                m8.o(f(), this.f4421a);
            }
        }
    }

    public void D(PorterDuff.Mode mode) {
        if (this.f4422a != mode) {
            this.f4422a = mode;
            if (f() != null && this.f4422a != null) {
                m8.p(f(), this.f4422a);
            }
        }
    }

    public final void E(int i, int i2) {
        int I = ya.I(this.f4425a);
        int paddingTop = this.f4425a.getPaddingTop();
        int H = ya.H(this.f4425a);
        int paddingBottom = this.f4425a.getPaddingBottom();
        int i3 = this.c;
        int i4 = this.d;
        this.d = i2;
        this.c = i;
        if (!this.f4430c) {
            F();
        }
        ya.A0(this.f4425a, I, (paddingTop + i) - i3, H, (paddingBottom + i2) - i4);
    }

    public final void F() {
        this.f4425a.setInternalBackground(a());
        hd1 f2 = f();
        if (f2 != null) {
            f2.V((float) this.g);
        }
    }

    public final void G(ld1 ld1) {
        if (f() != null) {
            f().setShapeAppearanceModel(ld1);
        }
        if (n() != null) {
            n().setShapeAppearanceModel(ld1);
        }
        if (e() != null) {
            e().setShapeAppearanceModel(ld1);
        }
    }

    public void H(int i, int i2) {
        Drawable drawable = this.f4423a;
        if (drawable != null) {
            drawable.setBounds(this.f4420a, this.c, i2 - this.b, i - this.d);
        }
    }

    public final void I() {
        hd1 f2 = f();
        hd1 n = n();
        if (f2 != null) {
            f2.c0((float) this.f, this.f4427b);
            if (n != null) {
                n.b0((float) this.f, this.f4428b ? ab1.c(this.f4425a, o91.colorSurface) : 0);
            }
        }
    }

    public final InsetDrawable J(Drawable drawable) {
        return new InsetDrawable(drawable, this.f4420a, this.c, this.b, this.d);
    }

    public final Drawable a() {
        hd1 hd1 = new hd1(this.f4426a);
        hd1.M(this.f4425a.getContext());
        m8.o(hd1, this.f4421a);
        PorterDuff.Mode mode = this.f4422a;
        if (mode != null) {
            m8.p(hd1, mode);
        }
        hd1.c0((float) this.f, this.f4427b);
        hd1 hd12 = new hd1(this.f4426a);
        hd12.setTint(0);
        hd12.b0((float) this.f, this.f4428b ? ab1.c(this.f4425a, o91.colorSurface) : 0);
        if (a) {
            hd1 hd13 = new hd1(this.f4426a);
            this.f4423a = hd13;
            m8.n(hd13, -1);
            RippleDrawable rippleDrawable = new RippleDrawable(yc1.a(this.f4429c), J(new LayerDrawable(new Drawable[]{hd12, hd1})), this.f4423a);
            this.f4424a = rippleDrawable;
            return rippleDrawable;
        }
        xc1 xc1 = new xc1(this.f4426a);
        this.f4423a = xc1;
        m8.o(xc1, yc1.a(this.f4429c));
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{hd12, hd1, this.f4423a});
        this.f4424a = layerDrawable;
        return J(layerDrawable);
    }

    public int b() {
        return this.e;
    }

    public int c() {
        return this.d;
    }

    public int d() {
        return this.c;
    }

    public od1 e() {
        LayerDrawable layerDrawable = this.f4424a;
        if (layerDrawable == null || layerDrawable.getNumberOfLayers() <= 1) {
            return null;
        }
        return (od1) (this.f4424a.getNumberOfLayers() > 2 ? this.f4424a.getDrawable(2) : this.f4424a.getDrawable(1));
    }

    public hd1 f() {
        return g(false);
    }

    public final hd1 g(boolean z) {
        LayerDrawable layerDrawable = this.f4424a;
        if (layerDrawable == null || layerDrawable.getNumberOfLayers() <= 0) {
            return null;
        }
        return (hd1) (a ? (LayerDrawable) ((InsetDrawable) this.f4424a.getDrawable(0)).getDrawable() : this.f4424a).getDrawable(z ^ true ? 1 : 0);
    }

    public ColorStateList h() {
        return this.f4429c;
    }

    public ld1 i() {
        return this.f4426a;
    }

    public ColorStateList j() {
        return this.f4427b;
    }

    public int k() {
        return this.f;
    }

    public ColorStateList l() {
        return this.f4421a;
    }

    public PorterDuff.Mode m() {
        return this.f4422a;
    }

    public final hd1 n() {
        return g(true);
    }

    public boolean o() {
        return this.f4430c;
    }

    public boolean p() {
        return this.f4432e;
    }

    public void q(TypedArray typedArray) {
        this.f4420a = typedArray.getDimensionPixelOffset(x91.MaterialButton_android_insetLeft, 0);
        this.b = typedArray.getDimensionPixelOffset(x91.MaterialButton_android_insetRight, 0);
        this.c = typedArray.getDimensionPixelOffset(x91.MaterialButton_android_insetTop, 0);
        this.d = typedArray.getDimensionPixelOffset(x91.MaterialButton_android_insetBottom, 0);
        int i = x91.MaterialButton_cornerRadius;
        if (typedArray.hasValue(i)) {
            int dimensionPixelSize = typedArray.getDimensionPixelSize(i, -1);
            this.e = dimensionPixelSize;
            y(this.f4426a.w((float) dimensionPixelSize));
            this.f4431d = true;
        }
        this.f = typedArray.getDimensionPixelSize(x91.MaterialButton_strokeWidth, 0);
        this.f4422a = nc1.e(typedArray.getInt(x91.MaterialButton_backgroundTintMode, -1), PorterDuff.Mode.SRC_IN);
        this.f4421a = tc1.a(this.f4425a.getContext(), typedArray, x91.MaterialButton_backgroundTint);
        this.f4427b = tc1.a(this.f4425a.getContext(), typedArray, x91.MaterialButton_strokeColor);
        this.f4429c = tc1.a(this.f4425a.getContext(), typedArray, x91.MaterialButton_rippleColor);
        this.f4432e = typedArray.getBoolean(x91.MaterialButton_android_checkable, false);
        this.g = typedArray.getDimensionPixelSize(x91.MaterialButton_elevation, 0);
        int I = ya.I(this.f4425a);
        int paddingTop = this.f4425a.getPaddingTop();
        int H = ya.H(this.f4425a);
        int paddingBottom = this.f4425a.getPaddingBottom();
        if (typedArray.hasValue(x91.MaterialButton_android_background)) {
            s();
        } else {
            F();
        }
        ya.A0(this.f4425a, I + this.f4420a, paddingTop + this.c, H + this.b, paddingBottom + this.d);
    }

    public void r(int i) {
        if (f() != null) {
            f().setTint(i);
        }
    }

    public void s() {
        this.f4430c = true;
        this.f4425a.setSupportBackgroundTintList(this.f4421a);
        this.f4425a.setSupportBackgroundTintMode(this.f4422a);
    }

    public void t(boolean z) {
        this.f4432e = z;
    }

    public void u(int i) {
        if (!this.f4431d || this.e != i) {
            this.e = i;
            this.f4431d = true;
            y(this.f4426a.w((float) i));
        }
    }

    public void v(int i) {
        E(this.c, i);
    }

    public void w(int i) {
        E(i, this.d);
    }

    public void x(ColorStateList colorStateList) {
        if (this.f4429c != colorStateList) {
            this.f4429c = colorStateList;
            boolean z = a;
            if (z && (this.f4425a.getBackground() instanceof RippleDrawable)) {
                ((RippleDrawable) this.f4425a.getBackground()).setColor(yc1.a(colorStateList));
            } else if (!z && (this.f4425a.getBackground() instanceof xc1)) {
                ((xc1) this.f4425a.getBackground()).setTintList(yc1.a(colorStateList));
            }
        }
    }

    public void y(ld1 ld1) {
        this.f4426a = ld1;
        G(ld1);
    }

    public void z(boolean z) {
        this.f4428b = z;
        I();
    }
}
