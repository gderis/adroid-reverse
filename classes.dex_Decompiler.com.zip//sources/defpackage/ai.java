package defpackage;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: ai  reason: default package */
public class ai extends fi implements ci {
    public ai(Context context, ViewGroup viewGroup, View view) {
        super(context, viewGroup, view);
    }

    public static ai g(ViewGroup viewGroup) {
        return (ai) fi.e(viewGroup);
    }

    public void a(View view) {
        this.a.b(view);
    }

    public void d(View view) {
        this.a.g(view);
    }
}
