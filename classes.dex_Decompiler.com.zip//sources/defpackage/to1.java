package defpackage;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import javax.annotation.concurrent.GuardedBy;

/* renamed from: to1  reason: default package */
public class to1 {
    @GuardedBy("this")
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f5221a;
    @GuardedBy("this")

    /* renamed from: a  reason: collision with other field name */
    public String f5222a;
    @GuardedBy("this")
    public int b = 0;
    @GuardedBy("this")

    /* renamed from: b  reason: collision with other field name */
    public String f5223b;

    public to1(Context context) {
        this.f5221a = context;
    }

    public static String c(re1 re1) {
        String d = re1.j().d();
        if (d != null) {
            return d;
        }
        String c = re1.j().c();
        if (!c.startsWith("1:")) {
            return c;
        }
        String[] split = c.split(":");
        if (split.length < 2) {
            return null;
        }
        String str = split[1];
        if (str.isEmpty()) {
            return null;
        }
        return str;
    }

    public synchronized String a() {
        if (this.f5222a == null) {
            h();
        }
        return this.f5222a;
    }

    public synchronized String b() {
        if (this.f5223b == null) {
            h();
        }
        return this.f5223b;
    }

    public synchronized int d() {
        PackageInfo f;
        if (this.a == 0 && (f = f("com.google.android.gms")) != null) {
            this.a = f.versionCode;
        }
        return this.a;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:38:0x006a, code lost:
        return r2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized int e() {
        /*
            r5 = this;
            monitor-enter(r5)
            int r0 = r5.b     // Catch:{ all -> 0x006b }
            if (r0 == 0) goto L_0x0007
            monitor-exit(r5)
            return r0
        L_0x0007:
            android.content.Context r0 = r5.f5221a     // Catch:{ all -> 0x006b }
            android.content.pm.PackageManager r0 = r0.getPackageManager()     // Catch:{ all -> 0x006b }
            java.lang.String r1 = "com.google.android.c2dm.permission.SEND"
            java.lang.String r2 = "com.google.android.gms"
            int r1 = r0.checkPermission(r1, r2)     // Catch:{ all -> 0x006b }
            r2 = -1
            r3 = 0
            if (r1 != r2) goto L_0x001b
            monitor-exit(r5)
            return r3
        L_0x001b:
            boolean r1 = defpackage.n40.h()     // Catch:{ all -> 0x006b }
            r2 = 1
            if (r1 != 0) goto L_0x003f
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x006b }
            java.lang.String r4 = "com.google.android.c2dm.intent.REGISTER"
            r1.<init>(r4)     // Catch:{ all -> 0x006b }
            java.lang.String r4 = "com.google.android.gms"
            r1.setPackage(r4)     // Catch:{ all -> 0x006b }
            java.util.List r1 = r0.queryIntentServices(r1, r3)     // Catch:{ all -> 0x006b }
            if (r1 == 0) goto L_0x003f
            int r1 = r1.size()     // Catch:{ all -> 0x006b }
            if (r1 > 0) goto L_0x003b
            goto L_0x003f
        L_0x003b:
            r5.b = r2     // Catch:{ all -> 0x006b }
            monitor-exit(r5)
            return r2
        L_0x003f:
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x006b }
            java.lang.String r4 = "com.google.iid.TOKEN_REQUEST"
            r1.<init>(r4)     // Catch:{ all -> 0x006b }
            java.lang.String r4 = "com.google.android.gms"
            r1.setPackage(r4)     // Catch:{ all -> 0x006b }
            java.util.List r0 = r0.queryBroadcastReceivers(r1, r3)     // Catch:{ all -> 0x006b }
            r1 = 2
            if (r0 == 0) goto L_0x005d
            int r0 = r0.size()     // Catch:{ all -> 0x006b }
            if (r0 > 0) goto L_0x0059
            goto L_0x005d
        L_0x0059:
            r5.b = r1     // Catch:{ all -> 0x006b }
            monitor-exit(r5)
            return r1
        L_0x005d:
            boolean r0 = defpackage.n40.h()     // Catch:{ all -> 0x006b }
            if (r0 == 0) goto L_0x0067
            r5.b = r1     // Catch:{ all -> 0x006b }
            r2 = 2
            goto L_0x0069
        L_0x0067:
            r5.b = r2     // Catch:{ all -> 0x006b }
        L_0x0069:
            monitor-exit(r5)
            return r2
        L_0x006b:
            r0 = move-exception
            monitor-exit(r5)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.to1.e():int");
    }

    public final PackageInfo f(String str) {
        try {
            return this.f5221a.getPackageManager().getPackageInfo(str, 0);
        } catch (PackageManager.NameNotFoundException e) {
            String valueOf = String.valueOf(e);
            StringBuilder sb = new StringBuilder(valueOf.length() + 23);
            sb.append("Failed to find package ");
            sb.append(valueOf);
            sb.toString();
            return null;
        }
    }

    public boolean g() {
        return e() != 0;
    }

    public final synchronized void h() {
        PackageInfo f = f(this.f5221a.getPackageName());
        if (f != null) {
            this.f5222a = Integer.toString(f.versionCode);
            this.f5223b = f.versionName;
        }
    }
}
