package defpackage;

/* renamed from: iz1  reason: default package */
public final class iz1 extends ty1 {
    public static final iz1 a = new iz1();

    public static iz1 a() {
        return a;
    }
}
