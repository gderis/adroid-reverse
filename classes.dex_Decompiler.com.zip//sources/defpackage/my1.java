package defpackage;

import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import defpackage.lt0;
import defpackage.mw;

/* renamed from: my1  reason: default package */
public class my1 implements mw.b, mw.c, jt0, sw<Status>, sw {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public by1 f3976a;

    /* renamed from: a  reason: collision with other field name */
    public LocationRequest f3977a;

    /* renamed from: a  reason: collision with other field name */
    public jy1 f3978a;

    /* renamed from: a  reason: collision with other field name */
    public mw f3979a;

    /* renamed from: a  reason: collision with other field name */
    public py1 f3980a;

    /* renamed from: a  reason: collision with other field name */
    public qy1 f3981a;

    /* renamed from: a  reason: collision with other field name */
    public sw<mt0> f3982a;

    /* renamed from: a  reason: collision with other field name */
    public sy1 f3983a;

    /* renamed from: a  reason: collision with other field name */
    public boolean f3984a;
    public boolean b;
    public boolean c;
    public boolean d;
    public boolean e;

    /* renamed from: my1$a */
    public class a implements sw<mt0> {
        public a() {
        }

        /* renamed from: a */
        public void g(mt0 mt0) {
            Status v = mt0.v();
            int B0 = v.B0();
            if (B0 == 0) {
                my1.this.f3981a.b("All location settings are satisfied.", new Object[0]);
                boolean unused = my1.this.d = true;
                my1 my1 = my1.this;
                my1.p(my1.f3977a);
            } else if (B0 == 6) {
                my1.this.f3981a.c("Location settings are not satisfied. Show the user a dialog to upgrade location settings. You should hook into the Activity onActivityResult and call this provider's onActivityResult method for continuing this call flow. ", new Object[0]);
                if (my1.this.a instanceof Activity) {
                    try {
                        v.F0((Activity) my1.this.a, 20001);
                    } catch (IntentSender.SendIntentException unused2) {
                        my1.this.f3981a.a("PendingIntent unable to execute request.", new Object[0]);
                    }
                } else {
                    my1.this.f3981a.c("Provided context is not the context of an activity, therefore we can't launch the resolution activity.", new Object[0]);
                }
            } else if (B0 == 8502) {
                my1.this.f3981a.a("Location settings are inadequate, and cannot be fixed here. Dialog not created.", new Object[0]);
                my1.this.q();
            }
        }
    }

    /* renamed from: my1$b */
    public static /* synthetic */ class b {
        public static final /* synthetic */ int[] a;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                ky1[] r0 = defpackage.ky1.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                ky1 r1 = defpackage.ky1.HIGH     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001d }
                ky1 r1 = defpackage.ky1.MEDIUM     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0028 }
                ky1 r1 = defpackage.ky1.LOW     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0033 }
                ky1 r1 = defpackage.ky1.LOWEST     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: defpackage.my1.b.<clinit>():void");
        }
    }

    public my1() {
        this.f3984a = false;
        this.b = false;
        this.e = true;
        this.f3982a = new a();
        this.c = false;
        this.d = false;
    }

    public my1(py1 py1) {
        this();
        this.f3980a = py1;
    }

    public void a(by1 by1, ly1 ly1, boolean z) {
        this.f3976a = by1;
        if (by1 == null) {
            this.f3981a.b("Listener is null, you sure about this?", new Object[0]);
        }
        this.f3977a = n(ly1, z);
        if (this.f3979a.k()) {
            p(this.f3977a);
            return;
        }
        boolean z2 = this.b;
        this.f3984a = true;
        if (z2) {
            this.f3979a.c();
            this.b = false;
            return;
        }
        this.f3981a.b("still not connected - scheduled start when connection is ok", new Object[0]);
    }

    public void b(int i) {
        qy1 qy1 = this.f3981a;
        qy1.b("onConnectionSuspended " + i, new Object[0]);
        py1 py1 = this.f3980a;
        if (py1 != null) {
            py1.b(i);
        }
        sy1 sy1 = this.f3983a;
        if (sy1 != null) {
            sy1.c();
        }
    }

    public void c(Bundle bundle) {
        this.f3981a.b("onConnected", new Object[0]);
        if (this.f3984a) {
            p(this.f3977a);
        }
        py1 py1 = this.f3980a;
        if (py1 != null) {
            py1.c(bundle);
        }
        sy1 sy1 = this.f3983a;
        if (sy1 != null) {
            sy1.b();
        }
    }

    public void d(wv wvVar) {
        qy1 qy1 = this.f3981a;
        qy1.b("onConnectionFailed " + wvVar.toString(), new Object[0]);
        py1 py1 = this.f3980a;
        if (py1 != null) {
            py1.d(wvVar);
        }
        sy1 sy1 = this.f3983a;
        if (sy1 != null) {
            sy1.a();
        }
    }

    public void f(Context context, qy1 qy1) {
        this.f3981a = qy1;
        this.a = context;
        this.f3978a = new jy1(context);
        if (!this.f3984a) {
            mw d2 = new mw.a(context).a(kt0.f3575a).b(this).c(this).d();
            this.f3979a = d2;
            d2.c();
            return;
        }
        qy1.b("already started", new Object[0]);
    }

    public final void m() {
        kt0.f3576a.a(this.f3979a, new lt0.a().c(this.e).a(this.f3977a).b()).f(this.f3982a);
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0045  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.google.android.gms.location.LocationRequest n(defpackage.ly1 r4, boolean r5) {
        /*
            r3 = this;
            com.google.android.gms.location.LocationRequest r0 = com.google.android.gms.location.LocationRequest.A0()
            long r1 = r4.c()
            com.google.android.gms.location.LocationRequest r0 = r0.C0(r1)
            long r1 = r4.c()
            com.google.android.gms.location.LocationRequest r0 = r0.D0(r1)
            float r1 = r4.b()
            com.google.android.gms.location.LocationRequest r0 = r0.G0(r1)
            int[] r1 = defpackage.my1.b.a
            ky1 r4 = r4.a()
            int r4 = r4.ordinal()
            r4 = r1[r4]
            r1 = 1
            if (r4 == r1) goto L_0x003e
            r2 = 2
            if (r4 == r2) goto L_0x003b
            r2 = 3
            if (r4 == r2) goto L_0x0038
            r2 = 4
            if (r4 == r2) goto L_0x0035
            goto L_0x0043
        L_0x0035:
            r4 = 105(0x69, float:1.47E-43)
            goto L_0x0040
        L_0x0038:
            r4 = 104(0x68, float:1.46E-43)
            goto L_0x0040
        L_0x003b:
            r4 = 102(0x66, float:1.43E-43)
            goto L_0x0040
        L_0x003e:
            r4 = 100
        L_0x0040:
            r0.F0(r4)
        L_0x0043:
            if (r5 == 0) goto L_0x0048
            r0.E0(r1)
        L_0x0048:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.my1.n(ly1, boolean):com.google.android.gms.location.LocationRequest");
    }

    /* renamed from: o */
    public void g(Status status) {
        if (status.E0()) {
            this.f3981a.b("Locations update request successful", new Object[0]);
        } else if (!status.D0() || !(this.a instanceof Activity)) {
            qy1 qy1 = this.f3981a;
            qy1.e("Registering failed: " + status.C0(), new Object[0]);
        } else {
            this.f3981a.c("Unable to register, but we can solve this - will startActivityForResult. You should hook into the Activity onActivityResult and call this provider's onActivityResult method for continuing this call flow.", new Object[0]);
            try {
                status.F0((Activity) this.a, 10001);
            } catch (IntentSender.SendIntentException e2) {
                this.f3981a.d(e2, "problem with startResolutionForResult", new Object[0]);
            }
        }
    }

    public void onLocationChanged(Location location) {
        this.f3981a.b("onLocationChanged", location);
        by1 by1 = this.f3976a;
        if (by1 != null) {
            by1.a(location);
        }
        if (this.f3978a != null) {
            this.f3981a.b("Stored in SharedPreferences", new Object[0]);
            this.f3978a.b("GMS", location);
        }
    }

    public final void p(LocationRequest locationRequest) {
        if (this.c && !this.d) {
            this.f3981a.b("startUpdating wont be executed for now, as we have to test the location settings before", new Object[0]);
            m();
        } else if (!this.f3979a.k()) {
            this.f3981a.c("startUpdating executed without the GoogleApiClient being connected!!", new Object[0]);
        } else if (r7.a(this.a, "android.permission.ACCESS_FINE_LOCATION") == 0 || r7.a(this.a, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            kt0.a.b(this.f3979a, locationRequest, this, Looper.getMainLooper()).f(this);
        } else {
            this.f3981a.a("Permission check failed. Please handle it in your app before setting up location", new Object[0]);
        }
    }

    public void q() {
        this.f3981a.b("stop", new Object[0]);
        if (this.f3979a.k()) {
            kt0.a.a(this.f3979a, this);
            this.f3979a.e();
        }
        this.d = false;
        this.f3984a = false;
        this.b = true;
    }
}
