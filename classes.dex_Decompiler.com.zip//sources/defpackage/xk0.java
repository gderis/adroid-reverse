package defpackage;

import defpackage.wk0;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* renamed from: xk0  reason: default package */
public final class xk0<T extends wk0<T>> {
    public static final xk0 a = new xk0(true);

    /* renamed from: a  reason: collision with other field name */
    public final hn0<T, Object> f5864a = new zm0(16);

    /* renamed from: a  reason: collision with other field name */
    public boolean f5865a;
    public boolean b;

    public xk0() {
    }

    public xk0(boolean z) {
        b();
        b();
    }

    public static <T extends wk0<T>> xk0<T> a() {
        throw null;
    }

    public static final void d(T t, Object obj) {
        boolean z;
        bo0 d = t.d();
        ol0.a(obj);
        bo0 bo0 = bo0.DOUBLE;
        co0 co0 = co0.INT;
        switch (d.a().ordinal()) {
            case 0:
                z = obj instanceof Integer;
                break;
            case 1:
                z = obj instanceof Long;
                break;
            case 2:
                z = obj instanceof Float;
                break;
            case 3:
                z = obj instanceof Double;
                break;
            case 4:
                z = obj instanceof Boolean;
                break;
            case 5:
                z = obj instanceof String;
                break;
            case 6:
                if ((obj instanceof gk0) || (obj instanceof byte[])) {
                    return;
                }
            case 7:
                if ((obj instanceof Integer) || (obj instanceof il0)) {
                    return;
                }
            case 8:
                if (obj instanceof lm0) {
                    return;
                }
                break;
        }
        if (z) {
            return;
        }
        throw new IllegalArgumentException(String.format("Wrong object type used with protocol message reflection.\nField number: %d, field java type: %s, value type: %s\n", new Object[]{Integer.valueOf(t.zza()), t.d().a(), obj.getClass().getName()}));
    }

    public final void b() {
        if (!this.f5865a) {
            this.f5864a.a();
            this.f5865a = true;
        }
    }

    public final void c(T t, Object obj) {
        if (!t.c()) {
            d(t, obj);
        } else if (obj instanceof List) {
            ArrayList arrayList = new ArrayList();
            arrayList.addAll((List) obj);
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                d(t, arrayList.get(i));
            }
            obj = arrayList;
        } else {
            throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
        }
        this.f5864a.put(t, obj);
    }

    public final /* bridge */ /* synthetic */ Object clone() {
        xk0 xk0 = new xk0();
        for (int i = 0; i < this.f5864a.c(); i++) {
            Map.Entry<T, Object> d = this.f5864a.d(i);
            xk0.c((wk0) d.getKey(), d.getValue());
        }
        for (Map.Entry next : this.f5864a.e()) {
            xk0.c((wk0) next.getKey(), next.getValue());
        }
        xk0.b = this.b;
        return xk0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof xk0)) {
            return false;
        }
        return this.f5864a.equals(((xk0) obj).f5864a);
    }

    public final int hashCode() {
        return this.f5864a.hashCode();
    }
}
