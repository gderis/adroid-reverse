package defpackage;

import java.util.ArrayList;

/* renamed from: c6  reason: default package */
public class c6 {
    public static i6 a(m5 m5Var, int i, ArrayList<i6> arrayList, i6 i6Var) {
        l5 l5Var;
        int b1;
        int i2 = i == 0 ? m5Var.B : m5Var.C;
        int i3 = 0;
        if (i2 != -1 && (i6Var == null || i2 != i6Var.b)) {
            int i4 = 0;
            while (true) {
                if (i4 >= arrayList.size()) {
                    break;
                }
                i6 i6Var2 = arrayList.get(i4);
                if (i6Var2.c() == i2) {
                    if (i6Var != null) {
                        i6Var.g(i, i6Var2);
                        arrayList.remove(i6Var);
                    }
                    i6Var = i6Var2;
                } else {
                    i4++;
                }
            }
        } else if (i2 != -1) {
            return i6Var;
        }
        if (i6Var == null) {
            if ((m5Var instanceof q5) && (b1 = ((q5) m5Var).b1(i)) != -1) {
                int i5 = 0;
                while (true) {
                    if (i5 >= arrayList.size()) {
                        break;
                    }
                    i6 i6Var3 = arrayList.get(i5);
                    if (i6Var3.c() == b1) {
                        i6Var = i6Var3;
                        break;
                    }
                    i5++;
                }
            }
            if (i6Var == null) {
                i6Var = new i6(i);
            }
            arrayList.add(i6Var);
        }
        if (i6Var.a(m5Var)) {
            if (m5Var instanceof o5) {
                o5 o5Var = (o5) m5Var;
                l5 a1 = o5Var.a1();
                if (o5Var.b1() == 0) {
                    i3 = 1;
                }
                a1.b(i3, arrayList, i6Var);
            }
            int c = i6Var.c();
            if (i == 0) {
                m5Var.B = c;
                m5Var.f3799a.b(i, arrayList, i6Var);
                l5Var = m5Var.f3820c;
            } else {
                m5Var.C = c;
                m5Var.f3812b.b(i, arrayList, i6Var);
                m5Var.f3827e.b(i, arrayList, i6Var);
                l5Var = m5Var.f3824d;
            }
            l5Var.b(i, arrayList, i6Var);
            m5Var.f3836h.b(i, arrayList, i6Var);
        }
        return i6Var;
    }

    public static i6 b(ArrayList<i6> arrayList, int i) {
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            i6 i6Var = arrayList.get(i2);
            if (i == i6Var.b) {
                return i6Var;
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:173:0x0343  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x037d  */
    /* JADX WARNING: Removed duplicated region for block: B:187:0x0381 A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean c(defpackage.n5 r16, defpackage.v5.b r17) {
        /*
            r0 = r16
            java.util.ArrayList r1 = r16.a1()
            int r2 = r1.size()
            r3 = 0
            r4 = 0
        L_0x000c:
            if (r4 >= r2) goto L_0x002e
            java.lang.Object r5 = r1.get(r4)
            m5 r5 = (defpackage.m5) r5
            m5$b r6 = r16.y()
            m5$b r7 = r16.O()
            m5$b r8 = r5.y()
            m5$b r5 = r5.O()
            boolean r5 = d(r6, r7, r8, r5)
            if (r5 != 0) goto L_0x002b
            return r3
        L_0x002b:
            int r4 = r4 + 1
            goto L_0x000c
        L_0x002e:
            c5 r4 = r0.f4060a
            if (r4 != 0) goto L_0x0388
            r4 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            r10 = 0
            r11 = 0
        L_0x0039:
            r12 = 1
            if (r4 >= r2) goto L_0x0110
            java.lang.Object r13 = r1.get(r4)
            m5 r13 = (defpackage.m5) r13
            m5$b r14 = r16.y()
            m5$b r15 = r16.O()
            m5$b r3 = r13.y()
            m5$b r5 = r13.O()
            boolean r3 = d(r14, r15, r3, r5)
            if (r3 != 0) goto L_0x0062
            v5$a r3 = r0.f4062a
            int r5 = defpackage.v5.a.a
            r14 = r17
            defpackage.n5.A1(r13, r14, r3, r5)
            goto L_0x0064
        L_0x0062:
            r14 = r17
        L_0x0064:
            boolean r3 = r13 instanceof defpackage.o5
            if (r3 == 0) goto L_0x008b
            r5 = r13
            o5 r5 = (defpackage.o5) r5
            int r15 = r5.b1()
            if (r15 != 0) goto L_0x007b
            if (r8 != 0) goto L_0x0078
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
        L_0x0078:
            r8.add(r5)
        L_0x007b:
            int r15 = r5.b1()
            if (r15 != r12) goto L_0x008b
            if (r6 != 0) goto L_0x0088
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
        L_0x0088:
            r6.add(r5)
        L_0x008b:
            boolean r5 = r13 instanceof defpackage.q5
            if (r5 == 0) goto L_0x00cb
            boolean r5 = r13 instanceof defpackage.i5
            if (r5 == 0) goto L_0x00b4
            r5 = r13
            i5 r5 = (defpackage.i5) r5
            int r15 = r5.g1()
            if (r15 != 0) goto L_0x00a6
            if (r7 != 0) goto L_0x00a3
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
        L_0x00a3:
            r7.add(r5)
        L_0x00a6:
            int r15 = r5.g1()
            if (r15 != r12) goto L_0x00cb
            if (r9 != 0) goto L_0x00c8
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            goto L_0x00c8
        L_0x00b4:
            r5 = r13
            q5 r5 = (defpackage.q5) r5
            if (r7 != 0) goto L_0x00be
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
        L_0x00be:
            r7.add(r5)
            if (r9 != 0) goto L_0x00c8
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
        L_0x00c8:
            r9.add(r5)
        L_0x00cb:
            l5 r5 = r13.f3799a
            l5 r5 = r5.f3624a
            if (r5 != 0) goto L_0x00e8
            l5 r5 = r13.f3820c
            l5 r5 = r5.f3624a
            if (r5 != 0) goto L_0x00e8
            if (r3 != 0) goto L_0x00e8
            boolean r5 = r13 instanceof defpackage.i5
            if (r5 != 0) goto L_0x00e8
            if (r10 != 0) goto L_0x00e5
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            r10 = r5
        L_0x00e5:
            r10.add(r13)
        L_0x00e8:
            l5 r5 = r13.f3812b
            l5 r5 = r5.f3624a
            if (r5 != 0) goto L_0x010b
            l5 r5 = r13.f3824d
            l5 r5 = r5.f3624a
            if (r5 != 0) goto L_0x010b
            l5 r5 = r13.f3827e
            l5 r5 = r5.f3624a
            if (r5 != 0) goto L_0x010b
            if (r3 != 0) goto L_0x010b
            boolean r3 = r13 instanceof defpackage.i5
            if (r3 != 0) goto L_0x010b
            if (r11 != 0) goto L_0x0108
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r11 = r3
        L_0x0108:
            r11.add(r13)
        L_0x010b:
            int r4 = r4 + 1
            r3 = 0
            goto L_0x0039
        L_0x0110:
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            if (r6 == 0) goto L_0x012d
            java.util.Iterator r4 = r6.iterator()
        L_0x011b:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x012d
            java.lang.Object r5 = r4.next()
            o5 r5 = (defpackage.o5) r5
            r6 = 0
            r13 = 0
            a(r5, r6, r3, r13)
            goto L_0x011b
        L_0x012d:
            r6 = 0
            r13 = 0
            if (r7 == 0) goto L_0x014e
            java.util.Iterator r4 = r7.iterator()
        L_0x0135:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x014e
            java.lang.Object r5 = r4.next()
            q5 r5 = (defpackage.q5) r5
            i6 r7 = a(r5, r6, r3, r13)
            r5.a1(r3, r6, r7)
            r7.b(r3)
            r6 = 0
            r13 = 0
            goto L_0x0135
        L_0x014e:
            l5$b r4 = defpackage.l5.b.LEFT
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x0176
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x0162:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x0176
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            r7 = 0
            a(r5, r6, r3, r7)
            goto L_0x0162
        L_0x0176:
            l5$b r4 = defpackage.l5.b.RIGHT
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x019e
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x018a:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x019e
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            r7 = 0
            a(r5, r6, r3, r7)
            goto L_0x018a
        L_0x019e:
            l5$b r4 = defpackage.l5.b.CENTER
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x01c6
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x01b2:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x01c6
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            r7 = 0
            a(r5, r6, r3, r7)
            goto L_0x01b2
        L_0x01c6:
            r6 = 0
            r7 = 0
            if (r10 == 0) goto L_0x01de
            java.util.Iterator r4 = r10.iterator()
        L_0x01ce:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x01de
            java.lang.Object r5 = r4.next()
            m5 r5 = (defpackage.m5) r5
            a(r5, r6, r3, r7)
            goto L_0x01ce
        L_0x01de:
            if (r8 == 0) goto L_0x01f4
            java.util.Iterator r4 = r8.iterator()
        L_0x01e4:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x01f4
            java.lang.Object r5 = r4.next()
            o5 r5 = (defpackage.o5) r5
            a(r5, r12, r3, r7)
            goto L_0x01e4
        L_0x01f4:
            if (r9 == 0) goto L_0x0212
            java.util.Iterator r4 = r9.iterator()
        L_0x01fa:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x0212
            java.lang.Object r5 = r4.next()
            q5 r5 = (defpackage.q5) r5
            i6 r6 = a(r5, r12, r3, r7)
            r5.a1(r3, r12, r6)
            r6.b(r3)
            r7 = 0
            goto L_0x01fa
        L_0x0212:
            l5$b r4 = defpackage.l5.b.TOP
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x0239
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x0226:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x0239
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            a(r5, r12, r3, r6)
            goto L_0x0226
        L_0x0239:
            l5$b r4 = defpackage.l5.b.BASELINE
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x0260
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x024d:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x0260
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            a(r5, r12, r3, r6)
            goto L_0x024d
        L_0x0260:
            l5$b r4 = defpackage.l5.b.BOTTOM
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x0287
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x0274:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x0287
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            a(r5, r12, r3, r6)
            goto L_0x0274
        L_0x0287:
            l5$b r4 = defpackage.l5.b.CENTER
            l5 r4 = r0.m(r4)
            java.util.HashSet r5 = r4.c()
            if (r5 == 0) goto L_0x02ae
            java.util.HashSet r4 = r4.c()
            java.util.Iterator r4 = r4.iterator()
        L_0x029b:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x02ae
            java.lang.Object r5 = r4.next()
            l5 r5 = (defpackage.l5) r5
            m5 r5 = r5.f3625a
            r6 = 0
            a(r5, r12, r3, r6)
            goto L_0x029b
        L_0x02ae:
            r6 = 0
            if (r11 == 0) goto L_0x02c5
            java.util.Iterator r4 = r11.iterator()
        L_0x02b5:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x02c5
            java.lang.Object r5 = r4.next()
            m5 r5 = (defpackage.m5) r5
            a(r5, r12, r3, r6)
            goto L_0x02b5
        L_0x02c5:
            r4 = 0
        L_0x02c6:
            if (r4 >= r2) goto L_0x02f2
            java.lang.Object r5 = r1.get(r4)
            m5 r5 = (defpackage.m5) r5
            boolean r6 = r5.g0()
            if (r6 == 0) goto L_0x02ef
            int r6 = r5.B
            i6 r6 = b(r3, r6)
            int r5 = r5.C
            i6 r5 = b(r3, r5)
            if (r6 == 0) goto L_0x02ef
            if (r5 == 0) goto L_0x02ef
            r7 = 0
            r6.g(r7, r5)
            r7 = 2
            r5.i(r7)
            r3.remove(r6)
        L_0x02ef:
            int r4 = r4 + 1
            goto L_0x02c6
        L_0x02f2:
            int r1 = r3.size()
            if (r1 > r12) goto L_0x02fa
            r1 = 0
            return r1
        L_0x02fa:
            m5$b r1 = r16.y()
            m5$b r2 = defpackage.m5.b.WRAP_CONTENT
            if (r1 != r2) goto L_0x033a
            java.util.Iterator r1 = r3.iterator()
            r6 = 0
            r13 = 0
        L_0x0308:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x032c
            java.lang.Object r2 = r1.next()
            i6 r2 = (defpackage.i6) r2
            int r4 = r2.d()
            if (r4 != r12) goto L_0x031b
            goto L_0x0308
        L_0x031b:
            r4 = 0
            r2.h(r4)
            b5 r5 = r16.t1()
            int r5 = r2.f(r5, r4)
            if (r5 <= r6) goto L_0x0308
            r13 = r2
            r6 = r5
            goto L_0x0308
        L_0x032c:
            if (r13 == 0) goto L_0x033a
            m5$b r1 = defpackage.m5.b.FIXED
            r0.z0(r1)
            r0.U0(r6)
            r13.h(r12)
            goto L_0x033b
        L_0x033a:
            r13 = 0
        L_0x033b:
            m5$b r1 = r16.O()
            m5$b r2 = defpackage.m5.b.WRAP_CONTENT
            if (r1 != r2) goto L_0x037d
            java.util.Iterator r1 = r3.iterator()
            r2 = 0
            r6 = 0
        L_0x0349:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x036d
            java.lang.Object r3 = r1.next()
            i6 r3 = (defpackage.i6) r3
            int r4 = r3.d()
            if (r4 != 0) goto L_0x035c
            goto L_0x0349
        L_0x035c:
            r4 = 0
            r3.h(r4)
            b5 r5 = r16.t1()
            int r5 = r3.f(r5, r12)
            if (r5 <= r6) goto L_0x0349
            r2 = r3
            r6 = r5
            goto L_0x0349
        L_0x036d:
            r4 = 0
            if (r2 == 0) goto L_0x037e
            m5$b r1 = defpackage.m5.b.FIXED
            r0.Q0(r1)
            r0.v0(r6)
            r2.h(r12)
            r5 = r2
            goto L_0x037f
        L_0x037d:
            r4 = 0
        L_0x037e:
            r5 = 0
        L_0x037f:
            if (r13 != 0) goto L_0x0386
            if (r5 == 0) goto L_0x0384
            goto L_0x0386
        L_0x0384:
            r3 = 0
            goto L_0x0387
        L_0x0386:
            r3 = 1
        L_0x0387:
            return r3
        L_0x0388:
            r0 = 0
            goto L_0x038b
        L_0x038a:
            throw r0
        L_0x038b:
            goto L_0x038a
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.c6.c(n5, v5$b):boolean");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r3 = defpackage.m5.b.WRAP_CONTENT;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean d(defpackage.m5.b r5, defpackage.m5.b r6, defpackage.m5.b r7, defpackage.m5.b r8) {
        /*
            m5$b r0 = defpackage.m5.b.FIXED
            r1 = 0
            r2 = 1
            if (r7 == r0) goto L_0x0013
            m5$b r3 = defpackage.m5.b.WRAP_CONTENT
            if (r7 == r3) goto L_0x0013
            m5$b r4 = defpackage.m5.b.MATCH_PARENT
            if (r7 != r4) goto L_0x0011
            if (r5 == r3) goto L_0x0011
            goto L_0x0013
        L_0x0011:
            r5 = 0
            goto L_0x0014
        L_0x0013:
            r5 = 1
        L_0x0014:
            if (r8 == r0) goto L_0x0023
            m5$b r7 = defpackage.m5.b.WRAP_CONTENT
            if (r8 == r7) goto L_0x0023
            m5$b r0 = defpackage.m5.b.MATCH_PARENT
            if (r8 != r0) goto L_0x0021
            if (r6 == r7) goto L_0x0021
            goto L_0x0023
        L_0x0021:
            r6 = 0
            goto L_0x0024
        L_0x0023:
            r6 = 1
        L_0x0024:
            if (r5 != 0) goto L_0x002a
            if (r6 == 0) goto L_0x0029
            goto L_0x002a
        L_0x0029:
            return r1
        L_0x002a:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.c6.d(m5$b, m5$b, m5$b, m5$b):boolean");
    }
}
