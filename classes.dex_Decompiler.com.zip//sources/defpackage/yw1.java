package defpackage;

import android.app.Application;
import android.content.Context;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: yw1  reason: default package */
public class yw1 extends Application {
    public static final HashMap<String, String> a = new HashMap<>();

    public static ix1 a(Context context, xt1 xt1, boolean z) {
        Class<lv1> cls = lv1.class;
        JSONArray jSONArray = new JSONArray();
        long j = 0;
        try {
            j = xt1.l(wx1.a(-481414611217376972L));
            int p = xt1.p(wx1.a(-481414649872082636L), 50);
            if (!xt1.a(wx1.a(-481414688526788300L), z)) {
                return new ix1(jSONArray, j);
            }
            xr1<TModel> a2 = fs1.c(new js1[0]).a(cls);
            ks1<Long> ks1 = mv1.f;
            List<TModel> p2 = a2.q(ks1.e(Long.valueOf(j))).s(ks1, true).r(p).p();
            o82.d(wx1.a(-481414727181493964L), ox1.c(j));
            if (p2.size() > 0) {
                for (int i = 0; i < p2.size(); i++) {
                    try {
                        String g = ((lv1) p2.get(i)).g();
                        JSONObject jSONObject = new JSONObject();
                        JSONObject jSONObject2 = new JSONObject();
                        jSONObject2.put(wx1.a(-481414800195937996L), g);
                        HashMap<String, String> hashMap = a;
                        if (hashMap.containsKey(g)) {
                            g = hashMap.get(g);
                        } else if (!g.startsWith(wx1.a(-481414821670774476L)) && !hashMap.containsKey(g)) {
                            String f = ox1.f(context, g);
                            if (f.length() <= 0) {
                                f = g;
                            }
                            hashMap.put(g, f);
                            g = f;
                        }
                        jSONObject2.put(wx1.a(-481414830260709068L), g);
                        jSONObject.put(wx1.a(-481414886095283916L), jSONObject2);
                        jSONObject.put(wx1.a(-481414920455022284L), ((lv1) p2.get(i)).e());
                        jSONObject.put(wx1.a(-481414954814760652L), ((lv1) p2.get(i)).h());
                        jSONObject.put(wx1.a(-481414976289597132L), ((lv1) p2.get(i)).i());
                        jSONObject.put(wx1.a(-481414997764433612L), ((lv1) p2.get(i)).c());
                        jSONObject.put(wx1.a(-481415019239270092L), ox1.c(((lv1) p2.get(i)).d()));
                        jSONObject.put(wx1.a(-481415057893975756L), ((lv1) p2.get(i)).f());
                        jSONArray.put(jSONObject);
                        if (((lv1) p2.get(i)).d() > j) {
                            j = ((lv1) p2.get(i)).d();
                        }
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                }
                try {
                    Calendar instance = Calendar.getInstance();
                    instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481415118023517900L)));
                    instance.add(10, -72);
                    fs1.b(cls).q(mv1.f.f(Long.valueOf(instance.getTimeInMillis()))).m().h();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return new ix1(jSONArray, j);
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }
}
