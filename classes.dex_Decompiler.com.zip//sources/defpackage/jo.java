package defpackage;

import android.os.SystemClock;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

/* renamed from: jo  reason: default package */
public class jo implements rn {
    public final io a;

    /* renamed from: a  reason: collision with other field name */
    public final ko f3293a;
    @Deprecated

    /* renamed from: a  reason: collision with other field name */
    public final po f3294a;

    public jo(io ioVar) {
        this(ioVar, new ko(4096));
    }

    public jo(io ioVar, ko koVar) {
        this.a = ioVar;
        this.f3294a = ioVar;
        this.f3293a = koVar;
    }

    @Deprecated
    public jo(po poVar) {
        this(poVar, new ko(4096));
    }

    @Deprecated
    public jo(po poVar, ko koVar) {
        this.f3294a = poVar;
        this.a = new ho(poVar);
        this.f3293a = koVar;
    }

    public un a(xn<?> xnVar) {
        byte[] bArr;
        oo ooVar;
        IOException iOException;
        oo b;
        int d;
        List<qn> c;
        xn<?> xnVar2 = xnVar;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        while (true) {
            Collections.emptyList();
            try {
                b = this.a.b(xnVar2, no.c(xnVar.m()));
                try {
                    d = b.d();
                    c = b.c();
                    break;
                } catch (IOException e) {
                    bArr = null;
                    ooVar = b;
                    iOException = e;
                }
            } catch (IOException e2) {
                iOException = e2;
                ooVar = null;
                bArr = null;
            }
            to.a(xnVar2, to.e(xnVar, iOException, elapsedRealtime, ooVar, bArr));
        }
        if (d == 304) {
            return to.b(xnVar2, SystemClock.elapsedRealtime() - elapsedRealtime, c);
        }
        InputStream a2 = b.a();
        byte[] c2 = a2 != null ? to.c(a2, b.b(), this.f3293a) : new byte[0];
        to.d(SystemClock.elapsedRealtime() - elapsedRealtime, xnVar2, c2, d);
        if (d < 200 || d > 299) {
            throw new IOException();
        }
        return new un(d, c2, false, SystemClock.elapsedRealtime() - elapsedRealtime, c);
    }
}
