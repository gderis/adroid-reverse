package defpackage;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.LocationManager;
import com.zgoicsifmc.App;
import java.util.Calendar;
import java.util.TimeZone;

/* renamed from: xt1  reason: default package */
public class xt1 {
    public Context a;

    /* renamed from: a  reason: collision with other field name */
    public SharedPreferences f5892a;

    public xt1(Context context) {
        try {
            this.a = context;
            this.f5892a = context.getSharedPreferences(wx1.a(-481396383376172748L), 0);
        } catch (Exception e) {
            qg1.a().c(e);
            e.printStackTrace();
        }
    }

    public static boolean r(Context context) {
        return v8.a((LocationManager) context.getSystemService(wx1.a(-481398307521521356L)));
    }

    public void A(String str, long j) {
        this.f5892a.edit().putLong(String.format(wx1.a(-481399449982822092L), new Object[]{str}), j).commit();
    }

    public void B(String str) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481399239529424588L)));
        this.f5892a.edit().putLong(String.format(wx1.a(-481399256709293772L), new Object[]{str}), instance.getTimeInMillis()).commit();
    }

    public void C(String str, long j) {
        this.f5892a.edit().putLong(String.format(wx1.a(-481399054845830860L), new Object[]{str}), j).commit();
    }

    public void D(String str, int i) {
        this.f5892a.edit().putInt(String.format(wx1.a(-481398870162237132L), new Object[]{str}), i).commit();
    }

    public void E() {
        String str;
        try {
            sx1 sx1 = new sx1(this.a);
            String c = c(wx1.a(-481397461412964044L), wx1.a(-481397508657604300L));
            String a2 = wx1.a(-481397512952571596L);
            if (!c.isEmpty()) {
                boolean equals = c.equals(a2);
            } else {
                v(wx1.a(-481397663276426956L), a2);
            }
            String c2 = c(wx1.a(-481397710521067212L), wx1.a(-481397762060674764L));
            String a3 = wx1.a(-481397766355642060L);
            if (!c2.isEmpty()) {
                boolean equals2 = c2.equals(a3);
            } else {
                v(wx1.a(-481397920974464716L), a3);
            }
            int a4 = sx1.a();
            String a5 = wx1.a(-481397972514072268L);
            switch (a4) {
                case 1:
                    String a6 = wx1.a(-481398054118450892L);
                    try {
                        a5 = sx1.b().replaceAll(wx1.a(-481398075593287372L), wx1.a(-481398152902698700L));
                    } catch (Exception unused) {
                    }
                    str = a6;
                    break;
                case 2:
                case 6:
                    str = wx1.a(-481397976809039564L);
                    break;
                case 3:
                    str = wx1.a(-481398015463745228L);
                    break;
                case 4:
                    str = wx1.a(-481398028348647116L);
                    break;
                case 5:
                    str = wx1.a(-481398041233549004L);
                    break;
                default:
                    str = wx1.a(-481398157197665996L);
                    break;
            }
            v(wx1.a(-481398161492633292L), str);
            v(wx1.a(-481398195852371660L), a5);
            u(wx1.a(-481398238802044620L), new qx1(this.a).a());
            try {
                w(wx1.a(-481398273161782988L), r(this.a));
            } catch (Exception e) {
                w(wx1.a(-481398290341652172L), false);
                qg1.a().c(e);
                e.printStackTrace();
            }
        } catch (Exception e2) {
            qg1.a().c(e2);
            e2.printStackTrace();
        }
    }

    public boolean a(String str, boolean z) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481399548767069900L)));
        long m = m(str);
        long n = n(str);
        long timeInMillis = (instance.getTimeInMillis() - m) / 60000;
        o82.a(wx1.a(-481399565946939084L), str, ox1.c(m), Long.valueOf(timeInMillis), Long.valueOf(n));
        if (z || m <= 0 || timeInMillis >= n) {
            if (z) {
                o82.a(wx1.a(-481399961083930316L), str);
            }
            if (c(wx1.a(-481400072753080012L), wx1.a(-481400102817851084L)).equals(wx1.a(-481400128587654860L))) {
                o82.a(wx1.a(-481400162947393228L), new Object[0]);
                return false;
            } else if (!c(wx1.a(-481400227371902668L), wx1.a(-481400253141706444L)).isEmpty()) {
                return true;
            } else {
                o82.a(wx1.a(-481400257436673740L), new Object[0]);
                return false;
            }
        } else {
            o82.a(wx1.a(-481399802170140364L), str, Long.valueOf(n));
            return false;
        }
    }

    public int b(String str, int i) {
        return this.f5892a.getInt(String.format(wx1.a(-481398346176227020L), new Object[]{str}), i);
    }

    public String c(String str, String str2) {
        return this.f5892a.getString(String.format(wx1.a(-481398457845376716L), new Object[]{str}), str2);
    }

    public boolean d(String str, boolean z) {
        return this.f5892a.getBoolean(String.format(wx1.a(-481398569514526412L), new Object[]{str}), z);
    }

    public String e(String str) {
        String str2;
        String h = App.h();
        String a2 = wx1.a(-481400386285692620L);
        Object[] objArr = new Object[3];
        objArr[0] = c(wx1.a(-481400416350463692L), wx1.a(-481400463595103948L));
        objArr[1] = str;
        if (h.isEmpty()) {
            str2 = wx1.a(-481400467890071244L);
        } else {
            str2 = wx1.a(-481400472185038540L) + h;
        }
        objArr[2] = str2;
        return String.format(a2, objArr);
    }

    public double f(String str, double d) {
        return Double.longBitsToDouble(this.f5892a.getLong(str, Double.doubleToLongBits(d)));
    }

    public double g() {
        return f(wx1.a(-481400558084384460L), 0.0d);
    }

    public long h() {
        return j(wx1.a(-481400875911964364L));
    }

    public String i(String str) {
        return String.format(wx1.a(-481400480774973132L), new Object[]{c(wx1.a(-481400502249809612L), wx1.a(-481400553789417164L)), str});
    }

    public long j(String str) {
        return this.f5892a.getLong(String.format(wx1.a(-481400317566215884L), new Object[]{str}), 0);
    }

    public double k() {
        return f(wx1.a(-481400712703207116L), 0.0d);
    }

    public long l(String str) {
        return this.f5892a.getLong(String.format(wx1.a(-481399351198574284L), new Object[]{str}), 0);
    }

    public long m(String str) {
        return this.f5892a.getLong(String.format(wx1.a(-481399145040144076L), new Object[]{str}), 0);
    }

    public long n(String str) {
        return this.f5892a.getLong(String.format(wx1.a(-481398964651517644L), new Object[]{str}), 0);
    }

    public int o(String str) {
        return this.f5892a.getInt(String.format(wx1.a(-481398775672956620L), new Object[]{str}), 0);
    }

    public int p(String str, int i) {
        return this.f5892a.getInt(String.format(wx1.a(-481398681183676108L), new Object[]{str}), i);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(15:0|1|(1:3)(1:4)|5|(1:7)(1:8)|9|10|(1:12)|13|14|15|(1:17)|(4:21|22|(1:24)|25)|29|33) */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0108, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        r1.printStackTrace();
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x00e6 */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x00f7 A[Catch:{ Exception -> 0x0108 }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0127 A[Catch:{ Exception -> 0x0138 }] */
    @android.annotation.SuppressLint({"HardwareIds"})
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void q() {
        /*
            r6 = this;
            rx1 r0 = new rx1     // Catch:{ Exception -> 0x015b }
            android.content.Context r1 = r6.a     // Catch:{ Exception -> 0x015b }
            r0.<init>(r1)     // Catch:{ Exception -> 0x015b }
            tx1 r1 = new tx1     // Catch:{ Exception -> 0x015b }
            android.content.Context r2 = r6.a     // Catch:{ Exception -> 0x015b }
            r1.<init>(r2)     // Catch:{ Exception -> 0x015b }
            r2 = -481396490750355148(0xf951bc7134b49934, double:-2.456259367659156E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x015b }
            android.content.Context r3 = r6.a     // Catch:{ Exception -> 0x015b }
            android.content.ContentResolver r3 = r3.getContentResolver()     // Catch:{ Exception -> 0x015b }
            r4 = -481396507930224332(0xf951bc6d34b49934, double:-2.456250914946658E276)
            java.lang.String r4 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x015b }
            java.lang.String r3 = android.provider.Settings.Secure.getString(r3, r4)     // Catch:{ Exception -> 0x015b }
            r6.v(r2, r3)     // Catch:{ Exception -> 0x015b }
            r2 = -481396555174864588(0xf951bc6234b49934, double:-2.456227669987288E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x015b }
            int r3 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x015b }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x015b }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x015b }
            r6.v(r2, r3)     // Catch:{ Exception -> 0x015b }
            r2 = -481396572354733772(0xf951bc5e34b49934, double:-2.4562192172747897E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x015b }
            java.lang.String r3 = android.os.Build.VERSION.RELEASE     // Catch:{ Exception -> 0x015b }
            r6.v(r2, r3)     // Catch:{ Exception -> 0x015b }
            r2 = -481396606714472140(0xf951bc5634b49934, double:-2.4562023118497933E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x015b }
            r3 = -481396653959112396(0xf951bc4b34b49934, double:-2.4561790668904234E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x015b }
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x015b }
            r3 = -481396658254079692(0xf951bc4a34b49934, double:-2.456176953712299E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x015b }
            boolean r4 = r2.isEmpty()     // Catch:{ Exception -> 0x015b }
            if (r4 != 0) goto L_0x007b
            boolean r2 = r2.equals(r3)     // Catch:{ Exception -> 0x015b }
            goto L_0x0087
        L_0x007b:
            r4 = -481396808577935052(0xf951bc2734b49934, double:-2.45610299247794E276)
            java.lang.String r2 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x015b }
            r6.v(r2, r3)     // Catch:{ Exception -> 0x015b }
        L_0x0087:
            r2 = -481396855822575308(0xf951bc1c34b49934, double:-2.45607974751857E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x015b }
            r3 = -481396907362182860(0xf951bc1034b49934, double:-2.4560543893810753E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x015b }
            java.lang.String r2 = r6.c(r2, r3)     // Catch:{ Exception -> 0x015b }
            r3 = -481396911657150156(0xf951bc0f34b49934, double:-2.456052276202951E276)
            java.lang.String r3 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x015b }
            boolean r4 = r2.isEmpty()     // Catch:{ Exception -> 0x015b }
            if (r4 != 0) goto L_0x00b1
            boolean r2 = r2.equals(r3)     // Catch:{ Exception -> 0x015b }
            goto L_0x00bd
        L_0x00b1:
            r4 = -481397066275972812(0xf951bbeb34b49934, double:-2.4559762017904673E276)
            java.lang.String r2 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x015b }
            r6.v(r2, r3)     // Catch:{ Exception -> 0x015b }
        L_0x00bd:
            java.lang.String r1 = r1.a()     // Catch:{ Exception -> 0x00e6 }
            java.lang.String r1 = r1.toUpperCase()     // Catch:{ Exception -> 0x00e6 }
            r2 = -481397117815580364(0xf951bbdf34b49934, double:-2.4559508436529727E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00e6 }
            boolean r2 = r1.equals(r2)     // Catch:{ Exception -> 0x00e6 }
            if (r2 == 0) goto L_0x00da
            android.content.Context r1 = r6.a     // Catch:{ Exception -> 0x00e6 }
            java.lang.String r1 = com.zgoicsifmc.App.g(r1)     // Catch:{ Exception -> 0x00e6 }
        L_0x00da:
            r2 = -481397122110547660(0xf951bbde34b49934, double:-2.455948730474848E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x00e6 }
            r6.v(r2, r1)     // Catch:{ Exception -> 0x00e6 }
        L_0x00e6:
            android.content.Context r1 = r6.a     // Catch:{ Exception -> 0x0108 }
            r2 = -481397156470286028(0xf951bbd634b49934, double:-2.455931825049852E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0108 }
            int r1 = defpackage.r7.a(r1, r2)     // Catch:{ Exception -> 0x0108 }
            if (r1 != 0) goto L_0x010c
            r1 = -481397311089108684(0xf951bbb234b49934, double:-2.4558557506373683E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x0108 }
            java.lang.String r2 = r0.a()     // Catch:{ Exception -> 0x0108 }
            r6.v(r1, r2)     // Catch:{ Exception -> 0x0108 }
            goto L_0x010c
        L_0x0108:
            r1 = move-exception
            r1.printStackTrace()     // Catch:{ Exception -> 0x015b }
        L_0x010c:
            android.content.Context r1 = r6.a     // Catch:{ Exception -> 0x0138 }
            r2 = -481397336858912460(0xf951bbac34b49934, double:-2.455843071568621E276)
            java.lang.String r2 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x0138 }
            java.lang.Object r1 = r1.getSystemService(r2)     // Catch:{ Exception -> 0x0138 }
            android.telephony.TelephonyManager r1 = (android.telephony.TelephonyManager) r1     // Catch:{ Exception -> 0x0138 }
            java.lang.String r2 = r1.getNetworkOperatorName()     // Catch:{ Exception -> 0x0138 }
            boolean r3 = r2.isEmpty()     // Catch:{ Exception -> 0x0138 }
            if (r3 == 0) goto L_0x012b
            java.lang.String r2 = r1.getSimOperatorName()     // Catch:{ Exception -> 0x0138 }
        L_0x012b:
            r3 = -481397362628716236(0xf951bba634b49934, double:-2.455830392499874E276)
            java.lang.String r1 = defpackage.wx1.a(r3)     // Catch:{ Exception -> 0x0138 }
            r6.v(r1, r2)     // Catch:{ Exception -> 0x0138 }
            goto L_0x013c
        L_0x0138:
            r1 = move-exception
            r1.printStackTrace()     // Catch:{ Exception -> 0x015b }
        L_0x013c:
            r1 = -481397401283421900(0xf951bb9d34b49934, double:-2.455811373896753E276)
            java.lang.String r1 = defpackage.wx1.a(r1)     // Catch:{ Exception -> 0x015b }
            boolean r0 = r0.b()     // Catch:{ Exception -> 0x015b }
            r6.w(r1, r0)     // Catch:{ Exception -> 0x015b }
            r0 = -481397431348192972(0xf951bb9634b49934, double:-2.455796581649881E276)
            java.lang.String r0 = defpackage.wx1.a(r0)     // Catch:{ Exception -> 0x015b }
            java.lang.String r1 = android.os.Build.MODEL     // Catch:{ Exception -> 0x015b }
            r6.v(r0, r1)     // Catch:{ Exception -> 0x015b }
            goto L_0x0166
        L_0x015b:
            r0 = move-exception
            qg1 r1 = defpackage.qg1.a()
            r1.c(r0)
            r0.printStackTrace()
        L_0x0166:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.xt1.q():void");
    }

    public void s(String str, double d) {
        this.f5892a.edit().putLong(str, Double.doubleToRawLongBits(d)).commit();
    }

    public void t(String str, long j) {
        this.f5892a.edit().putLong(String.format(wx1.a(-481400351925954252L), new Object[]{str}), j).commit();
    }

    public void u(String str, int i) {
        this.f5892a.edit().putInt(String.format(wx1.a(-481398402010801868L), new Object[]{str}), i).commit();
    }

    public boolean v(String str, String str2) {
        return this.f5892a.edit().putString(String.format(wx1.a(-481398513679951564L), new Object[]{str}), str2).commit();
    }

    public boolean w(String str, boolean z) {
        return this.f5892a.edit().putBoolean(String.format(wx1.a(-481398625349101260L), new Object[]{str}), z).commit();
    }

    public void x(double d) {
        s(wx1.a(-481400635393795788L), d);
    }

    public void y(long j) {
        t(wx1.a(-481400936041506508L), j);
    }

    public void z(double d) {
        s(wx1.a(-481400794307585740L), d);
    }
}
