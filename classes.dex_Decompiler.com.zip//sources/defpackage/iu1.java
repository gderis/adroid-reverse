package defpackage;

import android.view.View;
import com.zgoicsifmc.activities.TargetActivity;

/* renamed from: iu1  reason: default package */
public final /* synthetic */ class iu1 implements View.OnClickListener {
    public final /* synthetic */ TargetActivity a;

    public /* synthetic */ iu1(TargetActivity targetActivity) {
        this.a = targetActivity;
    }

    public final void onClick(View view) {
        this.a.M(view);
    }
}
