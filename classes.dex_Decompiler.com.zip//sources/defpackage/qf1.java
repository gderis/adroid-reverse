package defpackage;

import defpackage.jm1;

/* renamed from: qf1  reason: default package */
public final /* synthetic */ class qf1 implements jm1.a {
    public final /* synthetic */ jm1.a a;
    public final /* synthetic */ jm1.a b;

    public /* synthetic */ qf1(jm1.a aVar, jm1.a aVar2) {
        this.a = aVar;
        this.b = aVar2;
    }

    public final void a(km1 km1) {
        hg1.e(this.a, this.b, km1);
    }
}
