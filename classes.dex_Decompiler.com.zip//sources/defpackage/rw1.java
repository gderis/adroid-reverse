package defpackage;

import android.app.Application;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: rw1  reason: default package */
public class rw1 extends Application {
    public static ix1 a(xt1 xt1, boolean z) {
        Class<dv1> cls = dv1.class;
        JSONArray jSONArray = new JSONArray();
        long j = 0;
        try {
            j = xt1.l(wx1.a(-481408516658783948L));
            int p = xt1.p(wx1.a(-481408559608456908L), 50);
            if (!xt1.a(wx1.a(-481408602558129868L), z)) {
                return new ix1(jSONArray, j);
            }
            xr1<TModel> a = fs1.c(new js1[0]).a(cls);
            ks1<Long> ks1 = ev1.d;
            List<TModel> p2 = a.q(ks1.e(Long.valueOf(j))).s(ks1, true).r(p).p();
            o82.d(wx1.a(-481408645507802828L), ox1.c(j));
            if (p2.size() > 0) {
                for (int i = 0; i < p2.size(); i++) {
                    try {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put(wx1.a(-481408718522246860L), ((dv1) p2.get(i)).c());
                        jSONObject.put(wx1.a(-481408735702116044L), ((dv1) p2.get(i)).e());
                        jSONObject.put(wx1.a(-481408757176952524L), ox1.c(((dv1) p2.get(i)).d()));
                        jSONArray.put(jSONObject);
                        if (((dv1) p2.get(i)).d() > j) {
                            j = ((dv1) p2.get(i)).d();
                        }
                    } catch (Exception e) {
                        qg1.a().c(e);
                        e.printStackTrace();
                    }
                }
                try {
                    Calendar instance = Calendar.getInstance();
                    instance.setTimeZone(TimeZone.getTimeZone(wx1.a(-481408795831658188L)));
                    instance.add(10, -72);
                    fs1.b(cls).q(ev1.d.f(Long.valueOf(instance.getTimeInMillis()))).m().h();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return new ix1(jSONArray, j);
        } catch (Exception e3) {
            qg1.a().c(e3);
            e3.printStackTrace();
        }
    }
}
