package defpackage;

import com.google.auto.value.AutoValue;
import defpackage.gn1;

@AutoValue
/* renamed from: kn1  reason: default package */
public abstract class kn1 {

    @AutoValue.Builder
    /* renamed from: kn1$a */
    public static abstract class a {
        public abstract kn1 a();

        public abstract a b(b bVar);

        public abstract a c(String str);

        public abstract a d(long j);
    }

    /* renamed from: kn1$b */
    public enum b {
        OK,
        BAD_CONFIG,
        AUTH_ERROR
    }

    public static a a() {
        return new gn1.b().d(0);
    }

    public abstract b b();

    public abstract String c();

    public abstract long d();
}
