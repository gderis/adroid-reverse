package defpackage;

import com.zgoicsifmc.activities.LoginActivity;

/* renamed from: cu1  reason: default package */
public final /* synthetic */ class cu1 implements Runnable {
    public final /* synthetic */ LoginActivity.a.C0009a a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ i42 f1803a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ xt1 f1804a;

    public /* synthetic */ cu1(LoginActivity.a.C0009a aVar, i42 i42, xt1 xt1) {
        this.a = aVar;
        this.f1803a = i42;
        this.f1804a = xt1;
    }

    public final void run() {
        this.a.f(this.f1803a, this.f1804a);
    }
}
