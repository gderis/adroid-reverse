package defpackage;

/* renamed from: em0  reason: default package */
public final class em0<K, V> {
}
