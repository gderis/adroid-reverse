package defpackage;

/* renamed from: s22  reason: default package */
public class s22 {
    /* JADX WARNING: type inference failed for: r3v0, types: [i12<? super T, ? extends java.lang.CharSequence>, i12] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final <T> void a(java.lang.Appendable r1, T r2, defpackage.i12<? super T, ? extends java.lang.CharSequence> r3) {
        /*
            java.lang.String r0 = "$this$appendElement"
            defpackage.p12.d(r1, r0)
            if (r3 == 0) goto L_0x0011
            java.lang.Object r2 = r3.b(r2)
        L_0x000b:
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
        L_0x000d:
            r1.append(r2)
            goto L_0x002d
        L_0x0011:
            if (r2 == 0) goto L_0x0016
            boolean r3 = r2 instanceof java.lang.CharSequence
            goto L_0x0017
        L_0x0016:
            r3 = 1
        L_0x0017:
            if (r3 == 0) goto L_0x001a
            goto L_0x000b
        L_0x001a:
            boolean r3 = r2 instanceof java.lang.Character
            if (r3 == 0) goto L_0x0028
            java.lang.Character r2 = (java.lang.Character) r2
            char r2 = r2.charValue()
            r1.append(r2)
            goto L_0x002d
        L_0x0028:
            java.lang.String r2 = java.lang.String.valueOf(r2)
            goto L_0x000d
        L_0x002d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.s22.a(java.lang.Appendable, java.lang.Object, i12):void");
    }
}
