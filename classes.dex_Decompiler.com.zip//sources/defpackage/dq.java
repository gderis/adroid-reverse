package defpackage;

import defpackage.nq;
import java.util.Arrays;
import java.util.Objects;

/* renamed from: dq  reason: default package */
public final class dq extends nq {
    public final ap a;

    /* renamed from: a  reason: collision with other field name */
    public final String f2040a;

    /* renamed from: a  reason: collision with other field name */
    public final byte[] f2041a;

    /* renamed from: dq$b */
    public static final class b extends nq.a {
        public ap a;

        /* renamed from: a  reason: collision with other field name */
        public String f2042a;

        /* renamed from: a  reason: collision with other field name */
        public byte[] f2043a;

        public nq a() {
            String str = "";
            if (this.f2042a == null) {
                str = str + " backendName";
            }
            if (this.a == null) {
                str = str + " priority";
            }
            if (str.isEmpty()) {
                return new dq(this.f2042a, this.f2043a, this.a);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        public nq.a b(String str) {
            Objects.requireNonNull(str, "Null backendName");
            this.f2042a = str;
            return this;
        }

        public nq.a c(byte[] bArr) {
            this.f2043a = bArr;
            return this;
        }

        public nq.a d(ap apVar) {
            Objects.requireNonNull(apVar, "Null priority");
            this.a = apVar;
            return this;
        }
    }

    public dq(String str, byte[] bArr, ap apVar) {
        this.f2040a = str;
        this.f2041a = bArr;
        this.a = apVar;
    }

    public String b() {
        return this.f2040a;
    }

    public byte[] c() {
        return this.f2041a;
    }

    public ap d() {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof nq)) {
            return false;
        }
        nq nqVar = (nq) obj;
        if (this.f2040a.equals(nqVar.b())) {
            return Arrays.equals(this.f2041a, nqVar instanceof dq ? ((dq) nqVar).f2041a : nqVar.c()) && this.a.equals(nqVar.d());
        }
    }

    public int hashCode() {
        return ((((this.f2040a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f2041a)) * 1000003) ^ this.a.hashCode();
    }
}
