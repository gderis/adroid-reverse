package defpackage;

/* renamed from: cy  reason: default package */
public final class cy extends ky {
    public final /* synthetic */ u71 a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ ux f1812a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public cy(zx zxVar, iy iyVar, ux uxVar, u71 u71) {
        super(iyVar);
        this.f1812a = uxVar;
        this.a = u71;
    }

    public final void a() {
        this.f1812a.m(this.a);
    }
}
