package defpackage;

/* renamed from: ey  reason: default package */
public abstract class ey implements Runnable {
    public final /* synthetic */ ux a;

    public ey(ux uxVar) {
        this.a = uxVar;
    }

    public /* synthetic */ ey(ux uxVar, tx txVar) {
        this(uxVar);
    }

    public abstract void a();

    public void run() {
        this.a.f5470a.lock();
        try {
            if (!Thread.interrupted()) {
                a();
            }
        } catch (RuntimeException e) {
            this.a.f5472a.n(e);
        } catch (Throwable th) {
            this.a.f5470a.unlock();
            throw th;
        }
        this.a.f5470a.unlock();
    }
}
