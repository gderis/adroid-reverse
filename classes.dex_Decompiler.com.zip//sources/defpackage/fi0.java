package defpackage;

/* renamed from: fi0  reason: default package */
public interface fi0 {
    Object a(String str);
}
