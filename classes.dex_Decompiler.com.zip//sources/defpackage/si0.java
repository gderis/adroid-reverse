package defpackage;

import android.content.Context;
import android.net.Uri;
import javax.annotation.Nullable;

/* renamed from: si0  reason: default package */
public final class si0 {
    public final Uri a;

    /* renamed from: a  reason: collision with other field name */
    public final String f5060a = null;
    @Nullable

    /* renamed from: a  reason: collision with other field name */
    public final zi0<Context, Boolean> f5061a;

    /* renamed from: a  reason: collision with other field name */
    public final boolean f5062a;
    public final String b;

    /* renamed from: b  reason: collision with other field name */
    public final boolean f5063b;
    public final String c;

    /* renamed from: c  reason: collision with other field name */
    public final boolean f5064c;
    public final boolean d;

    public si0(Uri uri) {
        this.a = uri;
        this.b = "";
        this.c = "";
        this.f5062a = false;
        this.f5063b = false;
        this.f5064c = false;
        this.d = false;
        this.f5061a = null;
    }

    public final ui0<Long> a(String str, long j) {
        return new oi0(this, str, Long.valueOf(j), true);
    }

    public final ui0<Boolean> b(String str, boolean z) {
        return new pi0(this, str, Boolean.valueOf(z), true);
    }

    public final ui0<Double> c(String str, double d2) {
        return new qi0(this, "measurement.test.double_flag", Double.valueOf(-3.0d), true);
    }

    public final ui0<String> d(String str, String str2) {
        return new ri0(this, str, str2, true);
    }
}
