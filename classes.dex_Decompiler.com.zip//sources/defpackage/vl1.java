package defpackage;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/* renamed from: vl1  reason: default package */
public final class vl1 implements rl1<vl1> {
    public static final ml1<Object> a = sl1.a;

    /* renamed from: a  reason: collision with other field name */
    public static final ol1<String> f5590a = tl1.a;

    /* renamed from: a  reason: collision with other field name */
    public static final b f5591a = new b((a) null);
    public static final ol1<Boolean> b = ul1.a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<Class<?>, ml1<?>> f5592a = new HashMap();

    /* renamed from: a  reason: collision with other field name */
    public boolean f5593a = false;

    /* renamed from: b  reason: collision with other field name */
    public final Map<Class<?>, ol1<?>> f5594b = new HashMap();

    /* renamed from: b  reason: collision with other field name */
    public ml1<Object> f5595b = a;

    /* renamed from: vl1$a */
    public class a implements il1 {
        public a() {
        }

        public void a(Object obj, Writer writer) {
            wl1 wl1 = new wl1(writer, vl1.this.f5592a, vl1.this.f5594b, vl1.this.f5595b, vl1.this.f5593a);
            wl1.i(obj, false);
            wl1.r();
        }

        public String b(Object obj) {
            StringWriter stringWriter = new StringWriter();
            try {
                a(obj, stringWriter);
            } catch (IOException unused) {
            }
            return stringWriter.toString();
        }
    }

    /* renamed from: vl1$b */
    public static final class b implements ol1<Date> {
        public static final DateFormat a;

        static {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            a = simpleDateFormat;
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        }

        public b() {
        }

        public /* synthetic */ b(a aVar) {
            this();
        }

        /* renamed from: b */
        public void a(Date date, pl1 pl1) {
            pl1.e(a.format(date));
        }
    }

    public vl1() {
        m(String.class, f5590a);
        m(Boolean.class, b);
        m(Date.class, f5591a);
    }

    public static /* synthetic */ void i(Object obj, nl1 nl1) {
        throw new kl1("Couldn't find encoder for type " + obj.getClass().getCanonicalName());
    }

    public il1 f() {
        return new a();
    }

    public vl1 g(ql1 ql1) {
        ql1.a(this);
        return this;
    }

    public vl1 h(boolean z) {
        this.f5593a = z;
        return this;
    }

    /* renamed from: l */
    public <T> vl1 a(Class<T> cls, ml1<? super T> ml1) {
        this.f5592a.put(cls, ml1);
        this.f5594b.remove(cls);
        return this;
    }

    public <T> vl1 m(Class<T> cls, ol1<? super T> ol1) {
        this.f5594b.put(cls, ol1);
        this.f5592a.remove(cls);
        return this;
    }
}
