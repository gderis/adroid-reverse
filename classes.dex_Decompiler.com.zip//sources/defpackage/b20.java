package defpackage;

import android.os.IBinder;
import android.os.Parcel;

/* renamed from: b20  reason: default package */
public final class b20 extends r60 implements c20 {
    public b20(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.service.IClientTelemetryService");
    }

    public final void L(i20 i20) {
        Parcel b = b();
        s60.c(b, i20);
        d(1, b);
    }
}
