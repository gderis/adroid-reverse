package defpackage;

import android.graphics.RectF;
import java.util.Arrays;

/* renamed from: jd1  reason: default package */
public final class jd1 implements dd1 {
    public final float a;

    public jd1(float f) {
        this.a = f;
    }

    public float a(RectF rectF) {
        return this.a * rectF.height();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof jd1) && this.a == ((jd1) obj).a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.a)});
    }
}
