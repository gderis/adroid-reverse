package defpackage;

/* renamed from: de  reason: default package */
public interface de {
    ae j();
}
