package defpackage;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import defpackage.ia;
import defpackage.u0;

/* renamed from: e0  reason: default package */
public class e0 extends Dialog implements b0 {
    public c0 a;

    /* renamed from: a  reason: collision with other field name */
    public final ia.a f2101a = new a();

    /* renamed from: e0$a */
    public class a implements ia.a {
        public a() {
        }

        public boolean c(KeyEvent keyEvent) {
            return e0.this.d(keyEvent);
        }
    }

    public e0(Context context, int i) {
        super(context, c(context, i));
        c0 b = b();
        b.D(c(context, i));
        b.q((Bundle) null);
    }

    public static int c(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(o.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public void a(u0 u0Var) {
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        b().d(view, layoutParams);
    }

    public c0 b() {
        if (this.a == null) {
            this.a = c0.h(this, this);
        }
        return this.a;
    }

    public boolean d(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public void dismiss() {
        super.dismiss();
        b().r();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return ia.e(this.f2101a, getWindow().getDecorView(), this, keyEvent);
    }

    public boolean e(int i) {
        return b().z(i);
    }

    public <T extends View> T findViewById(int i) {
        return b().i(i);
    }

    public void g(u0 u0Var) {
    }

    public u0 i(u0.a aVar) {
        return null;
    }

    public void invalidateOptionsMenu() {
        b().o();
    }

    public void onCreate(Bundle bundle) {
        b().n();
        super.onCreate(bundle);
        b().q(bundle);
    }

    public void onStop() {
        super.onStop();
        b().w();
    }

    public void setContentView(int i) {
        b().A(i);
    }

    public void setContentView(View view) {
        b().B(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        b().C(view, layoutParams);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        b().E(getContext().getString(i));
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        b().E(charSequence);
    }
}
