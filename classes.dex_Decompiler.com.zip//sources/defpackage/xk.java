package defpackage;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemjob.SystemJobService;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* renamed from: xk  reason: default package */
public class xk implements hk {
    public static final String a = qj.f("SystemJobScheduler");

    /* renamed from: a  reason: collision with other field name */
    public final JobScheduler f5860a;

    /* renamed from: a  reason: collision with other field name */
    public final Context f5861a;

    /* renamed from: a  reason: collision with other field name */
    public final mk f5862a;

    /* renamed from: a  reason: collision with other field name */
    public final wk f5863a;

    public xk(Context context, mk mkVar) {
        this(context, mkVar, (JobScheduler) context.getSystemService("jobscheduler"), new wk(context));
    }

    public xk(Context context, mk mkVar, JobScheduler jobScheduler, wk wkVar) {
        this.f5861a = context;
        this.f5862a = mkVar;
        this.f5860a = jobScheduler;
        this.f5863a = wkVar;
    }

    public static void c(Context context) {
        List<JobInfo> g;
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService("jobscheduler");
        if (jobScheduler != null && (g = g(context, jobScheduler)) != null && !g.isEmpty()) {
            for (JobInfo id : g) {
                e(jobScheduler, id.getId());
            }
        }
    }

    public static void e(JobScheduler jobScheduler, int i) {
        try {
            jobScheduler.cancel(i);
        } catch (Throwable th) {
            qj.c().b(a, String.format(Locale.getDefault(), "Exception while trying to cancel job (%d)", new Object[]{Integer.valueOf(i)}), th);
        }
    }

    public static List<Integer> f(Context context, JobScheduler jobScheduler, String str) {
        List<JobInfo> g = g(context, jobScheduler);
        if (g == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(2);
        for (JobInfo next : g) {
            if (str.equals(h(next))) {
                arrayList.add(Integer.valueOf(next.getId()));
            }
        }
        return arrayList;
    }

    public static List<JobInfo> g(Context context, JobScheduler jobScheduler) {
        List<JobInfo> list;
        try {
            list = jobScheduler.getAllPendingJobs();
        } catch (Throwable th) {
            qj.c().b(a, "getAllPendingJobs() is not reliable on this device.", th);
            list = null;
        }
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        ComponentName componentName = new ComponentName(context, SystemJobService.class);
        for (JobInfo next : list) {
            if (componentName.equals(next.getService())) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public static String h(JobInfo jobInfo) {
        PersistableBundle extras = jobInfo.getExtras();
        if (extras == null) {
            return null;
        }
        try {
            if (extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return extras.getString("EXTRA_WORK_SPEC_ID");
            }
            return null;
        } catch (NullPointerException unused) {
            return null;
        }
    }

    public static boolean i(Context context, mk mkVar) {
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService("jobscheduler");
        List<JobInfo> g = g(context, jobScheduler);
        List<String> c = mkVar.u().y().c();
        boolean z = false;
        HashSet hashSet = new HashSet(g != null ? g.size() : 0);
        if (g != null && !g.isEmpty()) {
            for (JobInfo next : g) {
                String h = h(next);
                if (!TextUtils.isEmpty(h)) {
                    hashSet.add(h);
                } else {
                    e(jobScheduler, next.getId());
                }
            }
        }
        Iterator<String> it = c.iterator();
        while (true) {
            if (it.hasNext()) {
                if (!hashSet.contains(it.next())) {
                    qj.c().a(a, "Reconciling jobs", new Throwable[0]);
                    z = true;
                    break;
                }
            } else {
                break;
            }
        }
        if (z) {
            WorkDatabase u = mkVar.u();
            u.c();
            try {
                jm B = u.B();
                for (String o : c) {
                    B.o(o, -1);
                }
                u.r();
            } finally {
                u.g();
            }
        }
        return z;
    }

    public void a(String str) {
        List<Integer> f = f(this.f5861a, this.f5860a, str);
        if (f != null && !f.isEmpty()) {
            for (Integer intValue : f) {
                e(this.f5860a, intValue.intValue());
            }
            this.f5862a.u().y().a(str);
        }
    }

    public boolean b() {
        return true;
    }

    /* JADX INFO: finally extract failed */
    public void d(im... imVarArr) {
        List<Integer> f;
        WorkDatabase u = this.f5862a.u();
        rm rmVar = new rm(u);
        int length = imVarArr.length;
        int i = 0;
        while (i < length) {
            im imVar = imVarArr[i];
            u.c();
            try {
                im s = u.B().s(imVar.f3085b);
                if (s == null) {
                    qj c = qj.c();
                    String str = a;
                    c.h(str, "Skipping scheduling " + imVar.f3085b + " because it's no longer in the DB", new Throwable[0]);
                } else if (s.f3082a != zj.ENQUEUED) {
                    qj c2 = qj.c();
                    String str2 = a;
                    c2.h(str2, "Skipping scheduling " + imVar.f3085b + " because it is no longer enqueued", new Throwable[0]);
                } else {
                    zl b = u.y().b(imVar.f3085b);
                    int d = b != null ? b.a : rmVar.d(this.f5862a.n().h(), this.f5862a.n().f());
                    if (b == null) {
                        this.f5862a.u().y().d(new zl(imVar.f3085b, d));
                    }
                    j(imVar, d);
                    if (Build.VERSION.SDK_INT == 23 && (f = f(this.f5861a, this.f5860a, imVar.f3085b)) != null) {
                        int indexOf = f.indexOf(Integer.valueOf(d));
                        if (indexOf >= 0) {
                            f.remove(indexOf);
                        }
                        j(imVar, !f.isEmpty() ? f.get(0).intValue() : rmVar.d(this.f5862a.n().h(), this.f5862a.n().f()));
                    }
                }
                u.r();
                u.g();
                i++;
            } catch (Throwable th) {
                u.g();
                throw th;
            }
        }
    }

    public void j(im imVar, int i) {
        JobInfo a2 = this.f5863a.a(imVar, i);
        qj.c().a(a, String.format("Scheduling work ID %s Job ID %s", new Object[]{imVar.f3085b, Integer.valueOf(i)}), new Throwable[0]);
        try {
            this.f5860a.schedule(a2);
        } catch (IllegalStateException e) {
            List<JobInfo> g = g(this.f5861a, this.f5860a);
            String format = String.format(Locale.getDefault(), "JobScheduler 100 job limit exceeded.  We count %d WorkManager jobs in JobScheduler; we have %d tracked jobs in our DB; our Configuration limit is %d.", new Object[]{Integer.valueOf(g != null ? g.size() : 0), Integer.valueOf(this.f5862a.u().B().m().size()), Integer.valueOf(this.f5862a.n().g())});
            qj.c().b(a, format, new Throwable[0]);
            throw new IllegalStateException(format, e);
        } catch (Throwable th) {
            qj.c().b(a, String.format("Unable to schedule %s", new Object[]{imVar}), th);
        }
    }
}
