package defpackage;

/* renamed from: vq1  reason: default package */
public final class vq1<TModel> {
    public final Class<TModel> a;

    /* renamed from: a  reason: collision with other field name */
    public final os1<TModel> f5607a;

    /* renamed from: a  reason: collision with other field name */
    public final rs1<TModel> f5608a;

    /* renamed from: a  reason: collision with other field name */
    public final ss1<TModel> f5609a;

    public os1<TModel> a() {
        return this.f5607a;
    }

    public ss1<TModel> b() {
        return this.f5609a;
    }

    public rs1<TModel> c() {
        return this.f5608a;
    }

    public Class<?> d() {
        return this.a;
    }
}
