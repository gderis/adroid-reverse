package defpackage;

import android.os.Bundle;
import defpackage.vu0;

/* renamed from: af1  reason: default package */
public final class af1 implements vu0.a {
    public final /* synthetic */ bf1 a;

    public af1(bf1 bf1) {
        this.a = bf1;
    }

    public final void a(String str, String str2, Bundle bundle, long j) {
        if (str != null && !str.equals("crash") && xe1.c(str2)) {
            Bundle bundle2 = new Bundle();
            bundle2.putString("name", str2);
            bundle2.putLong("timestampInMillis", j);
            bundle2.putBundle("params", bundle);
            this.a.f1089a.a(3, bundle2);
        }
    }
}
