package defpackage;

/* renamed from: g11  reason: default package */
public final class g11 implements Runnable {
    public final /* synthetic */ g61 a;

    /* renamed from: a  reason: collision with other field name */
    public final /* synthetic */ p11 f2533a;

    public g11(p11 p11, g61 g61) {
        this.f2533a = p11;
        this.a = g61;
    }

    public final void run() {
        this.f2533a.f4365a.l();
        s51 L0 = this.f2533a.f4365a;
        g61 g61 = this.a;
        L0.f().h();
        L0.d0();
        s10.f(g61.f2574a);
        L0.y(g61);
    }
}
