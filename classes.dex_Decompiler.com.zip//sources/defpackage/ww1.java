package defpackage;

import android.app.Application;
import android.net.Uri;
import android.provider.MediaStore;

/* renamed from: ww1  reason: default package */
public class ww1 extends Application {
    public static final Uri a = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

    /* JADX WARNING: Removed duplicated region for block: B:114:0x03b7 A[SYNTHETIC, Splitter:B:114:0x03b7] */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x03cb A[Catch:{ Exception -> 0x03cf }] */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x03c9 A[EDGE_INSN: B:126:0x03c9->B:119:0x03c9 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:130:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0369 A[SYNTHETIC, Splitter:B:81:0x0369] */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0374 A[Catch:{ Exception -> 0x036d }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(android.content.Context r25, defpackage.xt1 r26, boolean r27) {
        /*
            r24 = this;
            r1 = r26
            r2 = -481411536020793036(0xf951aec234b49934, double:-2.448856904688883E276)
            java.lang.String r0 = defpackage.wx1.a(r2)     // Catch:{ Exception -> 0x03cf }
            long r2 = r1.l(r0)     // Catch:{ Exception -> 0x03cf }
            r4 = -481411591855367884(0xf951aeb534b49934, double:-2.448829433373264E276)
            java.lang.String r0 = defpackage.wx1.a(r4)     // Catch:{ Exception -> 0x03cf }
            r4 = 10
            int r4 = r1.p(r0, r4)     // Catch:{ Exception -> 0x03cf }
            r5 = -481411647689942732(0xf951aea834b49934, double:-2.448801962057645E276)
            java.lang.String r0 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x03cf }
            r5 = r27
            boolean r0 = r1.a(r0, r5)     // Catch:{ Exception -> 0x03cf }
            if (r0 != 0) goto L_0x0030
            return
        L_0x0030:
            int r0 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x03cf }
            r5 = 30
            r6 = 0
            r8 = 1
            r9 = 0
            if (r0 < r5) goto L_0x00b3
            android.os.Bundle r0 = new android.os.Bundle     // Catch:{ Exception -> 0x03cf }
            r0.<init>()     // Catch:{ Exception -> 0x03cf }
            r10 = -481411703524517580(0xf951ae9b34b49934, double:-2.448774490742026E276)
            java.lang.String r5 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            int r10 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r10 <= 0) goto L_0x004e
            r10 = r4
            goto L_0x004f
        L_0x004e:
            r10 = 1
        L_0x004f:
            r0.putInt(r5, r10)     // Catch:{ Exception -> 0x03cf }
            r10 = -481411806603732684(0xf951ae8334b49934, double:-2.448723774467037E276)
            java.lang.String r5 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            int r10 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r10 <= 0) goto L_0x0061
            r6 = 0
            goto L_0x0062
        L_0x0061:
            r6 = 1
        L_0x0062:
            r0.putInt(r5, r6)     // Catch:{ Exception -> 0x03cf }
            r5 = -481411948337653452(0xf951ae6234b49934, double:-2.448654039588927E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x03cf }
            java.lang.String[] r6 = new java.lang.String[r8]     // Catch:{ Exception -> 0x03cf }
            java.lang.String r7 = java.lang.String.valueOf(r2)     // Catch:{ Exception -> 0x03cf }
            r6[r9] = r7     // Catch:{ Exception -> 0x03cf }
            r10 = -481411982697391820(0xf951ae5a34b49934, double:-2.4486371341639306E276)
            java.lang.String r7 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            r0.putStringArray(r7, r6)     // Catch:{ Exception -> 0x03cf }
            r6 = -481412141611181772(0xf951ae3534b49934, double:-2.4485589465733225E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x03cf }
            r0.putString(r6, r5)     // Catch:{ Exception -> 0x03cf }
            java.lang.String[] r5 = new java.lang.String[r8]     // Catch:{ Exception -> 0x03cf }
            r6 = -481412279050135244(0xf951ae1534b49934, double:-2.448491324873337E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x03cf }
            r5[r9] = r6     // Catch:{ Exception -> 0x03cf }
            r6 = -481412296230004428(0xf951ae1134b49934, double:-2.448482872160839E276)
            java.lang.String r6 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x03cf }
            r0.putStringArray(r6, r5)     // Catch:{ Exception -> 0x03cf }
            android.content.ContentResolver r5 = r25.getContentResolver()     // Catch:{ Exception -> 0x03cf }
            android.net.Uri r6 = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI     // Catch:{ Exception -> 0x03cf }
            r7 = 0
            android.database.Cursor r0 = r5.query(r6, r7, r0, r7)     // Catch:{ Exception -> 0x03cf }
            goto L_0x0106
        L_0x00b3:
            int r0 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r0 <= 0) goto L_0x00f0
            android.content.ContentResolver r10 = r25.getContentResolver()     // Catch:{ Exception -> 0x03cf }
            android.net.Uri r11 = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI     // Catch:{ Exception -> 0x03cf }
            r12 = 0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x03cf }
            r0.<init>()     // Catch:{ Exception -> 0x03cf }
            r5 = -481412429373990604(0xf951adf234b49934, double:-2.448417363638978E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x03cf }
            r0.append(r5)     // Catch:{ Exception -> 0x03cf }
            r0.append(r2)     // Catch:{ Exception -> 0x03cf }
            java.lang.String r13 = r0.toString()     // Catch:{ Exception -> 0x03cf }
            r14 = 0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x03cf }
            r0.<init>()     // Catch:{ Exception -> 0x03cf }
            r5 = -481412459438761676(0xf951adeb34b49934, double:-2.4484025713921064E276)
            java.lang.String r5 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x03cf }
            r0.append(r5)     // Catch:{ Exception -> 0x03cf }
            r0.append(r4)     // Catch:{ Exception -> 0x03cf }
            java.lang.String r15 = r0.toString()     // Catch:{ Exception -> 0x03cf }
            goto L_0x0102
        L_0x00f0:
            android.content.ContentResolver r10 = r25.getContentResolver()     // Catch:{ Exception -> 0x03cf }
            android.net.Uri r11 = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI     // Catch:{ Exception -> 0x03cf }
            r12 = 0
            r13 = 0
            r14 = 0
            r5 = -481412523863271116(0xf951addc34b49934, double:-2.448370873720238E276)
            java.lang.String r15 = defpackage.wx1.a(r5)     // Catch:{ Exception -> 0x03cf }
        L_0x0102:
            android.database.Cursor r0 = r10.query(r11, r12, r13, r14, r15)     // Catch:{ Exception -> 0x03cf }
        L_0x0106:
            r5 = r0
            r6 = -481412596877715148(0xf951adcb34b49934, double:-2.448334949692121E276)
            java.lang.String r0 = defpackage.wx1.a(r6)     // Catch:{ Exception -> 0x03cf }
            r6 = 3
            java.lang.Object[] r7 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x03cf }
            android.net.Uri r10 = a     // Catch:{ Exception -> 0x03cf }
            r7[r9] = r10     // Catch:{ Exception -> 0x03cf }
            r10 = -481412674187126476(0xf951adb934b49934, double:-2.448296912485879E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            r7[r8] = r10     // Catch:{ Exception -> 0x03cf }
            java.lang.Long r2 = java.lang.Long.valueOf(r2)     // Catch:{ Exception -> 0x03cf }
            r3 = 2
            r7[r3] = r2     // Catch:{ Exception -> 0x03cf }
            defpackage.o82.d(r0, r7)     // Catch:{ Exception -> 0x03cf }
            if (r5 == 0) goto L_0x03c9
            boolean r0 = r5.moveToFirst()     // Catch:{ Exception -> 0x03cf }
            if (r0 == 0) goto L_0x03c9
            r10 = -481412691366995660(0xf951adb534b49934, double:-2.448288459773381E276)
            java.lang.String r0 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            int r2 = r5.getColumnIndex(r0)     // Catch:{ Exception -> 0x03cf }
            r10 = -481412708546864844(0xf951adb134b49934, double:-2.448280007060883E276)
            java.lang.String r0 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            int r7 = r5.getColumnIndex(r0)     // Catch:{ Exception -> 0x03cf }
            r10 = -481412734316668620(0xf951adab34b49934, double:-2.4482673279921356E276)
            java.lang.String r0 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x03cf }
            int r10 = r5.getColumnIndex(r0)     // Catch:{ Exception -> 0x03cf }
            r11 = -481412772971374284(0xf951ada234b49934, double:-2.4482483093890147E276)
            java.lang.String r0 = defpackage.wx1.a(r11)     // Catch:{ Exception -> 0x03cf }
            int r11 = r5.getColumnIndex(r0)     // Catch:{ Exception -> 0x03cf }
            r12 = -481412815921047244(0xf951ad9834b49934, double:-2.4482271776077693E276)
            java.lang.String r0 = defpackage.wx1.a(r12)     // Catch:{ Exception -> 0x03cf }
            int r12 = r5.getColumnIndex(r0)     // Catch:{ Exception -> 0x03cf }
            r13 = -481412841690851020(0xf951ad9234b49934, double:-2.448214498539022E276)
            java.lang.String r0 = defpackage.wx1.a(r13)     // Catch:{ Exception -> 0x03cf }
            int r13 = r5.getColumnIndex(r0)     // Catch:{ Exception -> 0x03cf }
            r14 = 0
        L_0x0183:
            java.lang.String r0 = r5.getString(r7)     // Catch:{ Exception -> 0x03a9 }
            int r15 = r5.getInt(r12)     // Catch:{ Exception -> 0x03a9 }
            int r6 = r5.getInt(r13)     // Catch:{ Exception -> 0x03a9 }
            if (r15 <= r6) goto L_0x0194
            r16 = 1
            goto L_0x0196
        L_0x0194:
            r16 = 0
        L_0x0196:
            java.lang.String r3 = r5.getString(r10)     // Catch:{ Exception -> 0x03a9 }
            java.lang.String r8 = r5.getString(r11)     // Catch:{ Exception -> 0x03a9 }
            r19 = -481412871755622092(0xf951ad8b34b49934, double:-2.4481997062921503E276)
            java.lang.String r9 = defpackage.wx1.a(r19)     // Catch:{ Exception -> 0x03a0 }
            r19 = r7
            r7 = 6
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x03a2 }
            r20 = 0
            r7[r20] = r0     // Catch:{ Exception -> 0x03a2 }
            r18 = 1
            r7[r18] = r3     // Catch:{ Exception -> 0x03a2 }
            r17 = 2
            r7[r17] = r8     // Catch:{ Exception -> 0x0399 }
            java.lang.Integer r20 = java.lang.Integer.valueOf(r16)     // Catch:{ Exception -> 0x0399 }
            r21 = 3
            r7[r21] = r20     // Catch:{ Exception -> 0x0392 }
            r20 = 4
            java.lang.Integer r15 = java.lang.Integer.valueOf(r15)     // Catch:{ Exception -> 0x0392 }
            r7[r20] = r15     // Catch:{ Exception -> 0x0392 }
            r15 = 5
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ Exception -> 0x0392 }
            r7[r15] = r6     // Catch:{ Exception -> 0x0392 }
            defpackage.o82.a(r9, r7)     // Catch:{ Exception -> 0x0392 }
            android.util.ArrayMap r6 = new android.util.ArrayMap     // Catch:{ Exception -> 0x0392 }
            r6.<init>()     // Catch:{ Exception -> 0x0392 }
            android.util.ArrayMap r7 = new android.util.ArrayMap     // Catch:{ Exception -> 0x0392 }
            r7.<init>()     // Catch:{ Exception -> 0x0392 }
            java.io.File r9 = new java.io.File     // Catch:{ Exception -> 0x037c }
            r9.<init>(r0)     // Catch:{ Exception -> 0x037c }
            java.io.File r0 = new java.io.File     // Catch:{ Exception -> 0x037c }
            java.lang.String r15 = r9.getPath()     // Catch:{ Exception -> 0x037c }
            r27 = r10
            java.lang.String r10 = r9.getName()     // Catch:{ Exception -> 0x037a }
            r20 = r11
            r11 = r25
            java.lang.String r10 = defpackage.ox1.i(r11, r15, r10)     // Catch:{ Exception -> 0x0378 }
            r0.<init>(r10)     // Catch:{ Exception -> 0x0378 }
            r22 = -481413168108365516(0xf951ad4634b49934, double:-2.448053897001557E276)
            java.lang.String r10 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0378 }
            r7.put(r10, r0)     // Catch:{ Exception -> 0x0378 }
            r22 = -481413189583201996(0xf951ad4134b49934, double:-2.448043331110934E276)
            java.lang.String r10 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0378 }
            r22 = -481413215353005772(0xf951ad3b34b49934, double:-2.448030652042187E276)
            java.lang.String r15 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0378 }
            r22 = -481413241122809548(0xf951ad3534b49934, double:-2.4480179729734396E276)
            java.lang.String r11 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r11 = r1.c(r15, r11)     // Catch:{ Exception -> 0x0378 }
            r6.put(r10, r11)     // Catch:{ Exception -> 0x0378 }
            r10 = -481413245417776844(0xf951ad3434b49934, double:-2.448015859795315E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x0378 }
            r22 = -481413262597646028(0xf951ad3034b49934, double:-2.448007407082817E276)
            java.lang.String r11 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0378 }
            r22 = -481413279777515212(0xf951ad2c34b49934, double:-2.4479989543703187E276)
            java.lang.String r15 = defpackage.wx1.a(r22)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r11 = r1.c(r11, r15)     // Catch:{ Exception -> 0x0378 }
            r6.put(r10, r11)     // Catch:{ Exception -> 0x0378 }
            r10 = -481413284072482508(0xf951ad2b34b49934, double:-2.447996841192194E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r11 = r0.getName()     // Catch:{ Exception -> 0x0378 }
            r6.put(r10, r11)     // Catch:{ Exception -> 0x0378 }
            r10 = -481413322727188172(0xf951ad2234b49934, double:-2.4479778225890733E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r11 = java.lang.String.valueOf(r16)     // Catch:{ Exception -> 0x0378 }
            r6.put(r10, r11)     // Catch:{ Exception -> 0x0378 }
            r10 = -481413374266795724(0xf951ad1634b49934, double:-2.447952464451579E276)
            java.lang.String r10 = defpackage.wx1.a(r10)     // Catch:{ Exception -> 0x0378 }
            long r15 = r9.lastModified()     // Catch:{ Exception -> 0x0378 }
            java.lang.String r9 = defpackage.ox1.c(r15)     // Catch:{ Exception -> 0x0378 }
            r6.put(r10, r9)     // Catch:{ Exception -> 0x0378 }
            if (r3 == 0) goto L_0x0296
            r9 = -481413412921501388(0xf951ad0d34b49934, double:-2.447933445848458E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x0378 }
            r6.put(r9, r3)     // Catch:{ Exception -> 0x0378 }
            r9 = -481413451576207052(0xf951ad0434b49934, double:-2.447914427245337E276)
            java.lang.String r3 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x0378 }
            r6.put(r3, r8)     // Catch:{ Exception -> 0x0378 }
        L_0x0296:
            r8 = -481413494525880012(0xf951acfa34b49934, double:-2.4478932954640916E276)
            java.lang.String r3 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x0378 }
            r8 = -481413537475552972(0xf951acf034b49934, double:-2.447872163682846E276)
            java.lang.String r8 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x0378 }
            r9 = -481413580425225932(0xf951ace634b49934, double:-2.4478510319016007E276)
            java.lang.String r9 = defpackage.wx1.a(r9)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r8 = r1.c(r8, r9)     // Catch:{ Exception -> 0x0378 }
            r6.put(r3, r8)     // Catch:{ Exception -> 0x0378 }
            r8 = -481413584720193228(0xf951ace534b49934, double:-2.447848918723476E276)
            java.lang.String r3 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x0378 }
            r8 = 1
            java.lang.Object[] r9 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x0378 }
            int r8 = r14 + 1
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ Exception -> 0x0378 }
            r10 = 0
            r9[r10] = r8     // Catch:{ Exception -> 0x0378 }
            defpackage.o82.d(r3, r9)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r3 = r6.toString()     // Catch:{ Exception -> 0x0378 }
            java.lang.Object[] r8 = new java.lang.Object[r10]     // Catch:{ Exception -> 0x0378 }
            defpackage.o82.d(r3, r8)     // Catch:{ Exception -> 0x0378 }
            r8 = -481413640554768076(0xf951acd834b49934, double:-2.447821447407857E276)
            java.lang.String r3 = defpackage.wx1.a(r8)     // Catch:{ Exception -> 0x0378 }
            java.lang.String r3 = r1.e(r3)     // Catch:{ Exception -> 0x0378 }
            java.lang.Object[] r8 = new java.lang.Object[r10]     // Catch:{ Exception -> 0x0378 }
            defpackage.o82.d(r3, r8)     // Catch:{ Exception -> 0x0378 }
            vt1 r8 = defpackage.vt1.a()     // Catch:{ Exception -> 0x0378 }
            i32 r3 = r8.e(r3, r6, r7)     // Catch:{ Exception -> 0x0378 }
            i42 r3 = r3.E()     // Catch:{ Exception -> 0x0378 }
            j42 r6 = r3.a()     // Catch:{ Exception -> 0x0378 }
            boolean r3 = r3.N()     // Catch:{ all -> 0x036f }
            if (r3 == 0) goto L_0x0365
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch:{ Exception -> 0x0334 }
            java.lang.String r7 = r6.w()     // Catch:{ Exception -> 0x0334 }
            r3.<init>(r7)     // Catch:{ Exception -> 0x0334 }
            java.lang.String r7 = r3.toString()     // Catch:{ Exception -> 0x0334 }
            r8 = 0
            java.lang.Object[] r9 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x0334 }
            defpackage.o82.d(r7, r9)     // Catch:{ Exception -> 0x0334 }
            r7 = -481413760813852364(0xf951acbc34b49934, double:-2.44776227842037E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x0334 }
            java.lang.String r3 = r3.getString(r7)     // Catch:{ Exception -> 0x0334 }
            r7 = -481413790878623436(0xf951acb534b49934, double:-2.447747486173498E276)
            java.lang.String r7 = defpackage.wx1.a(r7)     // Catch:{ Exception -> 0x0334 }
            boolean r3 = r3.equals(r7)     // Catch:{ Exception -> 0x0334 }
            if (r3 == 0) goto L_0x0334
            r6.close()     // Catch:{ Exception -> 0x0378 }
            return
        L_0x0334:
            r7 = -481413820943394508(0xf951acae34b49934, double:-2.4477326939266263E276)
            java.lang.String r3 = defpackage.wx1.a(r7)     // Catch:{ all -> 0x036f }
            long r7 = r5.getLong(r2)     // Catch:{ all -> 0x036f }
            r1.A(r3, r7)     // Catch:{ all -> 0x036f }
            boolean r3 = r0.delete()     // Catch:{ all -> 0x036f }
            if (r3 == 0) goto L_0x0365
            r7 = -481413876777969356(0xf951aca134b49934, double:-2.4477052226110073E276)
            java.lang.String r3 = defpackage.wx1.a(r7)     // Catch:{ all -> 0x036f }
            r7 = 1
            java.lang.Object[] r8 = new java.lang.Object[r7]     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = r0.getPath()     // Catch:{ all -> 0x0363 }
            r9 = 0
            r8[r9] = r0     // Catch:{ all -> 0x0361 }
            defpackage.o82.d(r3, r8)     // Catch:{ all -> 0x0361 }
            goto L_0x0367
        L_0x0361:
            r0 = move-exception
            goto L_0x0372
        L_0x0363:
            r0 = move-exception
            goto L_0x0371
        L_0x0365:
            r7 = 1
            r9 = 0
        L_0x0367:
            if (r6 == 0) goto L_0x038d
            r6.close()     // Catch:{ Exception -> 0x036d }
            goto L_0x038d
        L_0x036d:
            r0 = move-exception
            goto L_0x0383
        L_0x036f:
            r0 = move-exception
            r7 = 1
        L_0x0371:
            r9 = 0
        L_0x0372:
            if (r6 == 0) goto L_0x0377
            r6.close()     // Catch:{ Exception -> 0x036d }
        L_0x0377:
            throw r0     // Catch:{ Exception -> 0x036d }
        L_0x0378:
            r0 = move-exception
            goto L_0x0381
        L_0x037a:
            r0 = move-exception
            goto L_0x037f
        L_0x037c:
            r0 = move-exception
            r27 = r10
        L_0x037f:
            r20 = r11
        L_0x0381:
            r7 = 1
            r9 = 0
        L_0x0383:
            qg1 r3 = defpackage.qg1.a()     // Catch:{ Exception -> 0x0390 }
            r3.c(r0)     // Catch:{ Exception -> 0x0390 }
            r0.printStackTrace()     // Catch:{ Exception -> 0x0390 }
        L_0x038d:
            int r14 = r14 + 1
            goto L_0x03b4
        L_0x0390:
            goto L_0x03b4
        L_0x0392:
            r27 = r10
            r20 = r11
            r7 = 1
            r9 = 0
            goto L_0x03b4
        L_0x0399:
            r27 = r10
            r20 = r11
            r7 = 1
            r9 = 0
            goto L_0x03b2
        L_0x03a0:
            r19 = r7
        L_0x03a2:
            r27 = r10
            r20 = r11
            r7 = 1
            r9 = 0
            goto L_0x03b0
        L_0x03a9:
            r19 = r7
            r27 = r10
            r20 = r11
            r7 = 1
        L_0x03b0:
            r17 = 2
        L_0x03b2:
            r21 = 3
        L_0x03b4:
            if (r14 < r4) goto L_0x03b7
            goto L_0x03c9
        L_0x03b7:
            boolean r0 = r5.moveToNext()     // Catch:{ Exception -> 0x03cf }
            if (r0 != 0) goto L_0x03be
            goto L_0x03c9
        L_0x03be:
            r10 = r27
            r7 = r19
            r11 = r20
            r3 = 2
            r6 = 3
            r8 = 1
            goto L_0x0183
        L_0x03c9:
            if (r5 == 0) goto L_0x03da
            r5.close()     // Catch:{ Exception -> 0x03cf }
            goto L_0x03da
        L_0x03cf:
            r0 = move-exception
            qg1 r1 = defpackage.qg1.a()     // Catch:{ Exception -> 0x03da }
            r1.c(r0)     // Catch:{ Exception -> 0x03da }
            r0.printStackTrace()     // Catch:{ Exception -> 0x03da }
        L_0x03da:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ww1.a(android.content.Context, xt1, boolean):void");
    }
}
