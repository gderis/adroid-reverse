package defpackage;

/* renamed from: fr0  reason: default package */
public final class fr0 implements er0 {
    public static final ui0<Boolean> a = new si0(li0.a("com.google.android.gms.measurement")).b("measurement.collection.log_event_and_bundle_v2", true);

    public final boolean a() {
        return a.e().booleanValue();
    }
}
