package defpackage;

import android.location.Address;
import android.location.Location;
import java.util.List;

/* renamed from: cy1  reason: default package */
public interface cy1 {
    void a(Location location, List<Address> list);
}
