package defpackage;

/* renamed from: p7  reason: default package */
public abstract class p7 {
}
