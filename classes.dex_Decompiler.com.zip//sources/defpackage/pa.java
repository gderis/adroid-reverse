package defpackage;

import android.view.View;

/* renamed from: pa  reason: default package */
public interface pa extends ra {
    void h(View view, int i, int i2, int[] iArr, int i3);

    void i(View view, View view2, int i, int i2);

    void j(View view, int i, int i2, int i3, int i4, int i5);

    boolean n(View view, View view2, int i, int i2);

    void o(View view, int i);
}
