package defpackage;

import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/* renamed from: mz1  reason: default package */
public final class mz1 {
    public static final ty1 a = lz1.g(new h());
    public static final ty1 b = lz1.d(new b());
    public static final ty1 c = lz1.e(new c());
    public static final ty1 d = iz1.a();
    public static final ty1 e = lz1.f(new f());

    /* renamed from: mz1$a */
    public static final class a {
        public static final ty1 a = new az1();
    }

    /* renamed from: mz1$b */
    public static final class b implements Callable<ty1> {
        /* renamed from: a */
        public ty1 call() {
            return a.a;
        }
    }

    /* renamed from: mz1$c */
    public static final class c implements Callable<ty1> {
        /* renamed from: a */
        public ty1 call() {
            return d.a;
        }
    }

    /* renamed from: mz1$d */
    public static final class d {
        public static final ty1 a = new cz1();
    }

    /* renamed from: mz1$e */
    public static final class e {
        public static final ty1 a = new dz1();
    }

    /* renamed from: mz1$f */
    public static final class f implements Callable<ty1> {
        /* renamed from: a */
        public ty1 call() {
            return e.a;
        }
    }

    /* renamed from: mz1$g */
    public static final class g {
        public static final ty1 a = new hz1();
    }

    /* renamed from: mz1$h */
    public static final class h implements Callable<ty1> {
        /* renamed from: a */
        public ty1 call() {
            return g.a;
        }
    }

    public static ty1 a(Executor executor) {
        return new bz1(executor, false);
    }

    public static ty1 b() {
        return lz1.h(a);
    }
}
