package defpackage;

import defpackage.vp;
import java.util.Arrays;

/* renamed from: pp  reason: default package */
public final class pp extends vp {
    public final long a;

    /* renamed from: a  reason: collision with other field name */
    public final Integer f4517a;

    /* renamed from: a  reason: collision with other field name */
    public final String f4518a;

    /* renamed from: a  reason: collision with other field name */
    public final yp f4519a;

    /* renamed from: a  reason: collision with other field name */
    public final byte[] f4520a;
    public final long b;
    public final long c;

    /* renamed from: pp$b */
    public static final class b extends vp.a {
        public Integer a;

        /* renamed from: a  reason: collision with other field name */
        public Long f4521a;

        /* renamed from: a  reason: collision with other field name */
        public String f4522a;

        /* renamed from: a  reason: collision with other field name */
        public yp f4523a;

        /* renamed from: a  reason: collision with other field name */
        public byte[] f4524a;
        public Long b;
        public Long c;

        public vp a() {
            String str = "";
            if (this.f4521a == null) {
                str = str + " eventTimeMs";
            }
            if (this.b == null) {
                str = str + " eventUptimeMs";
            }
            if (this.c == null) {
                str = str + " timezoneOffsetSeconds";
            }
            if (str.isEmpty()) {
                return new pp(this.f4521a.longValue(), this.a, this.b.longValue(), this.f4524a, this.f4522a, this.c.longValue(), this.f4523a);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        public vp.a b(Integer num) {
            this.a = num;
            return this;
        }

        public vp.a c(long j) {
            this.f4521a = Long.valueOf(j);
            return this;
        }

        public vp.a d(long j) {
            this.b = Long.valueOf(j);
            return this;
        }

        public vp.a e(yp ypVar) {
            this.f4523a = ypVar;
            return this;
        }

        public vp.a f(byte[] bArr) {
            this.f4524a = bArr;
            return this;
        }

        public vp.a g(String str) {
            this.f4522a = str;
            return this;
        }

        public vp.a h(long j) {
            this.c = Long.valueOf(j);
            return this;
        }
    }

    public pp(long j, Integer num, long j2, byte[] bArr, String str, long j3, yp ypVar) {
        this.a = j;
        this.f4517a = num;
        this.b = j2;
        this.f4520a = bArr;
        this.f4518a = str;
        this.c = j3;
        this.f4519a = ypVar;
    }

    public Integer b() {
        return this.f4517a;
    }

    public long c() {
        return this.a;
    }

    public long d() {
        return this.b;
    }

    public yp e() {
        return this.f4519a;
    }

    public boolean equals(Object obj) {
        Integer num;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof vp)) {
            return false;
        }
        vp vpVar = (vp) obj;
        if (this.a == vpVar.c() && ((num = this.f4517a) != null ? num.equals(vpVar.b()) : vpVar.b() == null) && this.b == vpVar.d()) {
            if (Arrays.equals(this.f4520a, vpVar instanceof pp ? ((pp) vpVar).f4520a : vpVar.f()) && ((str = this.f4518a) != null ? str.equals(vpVar.g()) : vpVar.g() == null) && this.c == vpVar.h()) {
                yp ypVar = this.f4519a;
                yp e = vpVar.e();
                if (ypVar == null) {
                    if (e == null) {
                        return true;
                    }
                } else if (ypVar.equals(e)) {
                    return true;
                }
            }
        }
        return false;
    }

    public byte[] f() {
        return this.f4520a;
    }

    public String g() {
        return this.f4518a;
    }

    public long h() {
        return this.c;
    }

    public int hashCode() {
        long j = this.a;
        int i = (((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f4517a;
        int i2 = 0;
        int hashCode = num == null ? 0 : num.hashCode();
        long j2 = this.b;
        int hashCode2 = (((((i ^ hashCode) * 1000003) ^ ((int) (j2 ^ (j2 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f4520a)) * 1000003;
        String str = this.f4518a;
        int hashCode3 = str == null ? 0 : str.hashCode();
        long j3 = this.c;
        int i3 = (((hashCode2 ^ hashCode3) * 1000003) ^ ((int) ((j3 >>> 32) ^ j3))) * 1000003;
        yp ypVar = this.f4519a;
        if (ypVar != null) {
            i2 = ypVar.hashCode();
        }
        return i3 ^ i2;
    }

    public String toString() {
        return "LogEvent{eventTimeMs=" + this.a + ", eventCode=" + this.f4517a + ", eventUptimeMs=" + this.b + ", sourceExtension=" + Arrays.toString(this.f4520a) + ", sourceExtensionJsonProto3=" + this.f4518a + ", timezoneOffsetSeconds=" + this.c + ", networkConnectionInfo=" + this.f4519a + "}";
    }
}
