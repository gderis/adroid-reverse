package defpackage;

/* renamed from: qh0  reason: default package */
public final class qh0 implements jl0<sh0> {
}
