package defpackage;

import android.os.Bundle;

/* renamed from: vu0  reason: default package */
public class vu0 {
    public final cf0 a;

    /* renamed from: vu0$a */
    public interface a extends y11 {
    }

    public vu0(cf0 cf0) {
        this.a = cf0;
    }

    public void a(String str, String str2, Bundle bundle) {
        this.a.v(str, str2, bundle);
    }

    public void b(a aVar) {
        this.a.u(aVar);
    }

    public void c(String str, String str2, Object obj) {
        this.a.w(str, str2, obj, true);
    }

    public final void d(boolean z) {
        this.a.e(z);
    }
}
