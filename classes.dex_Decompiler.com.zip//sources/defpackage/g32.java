package defpackage;

import java.io.Closeable;
import java.io.Flushable;

/* renamed from: g32  reason: default package */
public final class g32 implements Closeable, Flushable {
}
