package defpackage;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: ud0  reason: default package */
public final class ud0 extends w10 {
    public static final Parcelable.Creator<ud0> CREATOR = new vd0();
    public final long a;

    /* renamed from: a  reason: collision with other field name */
    public final Bundle f5363a;

    /* renamed from: a  reason: collision with other field name */
    public final String f5364a;
    public final long b;

    /* renamed from: b  reason: collision with other field name */
    public final String f5365b;

    /* renamed from: b  reason: collision with other field name */
    public final boolean f5366b;
    public final String c;
    public final String d;

    public ud0(long j, long j2, boolean z, String str, String str2, String str3, Bundle bundle, String str4) {
        this.a = j;
        this.b = j2;
        this.f5366b = z;
        this.f5364a = str;
        this.f5365b = str2;
        this.c = str3;
        this.f5363a = bundle;
        this.d = str4;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = y10.a(parcel);
        y10.n(parcel, 1, this.a);
        y10.n(parcel, 2, this.b);
        y10.c(parcel, 3, this.f5366b);
        y10.r(parcel, 4, this.f5364a, false);
        y10.r(parcel, 5, this.f5365b, false);
        y10.r(parcel, 6, this.c, false);
        y10.e(parcel, 7, this.f5363a, false);
        y10.r(parcel, 8, this.d, false);
        y10.b(parcel, a2);
    }
}
