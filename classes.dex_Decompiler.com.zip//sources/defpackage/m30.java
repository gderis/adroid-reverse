package defpackage;

/* renamed from: m30  reason: default package */
public interface m30 {
}
