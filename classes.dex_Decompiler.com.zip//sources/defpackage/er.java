package defpackage;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import com.google.android.datatransport.runtime.backends.TransportBackendDiscovery;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: er  reason: default package */
public class er implements yq {
    public final cr a;

    /* renamed from: a  reason: collision with other field name */
    public final a f2322a;

    /* renamed from: a  reason: collision with other field name */
    public final Map<String, gr> f2323a;

    /* renamed from: er$a */
    public static class a {
        public final Context a;

        /* renamed from: a  reason: collision with other field name */
        public Map<String, String> f2324a = null;

        public a(Context context) {
            this.a = context;
        }

        public static Bundle d(Context context) {
            ServiceInfo serviceInfo;
            try {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager == null || (serviceInfo = packageManager.getServiceInfo(new ComponentName(context, TransportBackendDiscovery.class), 128)) == null) {
                    return null;
                }
                return serviceInfo.metaData;
            } catch (PackageManager.NameNotFoundException unused) {
                return null;
            }
        }

        public final Map<String, String> a(Context context) {
            Bundle d = d(context);
            if (d == null) {
                return Collections.emptyMap();
            }
            HashMap hashMap = new HashMap();
            for (String str : d.keySet()) {
                Object obj = d.get(str);
                if ((obj instanceof String) && str.startsWith("backend:")) {
                    for (String trim : ((String) obj).split(",", -1)) {
                        String trim2 = trim.trim();
                        if (!trim2.isEmpty()) {
                            hashMap.put(trim2, str.substring(8));
                        }
                    }
                }
            }
            return hashMap;
        }

        public xq b(String str) {
            String str2 = c().get(str);
            if (str2 == null) {
                return null;
            }
            try {
                return (xq) Class.forName(str2).asSubclass(xq.class).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
            } catch (ClassNotFoundException unused) {
                String.format("Class %s is not found.", new Object[]{str2});
                return null;
            } catch (IllegalAccessException unused2) {
                String.format("Could not instantiate %s.", new Object[]{str2});
                return null;
            } catch (InstantiationException unused3) {
                String.format("Could not instantiate %s.", new Object[]{str2});
                return null;
            } catch (NoSuchMethodException unused4) {
                String.format("Could not instantiate %s", new Object[]{str2});
                return null;
            } catch (InvocationTargetException unused5) {
                String.format("Could not instantiate %s", new Object[]{str2});
                return null;
            }
        }

        public final Map<String, String> c() {
            if (this.f2324a == null) {
                this.f2324a = a(this.a);
            }
            return this.f2324a;
        }
    }

    public er(Context context, cr crVar) {
        this(new a(context), crVar);
    }

    public er(a aVar, cr crVar) {
        this.f2323a = new HashMap();
        this.f2322a = aVar;
        this.a = crVar;
    }

    public synchronized gr a(String str) {
        if (this.f2323a.containsKey(str)) {
            return this.f2323a.get(str);
        }
        xq b = this.f2322a.b(str);
        if (b == null) {
            return null;
        }
        gr create = b.create(this.a.a(str));
        this.f2323a.put(str, create);
        return create;
    }
}
