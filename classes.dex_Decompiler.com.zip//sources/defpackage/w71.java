package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: w71  reason: default package */
public final class w71 implements Parcelable.Creator<u71> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int z = x10.z(parcel);
        wv wvVar = null;
        a30 a30 = null;
        int i = 0;
        while (parcel.dataPosition() < z) {
            int r = x10.r(parcel);
            int k = x10.k(r);
            if (k == 1) {
                i = x10.t(parcel, r);
            } else if (k == 2) {
                wvVar = (wv) x10.d(parcel, r, wv.CREATOR);
            } else if (k != 3) {
                x10.y(parcel, r);
            } else {
                a30 = (a30) x10.d(parcel, r, a30.CREATOR);
            }
        }
        x10.j(parcel, z);
        return new u71(i, wvVar, a30);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new u71[i];
    }
}
