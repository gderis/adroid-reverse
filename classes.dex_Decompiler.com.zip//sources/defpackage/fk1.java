package defpackage;

import android.content.Context;
import java.io.File;

/* renamed from: fk1  reason: default package */
public class fk1 implements ek1 {
    public final Context a;

    public fk1(Context context) {
        this.a = context;
    }

    public String a() {
        return new File(this.a.getFilesDir(), ".com.google.firebase.crashlytics").getPath();
    }

    public File b() {
        return c(new File(this.a.getFilesDir(), ".com.google.firebase.crashlytics"));
    }

    public File c(File file) {
        sg1 sg1;
        String str;
        if (file == null) {
            sg1 = sg1.f();
            str = "Null File";
        } else if (file.exists() || file.mkdirs()) {
            return file;
        } else {
            sg1 = sg1.f();
            str = "Couldn't create file";
        }
        sg1.k(str);
        return null;
    }
}
