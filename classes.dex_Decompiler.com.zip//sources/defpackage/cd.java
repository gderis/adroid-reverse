package defpackage;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import defpackage.ad;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
/* renamed from: cd  reason: default package */
public final class cd implements Parcelable {
    public static final Parcelable.Creator<cd> CREATOR = new a();
    public int a;

    /* renamed from: a  reason: collision with other field name */
    public String f1249a = null;

    /* renamed from: a  reason: collision with other field name */
    public ArrayList<gd> f1250a;

    /* renamed from: a  reason: collision with other field name */
    public oc[] f1251a;
    public ArrayList<String> b;
    public ArrayList<String> c = new ArrayList<>();
    public ArrayList<Bundle> d = new ArrayList<>();
    public ArrayList<ad.m> e;

    /* renamed from: cd$a */
    public class a implements Parcelable.Creator<cd> {
        /* renamed from: a */
        public cd createFromParcel(Parcel parcel) {
            return new cd(parcel);
        }

        /* renamed from: b */
        public cd[] newArray(int i) {
            return new cd[i];
        }
    }

    public cd() {
    }

    public cd(Parcel parcel) {
        this.f1250a = parcel.createTypedArrayList(gd.CREATOR);
        this.b = parcel.createStringArrayList();
        this.f1251a = (oc[]) parcel.createTypedArray(oc.CREATOR);
        this.a = parcel.readInt();
        this.f1249a = parcel.readString();
        this.c = parcel.createStringArrayList();
        this.d = parcel.createTypedArrayList(Bundle.CREATOR);
        this.e = parcel.createTypedArrayList(ad.m.CREATOR);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.f1250a);
        parcel.writeStringList(this.b);
        parcel.writeTypedArray(this.f1251a, i);
        parcel.writeInt(this.a);
        parcel.writeString(this.f1249a);
        parcel.writeStringList(this.c);
        parcel.writeTypedList(this.d);
        parcel.writeTypedList(this.e);
    }
}
