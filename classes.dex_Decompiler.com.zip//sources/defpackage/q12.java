package defpackage;

import java.io.Serializable;

/* renamed from: q12  reason: default package */
public abstract class q12<R> implements o12<R>, Serializable {
    public final int a;

    public q12(int i) {
        this.a = i;
    }

    public String toString() {
        String a2 = t12.a(this);
        p12.c(a2, "Reflection.renderLambdaToString(this)");
        return a2;
    }
}
