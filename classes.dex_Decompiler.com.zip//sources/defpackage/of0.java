package defpackage;

/* renamed from: of0  reason: default package */
public final class of0 extends gl0<of0, kf0> implements mm0 {
    /* access modifiers changed from: private */
    public static final of0 zzj;
    private int zza;
    private int zze;
    private boolean zzf;
    private String zzg = "";
    private String zzh = "";
    private String zzi = "";

    static {
        of0 of0 = new of0();
        zzj = of0;
        gl0.x(of0.class, of0);
    }

    public static of0 K() {
        return zzj;
    }

    public final boolean A() {
        return (this.zza & 1) != 0;
    }

    public final nf0 B() {
        nf0 a = nf0.a(this.zze);
        return a == null ? nf0.UNKNOWN_COMPARISON_TYPE : a;
    }

    public final boolean C() {
        return (this.zza & 2) != 0;
    }

    public final boolean D() {
        return this.zzf;
    }

    public final boolean E() {
        return (this.zza & 4) != 0;
    }

    public final String F() {
        return this.zzg;
    }

    public final boolean G() {
        return (this.zza & 8) != 0;
    }

    public final String H() {
        return this.zzh;
    }

    public final boolean I() {
        return (this.zza & 16) != 0;
    }

    public final String J() {
        return this.zzi;
    }

    public final Object z(int i, Object obj, Object obj2) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return gl0.y(zzj, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001ဌ\u0000\u0002ဇ\u0001\u0003ဈ\u0002\u0004ဈ\u0003\u0005ဈ\u0004", new Object[]{"zza", "zze", nf0.b(), "zzf", "zzg", "zzh", "zzi"});
        } else if (i2 == 3) {
            return new of0();
        } else {
            if (i2 == 4) {
                return new kf0((df0) null);
            }
            if (i2 != 5) {
                return null;
            }
            return zzj;
        }
    }
}
