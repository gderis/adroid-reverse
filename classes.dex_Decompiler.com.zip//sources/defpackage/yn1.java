package defpackage;

import java.util.concurrent.Executor;

/* renamed from: yn1  reason: default package */
public final /* synthetic */ class yn1 implements Executor {
    public static final Executor a = new yn1();

    public void execute(Runnable runnable) {
        runnable.run();
    }
}
