package defpackage;

import android.os.Bundle;
import defpackage.ue1;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/* renamed from: og1  reason: default package */
public class og1 {
    public volatile ch1 a;

    /* renamed from: a  reason: collision with other field name */
    public final List<bh1> f4286a;

    /* renamed from: a  reason: collision with other field name */
    public final jm1<ue1> f4287a;

    /* renamed from: a  reason: collision with other field name */
    public volatile vg1 f4288a;

    public og1(jm1<ue1> jm1) {
        this(jm1, new dh1(), new ah1());
    }

    public og1(jm1<ue1> jm1, ch1 ch1, vg1 vg1) {
        this.f4287a = jm1;
        this.a = ch1;
        this.f4286a = new ArrayList();
        this.f4288a = vg1;
        c();
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public /* synthetic */ void e(String str, Bundle bundle) {
        this.f4288a.b(str, bundle);
    }

    /* access modifiers changed from: private */
    /* renamed from: f */
    public /* synthetic */ void g(bh1 bh1) {
        synchronized (this) {
            if (this.a instanceof dh1) {
                this.f4286a.add(bh1);
            }
            this.a.b(bh1);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: h */
    public /* synthetic */ void i(km1 km1) {
        ue1 ue1 = (ue1) km1.get();
        zg1 zg1 = new zg1(ue1);
        pg1 pg1 = new pg1();
        if (j(ue1, pg1) != null) {
            sg1.f().b("Registered Firebase Analytics listener.");
            yg1 yg1 = new yg1();
            xg1 xg1 = new xg1(zg1, 500, TimeUnit.MILLISECONDS);
            synchronized (this) {
                for (bh1 b : this.f4286a) {
                    yg1.b(b);
                }
                pg1.d(yg1);
                pg1.e(xg1);
                this.a = yg1;
                this.f4288a = xg1;
            }
            return;
        }
        sg1.f().k("Could not register Firebase Analytics listener; a listener is already registered.");
    }

    public static ue1.a j(ue1 ue1, pg1 pg1) {
        ue1.a a2 = ue1.a("clx", pg1);
        if (a2 == null) {
            sg1.f().b("Could not register AnalyticsConnectorListener with Crashlytics origin.");
            a2 = ue1.a("crash", pg1);
            if (a2 != null) {
                sg1.f().k("A new version of the Google Analytics for Firebase SDK is now available. For improved performance and compatibility with Crashlytics, please update to the latest version.");
            }
        }
        return a2;
    }

    public vg1 a() {
        return new lg1(this);
    }

    public ch1 b() {
        return new mg1(this);
    }

    public final void c() {
        this.f4287a.a(new kg1(this));
    }
}
