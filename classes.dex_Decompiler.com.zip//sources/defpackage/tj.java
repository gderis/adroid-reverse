package defpackage;

import android.annotation.SuppressLint;

/* renamed from: tj  reason: default package */
public interface tj {
    @SuppressLint({"SyntheticAccessor"})
    public static final b.C0052b a = new b.C0052b();
    @SuppressLint({"SyntheticAccessor"})

    /* renamed from: a  reason: collision with other field name */
    public static final b.c f5201a = new b.c();

    /* renamed from: tj$b */
    public static abstract class b {

        /* renamed from: tj$b$a */
        public static final class a extends b {
            public final Throwable a;

            public a(Throwable th) {
                this.a = th;
            }

            public Throwable a() {
                return this.a;
            }

            public String toString() {
                return String.format("FAILURE (%s)", new Object[]{this.a.getMessage()});
            }
        }

        /* renamed from: tj$b$b  reason: collision with other inner class name */
        public static final class C0052b extends b {
            public C0052b() {
            }

            public String toString() {
                return "IN_PROGRESS";
            }
        }

        /* renamed from: tj$b$c */
        public static final class c extends b {
            public c() {
            }

            public String toString() {
                return "SUCCESS";
            }
        }
    }

    ke1<b.c> a();
}
