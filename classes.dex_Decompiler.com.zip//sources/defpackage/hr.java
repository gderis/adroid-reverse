package defpackage;

/* renamed from: hr  reason: default package */
public final class hr<T> implements nz1<T> {
    public static final Object a = new Object();

    /* renamed from: a  reason: collision with other field name */
    public volatile nz1<T> f2884a;
    public volatile Object b = a;

    public hr(nz1<T> nz1) {
        this.f2884a = nz1;
    }

    public static <P extends nz1<T>, T> nz1<T> a(P p) {
        kr.b(p);
        return p instanceof hr ? p : new hr(p);
    }

    public static Object b(Object obj, Object obj2) {
        if (!(obj != a) || obj == obj2) {
            return obj2;
        }
        throw new IllegalStateException("Scoped provider was invoked recursively returning different results: " + obj + " & " + obj2 + ". This is likely due to a circular dependency.");
    }

    public T get() {
        T t = this.b;
        T t2 = a;
        if (t == t2) {
            synchronized (this) {
                t = this.b;
                if (t == t2) {
                    t = this.f2884a.get();
                    this.b = b(this.b, t);
                    this.f2884a = null;
                }
            }
        }
        return t;
    }
}
