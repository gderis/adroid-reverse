package defpackage;

/* renamed from: ew0  reason: default package */
public final /* synthetic */ class ew0 implements xy0 {
    public static final xy0 a = new ew0();

    public final Object a() {
        zy0<Long> zy0 = bz0.f1148a;
        return Long.valueOf(to0.r());
    }
}
