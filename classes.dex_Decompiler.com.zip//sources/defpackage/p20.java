package defpackage;

import android.os.Bundle;
import defpackage.e10;

/* renamed from: p20  reason: default package */
public final class p20 implements e10.a {
    public final /* synthetic */ cx a;

    public p20(cx cxVar) {
        this.a = cxVar;
    }

    public final void b(int i) {
        this.a.b(i);
    }

    public final void c(Bundle bundle) {
        this.a.c(bundle);
    }
}
