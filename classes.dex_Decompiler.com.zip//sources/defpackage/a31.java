package defpackage;

import android.os.Bundle;
import java.util.List;
import java.util.Map;

/* renamed from: a31  reason: default package */
public interface a31 {
    long a();

    void b(String str, String str2, Bundle bundle);

    String c();

    void d(String str);

    String e();

    int f(String str);

    List<Bundle> g(String str, String str2);

    String h();

    void i(String str, String str2, Bundle bundle);

    Map<String, Object> j(String str, String str2, boolean z);

    void k(Bundle bundle);

    String l();

    void m(String str);
}
