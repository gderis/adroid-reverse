package defpackage;

import defpackage.b52;
import java.lang.ref.Reference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

/* renamed from: e52  reason: default package */
public final class e52 {
    public static final a a = new a((n12) null);

    /* renamed from: a  reason: collision with other field name */
    public final int f2227a;

    /* renamed from: a  reason: collision with other field name */
    public final long f2228a;

    /* renamed from: a  reason: collision with other field name */
    public final b f2229a = new b(this, n42.f4054a + " ConnectionPool");

    /* renamed from: a  reason: collision with other field name */
    public final ConcurrentLinkedQueue<c52> f2230a = new ConcurrentLinkedQueue<>();

    /* renamed from: a  reason: collision with other field name */
    public final v42 f2231a;

    /* renamed from: e52$a */
    public static final class a {
        public a() {
        }

        public /* synthetic */ a(n12 n12) {
            this();
        }
    }

    /* renamed from: e52$b */
    public static final class b extends s42 {
        public final /* synthetic */ e52 a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(e52 e52, String str) {
            super(str, false, 2, (n12) null);
            this.a = e52;
        }

        public long f() {
            return this.a.b(System.nanoTime());
        }
    }

    public e52(w42 w42, int i, long j, TimeUnit timeUnit) {
        p12.d(w42, "taskRunner");
        p12.d(timeUnit, "timeUnit");
        this.f2227a = i;
        this.f2228a = timeUnit.toNanos(j);
        this.f2231a = w42.i();
        if (!(j > 0)) {
            throw new IllegalArgumentException(("keepAliveDuration <= 0: " + j).toString());
        }
    }

    public final boolean a(e32 e32, b52 b52, List<k42> list, boolean z) {
        p12.d(e32, "address");
        p12.d(b52, "call");
        Iterator<c52> it = this.f2230a.iterator();
        while (it.hasNext()) {
            c52 next = it.next();
            p12.c(next, "connection");
            synchronized (next) {
                if (z) {
                    if (!next.v()) {
                        xz1 xz1 = xz1.a;
                    }
                }
                if (next.t(e32, list)) {
                    b52.c(next);
                    return true;
                }
                xz1 xz12 = xz1.a;
            }
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:44:0x007d, code lost:
        defpackage.n42.k(r3.D());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x008a, code lost:
        if (r10.f2230a.isEmpty() == false) goto L_0x0091;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x008c, code lost:
        r10.f2231a.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0091, code lost:
        return 0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final long b(long r11) {
        /*
            r10 = this;
            java.util.concurrent.ConcurrentLinkedQueue<c52> r0 = r10.f2230a
            java.util.Iterator r0 = r0.iterator()
            r1 = 0
            r2 = 0
            r3 = -9223372036854775808
            r4 = r3
            r3 = r2
            r2 = 0
        L_0x000d:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L_0x0040
            java.lang.Object r6 = r0.next()
            c52 r6 = (defpackage.c52) r6
            java.lang.String r7 = "connection"
            defpackage.p12.c(r6, r7)
            monitor-enter(r6)
            int r7 = r10.d(r6, r11)     // Catch:{ all -> 0x003d }
            if (r7 <= 0) goto L_0x0028
            int r2 = r2 + 1
            goto L_0x003b
        L_0x0028:
            int r1 = r1 + 1
            long r7 = r6.o()     // Catch:{ all -> 0x003d }
            long r7 = r11 - r7
            int r9 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r9 <= 0) goto L_0x0039
            xz1 r3 = defpackage.xz1.a     // Catch:{ all -> 0x003d }
            r3 = r6
            r4 = r7
            goto L_0x003b
        L_0x0039:
            xz1 r7 = defpackage.xz1.a     // Catch:{ all -> 0x003d }
        L_0x003b:
            monitor-exit(r6)
            goto L_0x000d
        L_0x003d:
            r11 = move-exception
            monitor-exit(r6)
            throw r11
        L_0x0040:
            long r6 = r10.f2228a
            int r0 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r0 >= 0) goto L_0x0055
            int r0 = r10.f2227a
            if (r1 <= r0) goto L_0x004b
            goto L_0x0055
        L_0x004b:
            if (r1 <= 0) goto L_0x004f
            long r6 = r6 - r4
            return r6
        L_0x004f:
            if (r2 <= 0) goto L_0x0052
            return r6
        L_0x0052:
            r11 = -1
            return r11
        L_0x0055:
            defpackage.p12.b(r3)
            monitor-enter(r3)
            java.util.List r0 = r3.n()     // Catch:{ all -> 0x0092 }
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x0092 }
            r1 = 1
            r0 = r0 ^ r1
            r6 = 0
            if (r0 == 0) goto L_0x0069
            monitor-exit(r3)
            return r6
        L_0x0069:
            long r8 = r3.o()     // Catch:{ all -> 0x0092 }
            long r8 = r8 + r4
            int r0 = (r8 > r11 ? 1 : (r8 == r11 ? 0 : -1))
            if (r0 == 0) goto L_0x0074
            monitor-exit(r3)
            return r6
        L_0x0074:
            r3.C(r1)     // Catch:{ all -> 0x0092 }
            java.util.concurrent.ConcurrentLinkedQueue<c52> r11 = r10.f2230a     // Catch:{ all -> 0x0092 }
            r11.remove(r3)     // Catch:{ all -> 0x0092 }
            monitor-exit(r3)
            java.net.Socket r11 = r3.D()
            defpackage.n42.k(r11)
            java.util.concurrent.ConcurrentLinkedQueue<c52> r11 = r10.f2230a
            boolean r11 = r11.isEmpty()
            if (r11 == 0) goto L_0x0091
            v42 r11 = r10.f2231a
            r11.a()
        L_0x0091:
            return r6
        L_0x0092:
            r11 = move-exception
            monitor-exit(r3)
            goto L_0x0096
        L_0x0095:
            throw r11
        L_0x0096:
            goto L_0x0095
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.e52.b(long):long");
    }

    public final boolean c(c52 c52) {
        p12.d(c52, "connection");
        if (n42.f4058a && !Thread.holdsLock(c52)) {
            StringBuilder sb = new StringBuilder();
            sb.append("Thread ");
            Thread currentThread = Thread.currentThread();
            p12.c(currentThread, "Thread.currentThread()");
            sb.append(currentThread.getName());
            sb.append(" MUST hold lock on ");
            sb.append(c52);
            throw new AssertionError(sb.toString());
        } else if (c52.p() || this.f2227a == 0) {
            c52.C(true);
            this.f2230a.remove(c52);
            if (!this.f2230a.isEmpty()) {
                return true;
            }
            this.f2231a.a();
            return true;
        } else {
            v42.j(this.f2231a, this.f2229a, 0, 2, (Object) null);
            return false;
        }
    }

    public final int d(c52 c52, long j) {
        if (!n42.f4058a || Thread.holdsLock(c52)) {
            List<Reference<b52>> n = c52.n();
            int i = 0;
            while (i < n.size()) {
                Reference reference = n.get(i);
                if (reference.get() != null) {
                    i++;
                } else {
                    q62.f4585a.g().l("A connection to " + c52.z().a().l() + " was leaked. " + "Did you forget to close a response body?", ((b52.b) reference).a());
                    n.remove(i);
                    c52.C(true);
                    if (n.isEmpty()) {
                        c52.B(j - this.f2228a);
                        return 0;
                    }
                }
            }
            return n.size();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        p12.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST hold lock on ");
        sb.append(c52);
        throw new AssertionError(sb.toString());
    }

    public final void e(c52 c52) {
        p12.d(c52, "connection");
        if (!n42.f4058a || Thread.holdsLock(c52)) {
            this.f2230a.add(c52);
            v42.j(this.f2231a, this.f2229a, 0, 2, (Object) null);
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        p12.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST hold lock on ");
        sb.append(c52);
        throw new AssertionError(sb.toString());
    }
}
