package defpackage;

import java.util.Iterator;
import java.util.List;

/* renamed from: pc0  reason: default package */
public final class pc0 extends dc0 {
    public pc0() {
        this.a.add(tc0.FOR_IN);
        this.a.add(tc0.FOR_IN_CONST);
        this.a.add(tc0.FOR_IN_LET);
        this.a.add(tc0.FOR_LET);
        this.a.add(tc0.FOR_OF);
        this.a.add(tc0.FOR_OF_CONST);
        this.a.add(tc0.FOR_OF_LET);
        this.a.add(tc0.WHILE);
    }

    public static wb0 c(nc0 nc0, wb0 wb0, wb0 wb02) {
        return e(nc0, wb0.d(), wb02);
    }

    public static wb0 d(nc0 nc0, wb0 wb0, wb0 wb02) {
        if (wb0 instanceof Iterable) {
            return e(nc0, ((Iterable) wb0).iterator(), wb02);
        }
        throw new IllegalArgumentException("Non-iterable type in for...of loop.");
    }

    public static wb0 e(nc0 nc0, Iterator<wb0> it, wb0 wb0) {
        if (it != null) {
            while (it.hasNext()) {
                wb0 b = nc0.a(it.next()).b((lb0) wb0);
                if (b instanceof nb0) {
                    nb0 nb0 = (nb0) b;
                    if ("break".equals(nb0.e())) {
                        return wb0.a;
                    }
                    if ("return".equals(nb0.e())) {
                        return nb0;
                    }
                }
            }
        }
        return wb0.a;
    }

    public final wb0 a(String str, zg0 zg0, List<wb0> list) {
        tc0 tc0 = tc0.ADD;
        int ordinal = ai0.e(str).ordinal();
        if (ordinal != 65) {
            switch (ordinal) {
                case 26:
                    ai0.a(tc0.FOR_IN.name(), 3, list);
                    if (list.get(0) instanceof ac0) {
                        String b = list.get(0).b();
                        return c(new oc0(zg0, b), zg0.a(list.get(1)), zg0.a(list.get(2)));
                    }
                    throw new IllegalArgumentException("Variable name in FOR_IN must be a string");
                case 27:
                    ai0.a(tc0.FOR_IN_CONST.name(), 3, list);
                    if (list.get(0) instanceof ac0) {
                        String b2 = list.get(0).b();
                        return c(new lc0(zg0, b2), zg0.a(list.get(1)), zg0.a(list.get(2)));
                    }
                    throw new IllegalArgumentException("Variable name in FOR_IN_CONST must be a string");
                case 28:
                    ai0.a(tc0.FOR_IN_LET.name(), 3, list);
                    if (list.get(0) instanceof ac0) {
                        String b3 = list.get(0).b();
                        return c(new mc0(zg0, b3), zg0.a(list.get(1)), zg0.a(list.get(2)));
                    }
                    throw new IllegalArgumentException("Variable name in FOR_IN_LET must be a string");
                case 29:
                    ai0.a(tc0.FOR_LET.name(), 4, list);
                    wb0 a = zg0.a(list.get(0));
                    if (a instanceof lb0) {
                        lb0 lb0 = (lb0) a;
                        wb0 wb0 = list.get(1);
                        wb0 wb02 = list.get(2);
                        wb0 a2 = zg0.a(list.get(3));
                        zg0 c = zg0.c();
                        for (int i = 0; i < lb0.m(); i++) {
                            String b4 = lb0.p(i).b();
                            c.e(b4, zg0.h(b4));
                        }
                        while (zg0.a(wb0).h().booleanValue()) {
                            wb0 b5 = zg0.b((lb0) a2);
                            if (b5 instanceof nb0) {
                                nb0 nb0 = (nb0) b5;
                                if ("break".equals(nb0.e())) {
                                    return wb0.a;
                                }
                                if ("return".equals(nb0.e())) {
                                    return nb0;
                                }
                            }
                            zg0 c2 = zg0.c();
                            for (int i2 = 0; i2 < lb0.m(); i2++) {
                                String b6 = lb0.p(i2).b();
                                c2.e(b6, c.h(b6));
                            }
                            c2.a(wb02);
                            c = c2;
                        }
                        return wb0.a;
                    }
                    throw new IllegalArgumentException("Initializer variables in FOR_LET must be an ArrayList");
                case 30:
                    ai0.a(tc0.FOR_OF.name(), 3, list);
                    if (list.get(0) instanceof ac0) {
                        String b7 = list.get(0).b();
                        return d(new oc0(zg0, b7), zg0.a(list.get(1)), zg0.a(list.get(2)));
                    }
                    throw new IllegalArgumentException("Variable name in FOR_OF must be a string");
                case 31:
                    ai0.a(tc0.FOR_OF_CONST.name(), 3, list);
                    if (list.get(0) instanceof ac0) {
                        String b8 = list.get(0).b();
                        return d(new lc0(zg0, b8), zg0.a(list.get(1)), zg0.a(list.get(2)));
                    }
                    throw new IllegalArgumentException("Variable name in FOR_OF_CONST must be a string");
                case 32:
                    ai0.a(tc0.FOR_OF_LET.name(), 3, list);
                    if (list.get(0) instanceof ac0) {
                        String b9 = list.get(0).b();
                        return d(new mc0(zg0, b9), zg0.a(list.get(1)), zg0.a(list.get(2)));
                    }
                    throw new IllegalArgumentException("Variable name in FOR_OF_LET must be a string");
                default:
                    return super.b(str);
            }
        } else {
            ai0.a(tc0.WHILE.name(), 4, list);
            wb0 wb03 = list.get(0);
            wb0 wb04 = list.get(1);
            wb0 a3 = zg0.a(list.get(3));
            if (zg0.a(list.get(2)).h().booleanValue()) {
                wb0 b10 = zg0.b((lb0) a3);
                if (b10 instanceof nb0) {
                    nb0 nb02 = (nb0) b10;
                    if (!"break".equals(nb02.e())) {
                        if ("return".equals(nb02.e())) {
                            return nb02;
                        }
                    }
                    return wb0.a;
                }
            }
            while (zg0.a(wb03).h().booleanValue()) {
                wb0 b11 = zg0.b((lb0) a3);
                if (b11 instanceof nb0) {
                    nb0 nb03 = (nb0) b11;
                    if ("break".equals(nb03.e())) {
                        break;
                    } else if ("return".equals(nb03.e())) {
                        return nb03;
                    }
                }
                zg0.a(wb04);
            }
            return wb0.a;
        }
    }
}
